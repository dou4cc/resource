Grailbird.data.tweets_2017_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/WgQgsepn3i",
      "expanded_url" : "https:\/\/archive.is\/akk36",
      "display_url" : "archive.is\/akk36"
    } ]
  },
  "geo" : { },
  "id_str" : "914105137685237760",
  "text" : "\u7F8E\u56FD\u5F00\u59CB\u62C5\u5FC3\u4E2D\u5171\u7684\u300A\u7F51\u7EDC\u5B89\u5168\u6CD5\u300B\uFF1Ahttps:\/\/t.co\/WgQgsepn3i",
  "id" : 914105137685237760,
  "created_at" : "2017-09-30 12:30:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/dGllbwGsZQ",
      "expanded_url" : "https:\/\/github.com\/dou4cc\/goproxy\/issues\/3",
      "display_url" : "github.com\/dou4cc\/goproxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "914103541798666241",
  "text" : "GoProxy\u7684\u672A\u6765\uFF1Ahttps:\/\/t.co\/dGllbwGsZQ",
  "id" : 914103541798666241,
  "created_at" : "2017-09-30 12:24:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/XqrGxvq7mK",
      "expanded_url" : "https:\/\/github.com\/dou4cc\/goproxy\/",
      "display_url" : "github.com\/dou4cc\/goproxy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "914050160455557121",
  "text" : "GoProxy\u5907\u4EFD\uFF08\u542Breleases\uFF09\uFF1Ahttps:\/\/t.co\/XqrGxvq7mK",
  "id" : 914050160455557121,
  "created_at" : "2017-09-30 08:51:55 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "898557764410130432",
  "geo" : { },
  "id_str" : "914049670493671425",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u5F7B\u5E95\u89E3\u51B3\u4E86\u7EF4\u57FA\u5A92\u4F53\u65D7\u4E0B\u7F51\u7AD9\u4EE5\u516C\u5171\u4EE3\u7406\u4E3A\u7531\u7981\u6B62\u7F16\u8F91\u6761\u76EE\u7684bug\u3002",
  "id" : 914049670493671425,
  "in_reply_to_status_id" : 898557764410130432,
  "created_at" : "2017-09-30 08:49:58 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/2u9x1a83nz",
      "expanded_url" : "https:\/\/github.com\/phuslu\/goproxy-ci\/",
      "display_url" : "github.com\/phuslu\/goproxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "914005539100688384",
  "text" : "Phus Lu\u6216\u5DF2\u88AB\u6355\uFF1Ahttps:\/\/t.co\/2u9x1a83nz",
  "id" : 914005539100688384,
  "created_at" : "2017-09-30 05:54:36 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/rNXcRD6qf5",
      "expanded_url" : "http:\/\/cn.wsj.com\/gb\/20170929\/fin142936.asp",
      "display_url" : "cn.wsj.com\/gb\/20170929\/fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913771195409076225",
  "text" : "\u97E9\u56FD\u6253\u51FBICO\uFF1Ahttps:\/\/t.co\/rNXcRD6qf5",
  "id" : 913771195409076225,
  "created_at" : "2017-09-29 14:23:24 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/913405207081553920\/photo\/1",
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/Xt8eKAK7ui",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DK0RL7sUMAETc5E.jpg",
      "id_str" : "913405196125876225",
      "id" : 913405196125876225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DK0RL7sUMAETc5E.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 962
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 962
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 962
      } ],
      "display_url" : "pic.twitter.com\/Xt8eKAK7ui"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "913405207081553920",
  "text" : "\u8054\u901A\u95F4\u6B47\u6027\u5C01\u9501DO\uFF1A https:\/\/t.co\/Xt8eKAK7ui",
  "id" : 913405207081553920,
  "created_at" : "2017-09-28 14:09:06 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/sPisj46U17",
      "expanded_url" : "https:\/\/archive.is\/jeGTb",
      "display_url" : "archive.is\/jeGTb"
    } ]
  },
  "geo" : { },
  "id_str" : "913403587371429889",
  "text" : "iOS11\u7684Safari\u5C06\u5185\u7F6E\u817E\u8BAF\u53CD\u6B3A\u8BC8\u670D\u52A1\uFF1Ahttps:\/\/t.co\/sPisj46U17",
  "id" : 913403587371429889,
  "created_at" : "2017-09-28 14:02:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/tM2fUTYlhf",
      "expanded_url" : "https:\/\/medium.com\/@ASPI_ICPC\/chinas-emerging-surveillance-state-4120af7c9b78",
      "display_url" : "medium.com\/@ASPI_ICPC\/chi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913034922058805251",
  "text" : "\u4E2D\u56FD\u6210\u4E3A\u76D1\u63A7\u5927\u56FD\uFF1Ahttps:\/\/t.co\/tM2fUTYlhf",
  "id" : 913034922058805251,
  "created_at" : "2017-09-27 13:37:43 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "898557764410130432",
  "geo" : { },
  "id_str" : "913008917814312960",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u521A\u521A\u9002\u914D\u4E86gfw\u7684\u8BC1\u4E66\u5C01\u9501\u3002",
  "id" : 913008917814312960,
  "in_reply_to_status_id" : 898557764410130432,
  "created_at" : "2017-09-27 11:54:23 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/mFHvhzfnlC",
      "expanded_url" : "https:\/\/archive.is\/LH7I4",
      "display_url" : "archive.is\/LH7I4"
    } ]
  },
  "geo" : { },
  "id_str" : "912997374536163328",
  "text" : "\u8309\u8389\u82B1\u9ED8\u9ED8\u5730\u505C\u66F4\u4E86\uFF08\u4E24\u5929\uFF09\uFF1Ahttps:\/\/t.co\/mFHvhzfnlC",
  "id" : 912997374536163328,
  "created_at" : "2017-09-27 11:08:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/c1D5wZeOxh",
      "expanded_url" : "https:\/\/blog.avast.com\/additional-information-regarding-the-recent-ccleaner-apt-security-incident",
      "display_url" : "blog.avast.com\/additional-inf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "912628831495888896",
  "text" : "CCleanup\u6295\u6BD2\u8005\u9ED1\u5165\u6570\u5341\u5BB6\u79D1\u6280\u5DE8\u5934\uFF1Ahttps:\/\/t.co\/c1D5wZeOxh",
  "id" : 912628831495888896,
  "created_at" : "2017-09-26 10:44:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/KiZdDBqld4",
      "expanded_url" : "https:\/\/archive.is\/WRKL3",
      "display_url" : "archive.is\/WRKL3"
    } ]
  },
  "geo" : { },
  "id_str" : "912627799541809152",
  "text" : "\u8309\u8389\u82B1\u9ED8\u9ED8\u5730\u505C\u66F4\u4E86\uFF08\u4E00\u5929\uFF09\uFF1Ahttps:\/\/t.co\/KiZdDBqld4",
  "id" : 912627799541809152,
  "created_at" : "2017-09-26 10:39:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912285565025996800",
  "geo" : { },
  "id_str" : "912286816992194560",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@solidotunoff \u8BF7\u6C42\u5907\u4EFDsolidot\u5168\u6587\u800C\u975E\u6458\u8981\u3002",
  "id" : 912286816992194560,
  "in_reply_to_status_id" : 912285565025996800,
  "created_at" : "2017-09-25 12:05:01 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/yyxaZpF7ko",
      "expanded_url" : "https:\/\/archive.is\/aXJoY",
      "display_url" : "archive.is\/aXJoY"
    }, {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/kLIbMSEY97",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/907627714219212800",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "912285565025996800",
  "text" : "solidot\u4E0D\u4EC5\u5F00\u59CB\u5220\u56DE\u590D\uFF0C\u8FD8\u5F00\u59CB\u5220\u5E16\u3002\n\u5F15\u7528\u7684\u63A8\u6587\u4E2D\u65B0\u95FB\u7684\u5907\u4EFD\uFF1Ahttps:\/\/t.co\/yyxaZpF7ko https:\/\/t.co\/kLIbMSEY97",
  "id" : 912285565025996800,
  "created_at" : "2017-09-25 12:00:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "912261483156983809",
  "text" : "solidot\u4F7F\u7528\u65B0\u6280\u672F\u5728\u4E0D\u59A8\u788D\u641C\u7D22\u5F15\u64CE\u6293\u53D6\u9875\u9762\u5185\u5BB9\u7684\u60C5\u51B5\u4E0B\u963B\u6B62\u4E86\u5404\u79CD\u65F6\u5149\u673A\u5668\u7684\u7F13\u5B58\u3002",
  "id" : 912261483156983809,
  "created_at" : "2017-09-25 10:24:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/GtBO4nvjAn",
      "expanded_url" : "https:\/\/archive.is\/Wgr0r",
      "display_url" : "archive.is\/Wgr0r"
    } ]
  },
  "geo" : { },
  "id_str" : "912260809966981120",
  "text" : "CPU\u7535\u6E90\u7BA1\u7406\u9020\u6210\u4E86\u96BE\u4EE5\u4FEE\u590D\u7684\u8D8A\u6743\u6F0F\u6D1E\uFF1Ahttps:\/\/t.co\/GtBO4nvjAn",
  "id" : 912260809966981120,
  "created_at" : "2017-09-25 10:21:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "911525363414700032",
  "text" : "\u73B0\u5728\u8FDE\u770B\u7535\u8111\u90FD\u8981\u6234\u773C\u955C\u4E86\/(\u3112o\u3112)\/~~",
  "id" : 911525363414700032,
  "created_at" : "2017-09-23 09:39:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Evans",
      "screen_name" : "DonEvansWm",
      "indices" : [ 0, 11 ],
      "id_str" : "435954378",
      "id" : 435954378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911506852814262273",
  "geo" : { },
  "id_str" : "911507003037626369",
  "in_reply_to_user_id" : 435954378,
  "text" : "@DonEvansWm \u4F60\u662F\u6CE1\u6CE1\u7684\u6210\u5458\u5417\uFF1F",
  "id" : 911507003037626369,
  "in_reply_to_status_id" : 911506852814262273,
  "created_at" : "2017-09-23 08:26:19 +0000",
  "in_reply_to_screen_name" : "DonEvansWm",
  "in_reply_to_user_id_str" : "435954378",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Evans",
      "screen_name" : "DonEvansWm",
      "indices" : [ 0, 11 ],
      "id_str" : "435954378",
      "id" : 435954378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/1jB4Eqf0fU",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/911065932725981185",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "911472250427031552",
  "geo" : { },
  "id_str" : "911491236577587205",
  "in_reply_to_user_id" : 435954378,
  "text" : "@DonEvansWm \u4F60\u600E\u4E48\u770B\u5F85GreatFire\u7684\u5904\u5883\uFF1Fhttps:\/\/t.co\/1jB4Eqf0fU",
  "id" : 911491236577587205,
  "in_reply_to_status_id" : 911472250427031552,
  "created_at" : "2017-09-23 07:23:40 +0000",
  "in_reply_to_screen_name" : "DonEvansWm",
  "in_reply_to_user_id_str" : "435954378",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/lebo165K99",
      "expanded_url" : "https:\/\/archive.is\/3nYXU",
      "display_url" : "archive.is\/3nYXU"
    } ]
  },
  "geo" : { },
  "id_str" : "911202150390337536",
  "text" : "\u7248\u6743\u7684\u771F\u76F8\uFF1Ahttps:\/\/t.co\/lebo165K99",
  "id" : 911202150390337536,
  "created_at" : "2017-09-22 12:14:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/oENbGf8VGV",
      "expanded_url" : "https:\/\/archive.is\/hBUJG",
      "display_url" : "archive.is\/hBUJG"
    } ]
  },
  "geo" : { },
  "id_str" : "911185384914264064",
  "text" : "\u4E00\u8D77\u63F4\u4EA4\u5427\uD83D\uDE02\uFF1Ahttps:\/\/t.co\/oENbGf8VGV",
  "id" : 911185384914264064,
  "created_at" : "2017-09-22 11:08:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/911114049345159168\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/43FDLj90KH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DKTtZRDW0AAOugI.jpg",
      "id_str" : "911114042965676032",
      "id" : 911114042965676032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DKTtZRDW0AAOugI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 571
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 571
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 571
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 571
      } ],
      "display_url" : "pic.twitter.com\/43FDLj90KH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "898557764410130432",
  "geo" : { },
  "id_str" : "911114049345159168",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/43FDLj90KH",
  "id" : 911114049345159168,
  "in_reply_to_status_id" : 898557764410130432,
  "created_at" : "2017-09-22 06:24:51 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/00t4GRGMsa",
      "expanded_url" : "https:\/\/cc.greatfire.org\/zh\/test",
      "display_url" : "cc.greatfire.org\/zh\/test"
    }, {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/1jB4Eqf0fU",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/911065932725981185",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "911069129725087744",
  "text" : "\u522B\u518D\u4F7F\u7528GreatFire\u7FFB\u5899\u4E2D\u5FC3\u51FA\u5356\u4F60\u7684\u68AF\u5B50\u548C\u90AE\u7BB1\uFF1Ahttps:\/\/t.co\/00t4GRGMsa https:\/\/t.co\/1jB4Eqf0fU",
  "id" : 911069129725087744,
  "created_at" : "2017-09-22 03:26:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/rJnaWRTcdb",
      "expanded_url" : "https:\/\/archive.is\/FVUBi",
      "display_url" : "archive.is\/FVUBi"
    } ]
  },
  "geo" : { },
  "id_str" : "911065932725981185",
  "text" : "GreatFire\u7684\u6F2B\u957F\u4EA4\u63A5\uFF1Ahttps:\/\/t.co\/rJnaWRTcdb",
  "id" : 911065932725981185,
  "created_at" : "2017-09-22 03:13:39 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 0, 9 ],
      "id_str" : "45630895",
      "id" : 45630895
    }, {
      "name" : "fox&wolf",
      "screen_name" : "FoxXIIWolf",
      "indices" : [ 10, 21 ],
      "id_str" : "4735140074",
      "id" : 4735140074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "909792567906099200",
  "geo" : { },
  "id_str" : "910804394832261120",
  "in_reply_to_user_id" : 45630895,
  "text" : "@chengr28 @FoxXIIWolf Cloudflare\u90A3\u4E48\u5F3A\uFF1F\uFF01",
  "id" : 910804394832261120,
  "in_reply_to_status_id" : 909792567906099200,
  "created_at" : "2017-09-21 09:54:24 +0000",
  "in_reply_to_screen_name" : "chengr28",
  "in_reply_to_user_id_str" : "45630895",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/tvrlLG9EQs",
      "expanded_url" : "https:\/\/archive.is\/161Lv",
      "display_url" : "archive.is\/161Lv"
    } ]
  },
  "geo" : { },
  "id_str" : "910802520653680640",
  "text" : "\u81EA\u7531\u6D4F\u89C8\u4E0D\u5B89\u5168\uFF1Ahttps:\/\/t.co\/tvrlLG9EQs",
  "id" : 910802520653680640,
  "created_at" : "2017-09-21 09:46:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/bjgHTn9OXK",
      "expanded_url" : "https:\/\/chrome.google.com\/webstore\/detail\/no-coin\/gojamcfopckidlocpkbelmpjcgmbgjcl",
      "display_url" : "chrome.google.com\/webstore\/detai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "910802072697757697",
  "text" : "\u62E6\u622A\u7F51\u9875\u4E0A\u7684\u6316\u77FF\u811A\u672C\uFF1Ahttps:\/\/t.co\/bjgHTn9OXK",
  "id" : 910802072697757697,
  "created_at" : "2017-09-21 09:45:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/yU3Rj5vlKS",
      "expanded_url" : "https:\/\/qz.com\/1080962\/china-is-retaliating-against-the-university-of-california-san-diego-for-inviting-the-dalai-lama-to-speak-at-commencement\/",
      "display_url" : "qz.com\/1080962\/china-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "910798331470901248",
  "text" : "\u4E2D\u5171\u542F\u7528\u5927\u89C4\u6A21\u82F1\u6587\u6C34\u519B\uFF1Ahttps:\/\/t.co\/yU3Rj5vlKS",
  "id" : 910798331470901248,
  "created_at" : "2017-09-21 09:30:18 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "910795540002217985",
  "text" : "RT @williamlong: \u963F\u91CC\u5DF4\u5DF4\u521B\u59CB\u4EBA\u9A6C\u4E91\u53D1\u5FAE\u535A\u900F\u9732\u4ECA\u5929\u5728\u7EBD\u7EA6\u7684\u884C\u7A0B\u3002\u4ED6\u8FD8\u7F55\u89C1\u5730\u900F\u9732\u8BF4\u81EA\u5DF1\u524D\u5929\u4E13\u95E8\u53BB\u89C2\u770B\u4E86\u6208\u6D1B\u592B\u91D1\u4E0E\u963F\u74E6\u96F7\u7684\u804C\u4E1A\u62F3\u51FB\u201C\u4E16\u7EAA\u5927\u6218\u201D\u3002\u9A6C\u4E91\u8FD8\u5E7D\u9ED8\u5730\u8BF4\uFF0C\u5E0C\u671B\u4E0E80\u540E\uFF08\u6307\u7684\u662F80\u5C81\u4EE5\u4E0A\u7684\u4EBA \uFF09\u4E0A\u64C2\u53F0\u6311\u6218\u62F3\u51FB\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "910676219074662400",
    "text" : "\u963F\u91CC\u5DF4\u5DF4\u521B\u59CB\u4EBA\u9A6C\u4E91\u53D1\u5FAE\u535A\u900F\u9732\u4ECA\u5929\u5728\u7EBD\u7EA6\u7684\u884C\u7A0B\u3002\u4ED6\u8FD8\u7F55\u89C1\u5730\u900F\u9732\u8BF4\u81EA\u5DF1\u524D\u5929\u4E13\u95E8\u53BB\u89C2\u770B\u4E86\u6208\u6D1B\u592B\u91D1\u4E0E\u963F\u74E6\u96F7\u7684\u804C\u4E1A\u62F3\u51FB\u201C\u4E16\u7EAA\u5927\u6218\u201D\u3002\u9A6C\u4E91\u8FD8\u5E7D\u9ED8\u5730\u8BF4\uFF0C\u5E0C\u671B\u4E0E80\u540E\uFF08\u6307\u7684\u662F80\u5C81\u4EE5\u4E0A\u7684\u4EBA \uFF09\u4E0A\u64C2\u53F0\u6311\u6218\u62F3\u51FB\u3002",
    "id" : 910676219074662400,
    "created_at" : "2017-09-21 01:25:04 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 910795540002217985,
  "created_at" : "2017-09-21 09:19:13 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/fcQ1BaJjAt",
      "expanded_url" : "https:\/\/archive.is\/U6z2o",
      "display_url" : "archive.is\/U6z2o"
    } ]
  },
  "geo" : { },
  "id_str" : "910793748006744064",
  "text" : "\u4E0D\u518D\u5F00\u653E\u7684W3C\uFF1Ahttps:\/\/t.co\/fcQ1BaJjAt",
  "id" : 910793748006744064,
  "created_at" : "2017-09-21 09:12:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/JBlnosan0g",
      "expanded_url" : "https:\/\/archive.is\/UieXe",
      "display_url" : "archive.is\/UieXe"
    } ]
  },
  "geo" : { },
  "id_str" : "910791397896261632",
  "text" : "\u63A8\u7279\u9971\u53D7\u5168\u7403\u653F\u5E9C\u538B\u529B\uFF1Ahttps:\/\/t.co\/JBlnosan0g",
  "id" : 910791397896261632,
  "created_at" : "2017-09-21 09:02:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/U5AklNGAxQ",
      "expanded_url" : "https:\/\/archive.is\/ho2td",
      "display_url" : "archive.is\/ho2td"
    } ]
  },
  "geo" : { },
  "id_str" : "910790417012097024",
  "text" : "Intel Management Engine\u88AB\u8BC1\u5B9E\u4E3A\u540E\u95E8\uFF1Ahttps:\/\/t.co\/U5AklNGAxQ",
  "id" : 910790417012097024,
  "created_at" : "2017-09-21 08:58:51 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/rhDgjTpMdX",
      "expanded_url" : "https:\/\/archive.is\/IZc6k",
      "display_url" : "archive.is\/IZc6k"
    } ]
  },
  "geo" : { },
  "id_str" : "910789023328849920",
  "text" : "CCleaner\u6295\u6BD2\u8005\u4F3C\u4E4E\u6765\u81EA\u4E2D\u56FD\uFF1Ahttps:\/\/t.co\/rhDgjTpMdX",
  "id" : 910789023328849920,
  "created_at" : "2017-09-21 08:53:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/bjEQSX8g9A",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53921",
      "display_url" : "solidot.org\/story?sid=53921"
    } ]
  },
  "geo" : { },
  "id_str" : "910786682500321282",
  "text" : "\u6CA6\u9677\u533ABTC\u4FE1\u5F92\u8F6C\u5165\u5730\u4E0B\uFF1Ahttps:\/\/t.co\/bjEQSX8g9A",
  "id" : 910786682500321282,
  "created_at" : "2017-09-21 08:44:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910466597411680256",
  "geo" : { },
  "id_str" : "910509641024581633",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u5357\u4EAC\u79FB\u52A8\u672A\u590D\u73B0\uFF0C\u8BF7\u6C42\u66F4\u591A\u4FE1\u606F\u3002",
  "id" : 910509641024581633,
  "in_reply_to_status_id" : 910466597411680256,
  "created_at" : "2017-09-20 14:23:09 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/XfV5QuC32d",
      "expanded_url" : "http:\/\/thehill.com\/policy\/technology\/351240-facebook-censoring-reports-of-ethnic-cleansing-in-burma-report?mobile_switch=standard",
      "display_url" : "thehill.com\/policy\/technol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "910154000414253056",
  "text" : "Facebook\u4E3A\u7F05\u7538\u79CD\u65CF\u5C60\u6740\u6D17\u5730\uFF1Ahttps:\/\/t.co\/XfV5QuC32d",
  "id" : 910154000414253056,
  "created_at" : "2017-09-19 14:49:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/910153285268623362\/photo\/1",
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/ocbKnUoBhO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DKGDizxWAAEWzHF.jpg",
      "id_str" : "910153233741512705",
      "id" : 910153233741512705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DKGDizxWAAEWzHF.jpg",
      "sizes" : [ {
        "h" : 55,
        "resize" : "crop",
        "w" : 55
      }, {
        "h" : 55,
        "resize" : "fit",
        "w" : 527
      }, {
        "h" : 55,
        "resize" : "fit",
        "w" : 527
      }, {
        "h" : 55,
        "resize" : "fit",
        "w" : 527
      }, {
        "h" : 55,
        "resize" : "fit",
        "w" : 527
      } ],
      "display_url" : "pic.twitter.com\/ocbKnUoBhO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "910153285268623362",
  "text" : "\u5378\u8F7D\u8FC5\u96F7\u5427\uFF01 https:\/\/t.co\/ocbKnUoBhO",
  "id" : 910153285268623362,
  "created_at" : "2017-09-19 14:47:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/bxyEERS7Kl",
      "expanded_url" : "https:\/\/archive.is\/U6rlh#selection-1291.78-1291.105",
      "display_url" : "archive.is\/U6rlh#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "910028205465141248",
  "text" : "paperbag\u79F0Percy\u662FGreatFire\u521B\u59CB\u4EBA\uFF1Ahttps:\/\/t.co\/bxyEERS7Kl",
  "id" : 910028205465141248,
  "created_at" : "2017-09-19 06:30:06 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bhuztez",
      "screen_name" : "bhuztez",
      "indices" : [ 0, 8 ],
      "id_str" : "97817250",
      "id" : 97817250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/NKxUimaN38",
      "expanded_url" : "https:\/\/www.zhihu.com\/question\/59974361\/answer\/231039482",
      "display_url" : "zhihu.com\/question\/59974\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "909779349531963393",
  "in_reply_to_user_id" : 97817250,
  "text" : "@bhuztez\u56DE\u5F52\u77E5\u4E4E\uFF1Ahttps:\/\/t.co\/NKxUimaN38",
  "id" : 909779349531963393,
  "created_at" : "2017-09-18 14:01:14 +0000",
  "in_reply_to_screen_name" : "bhuztez",
  "in_reply_to_user_id_str" : "97817250",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/AFKiMxIvre",
      "expanded_url" : "https:\/\/github.com\/XX-net\/XX-Net-dev\/issues\/33",
      "display_url" : "github.com\/XX-net\/XX-Net-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "909744553741123584",
  "text" : "GAEProxy\u62EF\u6551\u884C\u52A8\uFF1Ahttps:\/\/t.co\/AFKiMxIvre",
  "id" : 909744553741123584,
  "created_at" : "2017-09-18 11:42:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u795E\u697D\u5742 \u899A\u3005",
      "screen_name" : "satori_moe",
      "indices" : [ 0, 11 ],
      "id_str" : "800925059485298688",
      "id" : 800925059485298688
    }, {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 12, 27 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/S0nb3uW8Ap",
      "expanded_url" : "https:\/\/fast.com",
      "display_url" : "fast.com"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2ITaPkQI1A",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/898557764410130432",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "909720067851526144",
  "geo" : { },
  "id_str" : "909728225273802752",
  "in_reply_to_user_id" : 800925059485298688,
  "text" : "@satori_moe @GreatFireChina \u6D4F\u89C8\u80FD\u5230\u8FD9\u4E2A\u901F\u5EA6\u771F\u4E0D\u9519\uFF0C\u6211\u624D\u5927\u6982350Kbps\uFF0C\u4E0D\u8FC7\u4E0B\u8F7D\u901F\u5EA6\u5F97\u7528\u50CFhttps:\/\/t.co\/S0nb3uW8Ap\u8FD9\u6837\u7684\u5DE5\u5177\u6D4B\uFF0C\u6211\u80FD\u523025Mbps\u4EE5\u4E0A\u3002\u80FD\u7ED9\u4E2ACatNet\u7684\u94FE\u63A5\u5417\uFF1Fhttps:\/\/t.co\/2ITaPkQI1A",
  "id" : 909728225273802752,
  "in_reply_to_status_id" : 909720067851526144,
  "created_at" : "2017-09-18 10:38:05 +0000",
  "in_reply_to_screen_name" : "satori_moe",
  "in_reply_to_user_id_str" : "800925059485298688",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Y1NZNJL8wV",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53877",
      "display_url" : "solidot.org\/story?sid=53877"
    } ]
  },
  "geo" : { },
  "id_str" : "909725254305579008",
  "text" : "CCleanup\u88AB\u6295\u6BD2\uFF1Ahttps:\/\/t.co\/Y1NZNJL8wV",
  "id" : 909725254305579008,
  "created_at" : "2017-09-18 10:26:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krome",
      "screen_name" : "CaKrome",
      "indices" : [ 0, 8 ],
      "id_str" : "3344890713",
      "id" : 3344890713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "909611057991348224",
  "geo" : { },
  "id_str" : "909689636276105217",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@CaKrome Thanks!",
  "id" : 909689636276105217,
  "in_reply_to_status_id" : 909611057991348224,
  "created_at" : "2017-09-18 08:04:45 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "909651040588275713",
  "geo" : { },
  "id_str" : "909651212663971840",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u989D\u3002\u3002\u8FD0\u884C\u5728\u6C99\u76D2\u91CC\u5E76\u4E0D\u4E00\u5B9A\u5B89\u5168\uFF0C\u5FAE\u4FE1\u8981\u7684\u6743\u9650\u8FD8\u86EE\u591A\u7684\u3002",
  "id" : 909651212663971840,
  "in_reply_to_status_id" : 909651040588275713,
  "created_at" : "2017-09-18 05:32:04 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "909649791872770049",
  "geo" : { },
  "id_str" : "909650873378328576",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u8F6C\u5236\u5B8C\u8FD8\u662F\u8FD0\u884C\u5728\u6C99\u76D2\u91CC\uFF0C\u5177\u4F53\u89C1\u77E5\u4E4E\u3002",
  "id" : 909650873378328576,
  "in_reply_to_status_id" : 909649791872770049,
  "created_at" : "2017-09-18 05:30:43 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krome",
      "screen_name" : "CaKrome",
      "indices" : [ 0, 8 ],
      "id_str" : "3344890713",
      "id" : 3344890713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "909630959120637953",
  "geo" : { },
  "id_str" : "909631420808728576",
  "in_reply_to_user_id" : 3344890713,
  "text" : "@CaKrome \u8C8C\u4F3C\uFF1F\u8BF7\u63D0\u4F9B\u66F4\u591A\u4FE1\u606F\u3002",
  "id" : 909631420808728576,
  "in_reply_to_status_id" : 909630959120637953,
  "created_at" : "2017-09-18 04:13:25 +0000",
  "in_reply_to_screen_name" : "CaKrome",
  "in_reply_to_user_id_str" : "3344890713",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krome",
      "screen_name" : "CaKrome",
      "indices" : [ 0, 8 ],
      "id_str" : "3344890713",
      "id" : 3344890713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "909624818672136192",
  "geo" : { },
  "id_str" : "909625421184020480",
  "in_reply_to_user_id" : 3344890713,
  "text" : "@CaKrome \u6211\u9694\u4E2A\u534A\u4E2A\u6708\u624D\u770B\u770Blantern\u90A3\u8FB9\u7684\u60C5\u51B5\uFF0C\u4ECA\u5929\u4E00\u53BB\u53D1\u73B0p3rcya\u53D8ghost\u4E86\uFF0C\u4F60\u80FD\u63D0\u4F9B\u66F4\u591A\u4FE1\u606F\u5417\uFF1F",
  "id" : 909625421184020480,
  "in_reply_to_status_id" : 909624818672136192,
  "created_at" : "2017-09-18 03:49:35 +0000",
  "in_reply_to_screen_name" : "CaKrome",
  "in_reply_to_user_id_str" : "3344890713",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "glyceraldehyde",
      "screen_name" : "Sueharu_Nakano",
      "indices" : [ 0, 15 ],
      "id_str" : "4713166412",
      "id" : 4713166412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/LVxiSfEZ3O",
      "expanded_url" : "https:\/\/twitter.com\/Sueharu_Nakano\/status\/908173905470275585",
      "display_url" : "twitter.com\/Sueharu_Nakano\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "909614600680742912",
  "geo" : { },
  "id_str" : "909614995612323840",
  "in_reply_to_user_id" : 4713166412,
  "text" : "@Sueharu_Nakano \u4F60\u5378\u8F7D\u7684\u662F\u63A8\u7279\u5417\uFF1Fhttps:\/\/t.co\/LVxiSfEZ3O",
  "id" : 909614995612323840,
  "in_reply_to_status_id" : 909614600680742912,
  "created_at" : "2017-09-18 03:08:09 +0000",
  "in_reply_to_screen_name" : "Sueharu_Nakano",
  "in_reply_to_user_id_str" : "4713166412",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/JJEB9ndx5E",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53868",
      "display_url" : "solidot.org\/story?sid=53868"
    } ]
  },
  "geo" : { },
  "id_str" : "909611561723023361",
  "text" : "\u6CA6\u9677\u533ABTC\u5E73\u53F0\u8D1F\u8D23\u4EBA\u5931\u53BB\u4EBA\u8EAB\u81EA\u7531\uFF1Ahttps:\/\/t.co\/JJEB9ndx5E",
  "id" : 909611561723023361,
  "created_at" : "2017-09-18 02:54:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/lnK8kKsQTf",
      "expanded_url" : "https:\/\/github.com\/p3rcya",
      "display_url" : "github.com\/p3rcya"
    } ]
  },
  "geo" : { },
  "id_str" : "909611057991348224",
  "text" : "Lantern\u8DD1\u8DEF\uFF1Ahttps:\/\/t.co\/lnK8kKsQTf",
  "id" : 909611057991348224,
  "created_at" : "2017-09-18 02:52:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/qnoZgYqKv7",
      "expanded_url" : "https:\/\/web.archive.org\/web\/20170918015846\/https:\/\/www.v2ex.com\/t\/387325",
      "display_url" : "web.archive.org\/web\/2017091801\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "909597997507530753",
  "text" : "\u4E2D\u672C\u806A\u964D\u4E34\uFF1Ahttps:\/\/t.co\/qnoZgYqKv7",
  "id" : 909597997507530753,
  "created_at" : "2017-09-18 02:00:36 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/NNmSw3M5lI",
      "expanded_url" : "https:\/\/archive.is\/wFzob",
      "display_url" : "archive.is\/wFzob"
    } ]
  },
  "geo" : { },
  "id_str" : "909373909966966784",
  "text" : "\u6CA6\u9677\u533A\u5927\u5B66\u8F85\u5BFC\u5458\u5F3A\u5236\u5B66\u751F\u597D\u652F\u5A01\u5E0C\uFF1Ahttps:\/\/t.co\/NNmSw3M5lI",
  "id" : 909373909966966784,
  "created_at" : "2017-09-17 11:10:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/vkDxGPurX6",
      "expanded_url" : "https:\/\/twitter.com\/misakaloli\/status\/909122124266246144",
      "display_url" : "twitter.com\/misakaloli\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "909321386514112512",
  "text" : "\u5FA1\u5742\u7F8E\u7434\u5931\u8E2A144\u5929\u540E\u56DE\u5F52\uFF0C\u4F3C\u4E4E\u5DF2\u79BB\u5F00\u4E1C\u516B\u533A\u3002 https:\/\/t.co\/vkDxGPurX6",
  "id" : 909321386514112512,
  "created_at" : "2017-09-17 07:41:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/MvmHxxlIHg",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=15256603",
      "display_url" : "news.ycombinator.com\/item?id=152566\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "909012715053703169",
  "text" : "\u4E0EChrome\u76F8\u53CD\uFF0CFirefox\u5E2E\u4F60\u7EF4\u6301\u591A\u4E2A\u8EAB\u4EFD\uFF1Ahttps:\/\/t.co\/MvmHxxlIHg",
  "id" : 909012715053703169,
  "created_at" : "2017-09-16 11:14:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/b1ffhb0qZ3",
      "expanded_url" : "https:\/\/twitter.com\/solidotunoff\/status\/909004514929364992",
      "display_url" : "twitter.com\/solidotunoff\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "909011792151662592",
  "text" : "BIG BROWSER IS WATCHING https:\/\/t.co\/b1ffhb0qZ3",
  "id" : 909011792151662592,
  "created_at" : "2017-09-16 11:11:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News",
      "screen_name" : "newsycombinator",
      "indices" : [ 3, 19 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/FXyYsz1GV5",
      "expanded_url" : "https:\/\/techcrunch.com\/2017\/09\/15\/why-dropbox-decided-to-drop-aws-and-build-its-own-infrastructure-and-network\/amp\/",
      "display_url" : "techcrunch.com\/2017\/09\/15\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "909000144296783872",
  "text" : "RT @newsycombinator: Dropbox moves off AWS https:\/\/t.co\/FXyYsz1GV5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.steer.me\" rel=\"nofollow\"\u003Enewsycombinator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/FXyYsz1GV5",
        "expanded_url" : "https:\/\/techcrunch.com\/2017\/09\/15\/why-dropbox-decided-to-drop-aws-and-build-its-own-infrastructure-and-network\/amp\/",
        "display_url" : "techcrunch.com\/2017\/09\/15\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "908873541919150081",
    "text" : "Dropbox moves off AWS https:\/\/t.co\/FXyYsz1GV5",
    "id" : 908873541919150081,
    "created_at" : "2017-09-16 02:01:53 +0000",
    "user" : {
      "name" : "Hacker News",
      "screen_name" : "newsycombinator",
      "protected" : false,
      "id_str" : "14335498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469397708986269696\/iUrYEOpJ_normal.png",
      "id" : 14335498,
      "verified" : false
    }
  },
  "id" : 909000144296783872,
  "created_at" : "2017-09-16 10:24:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "898557764410130432",
  "geo" : { },
  "id_str" : "908957450761572352",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u73B0\u5DF2\u52A0\u5165DNSProxy\u3002",
  "id" : 908957450761572352,
  "in_reply_to_status_id" : 898557764410130432,
  "created_at" : "2017-09-16 07:35:18 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/QjPYAcdFGA",
      "expanded_url" : "https:\/\/archive.is",
      "display_url" : "archive.is"
    } ]
  },
  "geo" : { },
  "id_str" : "908916679031304192",
  "text" : "\u8FDEgoogle\u7F13\u5B58\u90FD\u80FD\u56CA\u62EC\u7684\u65F6\u95F4\u673A\u5668\uFF1Ahttps:\/\/t.co\/QjPYAcdFGA",
  "id" : 908916679031304192,
  "created_at" : "2017-09-16 04:53:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/a7wUXpFzZJ",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/908697138527338497",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908700574450962433",
  "text" : "\u6211\u662F\u4E0D\u662F\u975E\u5E38\u4E0D\u53D7\u6B22\u8FCE\uFF1F https:\/\/t.co\/a7wUXpFzZJ",
  "id" : 908700574450962433,
  "created_at" : "2017-09-15 14:34:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/M3t2JZA3rP",
      "expanded_url" : "https:\/\/archive.is\/Mxjbj",
      "display_url" : "archive.is\/Mxjbj"
    } ]
  },
  "geo" : { },
  "id_str" : "908697138527338497",
  "text" : "Phus Lu\u5BF9\u5BA1\u67E5\u7684\u59A5\u534F\uFF1Ahttps:\/\/t.co\/M3t2JZA3rP",
  "id" : 908697138527338497,
  "created_at" : "2017-09-15 14:20:55 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "908682537496694785",
  "text" : "\u63A8\u7279mtf\u90A3\u4E48\u591A\uFF0C\u65F6\u95F4\u7EBF\u91CC\u4E00\u5F20\u57FA\u8F85\u56FE\u4E5F\u627E\u4E0D\u5230~",
  "id" : 908682537496694785,
  "created_at" : "2017-09-15 13:22:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/WGvuWT0iEq",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53858",
      "display_url" : "solidot.org\/story?sid=53858"
    } ]
  },
  "geo" : { },
  "id_str" : "908673716736765958",
  "text" : "\u4E0D\u518D\u4E2D\u7ACB\u7684\u8C37\u6B4C\uFF1Ahttps:\/\/t.co\/WGvuWT0iEq",
  "id" : 908673716736765958,
  "created_at" : "2017-09-15 12:47:51 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u534E\u5C14\u8857\u65E5\u62A5\u4E2D\u6587\u7F51",
      "screen_name" : "ChineseWSJ",
      "indices" : [ 3, 14 ],
      "id_str" : "46574977",
      "id" : 46574977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/BSEfKrqZpD",
      "expanded_url" : "http:\/\/on.wsj.com\/2h7yanz",
      "display_url" : "on.wsj.com\/2h7yanz"
    } ]
  },
  "geo" : { },
  "id_str" : "908648106341879823",
  "text" : "RT @ChineseWSJ: \u300A\u5168\u7403\u9A6C\u683C\u5C3C\u8328\u57FA\u6CD5\u6848\u300B\u6388\u6743\u76F8\u5173\u90E8\u95E8\u5BF9\u5168\u4E16\u754C\u4EFB\u4F55\u5730\u533A\u8FDD\u53CD\u4EBA\u6743\u3001\u72AF\u4E0B\u6216\u534F\u52A9\u72AF\u4E0B\u4E25\u91CD\u8D2A\u6C61\u8150\u8D25\u884C\u4E3A\u7684\u653F\u5E9C\u5B98\u5458\u7981\u53D1\u7B7E\u8BC1\u5E76\u5C01\u5B58\u5176\u5728\u7F8E\u56FD\u7684\u8D44\u4EA7\u3002 https:\/\/t.co\/BSEfKrqZpD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/BSEfKrqZpD",
        "expanded_url" : "http:\/\/on.wsj.com\/2h7yanz",
        "display_url" : "on.wsj.com\/2h7yanz"
      } ]
    },
    "geo" : { },
    "id_str" : "908600131792056320",
    "text" : "\u300A\u5168\u7403\u9A6C\u683C\u5C3C\u8328\u57FA\u6CD5\u6848\u300B\u6388\u6743\u76F8\u5173\u90E8\u95E8\u5BF9\u5168\u4E16\u754C\u4EFB\u4F55\u5730\u533A\u8FDD\u53CD\u4EBA\u6743\u3001\u72AF\u4E0B\u6216\u534F\u52A9\u72AF\u4E0B\u4E25\u91CD\u8D2A\u6C61\u8150\u8D25\u884C\u4E3A\u7684\u653F\u5E9C\u5B98\u5458\u7981\u53D1\u7B7E\u8BC1\u5E76\u5C01\u5B58\u5176\u5728\u7F8E\u56FD\u7684\u8D44\u4EA7\u3002 https:\/\/t.co\/BSEfKrqZpD",
    "id" : 908600131792056320,
    "created_at" : "2017-09-15 07:55:27 +0000",
    "user" : {
      "name" : "\u534E\u5C14\u8857\u65E5\u62A5\u4E2D\u6587\u7F51",
      "screen_name" : "ChineseWSJ",
      "protected" : false,
      "id_str" : "46574977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324615974\/WSJ_tSina_pic_normal.jpg",
      "id" : 46574977,
      "verified" : false
    }
  },
  "id" : 908648106341879823,
  "created_at" : "2017-09-15 11:06:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/7ioEl05iON",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53840",
      "display_url" : "solidot.org\/story?sid=53840"
    } ]
  },
  "geo" : { },
  "id_str" : "908608629036773377",
  "text" : "\u516C\u5171\u8D44\u91D1\u4EE3\u7801\u7684\u81EA\u7531\u5316\uFF1Ahttps:\/\/t.co\/7ioEl05iON",
  "id" : 908608629036773377,
  "created_at" : "2017-09-15 08:29:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/qwGUsOL0PV",
      "expanded_url" : "https:\/\/github.com\/phuslu\/goproxy\/issues\/2030",
      "display_url" : "github.com\/phuslu\/goproxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908598632055795712",
  "text" : "GAE\u652F\u6301\u81EA\u5B9A\u4E49\u57DF\u540D\u548C\u8BC1\u4E66\uFF1Ahttps:\/\/t.co\/qwGUsOL0PV",
  "id" : 908598632055795712,
  "created_at" : "2017-09-15 07:49:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/ZzUrlMmWue",
      "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/908236374389669888",
      "display_url" : "twitter.com\/iyouport_news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908597214653616128",
  "text" : "80\u5E74\u7684\u505C\u6218 https:\/\/t.co\/ZzUrlMmWue",
  "id" : 908597214653616128,
  "created_at" : "2017-09-15 07:43:51 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908288569319473152",
  "geo" : { },
  "id_str" : "908596591916912640",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u5357\u4EAC\u79FB\u52A8\u5C4F\u853D\u4E86ping\u548Ctracert\uFF0C\u5728\u68C0\u6D4B\u5230\u7FFB\u5899\u6D41\u91CF\u540E\u65BD\u884C\u5168\u7F51\u9650\u901F\u3002",
  "id" : 908596591916912640,
  "in_reply_to_status_id" : 908288569319473152,
  "created_at" : "2017-09-15 07:41:23 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/FpoON6eWpp",
      "expanded_url" : "http:\/\/tech.163.com\/17\/0913\/14\/CU7I7MNP00097U81.html",
      "display_url" : "tech.163.com\/17\/0913\/14\/CU7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908173308557971456",
  "text" : "\u6CA6\u9677\u533A\u91CF\u5B50\u96A7\u9053\u6295\u5165\u4F7F\u7528\uFF1Ahttps:\/\/t.co\/FpoON6eWpp",
  "id" : 908173308557971456,
  "created_at" : "2017-09-14 03:39:24 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/fJeOD1HWJI",
      "expanded_url" : "https:\/\/web.archive.org\/web\/20170914032713\/http:\/\/tech.163.com\/17\/0914\/00\/CU8K0UHG00097U81.html",
      "display_url" : "web.archive.org\/web\/2017091403\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908170586618306560",
  "text" : "\u6539\u53D8\u8111\u56DE\u8DEF\u6765\u6212\u6BD2\uFF1Ahttps:\/\/t.co\/fJeOD1HWJI",
  "id" : 908170586618306560,
  "created_at" : "2017-09-14 03:28:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/Z0OwidWGzX",
      "expanded_url" : "http:\/\/tech.sina.com.cn\/i\/2017-09-12\/doc-ifykuffc5229397.shtml",
      "display_url" : "tech.sina.com.cn\/i\/2017-09-12\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908166474627473408",
  "text" : "\u7F51\u6613\u4E91\u97F3\u4E50\u88AB\u5B64\u7ACB\uFF1Ahttps:\/\/t.co\/Z0OwidWGzX",
  "id" : 908166474627473408,
  "created_at" : "2017-09-14 03:12:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/908149620215349249\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/WbpvlNceGD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DJplQTjXkAU7kut.jpg",
      "id_str" : "908149605669507077",
      "id" : 908149605669507077,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJplQTjXkAU7kut.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/WbpvlNceGD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "908149620215349249",
  "text" : "https:\/\/t.co\/WbpvlNceGD",
  "id" : 908149620215349249,
  "created_at" : "2017-09-14 02:05:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/LOBmuYVitl",
      "expanded_url" : "http:\/\/gfwrev.blogspot.com\/2010\/01\/blog-post.html",
      "display_url" : "gfwrev.blogspot.com\/2010\/01\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907954272964358144",
  "text" : "\u6CA6\u9677\u533A\u5B58\u5728\u5DF2\u4E45\u7684\u641C\u7D22\u5F15\u64CE\u88AB\u81EA\u6211\u5BA1\u67E5\uFF1Ahttps:\/\/t.co\/LOBmuYVitl",
  "id" : 907954272964358144,
  "created_at" : "2017-09-13 13:09:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/4PWCG5fOzn",
      "expanded_url" : "http:\/\/blog.sina.com.cn\/s\/blog_6204ca3001010ikf.html",
      "display_url" : "blog.sina.com.cn\/s\/blog_6204ca3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907947722484977664",
  "text" : "md5\u4E0D\u4EC5\u53EF\u4EE5\u5FEB\u901F\u78B0\u649E\uFF0C\u8FD8\u80FD\u649E\u51FA\u5927\u5C0F\u4E00\u6837\u5374\u529F\u80FD\u4E0D\u540C\u7684\u53EF\u6267\u884C\u7A0B\u5E8F\uFF1Ahttps:\/\/t.co\/4PWCG5fOzn",
  "id" : 907947722484977664,
  "created_at" : "2017-09-13 12:43:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "907869691057762304",
  "text" : "RT @williamlong: \u4E0D\u8981\u66F4\u65B0iTunes\u5230\u6700\u65B0\u7248\u672C12.7\uFF0C\u4ECE\u8BE5\u7248\u672C\u8D77\u5F7B\u5E95\u53D6\u6D88\u5185\u7F6EApp Store\uFF0C\u4E5F\u5C31\u662F\u8BF4\uFF0C\u7528\u6237\u53EA\u80FD\u5728iOS\u8BBE\u5907\u4E0A\u4E0B\u8F7D\u5E94\u7528\uFF0C\u4E0D\u80FD\u5728\u7535\u8111\u4E0A\u4E0B\u8F7D\u548C\u5907\u4EFD\u5E94\u7528\u4E86\u3002\u5982\u679C\u8BE5\u5E94\u7528\u4E0B\u67B6\u4E86\uFF0C\u4F60\u5C06\u65E0\u6CD5\u4ECE\u7535\u8111\u4E0A\u91CD\u65B0\u5B89\u88C5\u8BE5\u5E94\u7528\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "907819192589713408",
    "text" : "\u4E0D\u8981\u66F4\u65B0iTunes\u5230\u6700\u65B0\u7248\u672C12.7\uFF0C\u4ECE\u8BE5\u7248\u672C\u8D77\u5F7B\u5E95\u53D6\u6D88\u5185\u7F6EApp Store\uFF0C\u4E5F\u5C31\u662F\u8BF4\uFF0C\u7528\u6237\u53EA\u80FD\u5728iOS\u8BBE\u5907\u4E0A\u4E0B\u8F7D\u5E94\u7528\uFF0C\u4E0D\u80FD\u5728\u7535\u8111\u4E0A\u4E0B\u8F7D\u548C\u5907\u4EFD\u5E94\u7528\u4E86\u3002\u5982\u679C\u8BE5\u5E94\u7528\u4E0B\u67B6\u4E86\uFF0C\u4F60\u5C06\u65E0\u6CD5\u4ECE\u7535\u8111\u4E0A\u91CD\u65B0\u5B89\u88C5\u8BE5\u5E94\u7528\u3002",
    "id" : 907819192589713408,
    "created_at" : "2017-09-13 04:12:16 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 907869691057762304,
  "created_at" : "2017-09-13 07:32:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/2Bene01Whb",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/907642279803998209",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907643849543229440",
  "text" : "\u4E0D\u6DF7fb\u3001reddit\uFF0C\u7B2C\u4E00\u6B21\u611F\u5230\u767D\u5DE6\u7684\u53CC\u6807\u5BA1\u67E5\u5C31\u5728\u8EAB\u8FB9\uFF0C\u4E5F\u8BB8twitter\u4E5F\u4E0D\u662F\u4E45\u7559\u7684\u5730\u65B9\uD83D\uDE14 https:\/\/t.co\/2Bene01Whb",
  "id" : 907643849543229440,
  "created_at" : "2017-09-12 16:35:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/WDsdPZJyAR",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53812",
      "display_url" : "solidot.org\/story?sid=53812"
    } ]
  },
  "geo" : { },
  "id_str" : "907627714219212800",
  "text" : "\u8001\u5927\u54E5360\uFF1Ahttps:\/\/t.co\/WDsdPZJyAR",
  "id" : 907627714219212800,
  "created_at" : "2017-09-12 15:31:24 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Assange \uD83D\uDD39",
      "screen_name" : "JulianAssange",
      "indices" : [ 3, 17 ],
      "id_str" : "388983706",
      "id" : 388983706
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "filterverse",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "harmfulopinions",
      "indices" : [ 115, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "907488711843221504",
  "text" : "RT @JulianAssange: That link I shared to a YouTube video about YouTube censorship? It's now censored. #filterverse #harmfulopinions https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "filterverse",
        "indices" : [ 83, 95 ]
      }, {
        "text" : "harmfulopinions",
        "indices" : [ 96, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/kFzauOzD9Q",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=deDAFxjUOnU",
        "display_url" : "youtube.com\/watch?v=deDAFx\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "907402152582270976",
    "text" : "That link I shared to a YouTube video about YouTube censorship? It's now censored. #filterverse #harmfulopinions https:\/\/t.co\/kFzauOzD9Q",
    "id" : 907402152582270976,
    "created_at" : "2017-09-12 00:35:06 +0000",
    "user" : {
      "name" : "Julian Assange \uD83D\uDD39",
      "screen_name" : "JulianAssange",
      "protected" : false,
      "id_str" : "388983706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841283762914656256\/2AyBiX8E_normal.jpg",
      "id" : 388983706,
      "verified" : false
    }
  },
  "id" : 907488711843221504,
  "created_at" : "2017-09-12 06:19:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/wJ7CDDccDn",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53798",
      "display_url" : "solidot.org\/story?sid=53798"
    } ]
  },
  "geo" : { },
  "id_str" : "907246565768744960",
  "text" : "\u4E2D\u5171\u6728\u9A6C\u76D1\u63A7\u9999\u6E2F\u6297\u8BAE\u8005\uFF1Ahttps:\/\/t.co\/wJ7CDDccDn",
  "id" : 907246565768744960,
  "created_at" : "2017-09-11 14:16:51 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/hotwSAzNHU",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/907136576123260929",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907244106526707713",
  "text" : "\u5168\u6C11\u7FFB\u5899\u7684\u524D\u5146\uFF1F https:\/\/t.co\/hotwSAzNHU",
  "id" : 907244106526707713,
  "created_at" : "2017-09-11 14:07:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/AogJAdokjg",
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/907018515147767809",
      "display_url" : "twitter.com\/ruanyf\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907185066534678529",
  "text" : "(\u2299\u02CD\u2299) https:\/\/t.co\/AogJAdokjg",
  "id" : 907185066534678529,
  "created_at" : "2017-09-11 10:12:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/ISKH6nUDUo",
      "expanded_url" : "https:\/\/github.com\/phuslu\/goproxy\/issues\/2016",
      "display_url" : "github.com\/phuslu\/goproxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "906472420613246977",
  "text" : "GAE\u505A\u6B63\u786E\u7684\u4E8B\uFF1Ahttps:\/\/t.co\/ISKH6nUDUo",
  "id" : 906472420613246977,
  "created_at" : "2017-09-09 11:00:41 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906145237566988290",
  "text" : "1\u7F8E\u5143 = 6.4645002\u4EBA\u6C11\u5E01",
  "id" : 906145237566988290,
  "created_at" : "2017-09-08 13:20:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7834\u5A03\u9171",
      "screen_name" : "breakwa11",
      "indices" : [ 2, 12 ],
      "id_str" : "3360572424",
      "id" : 3360572424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906143331998212096",
  "text" : "\u56E0\u4E3A@breakwa11\u53CD\u5BF9\uFF0C\u6211\u5C06\u572824\u5C0F\u65F6\u5185\u5220\u9664\u6240\u6709\u8F6Cta\u7684\u63A8\u3002",
  "id" : 906143331998212096,
  "created_at" : "2017-09-08 13:13:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/yE3ajX7r6Y",
      "expanded_url" : "https:\/\/archive.is\/vjOjA#selection-1433.23-1433.47",
      "display_url" : "archive.is\/vjOjA#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "906140121656946692",
  "text" : "Chrome OS\u5360\u9886\u6B27\u7F8E\u9152\u5E97\uFF1Ahttps:\/\/t.co\/yE3ajX7r6Y",
  "id" : 906140121656946692,
  "created_at" : "2017-09-08 13:00:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/tveHBhKiQS",
      "expanded_url" : "https:\/\/twitter.com\/wangDevming\/status\/905778050775752704",
      "display_url" : "twitter.com\/wangDevming\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "906102045135929344",
  "geo" : { },
  "id_str" : "906138342005374976",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming https:\/\/t.co\/tveHBhKiQS",
  "id" : 906138342005374976,
  "in_reply_to_status_id" : 906102045135929344,
  "created_at" : "2017-09-08 12:53:10 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/YDbP0rA0fG",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/09\/blog-post_38.html",
      "display_url" : "molihua.org\/2017\/09\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "906130929541885952",
  "text" : "\u5BB6\u957F\u5236\u4E0A\u4E0B\u4E94\u5343\u5E74\uFF1Ahttps:\/\/t.co\/YDbP0rA0fG",
  "id" : 906130929541885952,
  "created_at" : "2017-09-08 12:23:43 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/unLyfnSseu",
      "expanded_url" : "https:\/\/github.com\/XX-net\/XX-Net-dev\/issues\/28",
      "display_url" : "github.com\/XX-net\/XX-Net-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "906123169974669312",
  "text" : "\u4E00\u8D77\u53C2\u4E0E\u8BA8\u8BBAXX-Net\u7684\u672A\u6765\uFF1Ahttps:\/\/t.co\/unLyfnSseu",
  "id" : 906123169974669312,
  "created_at" : "2017-09-08 11:52:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigbrother",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "yourchina",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906116491170521088",
  "text" : "RT @iyouport_news: \uFF3B\u4E2D\u56FD\u52A0\u5F3A\u5BF9\u7FA4\u804A\u7684\u76D1\u63A7  \u804A\u5929\u5185\u5BB9\u5C06\u4E0E\u4FE1\u7528\u8BC4\u7EA7\u6302\u94A9\uFF3D\uFF03bigbrother #yourchina \u7F51\u4FE1\u529E\u79F0 \u4E92\u8054\u7F51\u804A\u5929\u670D\u52A1\u5546\u5FC5\u987B\u9A8C\u8BC1\u5176\u7528\u6237\u7684\u8EAB\u4EFD\uFF0C\u5E76\u4FDD\u5B58\u4E0D\u5C11\u4E8E\u516D\u4E2A\u6708\uFF0C\u89C4\u5B9A\u8FD8\u8981\u6C42\u4F01\u4E1A\u5EFA\u7ACB\u4FE1\u7528\u4F53\u7CFB\uFF0C\u5E76\u6839\u636E\u4FE1\u7528\u8BC4\u7EA7\u5411\u7528\u6237\u63D0\u4F9B\u7FA4\u804A\u670D\u52A1\uFF1Ahttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/906053327204388865\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/3d5dg3iMXJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJLysT_UQAA_Hgu.jpg",
        "id_str" : "906053318148898816",
        "id" : 906053318148898816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJLysT_UQAA_Hgu.jpg",
        "sizes" : [ {
          "h" : 369,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 648
        } ],
        "display_url" : "pic.twitter.com\/3d5dg3iMXJ"
      } ],
      "hashtags" : [ {
        "text" : "bigbrother",
        "indices" : [ 26, 37 ]
      }, {
        "text" : "yourchina",
        "indices" : [ 38, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/QB3MxZV20t",
        "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1650636224967515",
        "display_url" : "facebook.com\/iyouport\/posts\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "906053327204388865",
    "text" : "\uFF3B\u4E2D\u56FD\u52A0\u5F3A\u5BF9\u7FA4\u804A\u7684\u76D1\u63A7  \u804A\u5929\u5185\u5BB9\u5C06\u4E0E\u4FE1\u7528\u8BC4\u7EA7\u6302\u94A9\uFF3D\uFF03bigbrother #yourchina \u7F51\u4FE1\u529E\u79F0 \u4E92\u8054\u7F51\u804A\u5929\u670D\u52A1\u5546\u5FC5\u987B\u9A8C\u8BC1\u5176\u7528\u6237\u7684\u8EAB\u4EFD\uFF0C\u5E76\u4FDD\u5B58\u4E0D\u5C11\u4E8E\u516D\u4E2A\u6708\uFF0C\u89C4\u5B9A\u8FD8\u8981\u6C42\u4F01\u4E1A\u5EFA\u7ACB\u4FE1\u7528\u4F53\u7CFB\uFF0C\u5E76\u6839\u636E\u4FE1\u7528\u8BC4\u7EA7\u5411\u7528\u6237\u63D0\u4F9B\u7FA4\u804A\u670D\u52A1\uFF1Ahttps:\/\/t.co\/QB3MxZV20t https:\/\/t.co\/3d5dg3iMXJ",
    "id" : 906053327204388865,
    "created_at" : "2017-09-08 07:15:21 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 906116491170521088,
  "created_at" : "2017-09-08 11:26:20 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "905782767564210178",
  "geo" : { },
  "id_str" : "905783323171180544",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u8BF4\u597D\u7684\u6298\u5C04\u7F51\u7EDC\u5462\u3002\u3002",
  "id" : 905783323171180544,
  "in_reply_to_status_id" : 905782767564210178,
  "created_at" : "2017-09-07 13:22:27 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "905778050775752704",
  "geo" : { },
  "id_str" : "905781580425306112",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u957F\u90A3\u4E48\u5E05\u4E0D\u5B9E\u540D\u53EF\u60DC\u4E86\u3002\u3002",
  "id" : 905781580425306112,
  "in_reply_to_status_id" : 905778050775752704,
  "created_at" : "2017-09-07 13:15:32 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "905736495721463809",
  "geo" : { },
  "id_str" : "905759575432986624",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf Web\u4E0D\u662F\u57FA\u4E8E\u6587\u4EF6\u7CFB\u7EDF\u3001\u4E5F\u4E0D\u662F\u57FA\u4E8ESQL\u7684\u3002",
  "id" : 905759575432986624,
  "in_reply_to_status_id" : 905736495721463809,
  "created_at" : "2017-09-07 11:48:05 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/DnY3yLXlRO",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53716",
      "display_url" : "solidot.org\/story?sid=53716"
    } ]
  },
  "geo" : { },
  "id_str" : "905662259644424192",
  "text" : "\u51FA\u552ESS(R)\u83B7\u52291\u4E07\u8005\u88AB\u5224\u52119\u4E2A\u6708\uFF1Ahttps:\/\/t.co\/DnY3yLXlRO",
  "id" : 905662259644424192,
  "created_at" : "2017-09-07 05:21:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 3, 18 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "905658356391493633",
  "text" : "RT @GreatFireChina: Telegram blocked in Macau. Authorities testing one country, one GFW in preparation for HK rollout? https:\/\/t.co\/1Bh9Mkr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HRIC \u4E2D\u56FD\u4EBA\u6743",
        "screen_name" : "hrichina",
        "indices" : [ 127, 136 ],
        "id_str" : "20784367",
        "id" : 20784367
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/1Bh9MkrbAA",
        "expanded_url" : "https:\/\/www.facebook.com\/macauconcealers\/photos\/a.158212900914486.37247.153478958054547\/1423428511059579\/?type=3&permPage=1",
        "display_url" : "facebook.com\/macauconcealer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "905373637519319042",
    "text" : "Telegram blocked in Macau. Authorities testing one country, one GFW in preparation for HK rollout? https:\/\/t.co\/1Bh9MkrbAA h\/t @hrichina",
    "id" : 905373637519319042,
    "created_at" : "2017-09-06 10:14:30 +0000",
    "user" : {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "protected" : false,
      "id_str" : "254148157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794103496836517888\/BE7Ek2ae_normal.jpg",
      "id" : 254148157,
      "verified" : true
    }
  },
  "id" : 905658356391493633,
  "created_at" : "2017-09-07 05:05:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904815696302882816",
  "geo" : { },
  "id_str" : "904816116253515777",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u4F60\u5728\u4EC0\u4E48\u65F6\u533A\uFF1F",
  "id" : 904816116253515777,
  "in_reply_to_status_id" : 904815696302882816,
  "created_at" : "2017-09-04 21:19:07 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/904711006118715393\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/jpBG0JQUPQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DI4tz4TW0AADDaA.jpg",
      "id_str" : "904710944458199040",
      "id" : 904710944458199040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DI4tz4TW0AADDaA.jpg",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1282
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1282
      } ],
      "display_url" : "pic.twitter.com\/jpBG0JQUPQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "904711006118715393",
  "text" : "\u554A\u554A\u554A\u554A\u554A\u554A\u554A\u554A\u554A\u554A\u554A\u554A\u554A\u554A https:\/\/t.co\/jpBG0JQUPQ",
  "id" : 904711006118715393,
  "created_at" : "2017-09-04 14:21:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/fta5XWURAn",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53709",
      "display_url" : "solidot.org\/story?sid=53709"
    } ]
  },
  "geo" : { },
  "id_str" : "904707365823533056",
  "text" : "Reddit\u7684\u4E2D\u56FD\u68A6\uFF1Ahttps:\/\/t.co\/fta5XWURAn",
  "id" : 904707365823533056,
  "created_at" : "2017-09-04 14:06:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/wbsZNX62w4",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53700",
      "display_url" : "solidot.org\/story?sid=53700"
    } ]
  },
  "geo" : { },
  "id_str" : "904707074457825281",
  "text" : "ICO\u6D41\u6D6A\u6D77\u5916\uFF1Ahttps:\/\/t.co\/wbsZNX62w4",
  "id" : 904707074457825281,
  "created_at" : "2017-09-04 14:05:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 0, 15 ],
      "id_str" : "254148157",
      "id" : 254148157
    }, {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 16, 31 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904702169751932928",
  "geo" : { },
  "id_str" : "904702580185542656",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@GreatFireChina @GreatFireChina \u8BF7\u5217\u51FA\u4F60\u7684\u6240\u6709\u8D26\u53F7\u3002",
  "id" : 904702580185542656,
  "in_reply_to_status_id" : 904702169751932928,
  "created_at" : "2017-09-04 13:47:58 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 25, 40 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/904702169751932928\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/feaL6JQIoy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DI4l0aQW0AAl3CZ.jpg",
      "id_str" : "904702157479399424",
      "id" : 904702157479399424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DI4l0aQW0AAl3CZ.jpg",
      "sizes" : [ {
        "h" : 642,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 864
      } ],
      "display_url" : "pic.twitter.com\/feaL6JQIoy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/pG4EJjpC9D",
      "expanded_url" : "https:\/\/github.com\/GreatfireChina",
      "display_url" : "github.com\/GreatfireChina"
    }, {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/MnXLVBQ8pN",
      "expanded_url" : "https:\/\/archive.is\/uvx32#selection-803.0-803.15",
      "display_url" : "archive.is\/uvx32#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "904702169751932928",
  "text" : "https:\/\/t.co\/pG4EJjpC9D\u4E0D\u662F@GreatFireChina\uFF1Ahttps:\/\/t.co\/MnXLVBQ8pN https:\/\/t.co\/feaL6JQIoy",
  "id" : 904702169751932928,
  "created_at" : "2017-09-04 13:46:20 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/gcmwBUBICZ",
      "expanded_url" : "https:\/\/dns.google.com\/resolve?name=m10.music.126.net",
      "display_url" : "dns.google.com\/resolve?name=m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903908472365998081",
  "text" : "\u539F\u6765\u57DF\u540D\u53EF\u4EE5\u6307\u5411127.0.0.1\uFF1Ahttps:\/\/t.co\/gcmwBUBICZ",
  "id" : 903908472365998081,
  "created_at" : "2017-09-02 09:12:28 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/J0tqI60ZAw",
      "expanded_url" : "https:\/\/www.ithome.com\/html\/android\/324155.htm",
      "display_url" : "ithome.com\/html\/android\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903908163736526848",
  "text" : "\u505A\u6B63\u786E\u7684\u4E8B\uFF1Ahttps:\/\/t.co\/J0tqI60ZAw",
  "id" : 903908163736526848,
  "created_at" : "2017-09-02 09:11:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "903904609651089408",
  "text" : "1\u7F8E\u5143 = 6.55909747\u4EBA\u6C11\u5E01",
  "id" : 903904609651089408,
  "created_at" : "2017-09-02 08:57:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/MnTm00enJy",
      "expanded_url" : "https:\/\/github.com\/sjdy521\/Mojo-Webqq\/issues\/145",
      "display_url" : "github.com\/sjdy521\/Mojo-W\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "903892758359941121",
  "geo" : { },
  "id_str" : "903901310327681025",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/MnTm00enJy",
  "id" : 903901310327681025,
  "in_reply_to_status_id" : 903892758359941121,
  "created_at" : "2017-09-02 08:44:00 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "903892758359941121",
  "text" : "SmartQQ\u91CD\u65B0\u652F\u6301\u8D26\u53F7\u5BC6\u7801\u767B\u5F55\u3002",
  "id" : 903892758359941121,
  "created_at" : "2017-09-02 08:10:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "903857011590344704",
  "text" : "Firefox\u53EF\u4EE5\u6253\u5F00JSON\u4E86\u3002",
  "id" : 903857011590344704,
  "created_at" : "2017-09-02 05:47:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "898557764410130432",
  "geo" : { },
  "id_str" : "903850771967598592",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u8FD9\u4E2A\u7FFB\u5899\u65B9\u6848\u5F88\u5FEB\uFF0C\u4F46\u80FD\u652F\u6301\u7684\u7528\u6237\u6570\u6709\u9650\uFF0C\u8BF7\u65E5\u5E38\u4F7F\u7528\u8005\u5728\u6B64\u7559\u8A00\u3002",
  "id" : 903850771967598592,
  "in_reply_to_status_id" : 898557764410130432,
  "created_at" : "2017-09-02 05:23:11 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF61\uFF65\u04E9\uFF65\uFF61) \u2744\uFE0F",
      "screen_name" : "SphericalSuki",
      "indices" : [ 0, 14 ],
      "id_str" : "3018108065",
      "id" : 3018108065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903483685944475648",
  "geo" : { },
  "id_str" : "903850177538265088",
  "in_reply_to_user_id" : 3018108065,
  "text" : "@SphericalSuki \uFF1F",
  "id" : 903850177538265088,
  "in_reply_to_status_id" : 903483685944475648,
  "created_at" : "2017-09-02 05:20:49 +0000",
  "in_reply_to_screen_name" : "SphericalSuki",
  "in_reply_to_user_id_str" : "3018108065",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/2kmOK0edqf",
      "expanded_url" : "https:\/\/web.archive.org\/web\/20170902035432\/https:\/\/www.v2ex.com\/t\/384971",
      "display_url" : "web.archive.org\/web\/2017090203\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903828755487088640",
  "text" : "\u79FB\u52A8\u51FA\u56FD\u4F18\u52BF\u4E0D\u518D\uFF1Ahttps:\/\/t.co\/2kmOK0edqf",
  "id" : 903828755487088640,
  "created_at" : "2017-09-02 03:55:42 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/MPj23L6Udr",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SacePowbHsY",
      "display_url" : "youtube.com\/watch?v=SacePo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903582058739634176",
  "text" : "\u4E2D\u7F8E\u8C0D\u6218\u7684\u6D17\u724C\uFF1Ahttps:\/\/t.co\/MPj23L6Udr",
  "id" : 903582058739634176,
  "created_at" : "2017-09-01 11:35:25 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]