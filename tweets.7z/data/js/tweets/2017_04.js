Grailbird.data.tweets_2017_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "858183112534220800",
  "text" : "RT @williamlong: \u8FD1\u65E5\uFF0C\u9A6C\u4E91\u5728\u676D\u5DDE\u4E3E\u884C\u7684\u5168\u7403\u5CF0\u4F1A\u4E0A\u53D1\u8868\u4E3B\u9898\u6F14\u8BB2\u8BF4\u5230\uFF1A\u672A\u6765\u623F\u5B50\u5982\u8471\u3002\u4ED6\u8BF4\uFF0C\u8FC7\u53BB8\u5E74\u5185\uFF0C\u4E2D\u56FD\u7684\u623F\u5B50\u6574\u4F53\u4E0A\u5904\u4E8E\u5927\u5E45\u4E0A\u5347\u7684\u72B6\u6001\u30028\u5E74\u540E\uFF0C\u4E2D\u56FD\u6700\u4FBF\u5B9C\u7684\u4E1C\u897F\u53EF\u80FD\u5C31\u662F\u623F\u5B50\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "858007946394992641",
    "text" : "\u8FD1\u65E5\uFF0C\u9A6C\u4E91\u5728\u676D\u5DDE\u4E3E\u884C\u7684\u5168\u7403\u5CF0\u4F1A\u4E0A\u53D1\u8868\u4E3B\u9898\u6F14\u8BB2\u8BF4\u5230\uFF1A\u672A\u6765\u623F\u5B50\u5982\u8471\u3002\u4ED6\u8BF4\uFF0C\u8FC7\u53BB8\u5E74\u5185\uFF0C\u4E2D\u56FD\u7684\u623F\u5B50\u6574\u4F53\u4E0A\u5904\u4E8E\u5927\u5E45\u4E0A\u5347\u7684\u72B6\u6001\u30028\u5E74\u540E\uFF0C\u4E2D\u56FD\u6700\u4FBF\u5B9C\u7684\u4E1C\u897F\u53EF\u80FD\u5C31\u662F\u623F\u5B50\u3002",
    "id" : 858007946394992641,
    "created_at" : "2017-04-28 17:20:10 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 858183112534220800,
  "created_at" : "2017-04-29 04:56:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/GFZ0G5HqqQ",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/846982565105938432",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "848132241477828608",
  "text" : "\u5341\u5E74 https:\/\/t.co\/GFZ0G5HqqQ",
  "id" : 848132241477828608,
  "created_at" : "2017-04-01 11:17:38 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "848122735977013249",
  "text" : "RT @williamlong: \u7FFB\u5899\u5BF9\u4E8E\u6211\u6765\u8BF4\u662F\u521A\u9700\uFF0C\u4E3B\u8981\u662F\u56E0\u4E3Agmail\u548Cdropbox\u4E24\u4E2A\u670D\u52A1\u4E0D\u53EF\u66FF\u4EE3\uFF0C\u4E24\u8005\u90FD\u652F\u6301\u4E24\u6B65\u9A8C\u8BC1\uFF0C\u975E\u5E38\u5B89\u5168\uFF0C\u4E00\u4E2A\u6CE8\u518C\u4E86\u5404\u7C7B\u7F51\u7AD9\u7528\u6237\uFF0C\u4E00\u4E2A\u7528\u4E8E\u540C\u6B65\u591A\u53F0\u7535\u8111\u4E0D\u540C\u64CD\u4F5C\u7CFB\u7EDF\u7684\u91CD\u8981\u6587\u6863\u548C\u6587\u4EF6\uFF0C\u4E00\u5929\u4E0D\u7FFB\u5899\uFF0C\u6211\u7684\u5DE5\u4F5C\u548C\u751F\u6D3B\u90FD\u65E0\u6CD5\u6B63\u5E38\u8FDB\u884C\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "846879875470446593",
    "text" : "\u7FFB\u5899\u5BF9\u4E8E\u6211\u6765\u8BF4\u662F\u521A\u9700\uFF0C\u4E3B\u8981\u662F\u56E0\u4E3Agmail\u548Cdropbox\u4E24\u4E2A\u670D\u52A1\u4E0D\u53EF\u66FF\u4EE3\uFF0C\u4E24\u8005\u90FD\u652F\u6301\u4E24\u6B65\u9A8C\u8BC1\uFF0C\u975E\u5E38\u5B89\u5168\uFF0C\u4E00\u4E2A\u6CE8\u518C\u4E86\u5404\u7C7B\u7F51\u7AD9\u7528\u6237\uFF0C\u4E00\u4E2A\u7528\u4E8E\u540C\u6B65\u591A\u53F0\u7535\u8111\u4E0D\u540C\u64CD\u4F5C\u7CFB\u7EDF\u7684\u91CD\u8981\u6587\u6863\u548C\u6587\u4EF6\uFF0C\u4E00\u5929\u4E0D\u7FFB\u5899\uFF0C\u6211\u7684\u5DE5\u4F5C\u548C\u751F\u6D3B\u90FD\u65E0\u6CD5\u6B63\u5E38\u8FDB\u884C\u3002",
    "id" : 846879875470446593,
    "created_at" : "2017-03-29 00:21:11 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 848122735977013249,
  "created_at" : "2017-04-01 10:39:52 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]