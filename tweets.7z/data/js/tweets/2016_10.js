Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 3, 18 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/1UfC7UB5RD",
      "expanded_url" : "https:\/\/www.theguardian.com\/world\/2016\/oct\/27\/xi-jinping-becomes-core-leader-of-china?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/world\/2016\/oct\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792361456922611713",
  "text" : "RT @GreatFireChina: Xi Jinping becomes 'core' leader of China https:\/\/t.co\/1UfC7UB5RD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/1UfC7UB5RD",
        "expanded_url" : "https:\/\/www.theguardian.com\/world\/2016\/oct\/27\/xi-jinping-becomes-core-leader-of-china?CMP=share_btn_tw",
        "display_url" : "theguardian.com\/world\/2016\/oct\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792167569339932672",
    "text" : "Xi Jinping becomes 'core' leader of China https:\/\/t.co\/1UfC7UB5RD",
    "id" : 792167569339932672,
    "created_at" : "2016-10-29 00:54:00 +0000",
    "user" : {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "protected" : false,
      "id_str" : "254148157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794103496836517888\/BE7Ek2ae_normal.jpg",
      "id" : 254148157,
      "verified" : true
    }
  },
  "id" : 792361456922611713,
  "created_at" : "2016-10-29 13:44:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/JShrle6jTJ",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/786781180121141248",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786786120331776002",
  "text" : "\u4E09\u661F\u836F\u4E38 https:\/\/t.co\/JShrle6jTJ",
  "id" : 786786120331776002,
  "created_at" : "2016-10-14 04:30:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]