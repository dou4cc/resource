Grailbird.data.tweets_2016_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/B3HHoANsOp",
      "expanded_url" : "http:\/\/t.cn\/RfKtN2A",
      "display_url" : "t.cn\/RfKtN2A"
    } ]
  },
  "geo" : { },
  "id_str" : "802113574625824769",
  "text" : "RT @williamlong: \u7EBD\u7EA6\u65F6\u62A5\u62A5\u9053\uFF0C\u624E\u514B\u4F2F\u683C\u4E3A\u4E86\u628AFacebook\u5F15\u5165\u4E2D\u56FD\uFF0C\u5DF2\u7ECF\u79D8\u5BC6\u4E3A\u4E2D\u56FD\u5F00\u53D1\u4E86\u5BA1\u67E5\u5DE5\u5177\u8FC7\u6EE4\u4E0D\u826F\u4FE1\u606F\uFF0C\u8BE5\u5DE5\u5177\u4F1A\u8BA9Facebook\u7684\u5408\u4F5C\u4F19\u4F34\u83B7\u5F97\u5B8C\u5168\u7684\u63A7\u5236\u6743\uFF0C\u51B3\u5B9A\u8FD9\u4E9B\u5E16\u5B50\u662F\u5426\u5E94\u8BE5\u663E\u793A\u5728\u7528\u6237\u7684\u65B0\u95FB\u6D41\u4E2D\u3002https:\/\/t.co\/B3HHoANsOp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/B3HHoANsOp",
        "expanded_url" : "http:\/\/t.cn\/RfKtN2A",
        "display_url" : "t.cn\/RfKtN2A"
      } ]
    },
    "geo" : { },
    "id_str" : "801612076166840320",
    "text" : "\u7EBD\u7EA6\u65F6\u62A5\u62A5\u9053\uFF0C\u624E\u514B\u4F2F\u683C\u4E3A\u4E86\u628AFacebook\u5F15\u5165\u4E2D\u56FD\uFF0C\u5DF2\u7ECF\u79D8\u5BC6\u4E3A\u4E2D\u56FD\u5F00\u53D1\u4E86\u5BA1\u67E5\u5DE5\u5177\u8FC7\u6EE4\u4E0D\u826F\u4FE1\u606F\uFF0C\u8BE5\u5DE5\u5177\u4F1A\u8BA9Facebook\u7684\u5408\u4F5C\u4F19\u4F34\u83B7\u5F97\u5B8C\u5168\u7684\u63A7\u5236\u6743\uFF0C\u51B3\u5B9A\u8FD9\u4E9B\u5E16\u5B50\u662F\u5426\u5E94\u8BE5\u663E\u793A\u5728\u7528\u6237\u7684\u65B0\u95FB\u6D41\u4E2D\u3002https:\/\/t.co\/B3HHoANsOp",
    "id" : 801612076166840320,
    "created_at" : "2016-11-24 02:23:06 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 802113574625824769,
  "created_at" : "2016-11-25 11:35:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]