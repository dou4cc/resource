Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/766263884583796737\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/TSWYpZHpnB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJQ7R7UkAAYja_.jpg",
      "id_str" : "766263865961123840",
      "id" : 766263865961123840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJQ7R7UkAAYja_.jpg",
      "sizes" : [ {
        "h" : 141,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 141,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 141,
        "resize" : "crop",
        "w" : 141
      }, {
        "h" : 141,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 141,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/TSWYpZHpnB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/DUPIlGeRog",
      "expanded_url" : "https:\/\/blog.cloudflare.com\/bandwidth-costs-around-the-world\/",
      "display_url" : "blog.cloudflare.com\/bandwidth-cost\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767647574543077376",
  "text" : "RT @ruanyf: CloudFlare\u62B1\u6028\u4E9A\u6D32ISP\u7684\u5E26\u5BBD\u592A\u8D35\uFF0C\u97E9\u56FD\u548C\u53F0\u6E7E\u662F\u5317\u7F8E\u4EF7\u683C\u768415\u500D\u3002\u611F\u53F9\u4E00\u58F0\uFF0C\u90A3\u662F\u6CA1\u89C1\u8FC7\u4E2D\u56FD\u7684ISP\u7684\u5E26\u5BBD\u4EF7\u683C\u3002https:\/\/t.co\/DUPIlGeRog https:\/\/t.co\/TSWYpZHpnB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/766263884583796737\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/TSWYpZHpnB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJQ7R7UkAAYja_.jpg",
        "id_str" : "766263865961123840",
        "id" : 766263865961123840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJQ7R7UkAAYja_.jpg",
        "sizes" : [ {
          "h" : 141,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 141,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 141,
          "resize" : "crop",
          "w" : 141
        }, {
          "h" : 141,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 141,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/TSWYpZHpnB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/DUPIlGeRog",
        "expanded_url" : "https:\/\/blog.cloudflare.com\/bandwidth-costs-around-the-world\/",
        "display_url" : "blog.cloudflare.com\/bandwidth-cost\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766263884583796737",
    "text" : "CloudFlare\u62B1\u6028\u4E9A\u6D32ISP\u7684\u5E26\u5BBD\u592A\u8D35\uFF0C\u97E9\u56FD\u548C\u53F0\u6E7E\u662F\u5317\u7F8E\u4EF7\u683C\u768415\u500D\u3002\u611F\u53F9\u4E00\u58F0\uFF0C\u90A3\u662F\u6CA1\u89C1\u8FC7\u4E2D\u56FD\u7684ISP\u7684\u5E26\u5BBD\u4EF7\u683C\u3002https:\/\/t.co\/DUPIlGeRog https:\/\/t.co\/TSWYpZHpnB",
    "id" : 766263884583796737,
    "created_at" : "2016-08-18 13:22:01 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 767647574543077376,
  "created_at" : "2016-08-22 09:00:18 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]