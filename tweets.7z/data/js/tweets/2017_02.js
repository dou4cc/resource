Grailbird.data.tweets_2017_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/f7Vnu0khVr",
      "expanded_url" : "http:\/\/t.cn\/RfXZTXg",
      "display_url" : "t.cn\/RfXZTXg"
    } ]
  },
  "geo" : { },
  "id_str" : "832173646751870981",
  "text" : "RT @williamlong: \u534E\u4E3A\u89C4\u5B9A45\u5C81\u5FC5\u987B\u9000\u4F11\uFF0C\u60F3\u7EE7\u7EED\u5DE5\u4F5C\u7684\uFF0C\u9700\u4EBA\u529B\u8D44\u6E90\u90E8\u91CD\u65B0\u5BA1\u6279\u3002 https:\/\/t.co\/f7Vnu0khVr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/f7Vnu0khVr",
        "expanded_url" : "http:\/\/t.cn\/RfXZTXg",
        "display_url" : "t.cn\/RfXZTXg"
      } ]
    },
    "geo" : { },
    "id_str" : "832130169552896000",
    "text" : "\u534E\u4E3A\u89C4\u5B9A45\u5C81\u5FC5\u987B\u9000\u4F11\uFF0C\u60F3\u7EE7\u7EED\u5DE5\u4F5C\u7684\uFF0C\u9700\u4EBA\u529B\u8D44\u6E90\u90E8\u91CD\u65B0\u5BA1\u6279\u3002 https:\/\/t.co\/f7Vnu0khVr",
    "id" : 832130169552896000,
    "created_at" : "2017-02-16 07:31:07 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 832173646751870981,
  "created_at" : "2017-02-16 10:23:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/cj8YKncdcA",
      "expanded_url" : "https:\/\/wicg.github.io\/shape-detection-api\/#image-sources-for-detection",
      "display_url" : "wicg.github.io\/shape-detectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828582061829074944",
  "text" : "RT @ruanyf: Chrome 56\u5DF2\u7ECF\u652F\u6301\u56FE\u50CF\u8BC6\u522B API\uFF08Shape Detection API\uFF09\uFF0C\u4E0D\u7528\u4EFB\u4F55\u5916\u90E8\u5E93\uFF0C\u4E00\u884C\u8BED\u53E5\u5C31\u80FD\u8BC6\u522B\u6761\u5F62\u7801\u548C\u4EBA\u8138\uFF0C\u5C06\u6765\u8FD8\u652F\u6301\u6587\u5B57 OCR\u3002\u592A\u5F3A\u4E86\uFF0C\u4E0B\u56FE\u7684\u4EE3\u7801\u53EF\u4EE5\u76F4\u63A5\u8FD0\u884C\u3002https:\/\/t.co\/cj8YKncdcA https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/828474622215540737\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/oMaB7zrM4d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C39U9zVUEAAyzpL.jpg",
        "id_str" : "828474277187817472",
        "id" : 828474277187817472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C39U9zVUEAAyzpL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 781,
          "resize" : "fit",
          "w" : 915
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 781,
          "resize" : "fit",
          "w" : 915
        }, {
          "h" : 781,
          "resize" : "fit",
          "w" : 915
        } ],
        "display_url" : "pic.twitter.com\/oMaB7zrM4d"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/cj8YKncdcA",
        "expanded_url" : "https:\/\/wicg.github.io\/shape-detection-api\/#image-sources-for-detection",
        "display_url" : "wicg.github.io\/shape-detectio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "828474622215540737",
    "text" : "Chrome 56\u5DF2\u7ECF\u652F\u6301\u56FE\u50CF\u8BC6\u522B API\uFF08Shape Detection API\uFF09\uFF0C\u4E0D\u7528\u4EFB\u4F55\u5916\u90E8\u5E93\uFF0C\u4E00\u884C\u8BED\u53E5\u5C31\u80FD\u8BC6\u522B\u6761\u5F62\u7801\u548C\u4EBA\u8138\uFF0C\u5C06\u6765\u8FD8\u652F\u6301\u6587\u5B57 OCR\u3002\u592A\u5F3A\u4E86\uFF0C\u4E0B\u56FE\u7684\u4EE3\u7801\u53EF\u4EE5\u76F4\u63A5\u8FD0\u884C\u3002https:\/\/t.co\/cj8YKncdcA https:\/\/t.co\/oMaB7zrM4d",
    "id" : 828474622215540737,
    "created_at" : "2017-02-06 05:25:16 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 828582061829074944,
  "created_at" : "2017-02-06 12:32:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Cov7bSL1is",
      "expanded_url" : "http:\/\/GitLab.com",
      "display_url" : "GitLab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "827098031774248966",
  "text" : "RT @ruanyf: https:\/\/t.co\/Cov7bSL1is\u8FD9\u6B21\u9EBB\u70E6\u4E86\uFF0C\u6570\u636E\u5E93\u7EF4\u62A4\u65F6\uFF0Crm -rf \u5220\u4E86300GB \u751F\u4EA7\u73AF\u5883\u6570\u636E\u3002\u7B49\u5230\u6E05\u9192\u8FC7\u6765\u7D27\u6025\u6309\u4E0Bctrl + c\uFF0C\u53EA\u67094.5GB\u4FDD\u7559\u4E0B\u6765\u3002\u7136\u540E\u6062\u590D\u5907\u4EFD\u5931\u8D25\uFF0C\u7F51\u7AD9\u5DF2\u7ECF\u5B95\u4E8610\u4E2A\u5C0F\u65F6\uFF0C\u73B0\u5728\u8FD8\u6CA1\u6062\u590D\u3002https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/826693852194971648\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/ThDw6b5cCE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C3kBpzuUcAAJSoP.jpg",
        "id_str" : "826693824369946624",
        "id" : 826693824369946624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C3kBpzuUcAAJSoP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 792
        } ],
        "display_url" : "pic.twitter.com\/ThDw6b5cCE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/Cov7bSL1is",
        "expanded_url" : "http:\/\/GitLab.com",
        "display_url" : "GitLab.com"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ixVo0qqubc",
        "expanded_url" : "https:\/\/www.theregister.co.uk\/2017\/02\/01\/gitlab_data_loss\/?mt=1485933661486",
        "display_url" : "theregister.co.uk\/2017\/02\/01\/git\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "826693852194971648",
    "text" : "https:\/\/t.co\/Cov7bSL1is\u8FD9\u6B21\u9EBB\u70E6\u4E86\uFF0C\u6570\u636E\u5E93\u7EF4\u62A4\u65F6\uFF0Crm -rf \u5220\u4E86300GB \u751F\u4EA7\u73AF\u5883\u6570\u636E\u3002\u7B49\u5230\u6E05\u9192\u8FC7\u6765\u7D27\u6025\u6309\u4E0Bctrl + c\uFF0C\u53EA\u67094.5GB\u4FDD\u7559\u4E0B\u6765\u3002\u7136\u540E\u6062\u590D\u5907\u4EFD\u5931\u8D25\uFF0C\u7F51\u7AD9\u5DF2\u7ECF\u5B95\u4E8610\u4E2A\u5C0F\u65F6\uFF0C\u73B0\u5728\u8FD8\u6CA1\u6062\u590D\u3002https:\/\/t.co\/ixVo0qqubc https:\/\/t.co\/ThDw6b5cCE",
    "id" : 826693852194971648,
    "created_at" : "2017-02-01 07:29:08 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 827098031774248966,
  "created_at" : "2017-02-02 10:15:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "827096922171142144",
  "text" : "RT @williamlong: \u3010\u8C37\u6B4C\u5168\u5458\u505C\u5DE5\uFF0C\u6297\u8BAE\u5DDD\u666E\u79FB\u6C11\u65B0\u653F\u3011\u7F8E\u56FD\u65F6\u95F41\u670830\u65E5\u4E0B\u5348\uFF0C\u8C37\u6B4C\u5168\u4F53\u96C7\u5458\u505C\u6B62\u5DE5\u4F5C\uFF0C\u5728\u5168\u7403\u529E\u516C\u5BA4\u95E8\u53E3\u96C6\u7ED3\u6297\u8BAE\u7279\u6717\u666E\u65B0\u79FB\u6C11\u653F\u7B56\uFF0C\u8C37\u6B4CCEO\u6851\u8FBE\u00B7\u76AE\u67E5\u4F0A\u5F53\u5929\u4E5F\u7AD9\u51FA\u6765\u53D1\u8A00\uFF0C\u79F0\u8C37\u6B4C\u7684\u521B\u59CB\u4EBA\u4E5F\u662F\u79FB\u6C11\uFF0C\u8FD9\u662F\u8C37\u6B4C\u5171\u540C\u7684\u6545\u4E8B\uFF0C\u201C\u5728\u8FD9\u4EF6\u4E8B\u4E0A\u6211\u4EEC\u51B3\u4E0D\u59A5\u534F\uFF01\u201D \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "826719804346220544",
    "text" : "\u3010\u8C37\u6B4C\u5168\u5458\u505C\u5DE5\uFF0C\u6297\u8BAE\u5DDD\u666E\u79FB\u6C11\u65B0\u653F\u3011\u7F8E\u56FD\u65F6\u95F41\u670830\u65E5\u4E0B\u5348\uFF0C\u8C37\u6B4C\u5168\u4F53\u96C7\u5458\u505C\u6B62\u5DE5\u4F5C\uFF0C\u5728\u5168\u7403\u529E\u516C\u5BA4\u95E8\u53E3\u96C6\u7ED3\u6297\u8BAE\u7279\u6717\u666E\u65B0\u79FB\u6C11\u653F\u7B56\uFF0C\u8C37\u6B4CCEO\u6851\u8FBE\u00B7\u76AE\u67E5\u4F0A\u5F53\u5929\u4E5F\u7AD9\u51FA\u6765\u53D1\u8A00\uFF0C\u79F0\u8C37\u6B4C\u7684\u521B\u59CB\u4EBA\u4E5F\u662F\u79FB\u6C11\uFF0C\u8FD9\u662F\u8C37\u6B4C\u5171\u540C\u7684\u6545\u4E8B\uFF0C\u201C\u5728\u8FD9\u4EF6\u4E8B\u4E0A\u6211\u4EEC\u51B3\u4E0D\u59A5\u534F\uFF01\u201D \u2026",
    "id" : 826719804346220544,
    "created_at" : "2017-02-01 09:12:15 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 827096922171142144,
  "created_at" : "2017-02-02 10:10:47 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]