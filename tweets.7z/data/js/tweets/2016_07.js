Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/VAvcBlrcsN",
      "expanded_url" : "https:\/\/github.com\/dou4cc\/drool",
      "display_url" : "github.com\/dou4cc\/drool"
    } ]
  },
  "geo" : { },
  "id_str" : "758479903553495041",
  "text" : "\u6211\u8BBE\u8BA1\u4E86\u4E00\u95E8\u8F7B\u91CF\u6807\u8BB0\u8BED\u8A00\u2014\u2014drool\uFF1Ahttps:\/\/t.co\/VAvcBlrcsN",
  "id" : 758479903553495041,
  "created_at" : "2016-07-28 01:51:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 3, 18 ],
      "id_str" : "254148157",
      "id" : 254148157
    }, {
      "name" : "\u7EBD\u7EA6\u65F6\u62A5\u4E2D\u6587\u7F51",
      "screen_name" : "nytchinese",
      "indices" : [ 81, 92 ],
      "id_str" : "620632841",
      "id" : 620632841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/efl4D1ziL6",
      "expanded_url" : "http:\/\/cn.nytimes.com\/china\/20160726\/china-media-sina-sohu-netease-phoenix\/",
      "display_url" : "cn.nytimes.com\/china\/20160726\u2026"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Sr41vIqPzk",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=org.greatfire.nyt",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758137135371325441",
  "text" : "RT @GreatFireChina: \u4E2D\u56FD\u591A\u5BB6\u95E8\u6237\u7F51\u7AD9\u539F\u521B\u65B0\u95FB\u680F\u76EE\u906D\u5173\u505C - \u7EBD\u7EA6\u65F6\u62A5\u4E2D\u6587\u7F51 \u56FD\u9645\u7EB5\u89C8 https:\/\/t.co\/efl4D1ziL6 via @nytchinese and https:\/\/t.co\/Sr41vIqPzk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u7EBD\u7EA6\u65F6\u62A5\u4E2D\u6587\u7F51",
        "screen_name" : "nytchinese",
        "indices" : [ 61, 72 ],
        "id_str" : "620632841",
        "id" : 620632841
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/efl4D1ziL6",
        "expanded_url" : "http:\/\/cn.nytimes.com\/china\/20160726\/china-media-sina-sohu-netease-phoenix\/",
        "display_url" : "cn.nytimes.com\/china\/20160726\u2026"
      }, {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/Sr41vIqPzk",
        "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=org.greatfire.nyt",
        "display_url" : "play.google.com\/store\/apps\/det\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757841117710684160",
    "text" : "\u4E2D\u56FD\u591A\u5BB6\u95E8\u6237\u7F51\u7AD9\u539F\u521B\u65B0\u95FB\u680F\u76EE\u906D\u5173\u505C - \u7EBD\u7EA6\u65F6\u62A5\u4E2D\u6587\u7F51 \u56FD\u9645\u7EB5\u89C8 https:\/\/t.co\/efl4D1ziL6 via @nytchinese and https:\/\/t.co\/Sr41vIqPzk",
    "id" : 757841117710684160,
    "created_at" : "2016-07-26 07:32:57 +0000",
    "user" : {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "protected" : false,
      "id_str" : "254148157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794103496836517888\/BE7Ek2ae_normal.jpg",
      "id" : 254148157,
      "verified" : true
    }
  },
  "id" : 758137135371325441,
  "created_at" : "2016-07-27 03:09:13 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756475124052668416",
  "text" : "RT @williamlong: \u4E2D\u56FD\u817E\u8BAF\u7F51\u672C\u6708\u521D\u5728\u62A5\u9053\u4E2D\u5171\u6210\u7ACB95\u5468\u5E74\u5927\u4F1A\u65F6\uFF0C\u62A5\u9053\u4E2D\u5C06\u201C\u4E60\u8FD1\u5E73\u53D1\u8868\u91CD\u8981\u8BB2\u8BDD\u201D\u8BEF\u4E3A\u201C\u53D1\u98D9\u91CD\u8981\u8BB2\u8BDD\u201D\uFF0C\u4E2D\u5BA3\u90E8\u51B3\u5B9A\u5C06\u817E\u8BAF\u7F51\u603B\u7F16\u548C\u4E3B\u7F16\u64A4\u804C\uFF0C\u8BE5\u7F51\u7AD9\u4E5F\u4ECE\u7531\u6DF1\u5733\u7F51\u4FE1\u529E\u76D1\u7BA1\u6539\u4E3A\u7531\u5317\u4EAC\u7F51\u4FE1\u529E\u76F4\u63A5\u7BA1\u7406\u3002\u6D88\u606F\u4EBA\u58EB\u6307\u51FA\uFF0C\u201C\u53D1\u98D9\u201D\u4E8B\u4EF6\u4EE4\u9AD8\u5C42\u5927\u4E3A\u607C\u706B\uFF0C\u5B9A\u6027\u4E3A\u201C\u91CD\u5927\u8D1F\u9762\u4E8B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756302882559762432",
    "text" : "\u4E2D\u56FD\u817E\u8BAF\u7F51\u672C\u6708\u521D\u5728\u62A5\u9053\u4E2D\u5171\u6210\u7ACB95\u5468\u5E74\u5927\u4F1A\u65F6\uFF0C\u62A5\u9053\u4E2D\u5C06\u201C\u4E60\u8FD1\u5E73\u53D1\u8868\u91CD\u8981\u8BB2\u8BDD\u201D\u8BEF\u4E3A\u201C\u53D1\u98D9\u91CD\u8981\u8BB2\u8BDD\u201D\uFF0C\u4E2D\u5BA3\u90E8\u51B3\u5B9A\u5C06\u817E\u8BAF\u7F51\u603B\u7F16\u548C\u4E3B\u7F16\u64A4\u804C\uFF0C\u8BE5\u7F51\u7AD9\u4E5F\u4ECE\u7531\u6DF1\u5733\u7F51\u4FE1\u529E\u76D1\u7BA1\u6539\u4E3A\u7531\u5317\u4EAC\u7F51\u4FE1\u529E\u76F4\u63A5\u7BA1\u7406\u3002\u6D88\u606F\u4EBA\u58EB\u6307\u51FA\uFF0C\u201C\u53D1\u98D9\u201D\u4E8B\u4EF6\u4EE4\u9AD8\u5C42\u5927\u4E3A\u607C\u706B\uFF0C\u5B9A\u6027\u4E3A\u201C\u91CD\u5927\u8D1F\u9762\u4E8B\u4EF6\u201D\uFF0C\u4E2D\u5BA3\u90E8\u7275\u5934\u5C0F\u7EC4\u8FDB\u9A7B\u817E\u8BAF\u8C03\u67E5\u3002",
    "id" : 756302882559762432,
    "created_at" : "2016-07-22 01:40:33 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 756475124052668416,
  "created_at" : "2016-07-22 13:04:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/aeHxduinLT",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/755596812791255041",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756001602457079809",
  "text" : "\u62B5\u5236\u4E50\u89C6\uFF0C\u8FD8\u6211\u5FEB\u64AD\uFF01 https:\/\/t.co\/aeHxduinLT",
  "id" : 756001602457079809,
  "created_at" : "2016-07-21 05:43:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755743396996653056",
  "text" : "RT @williamlong: 7\u670820\u65E5\u51CC\u6668\uFF0C\u4E2D\u56FD\u6700\u5927\u6F0F\u6D1E\u62A5\u544A\u5E73\u53F0\u4E4C\u4E91\u7F51\u7A81\u7136\u65E0\u6CD5\u8BBF\u95EE\u3002\u7F51\u7AD9\u516C\u544A\u79F0\uFF0C\u4E4C\u4E91\u53CA\u76F8\u5173\u670D\u52A1\u5C06\u5347\u7EA7\uFF0C\u5E76\u79F0\u5C06\u5728\u6700\u77ED\u65F6\u95F4\u5185\u56DE\u5F52\u3002\u4E4C\u4E91\u7684\u6574\u6CBB\u884C\u52A8\uFF0C\u53EF\u80FD\u4E0E\u56FD\u5185\u201C\u767D\u5E3D\u5B50\u201D\u9ED1\u5BA2\u5708\u5B50\u91CC\u5173\u6CE8\u5EA6\u6700\u9AD8\u7684\u201C\u8881\u709C\u4E8B\u4EF6\u201D\u6709\u5173\u8054\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755683537764904961",
    "text" : "7\u670820\u65E5\u51CC\u6668\uFF0C\u4E2D\u56FD\u6700\u5927\u6F0F\u6D1E\u62A5\u544A\u5E73\u53F0\u4E4C\u4E91\u7F51\u7A81\u7136\u65E0\u6CD5\u8BBF\u95EE\u3002\u7F51\u7AD9\u516C\u544A\u79F0\uFF0C\u4E4C\u4E91\u53CA\u76F8\u5173\u670D\u52A1\u5C06\u5347\u7EA7\uFF0C\u5E76\u79F0\u5C06\u5728\u6700\u77ED\u65F6\u95F4\u5185\u56DE\u5F52\u3002\u4E4C\u4E91\u7684\u6574\u6CBB\u884C\u52A8\uFF0C\u53EF\u80FD\u4E0E\u56FD\u5185\u201C\u767D\u5E3D\u5B50\u201D\u9ED1\u5BA2\u5708\u5B50\u91CC\u5173\u6CE8\u5EA6\u6700\u9AD8\u7684\u201C\u8881\u709C\u4E8B\u4EF6\u201D\u6709\u5173\u8054\u3002",
    "id" : 755683537764904961,
    "created_at" : "2016-07-20 08:39:29 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 755743396996653056,
  "created_at" : "2016-07-20 12:37:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754698196232699904",
  "text" : "RT @williamlong: \u5FC3\u7406\u5B66\u5BB6\u5510\u6620\u7EA2\u5206\u6790\uFF0C\u53EA\u8981\u628A\u4EBA\u7FA4\u5206\u4E3A\u201C\u6211\u4EEC\u201D\u548C\u201C\u4ED6\u4EEC\u201D\uFF0C\u4EBA\u4EEC\u4F1A\u81EA\u52A8\u5730\u51FA\u73B0\u7FA4\u4F53\u504F\u597D\uFF1B\u4E00\u4E9B\u793E\u4F1A\u6210\u5458\u53EF\u80FD\u56E0\u4E3A\u65E0\u6CD5\u4ECE\u65E5\u5E38\u751F\u6D3B\u4E2D\u6B63\u5E38\u83B7\u5F97\u81EA\u5C0A\u611F\u7684\u6EE1\u8DB3\uFF0C\u800C\u6295\u8EAB\u5230\u7FA4\u4F53\u6027\u7684\u8FD0\u52A8\u4E2D\uFF0C\u8FC5\u901F\u63D0\u5347\u81EA\u8EAB\u7684\u81EA\u5C0A\u611F\uFF0C\u4F46\u8FD9\u79CD\u4E0D\u7A33\u5B9A\u3001\u8106\u5F31\u7684\u81EA\u5C0A\u611F\uFF0C\u53EF\u80FD\u5BFC\u81F4\u4ED6\u4EEC\u505A\u51FA\u6781\u7AEF\u884C\u4E3A\uFF0C\u5BF9\u4ED6\u4EBA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754498300422811648",
    "text" : "\u5FC3\u7406\u5B66\u5BB6\u5510\u6620\u7EA2\u5206\u6790\uFF0C\u53EA\u8981\u628A\u4EBA\u7FA4\u5206\u4E3A\u201C\u6211\u4EEC\u201D\u548C\u201C\u4ED6\u4EEC\u201D\uFF0C\u4EBA\u4EEC\u4F1A\u81EA\u52A8\u5730\u51FA\u73B0\u7FA4\u4F53\u504F\u597D\uFF1B\u4E00\u4E9B\u793E\u4F1A\u6210\u5458\u53EF\u80FD\u56E0\u4E3A\u65E0\u6CD5\u4ECE\u65E5\u5E38\u751F\u6D3B\u4E2D\u6B63\u5E38\u83B7\u5F97\u81EA\u5C0A\u611F\u7684\u6EE1\u8DB3\uFF0C\u800C\u6295\u8EAB\u5230\u7FA4\u4F53\u6027\u7684\u8FD0\u52A8\u4E2D\uFF0C\u8FC5\u901F\u63D0\u5347\u81EA\u8EAB\u7684\u81EA\u5C0A\u611F\uFF0C\u4F46\u8FD9\u79CD\u4E0D\u7A33\u5B9A\u3001\u8106\u5F31\u7684\u81EA\u5C0A\u611F\uFF0C\u53EF\u80FD\u5BFC\u81F4\u4ED6\u4EEC\u505A\u51FA\u6781\u7AEF\u884C\u4E3A\uFF0C\u5BF9\u4ED6\u4EBA\u6216\u4ED6\u7FA4\u4F53\u7684\u8D2C\u635F\u3001\u6253\u538B\u751A\u81F3\u66B4\u529B\u4FB5\u72AF\u3002",
    "id" : 754498300422811648,
    "created_at" : "2016-07-17 02:09:47 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 754698196232699904,
  "created_at" : "2016-07-17 15:24:06 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/gBkNk0UBk3",
      "expanded_url" : "https:\/\/twitter.com\/GreatFireChina\/status\/753466602587381760",
      "display_url" : "twitter.com\/GreatFireChina\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753497249850679296",
  "text" : "6\u6708\u53D1\u751F\u4E86\u4EC0\u4E48\uFF1F https:\/\/t.co\/gBkNk0UBk3",
  "id" : 753497249850679296,
  "created_at" : "2016-07-14 07:51:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750884098294419457",
  "text" : "RT @williamlong: \u3010Twitter\u9996\u6B21\u62AB\u9732\u4E2D\u56FD\u7528\u6237\u6570\u91CF:\u7EA61000\u4E07\u6D3B\u8DC3\u7528\u6237\u3011Twitter\u4F30\u8BA1\u5728\u4E2D\u56FD\u7EA6\u67091000\u4E07\u6D3B\u8DC3\u7528\u6237\uFF0C\u4E0D\u8FC7\u4E2D\u56FD\u7684Twitter\u7528\u6237\u770B\u8D77\u6765\u50CF\u662F\u5728\u7F8E\u56FD\u3001\u6FB3\u5927\u5229\u4E9A\u6216\u8005\u522B\u7684\u5730\u533A\u8BBF\u95EE\u8BE5\u9879\u670D\u52A1\u3002\u56E0\u6B64\uFF0C\u8981\u5B9E\u9645\u7EDF\u8BA1\u51FA\u4E2D\u56FD\u7684\u7528\u6237\u91CF\u975E\u5E38\u56F0\u96BE\u3002Twitter\u5728\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750498990584725504",
    "text" : "\u3010Twitter\u9996\u6B21\u62AB\u9732\u4E2D\u56FD\u7528\u6237\u6570\u91CF:\u7EA61000\u4E07\u6D3B\u8DC3\u7528\u6237\u3011Twitter\u4F30\u8BA1\u5728\u4E2D\u56FD\u7EA6\u67091000\u4E07\u6D3B\u8DC3\u7528\u6237\uFF0C\u4E0D\u8FC7\u4E2D\u56FD\u7684Twitter\u7528\u6237\u770B\u8D77\u6765\u50CF\u662F\u5728\u7F8E\u56FD\u3001\u6FB3\u5927\u5229\u4E9A\u6216\u8005\u522B\u7684\u5730\u533A\u8BBF\u95EE\u8BE5\u9879\u670D\u52A1\u3002\u56E0\u6B64\uFF0C\u8981\u5B9E\u9645\u7EDF\u8BA1\u51FA\u4E2D\u56FD\u7684\u7528\u6237\u91CF\u975E\u5E38\u56F0\u96BE\u3002Twitter\u5728\u7F8E\u56FD\u5E02\u573A\u7684\u6D3B\u8DC3\u7528\u6237\u91CF\u4E3A6500\u4E07\u3002",
    "id" : 750498990584725504,
    "created_at" : "2016-07-06 01:17:57 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 750884098294419457,
  "created_at" : "2016-07-07 02:48:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/zjLyifzGBa",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/748412228768980992",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748872882902695936",
  "text" : "\u662F\u65F6\u5019\u8BD5\u8BD5\u58F0\u6CE2\u8054\u7F51\u3002 https:\/\/t.co\/zjLyifzGBa",
  "id" : 748872882902695936,
  "created_at" : "2016-07-01 13:36:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]