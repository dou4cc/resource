Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746307829695315968",
  "text" : "RT @williamlong: \u82F1\u8131\u6B27\u516C\u6295\u7ED3\u679C\u6B63\u5F0F\u51FA\u7089\uFF1A\u8131\u6B27\u6D3E51.9%\uFF0C\u7559\u6B27\u6D3E48.1%\u3002\u82F1\u56FD\u9996\u76F8\u5361\u6885\u4F26\u5BA3\u5E03\u8F9E\u804C\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746251823556730880",
    "text" : "\u82F1\u8131\u6B27\u516C\u6295\u7ED3\u679C\u6B63\u5F0F\u51FA\u7089\uFF1A\u8131\u6B27\u6D3E51.9%\uFF0C\u7559\u6B27\u6D3E48.1%\u3002\u82F1\u56FD\u9996\u76F8\u5361\u6885\u4F26\u5BA3\u5E03\u8F9E\u804C\u3002",
    "id" : 746251823556730880,
    "created_at" : "2016-06-24 08:01:14 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 746307829695315968,
  "created_at" : "2016-06-24 11:43:46 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 16, 28 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743081981827653634",
  "text" : "RT @cuimengren: @williamlong \u770B\u5230\u5373\u5C06\u592A\u76D1\u7684\u56FD\u5916\u8F6F\u4EF6\u5B66\u4F1A\u800D\u6D41\u6C13\u6211\u4E5F\u5C31\u653E\u5FC3\u4E86\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u6708\u5149\u535A\u5BA2",
        "screen_name" : "williamlong",
        "indices" : [ 0, 12 ],
        "id_str" : "2786701",
        "id" : 2786701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "742170425350819840",
    "geo" : { },
    "id_str" : "742199472365522944",
    "in_reply_to_user_id" : 2786701,
    "text" : "@williamlong \u770B\u5230\u5373\u5C06\u592A\u76D1\u7684\u56FD\u5916\u8F6F\u4EF6\u5B66\u4F1A\u800D\u6D41\u6C13\u6211\u4E5F\u5C31\u653E\u5FC3\u4E86\u3002",
    "id" : 742199472365522944,
    "in_reply_to_status_id" : 742170425350819840,
    "created_at" : "2016-06-13 03:38:38 +0000",
    "in_reply_to_screen_name" : "williamlong",
    "in_reply_to_user_id_str" : "2786701",
    "user" : {
      "name" : "\u5B5F\u4EC1",
      "screen_name" : "zncmr",
      "protected" : false,
      "id_str" : "240186505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922320175939981313\/22Ru6VAh_normal.jpg",
      "id" : 240186505,
      "verified" : false
    }
  },
  "id" : 743081981827653634,
  "created_at" : "2016-06-15 14:05:24 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741650655459332097",
  "text" : "TorBrowser\u597D\u50CF\u81EA\u5E26CNNIC\u3002",
  "id" : 741650655459332097,
  "created_at" : "2016-06-11 15:17:50 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/KmXpSTklmy",
      "expanded_url" : "https:\/\/twitter.com\/github\/status\/740613397226610689",
      "display_url" : "twitter.com\/github\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741288292335783936",
  "text" : "HTTPS\u5927\u6CD5\u597D https:\/\/t.co\/KmXpSTklmy",
  "id" : 741288292335783936,
  "created_at" : "2016-06-10 15:17:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6CE1\u6CE1",
      "screen_name" : "paopaonet",
      "indices" : [ 36, 46 ],
      "id_str" : "2292814356",
      "id" : 2292814356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/v8YlkFiJF4",
      "expanded_url" : "https:\/\/github.com\/getlantern\/lantern\/issues\/4529",
      "display_url" : "github.com\/getlantern\/lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739744825596076032",
  "text" : "Lantern\u5B8C\u5168\u5931\u6548\uFF1Ahttps:\/\/t.co\/v8YlkFiJF4\n@paopaonet",
  "id" : 739744825596076032,
  "created_at" : "2016-06-06 09:04:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739677302984835072",
  "text" : "RT @williamlong: \u3010\u5BC6\u7801\u91CD\u590D\u4F7F\u7528 \u624E\u514B\u4F2F\u683C\u591A\u4E2A\u8D26\u6237\u88AB\u9ED1\u3011\u624E\u514B\u4F2F\u683C\u7684\u63A8\u7279\u3001Pinterest\u548CInstagram\u8D26\u6237\u90FD\u88AB\u9ED1\u5BA2\u653B\u7834\uFF0C\u56E0\u4E3A\u4ED6\u5728\u8FD9\u4E9B\u7F51\u7AD9\u90FD\u4F7F\u7528\u4E86\u4E0E\u9886\u82F1\u4E00\u6837\u7684\u5BC6\u7801\uFF0C\u800C\u9886\u82F12012\u5E74\u66FE\u6709\u8D85\u8FC7100\u4E07\u5BC6\u7801\u88AB\u76D7\uFF0C\u4E0D\u4E45\u524D\u5168\u90E8\u88AB\u4F20\u5230\u4E86\u7F51\u4E0A\u3002\u7814\u7A76\u53D1\u73B0\uFF0C55%\u7684\u4E92\u8054\u7F51\u7528\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739648815586775040",
    "text" : "\u3010\u5BC6\u7801\u91CD\u590D\u4F7F\u7528 \u624E\u514B\u4F2F\u683C\u591A\u4E2A\u8D26\u6237\u88AB\u9ED1\u3011\u624E\u514B\u4F2F\u683C\u7684\u63A8\u7279\u3001Pinterest\u548CInstagram\u8D26\u6237\u90FD\u88AB\u9ED1\u5BA2\u653B\u7834\uFF0C\u56E0\u4E3A\u4ED6\u5728\u8FD9\u4E9B\u7F51\u7AD9\u90FD\u4F7F\u7528\u4E86\u4E0E\u9886\u82F1\u4E00\u6837\u7684\u5BC6\u7801\uFF0C\u800C\u9886\u82F12012\u5E74\u66FE\u6709\u8D85\u8FC7100\u4E07\u5BC6\u7801\u88AB\u76D7\uFF0C\u4E0D\u4E45\u524D\u5168\u90E8\u88AB\u4F20\u5230\u4E86\u7F51\u4E0A\u3002\u7814\u7A76\u53D1\u73B0\uFF0C55%\u7684\u4E92\u8054\u7F51\u7528\u6237\u90FD\u5728\u81EA\u5DF1\u6CE8\u518C\u7684\u5927\u591A\u6570\u7F51\u7AD9\u4F7F\u7528\u540C\u6837\u2026",
    "id" : 739648815586775040,
    "created_at" : "2016-06-06 02:43:14 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 739677302984835072,
  "created_at" : "2016-06-06 04:36:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]