Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/670444363936346112\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/yyyl4MeM3K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU3lmEUVEAEXAe4.png",
      "id_str" : "670444361704869889",
      "id" : 670444361704869889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU3lmEUVEAEXAe4.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 769
      } ],
      "display_url" : "pic.twitter.com\/yyyl4MeM3K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670502069111926784",
  "text" : "RT @ruanyf: \u7B2C\u4E00\u6B21\u770B\u5230\u8FD9\u6837\u7684\u611F\u53F9\uFF1A\u201C\u6211\u7684\u5F00\u6E90\u9879\u76EE\u5DF2\u7ECF\u5931\u63A7\uFF0C\u7528\u5F97\u4EBA\u592A\u591A\uFF0C\u4E0A\u4E2A\u6708\u5B89\u88C5\u8D85\u8FC71\u4E074\u5343\u6B21\uFF0C\u5404\u79CD\u95EE\u9898\u7BA1\u4E0D\u8FC7\u6765\uFF0C\u611F\u89C9\u5F88\u5DEE\u3002\u201D https:\/\/t.co\/yyyl4MeM3K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/670444363936346112\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/yyyl4MeM3K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU3lmEUVEAEXAe4.png",
        "id_str" : "670444361704869889",
        "id" : 670444361704869889,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU3lmEUVEAEXAe4.png",
        "sizes" : [ {
          "h" : 334,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 769
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 769
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 769
        } ],
        "display_url" : "pic.twitter.com\/yyyl4MeM3K"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670444363936346112",
    "text" : "\u7B2C\u4E00\u6B21\u770B\u5230\u8FD9\u6837\u7684\u611F\u53F9\uFF1A\u201C\u6211\u7684\u5F00\u6E90\u9879\u76EE\u5DF2\u7ECF\u5931\u63A7\uFF0C\u7528\u5F97\u4EBA\u592A\u591A\uFF0C\u4E0A\u4E2A\u6708\u5B89\u88C5\u8D85\u8FC71\u4E074\u5343\u6B21\uFF0C\u5404\u79CD\u95EE\u9898\u7BA1\u4E0D\u8FC7\u6765\uFF0C\u611F\u89C9\u5F88\u5DEE\u3002\u201D https:\/\/t.co\/yyyl4MeM3K",
    "id" : 670444363936346112,
    "created_at" : "2015-11-28 03:29:27 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 670502069111926784,
  "created_at" : "2015-11-28 07:18:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669484279584419841",
  "text" : "\u592A\u611F\u52A8\u4E86~\u5341\u4E09\u4E2D\u6559\u5BA4\u673A\u662FUEFI\u3002",
  "id" : 669484279584419841,
  "created_at" : "2015-11-25 11:54:25 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]