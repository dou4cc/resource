Grailbird.data.tweets_2017_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/gZtFO8HfFr",
      "expanded_url" : "https:\/\/twitter.com\/anamewing\/status\/844232598066941952",
      "display_url" : "twitter.com\/anamewing\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "844391698583224322",
  "text" : "\u6211\u4EEC\u4E3A\u4F55\u4F7F\u7528Linux\uFF1F https:\/\/t.co\/gZtFO8HfFr",
  "id" : 844391698583224322,
  "created_at" : "2017-03-22 03:34:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mewing",
      "screen_name" : "anamewing",
      "indices" : [ 3, 13 ],
      "id_str" : "212350178",
      "id" : 212350178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "843434750064939008",
  "text" : "RT @anamewing: \u5927\u5BB6\u80AF\u5B9A\u90FD\u4EE5\u4E3A CIA \u627E\u5230\u4E86 sublime \u7684\u6F0F\u6D1E\uFF0C\u5F53\u4F60\u628A\u8FD9\u6BB5\u6CE8\u518C\u7801\u7C98\u8D34\u5230sublime\u91CC\u7684\u65F6\u5019\u628A\u4E00\u6BB5\u4EE3\u7801\u6CE8\u5165\uFF0C\u7136\u540E\u901A\u8FC7\u5B83\u7559\u4E0B\u540E\u95E8\u3002\u4E0D\u662F\u8FD9\u6837\u7684\uFF01\u5176\u5B9E CIA \u627E\u5230\u4E86\u64CD\u4F5C\u7CFB\u7EDF\u526A\u8D34\u677F\u7684\u6F0F\u6D1E\uFF0C\u5F53\u4F60\u590D\u5236\u7684\u65F6\u5019\uFF0C\u4F60\u7684\u64CD\u4F5C\u7CFB\u7EDF\u88AB\u6CE8\u5165\u7559\u4E0B\u540E\u95E8\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/JV65vRUSJF",
        "expanded_url" : "https:\/\/www.v2ex.com\/t\/345827",
        "display_url" : "v2ex.com\/t\/345827"
      } ]
    },
    "geo" : { },
    "id_str" : "839456420932251649",
    "text" : "\u5927\u5BB6\u80AF\u5B9A\u90FD\u4EE5\u4E3A CIA \u627E\u5230\u4E86 sublime \u7684\u6F0F\u6D1E\uFF0C\u5F53\u4F60\u628A\u8FD9\u6BB5\u6CE8\u518C\u7801\u7C98\u8D34\u5230sublime\u91CC\u7684\u65F6\u5019\u628A\u4E00\u6BB5\u4EE3\u7801\u6CE8\u5165\uFF0C\u7136\u540E\u901A\u8FC7\u5B83\u7559\u4E0B\u540E\u95E8\u3002\u4E0D\u662F\u8FD9\u6837\u7684\uFF01\u5176\u5B9E CIA \u627E\u5230\u4E86\u64CD\u4F5C\u7CFB\u7EDF\u526A\u8D34\u677F\u7684\u6F0F\u6D1E\uFF0C\u5F53\u4F60\u590D\u5236\u7684\u65F6\u5019\uFF0C\u4F60\u7684\u64CD\u4F5C\u7CFB\u7EDF\u88AB\u6CE8\u5165\u7559\u4E0B\u540E\u95E8\nhttps:\/\/t.co\/JV65vRUSJF",
    "id" : 839456420932251649,
    "created_at" : "2017-03-08 12:43:01 +0000",
    "user" : {
      "name" : "mewing",
      "screen_name" : "anamewing",
      "protected" : false,
      "id_str" : "212350178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945675722198151168\/SoyGQh3E_normal.jpg",
      "id" : 212350178,
      "verified" : false
    }
  },
  "id" : 843434750064939008,
  "created_at" : "2017-03-19 12:11:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/842977000738365440\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/o29nohCp3V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C7LbGSVU8AAMorY.jpg",
      "id_str" : "842976981318692864",
      "id" : 842976981318692864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7LbGSVU8AAMorY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 457
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 457
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 457
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 457
      } ],
      "display_url" : "pic.twitter.com\/o29nohCp3V"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/fryg0va3VP",
      "expanded_url" : "https:\/\/github.com\/vvanders\/wasm_lua",
      "display_url" : "github.com\/vvanders\/wasm_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "843048786675032065",
  "text" : "RT @ruanyf: Lua \u865A\u62DF\u673A\u4F7F\u7528 WebAssembly \u5D4C\u5165\u6D4F\u89C8\u5668\uFF0C\u5927\u5C0F\u53EA\u6709 241KB\u3002\u8FD9\u610F\u5473\u7740\uFF0C\u4EE5\u540E\u5B8C\u5168\u53EF\u4EE5\u4F7F\u7528 Lua \u6846\u67B6\u5F00\u53D1\u524D\u7AEF\u5E94\u7528\u3002https:\/\/t.co\/fryg0va3VP https:\/\/t.co\/o29nohCp3V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/842977000738365440\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/o29nohCp3V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C7LbGSVU8AAMorY.jpg",
        "id_str" : "842976981318692864",
        "id" : 842976981318692864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7LbGSVU8AAMorY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 457
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 457
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 457
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 457
        } ],
        "display_url" : "pic.twitter.com\/o29nohCp3V"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/fryg0va3VP",
        "expanded_url" : "https:\/\/github.com\/vvanders\/wasm_lua",
        "display_url" : "github.com\/vvanders\/wasm_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "842977000738365440",
    "text" : "Lua \u865A\u62DF\u673A\u4F7F\u7528 WebAssembly \u5D4C\u5165\u6D4F\u89C8\u5668\uFF0C\u5927\u5C0F\u53EA\u6709 241KB\u3002\u8FD9\u610F\u5473\u7740\uFF0C\u4EE5\u540E\u5B8C\u5168\u53EF\u4EE5\u4F7F\u7528 Lua \u6846\u67B6\u5F00\u53D1\u524D\u7AEF\u5E94\u7528\u3002https:\/\/t.co\/fryg0va3VP https:\/\/t.co\/o29nohCp3V",
    "id" : 842977000738365440,
    "created_at" : "2017-03-18 05:52:33 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 843048786675032065,
  "created_at" : "2017-03-18 10:37:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "843046214891397120",
  "text" : "RT @ruanyf: \u6709\u4E86 WebAssembly\uFF0C\u4E24\u4E09\u5E74\u540E Java \u8BED\u8A00\u5C06\u80FD\u5F00\u53D1\u524D\u7AEF\u5E94\u7528\uFF0C\u8FD9\u4E2A\u884C\u4E1A\u4F1A\u600E\u6837\uFF1F\n\n\u65E0\u6570\u7684\u4F01\u4E1A\u7EA7\u670D\u52A1\uFF0C\u5927\u91CF\u7684\u5DE5\u7A0B\u5E08\uFF0C\u5B8C\u5584\u7684\u6700\u4F73\u5B9E\u8DF5\uFF0C\u6210\u719F\u7684\u5DE5\u7A0B\u4F53\u7CFB\uFF0C\u53EF\u9760\u7684\u7C7B\u578B\u548C\u5305\u7BA1\u7406\u2026\u2026 \u6211\u731C\u6D4B\uFF0CJS \u8BED\u8A00\u5C06\u5931\u53BB\u4F01\u4E1A\u7EA7\u5E02\u573A\u3002 https:\/\/t.co\/mNqzd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/842984230346924033\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/mNqzdX7sfc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C7Lhq_wU4AAguJ_.jpg",
        "id_str" : "842984209056587776",
        "id" : 842984209056587776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C7Lhq_wU4AAguJ_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/mNqzdX7sfc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "842984230346924033",
    "text" : "\u6709\u4E86 WebAssembly\uFF0C\u4E24\u4E09\u5E74\u540E Java \u8BED\u8A00\u5C06\u80FD\u5F00\u53D1\u524D\u7AEF\u5E94\u7528\uFF0C\u8FD9\u4E2A\u884C\u4E1A\u4F1A\u600E\u6837\uFF1F\n\n\u65E0\u6570\u7684\u4F01\u4E1A\u7EA7\u670D\u52A1\uFF0C\u5927\u91CF\u7684\u5DE5\u7A0B\u5E08\uFF0C\u5B8C\u5584\u7684\u6700\u4F73\u5B9E\u8DF5\uFF0C\u6210\u719F\u7684\u5DE5\u7A0B\u4F53\u7CFB\uFF0C\u53EF\u9760\u7684\u7C7B\u578B\u548C\u5305\u7BA1\u7406\u2026\u2026 \u6211\u731C\u6D4B\uFF0CJS \u8BED\u8A00\u5C06\u5931\u53BB\u4F01\u4E1A\u7EA7\u5E02\u573A\u3002 https:\/\/t.co\/mNqzdX7sfc",
    "id" : 842984230346924033,
    "created_at" : "2017-03-18 06:21:17 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 843046214891397120,
  "created_at" : "2017-03-18 10:27:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 3, 18 ],
      "id_str" : "254148157",
      "id" : 254148157
    }, {
      "name" : "DW (\u4E2D\u6587)",
      "screen_name" : "dw_chinese",
      "indices" : [ 67, 78 ],
      "id_str" : "143810986",
      "id" : 143810986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/67VcCrZWlP",
      "expanded_url" : "http:\/\/www.dw.com\/p\/2Ydcp?tw",
      "display_url" : "dw.com\/p\/2Ydcp?tw"
    } ]
  },
  "geo" : { },
  "id_str" : "840389527273377796",
  "text" : "RT @GreatFireChina: \u653F\u534F\u526F\u4E3B\u5E2D\uFF1A\u7F51\u7EDC\u5C01\u9501\u6709\u6096\u5F00\u653E\u53D1\u5C55\u7406\u5FF5 https:\/\/t.co\/67VcCrZWlP via @dw_chinese",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DW (\u4E2D\u6587)",
        "screen_name" : "dw_chinese",
        "indices" : [ 47, 58 ],
        "id_str" : "143810986",
        "id" : 143810986
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/67VcCrZWlP",
        "expanded_url" : "http:\/\/www.dw.com\/p\/2Ydcp?tw",
        "display_url" : "dw.com\/p\/2Ydcp?tw"
      } ]
    },
    "geo" : { },
    "id_str" : "840232791493246977",
    "text" : "\u653F\u534F\u526F\u4E3B\u5E2D\uFF1A\u7F51\u7EDC\u5C01\u9501\u6709\u6096\u5F00\u653E\u53D1\u5C55\u7406\u5FF5 https:\/\/t.co\/67VcCrZWlP via @dw_chinese",
    "id" : 840232791493246977,
    "created_at" : "2017-03-10 16:08:02 +0000",
    "user" : {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "protected" : false,
      "id_str" : "254148157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794103496836517888\/BE7Ek2ae_normal.jpg",
      "id" : 254148157,
      "verified" : true
    }
  },
  "id" : 840389527273377796,
  "created_at" : "2017-03-11 02:30:51 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]