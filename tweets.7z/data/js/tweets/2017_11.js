Grailbird.data.tweets_2017_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/936104674251427841\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/lERNzTt8Yu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DP22FUnW0AEUN61.jpg",
      "id_str" : "936104500112314369",
      "id" : 936104500112314369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP22FUnW0AEUN61.jpg",
      "sizes" : [ {
        "h" : 117,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 117,
        "resize" : "crop",
        "w" : 117
      }, {
        "h" : 117,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 117,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 117,
        "resize" : "fit",
        "w" : 528
      } ],
      "display_url" : "pic.twitter.com\/lERNzTt8Yu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936104674251427841",
  "text" : "Chrome Dev Tools\u7684Console\u662F\u600E\u9EBD\u505A\u5230\u652F\u6301await\u537B\u4E0D\u80FDreturn\u7684\uFF1F https:\/\/t.co\/lERNzTt8Yu",
  "id" : 936104674251427841,
  "created_at" : "2017-11-30 05:28:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/IvAXtHC9Uc",
      "expanded_url" : "https:\/\/www.windowscentral.com\/windows-10-sets-announcement?utm_source=wc_tw&utm_medium=tw_card&utm_content=52493&utm_campaign=social",
      "display_url" : "windowscentral.com\/windows-10-set\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936100566610120704",
  "text" : "All in Edge\uFF1Ahttps:\/\/t.co\/IvAXtHC9Uc",
  "id" : 936100566610120704,
  "created_at" : "2017-11-30 05:12:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u901D\u8005\u7684\u5929\u7A7A",
      "screen_name" : "Air_Mu",
      "indices" : [ 0, 7 ],
      "id_str" : "165407871",
      "id" : 165407871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934190770638143488",
  "geo" : { },
  "id_str" : "936077296800354304",
  "in_reply_to_user_id" : 165407871,
  "text" : "@Air_Mu \u8FD1\u8996\u7684\u6211\u90231080p\u548C720p\u90FD\u5206\u8FA8\u4E0D\u6E05\u3002",
  "id" : 936077296800354304,
  "in_reply_to_status_id" : 934190770638143488,
  "created_at" : "2017-11-30 03:39:53 +0000",
  "in_reply_to_screen_name" : "Air_Mu",
  "in_reply_to_user_id_str" : "165407871",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/936064518739939328\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hJ0foyZWPU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DP2RtSRVQAIFBVp.jpg",
      "id_str" : "936064504747606018",
      "id" : 936064504747606018,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP2RtSRVQAIFBVp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/hJ0foyZWPU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "936061997187260416",
  "geo" : { },
  "id_str" : "936064518739939328",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/hJ0foyZWPU",
  "id" : 936064518739939328,
  "in_reply_to_status_id" : 936061997187260416,
  "created_at" : "2017-11-30 02:49:07 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/936061997187260416\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/HZuKWvVTok",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DP2PYY_X4AAn7_u.jpg",
      "id_str" : "936061946750820352",
      "id" : 936061946750820352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP2PYY_X4AAn7_u.jpg",
      "sizes" : [ {
        "h" : 625,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/HZuKWvVTok"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "935747253393817601",
  "geo" : { },
  "id_str" : "936061997187260416",
  "in_reply_to_user_id" : 3359880735,
  "text" : "Attend a protest! https:\/\/t.co\/HZuKWvVTok",
  "id" : 936061997187260416,
  "in_reply_to_status_id" : 935747253393817601,
  "created_at" : "2017-11-30 02:39:05 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/6zfUiNy8L0",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/11\/20_29.html",
      "display_url" : "molihua.org\/2017\/11\/20_29.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935903493512224769",
  "text" : "\u5BE7\u6CE2\u5927\u7206\u70B8\uFF1Ahttps:\/\/t.co\/6zfUiNy8L0",
  "id" : 935903493512224769,
  "created_at" : "2017-11-29 16:09:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/jeX87sbKAN",
      "expanded_url" : "http:\/\/www.ftchinese.com\/story\/001075262",
      "display_url" : "ftchinese.com\/story\/001075262"
    } ]
  },
  "geo" : { },
  "id_str" : "935895242829594626",
  "text" : "\u5317\u4EAC\u81F3\u5C11135\u500B\u5C0F\u5340\u88AB\u6E05\u7406\uFF1Ahttps:\/\/t.co\/jeX87sbKAN",
  "id" : 935895242829594626,
  "created_at" : "2017-11-29 15:36:28 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy-_-Yeung",
      "screen_name" : "andyyeung12",
      "indices" : [ 3, 15 ],
      "id_str" : "2885868440",
      "id" : 2885868440
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/andyyeung12\/status\/935075795029999616\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/O8oqs4w2wS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPoOd9IUEAALV4k.jpg",
      "id_str" : "935075780421226496",
      "id" : 935075780421226496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPoOd9IUEAALV4k.jpg",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/O8oqs4w2wS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935800837888204802",
  "text" : "RT @andyyeung12: \u5E7F\u5DDE\u4E5F\u5F00\u59CB\u4E86\u2026\u679C\u7136\u662F\u573A\u8FD0\u52A8 https:\/\/t.co\/O8oqs4w2wS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/andyyeung12\/status\/935075795029999616\/photo\/1",
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/O8oqs4w2wS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPoOd9IUEAALV4k.jpg",
        "id_str" : "935075780421226496",
        "id" : 935075780421226496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPoOd9IUEAALV4k.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/O8oqs4w2wS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "935075795029999616",
    "text" : "\u5E7F\u5DDE\u4E5F\u5F00\u59CB\u4E86\u2026\u679C\u7136\u662F\u573A\u8FD0\u52A8 https:\/\/t.co\/O8oqs4w2wS",
    "id" : 935075795029999616,
    "created_at" : "2017-11-27 09:20:17 +0000",
    "user" : {
      "name" : "Andy-_-Yeung",
      "screen_name" : "andyyeung12",
      "protected" : false,
      "id_str" : "2885868440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528451935154606080\/wmHltCcM_normal.jpeg",
      "id" : 2885868440,
      "verified" : false
    }
  },
  "id" : 935800837888204802,
  "created_at" : "2017-11-29 09:21:20 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/935797339465412608\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/w42JnG7NtA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPyetypWAAAqZDj.jpg",
      "id_str" : "935797332112703488",
      "id" : 935797332112703488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPyetypWAAAqZDj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 867
      } ],
      "display_url" : "pic.twitter.com\/w42JnG7NtA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935797339465412608",
  "text" : "Chrome\u7981\u7528IDN\u540E\u628Apath\u7684\u8F49\u7FA9\u4E5F\u5EE2\u4E86: https:\/\/t.co\/w42JnG7NtA",
  "id" : 935797339465412608,
  "created_at" : "2017-11-29 09:07:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79E6\u515D\u7684\u8DEF\u7531\u5668",
      "screen_name" : "fqrouter",
      "indices" : [ 3, 12 ],
      "id_str" : "281579156",
      "id" : 281579156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935765746784849920",
  "text" : "RT @fqrouter: \u9274\u4E8E RGB \u4E8B\u4EF6\u7684\u75AF\u72C2\u5220\u5E16\uFF0Cfqrouter \u5373\u5C06\u91CD\u542F\u5F00\u53D1\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "935746562701086722",
    "text" : "\u9274\u4E8E RGB \u4E8B\u4EF6\u7684\u75AF\u72C2\u5220\u5E16\uFF0Cfqrouter \u5373\u5C06\u91CD\u542F\u5F00\u53D1\u3002",
    "id" : 935746562701086722,
    "created_at" : "2017-11-29 05:45:40 +0000",
    "user" : {
      "name" : "\u79E6\u515D\u7684\u8DEF\u7531\u5668",
      "screen_name" : "fqrouter",
      "protected" : false,
      "id_str" : "281579156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000094913530\/09f2a4652f78fbfc91eb40cdadc2668e_normal.png",
      "id" : 281579156,
      "verified" : false
    }
  },
  "id" : 935765746784849920,
  "created_at" : "2017-11-29 07:01:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/lbngn9vHzY",
      "expanded_url" : "https:\/\/cn.nytimes.com\/asia-pacific\/20171129\/north-korea-missile-test\/",
      "display_url" : "cn.nytimes.com\/asia-pacific\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935759488224768007",
  "text" : "\u671D\u9BAE\u5C0E\u5F48\u5C04\u7A0B\u8986\u84CB\u7F8E\u570B\u5404\u5DDE\uFF1Ahttps:\/\/t.co\/lbngn9vHzY",
  "id" : 935759488224768007,
  "created_at" : "2017-11-29 06:37:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/t33EZebvQk",
      "expanded_url" : "http:\/\/www.bbc.com\/zhongwen\/simp\/chinese-news-42149747",
      "display_url" : "bbc.com\/zhongwen\/simp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935757467656613888",
  "text" : "\u674E\u660E\u54F2\u73FE\u8EAB\uFF0C\u985B\u8986\u570B\u5BB6\u88AB\u52245\u5E74\uFF1Ahttps:\/\/t.co\/t33EZebvQk",
  "id" : 935757467656613888,
  "created_at" : "2017-11-29 06:29:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/935747253393817601\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/j6JiVoNJom",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPxxKGmW0AAPcNO.jpg",
      "id_str" : "935747240970342400",
      "id" : 935747240970342400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPxxKGmW0AAPcNO.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/j6JiVoNJom"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "935320635189944321",
  "geo" : { },
  "id_str" : "935747253393817601",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/j6JiVoNJom",
  "id" : 935747253393817601,
  "in_reply_to_status_id" : 935320635189944321,
  "created_at" : "2017-11-29 05:48:25 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/7QvAW2wCdp",
      "expanded_url" : "https:\/\/archive.is\/Mox9X",
      "display_url" : "archive.is\/Mox9X"
    } ]
  },
  "geo" : { },
  "id_str" : "935744207175766016",
  "text" : "\u60E0\u666E\u88AB\u66DD\u9810\u88DD\u9593\u8ADC\u8EDF\u4EF6\uFF0C\u6B65\u806F\u60F3\u5F8C\u5875\uFF1Ahttps:\/\/t.co\/7QvAW2wCdp",
  "id" : 935744207175766016,
  "created_at" : "2017-11-29 05:36:18 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/wi1m2DDiiz",
      "expanded_url" : "http:\/\/lodejs.org\/",
      "display_url" : "lodejs.org"
    } ]
  },
  "in_reply_to_status_id_str" : "935355622500921344",
  "geo" : { },
  "id_str" : "935740540204830720",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang https:\/\/t.co\/wi1m2DDiiz",
  "id" : 935740540204830720,
  "in_reply_to_status_id" : 935355622500921344,
  "created_at" : "2017-11-29 05:21:44 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 0, 12 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "935467974957268997",
  "geo" : { },
  "id_str" : "935729040568324098",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@DevinStever quic\u76F4\u63A5\u5C01\u554A~",
  "id" : 935729040568324098,
  "in_reply_to_status_id" : 935467974957268997,
  "created_at" : "2017-11-29 04:36:02 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saka@12.31-1.1\u4E0A\u6D77",
      "screen_name" : "shiuya_",
      "indices" : [ 3, 11 ],
      "id_str" : "845524978468503552",
      "id" : 845524978468503552
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/shiuya_\/status\/935396115414892544\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/3mPjA5wVJr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPsxzdQUIAATWWW.jpg",
      "id_str" : "935396107705655296",
      "id" : 935396107705655296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPsxzdQUIAATWWW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/3mPjA5wVJr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935723645804204034",
  "text" : "RT @shiuya_: \u6DF1\u5733\u4E5F\u958B\u59CB\u4E86\u554A... https:\/\/t.co\/3mPjA5wVJr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/shiuya_\/status\/935396115414892544\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/3mPjA5wVJr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPsxzdQUIAATWWW.jpg",
        "id_str" : "935396107705655296",
        "id" : 935396107705655296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPsxzdQUIAATWWW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/3mPjA5wVJr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "935396115414892544",
    "text" : "\u6DF1\u5733\u4E5F\u958B\u59CB\u4E86\u554A... https:\/\/t.co\/3mPjA5wVJr",
    "id" : 935396115414892544,
    "created_at" : "2017-11-28 06:33:07 +0000",
    "user" : {
      "name" : "Saka@12.31-1.1\u4E0A\u6D77",
      "screen_name" : "shiuya_",
      "protected" : false,
      "id_str" : "845524978468503552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943875971421151232\/nDOxIvwv_normal.jpg",
      "id" : 845524978468503552,
      "verified" : false
    }
  },
  "id" : 935723645804204034,
  "created_at" : "2017-11-29 04:14:36 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 0, 15 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/1jB4Eqf0fU",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/911065932725981185",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "935466012094410752",
  "geo" : { },
  "id_str" : "935718322037055488",
  "in_reply_to_user_id" : 254148157,
  "text" : "@GreatFireChina https:\/\/t.co\/1jB4Eqf0fU",
  "id" : 935718322037055488,
  "in_reply_to_status_id" : 935466012094410752,
  "created_at" : "2017-11-29 03:53:27 +0000",
  "in_reply_to_screen_name" : "GreatFireChina",
  "in_reply_to_user_id_str" : "254148157",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/FoDwNO0S6h",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/935711946179047425",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "934645930833346560",
  "geo" : { },
  "id_str" : "935715281472811008",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/FoDwNO0S6h",
  "id" : 935715281472811008,
  "in_reply_to_status_id" : 934645930833346560,
  "created_at" : "2017-11-29 03:41:22 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Low-end poopulation",
      "screen_name" : "alias5100",
      "indices" : [ 0, 10 ],
      "id_str" : "889483829878169601",
      "id" : 889483829878169601
    }, {
      "name" : "\u7EA2x",
      "screen_name" : "redsnow7",
      "indices" : [ 11, 20 ],
      "id_str" : "95572637",
      "id" : 95572637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/zkgEvTTI5K",
      "expanded_url" : "https:\/\/archive.is\/0nlXc",
      "display_url" : "archive.is\/0nlXc"
    } ]
  },
  "in_reply_to_status_id_str" : "935079711004352512",
  "geo" : { },
  "id_str" : "935376978689118208",
  "in_reply_to_user_id" : 889483829878169601,
  "text" : "@alias5100 @redsnow7 https:\/\/t.co\/zkgEvTTI5K",
  "id" : 935376978689118208,
  "in_reply_to_status_id" : 935079711004352512,
  "created_at" : "2017-11-28 05:17:04 +0000",
  "in_reply_to_screen_name" : "alias5100",
  "in_reply_to_user_id_str" : "889483829878169601",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/xdgvLYqv8O",
      "expanded_url" : "https:\/\/archive.is\/MmDZK",
      "display_url" : "archive.is\/MmDZK"
    } ]
  },
  "geo" : { },
  "id_str" : "935343501499396097",
  "text" : "\u96FB\u4FE1\u53C8\u73A9\u65B7\u7DB2\uFF1Ahttps:\/\/t.co\/xdgvLYqv8O",
  "id" : 935343501499396097,
  "created_at" : "2017-11-28 03:04:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/nPreoVwe8E",
      "expanded_url" : "https:\/\/archive.is\/NhaKF",
      "display_url" : "archive.is\/NhaKF"
    } ]
  },
  "geo" : { },
  "id_str" : "935321845934575616",
  "text" : "\u5DE5\u4FE1\u90E8\u7A31\u4FE1\u606F\u6CC4\u9732\u6210\u7232\u7279\u5927\u7DB2\u7D61\u5B89\u5168\u4E8B\u4EF6\u9700\u6D89\u53CA\u4E00\u5104\u4EE5\u4E0A\u7528\u6236\uFF1Ahttps:\/\/t.co\/nPreoVwe8E",
  "id" : 935321845934575616,
  "created_at" : "2017-11-28 01:38:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/935320635189944321\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/RWmACGgYkv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPrtJcfVAAAlSmQ.jpg",
      "id_str" : "935320619154997248",
      "id" : 935320619154997248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPrtJcfVAAAlSmQ.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/RWmACGgYkv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "935071905979207682",
  "geo" : { },
  "id_str" : "935320635189944321",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/RWmACGgYkv",
  "id" : 935320635189944321,
  "in_reply_to_status_id" : 935071905979207682,
  "created_at" : "2017-11-28 01:33:11 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/v7aK7UXtmH",
      "expanded_url" : "https:\/\/archive.is\/5tohx",
      "display_url" : "archive.is\/5tohx"
    } ]
  },
  "geo" : { },
  "id_str" : "935320194519654401",
  "text" : "AcFun\u5FA9\u6D3B\uFF1Ahttps:\/\/t.co\/v7aK7UXtmH",
  "id" : 935320194519654401,
  "created_at" : "2017-11-28 01:31:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/m2qHQYfsOM",
      "expanded_url" : "https:\/\/archive.is\/s0Cmk",
      "display_url" : "archive.is\/s0Cmk"
    } ]
  },
  "geo" : { },
  "id_str" : "935128721324900353",
  "text" : "\u7E41\u7463\u7684\u6578\u64DA\u4E2D\u5FC3\u548C\u8106\u5F31\u7684\u73FE\u4EE3\u79D1\u6280\uFF1Ahttps:\/\/t.co\/m2qHQYfsOM",
  "id" : 935128721324900353,
  "created_at" : "2017-11-27 12:50:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935124192500047872",
  "text" : "\u63A8\u7279\u4E2D\u6587\u5708\u5728\u6E1B\u5C11\u68AF\u5B50\u7684\u5206\u4EAB\u540E\u53C8\u8FCE\u4F86\u4E00\u6CE2\u9396\u63A8\u6F6E\uD83D\uDC8A",
  "id" : 935124192500047872,
  "created_at" : "2017-11-27 12:32:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935073474623819776",
  "text" : "1\u6BD4\u7279\u5E63 &gt; 9000\u7F8E\u5143",
  "id" : 935073474623819776,
  "created_at" : "2017-11-27 09:11:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/AlH6TPM0SG",
      "expanded_url" : "https:\/\/archive.is\/00huN",
      "display_url" : "archive.is\/00huN"
    } ]
  },
  "geo" : { },
  "id_str" : "935073114794446848",
  "text" : "Bilibili\u767B\u9304\u7CFB\u7D71\u6545\u969C\uFF1Ahttps:\/\/t.co\/AlH6TPM0SG",
  "id" : 935073114794446848,
  "created_at" : "2017-11-27 09:09:38 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/935071905979207682\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/pTY8eBj4pb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPoK7JVU8AAn6Vg.jpg",
      "id_str" : "935071883866730496",
      "id" : 935071883866730496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPoK7JVU8AAn6Vg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 532
      } ],
      "display_url" : "pic.twitter.com\/pTY8eBj4pb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934616586702475265",
  "geo" : { },
  "id_str" : "935071905979207682",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/pTY8eBj4pb",
  "id" : 935071905979207682,
  "in_reply_to_status_id" : 934616586702475265,
  "created_at" : "2017-11-27 09:04:49 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935070783734468608",
  "text" : "RT @williamlong: \u3010\u7F51\u4F20A\u7AD9\u5DF2\u88AB\u5173\u505C\u3011\u6709\u4F20\u8A00\u79F0AcFun\uFF08\u7B80\u79F0\u201CA\u7AD9\u201D\uFF09\u5DF2\u88AB\u5173\u505C\uFF0C\u76EE\u524D\u4F7F\u7528\u6D4F\u89C8\u5668\u4E5F\u65E0\u6CD5\u6253\u5F00\u8BE5\u7F51\u7AD9\u3002\u6709\u7528\u6237\u53CD\u5E94\uFF0C\u8FD9\u4E00\u72B6\u51B5\u5DF2\u6301\u7EED\u4E09\u5929\u3002\u4F7F\u7528\u767E\u5EA6\u641C\u7D22A\u7AD9\u5219\u767E\u5EA6\u63D0\u793A\uFF1A\u201C\u63D0\u9192\uFF1A\u8BE5\u9875\u9762\u56E0\u670D\u52A1\u4E0D\u7A33\u5B9A\u53EF\u80FD\u65E0\u6CD5\u6B63\u5E38\u8BBF\u95EE\uFF01\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "935060161844121600",
    "text" : "\u3010\u7F51\u4F20A\u7AD9\u5DF2\u88AB\u5173\u505C\u3011\u6709\u4F20\u8A00\u79F0AcFun\uFF08\u7B80\u79F0\u201CA\u7AD9\u201D\uFF09\u5DF2\u88AB\u5173\u505C\uFF0C\u76EE\u524D\u4F7F\u7528\u6D4F\u89C8\u5668\u4E5F\u65E0\u6CD5\u6253\u5F00\u8BE5\u7F51\u7AD9\u3002\u6709\u7528\u6237\u53CD\u5E94\uFF0C\u8FD9\u4E00\u72B6\u51B5\u5DF2\u6301\u7EED\u4E09\u5929\u3002\u4F7F\u7528\u767E\u5EA6\u641C\u7D22A\u7AD9\u5219\u767E\u5EA6\u63D0\u793A\uFF1A\u201C\u63D0\u9192\uFF1A\u8BE5\u9875\u9762\u56E0\u670D\u52A1\u4E0D\u7A33\u5B9A\u53EF\u80FD\u65E0\u6CD5\u6B63\u5E38\u8BBF\u95EE\uFF01\u201D",
    "id" : 935060161844121600,
    "created_at" : "2017-11-27 08:18:09 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 935070783734468608,
  "created_at" : "2017-11-27 09:00:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u795E\u697D\u5742\u6CC9@\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "KagurazakaIzumi",
      "indices" : [ 0, 16 ],
      "id_str" : "482695937",
      "id" : 482695937
    }, {
      "name" : "\u795E\u697D\u5742\u8BD7\u7EC7@\u4E2D\u4E86\u540D\u4E3A\u516B\u91CD\u6A31\u7684\u6BD2",
      "screen_name" : "shoumiao",
      "indices" : [ 17, 26 ],
      "id_str" : "2995860974",
      "id" : 2995860974
    }, {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 27, 35 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    }, {
      "name" : "Poi\u2642next\u2642door",
      "screen_name" : "v2_poi",
      "indices" : [ 36, 43 ],
      "id_str" : "1092469987",
      "id" : 1092469987
    }, {
      "name" : "\u62B9\u8336\u706C\u5E03\u4E01",
      "screen_name" : "ikaros_qwq",
      "indices" : [ 44, 55 ],
      "id_str" : "828413584082235397",
      "id" : 828413584082235397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934644701948362752",
  "geo" : { },
  "id_str" : "934711978463031296",
  "in_reply_to_user_id" : 482695937,
  "text" : "@KagurazakaIzumi @shoumiao @39__bot @v2_poi @ikaros_qwq \u90A3\u9EBD\u60F3\u8B93\u53D7\u55B5\u767C\u60C5\u55CE\uFF1F\uD83D\uDE1C",
  "id" : 934711978463031296,
  "in_reply_to_status_id" : 934644701948362752,
  "created_at" : "2017-11-26 09:14:36 +0000",
  "in_reply_to_screen_name" : "KagurazakaIzumi",
  "in_reply_to_user_id_str" : "482695937",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 0, 9 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934705841281712129",
  "geo" : { },
  "id_str" : "934711603924275200",
  "in_reply_to_user_id" : 45630895,
  "text" : "@chengr28 \u793E\u6703\u9054\u723E\u6587\u4E3B\u7FA9\uFF1F\n\u570B\u5BB6\u793E\u6703\u4E3B\u7FA9\uFF1F",
  "id" : 934711603924275200,
  "in_reply_to_status_id" : 934705841281712129,
  "created_at" : "2017-11-26 09:13:07 +0000",
  "in_reply_to_screen_name" : "chengr28",
  "in_reply_to_user_id_str" : "45630895",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5899\u5916\u697C",
      "screen_name" : "letscorp",
      "indices" : [ 3, 12 ],
      "id_str" : "230973714",
      "id" : 230973714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "934710043072745472",
  "text" : "RT @letscorp: \u5317\u4EAC\u5F53\u5C40\u8FD1\u65E5\u4EE5\u5927\u5174\u706B\u707E\u540E\u9700\u8981\u5927\u9762\u79EF\u6574\u987F\u4E3A\u7531\uFF0C\u5F00\u59CB\u96C6\u4E2D\u9A71\u8D76\u7FA4\u5916\u6765\u4EBA\u5458\u3002\u5F53\u5730\u65F6\u95F42017\u5E7411\u670824\u65E5\uFF0C\u4E00\u5219\u201C\u540C\u821F\u5BB6\u56ED\u201D\u4E3A\u65E0\u5BB6\u53EF\u5F52\u7684\u5317\u6F02\u8005\u63D0\u4F9B\u4E34\u65F6\u4F4F\u5904\u7684\u6D88\u606F\u5728\u7F51\u7EDC\u70ED\u4F20\uFF1B\u636E\u4FE1\uFF0C\u8FD9\u662F\u51E0\u5BB6\u5728\u4E2D\u56FD\u5408\u6CD5\u6CE8\u518C\u7684\u516C\u76CA\u7EC4\u7EC7\u81EA\u53D1\u5C55\u5F00\u7684\u6551\u52A9\u884C\u52A8\u3002\u4EC5\u4EC5\u4E00\u5929\u540E\uFF0C\u8BE5\u884C\u52A8\u5373\u906D\u5F53\u5C40\u53EB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/letscorp\/status\/934356329480597504\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/CNwDii7keS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPd_9vTUIAAR7ri.jpg",
        "id_str" : "934356146348892160",
        "id" : 934356146348892160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPd_9vTUIAAR7ri.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 1524
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 1524
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 762,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/CNwDii7keS"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/letscorp\/status\/934356329480597504\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/CNwDii7keS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPeAAx6UMAAhJRF.jpg",
        "id_str" : "934356198588952576",
        "id" : 934356198588952576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPeAAx6UMAAhJRF.jpg",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 1216
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 1216
        } ],
        "display_url" : "pic.twitter.com\/CNwDii7keS"
      } ],
      "hashtags" : [ {
        "text" : "\u793E\u4F1A\u4E3B\u4E49\u4E13\u653F\u94C1\u62F3",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "934356329480597504",
    "text" : "\u5317\u4EAC\u5F53\u5C40\u8FD1\u65E5\u4EE5\u5927\u5174\u706B\u707E\u540E\u9700\u8981\u5927\u9762\u79EF\u6574\u987F\u4E3A\u7531\uFF0C\u5F00\u59CB\u96C6\u4E2D\u9A71\u8D76\u7FA4\u5916\u6765\u4EBA\u5458\u3002\u5F53\u5730\u65F6\u95F42017\u5E7411\u670824\u65E5\uFF0C\u4E00\u5219\u201C\u540C\u821F\u5BB6\u56ED\u201D\u4E3A\u65E0\u5BB6\u53EF\u5F52\u7684\u5317\u6F02\u8005\u63D0\u4F9B\u4E34\u65F6\u4F4F\u5904\u7684\u6D88\u606F\u5728\u7F51\u7EDC\u70ED\u4F20\uFF1B\u636E\u4FE1\uFF0C\u8FD9\u662F\u51E0\u5BB6\u5728\u4E2D\u56FD\u5408\u6CD5\u6CE8\u518C\u7684\u516C\u76CA\u7EC4\u7EC7\u81EA\u53D1\u5C55\u5F00\u7684\u6551\u52A9\u884C\u52A8\u3002\u4EC5\u4EC5\u4E00\u5929\u540E\uFF0C\u8BE5\u884C\u52A8\u5373\u906D\u5F53\u5C40\u53EB\u505C\u3002 #\u793E\u4F1A\u4E3B\u4E49\u4E13\u653F\u94C1\u62F3 https:\/\/t.co\/CNwDii7keS",
    "id" : 934356329480597504,
    "created_at" : "2017-11-25 09:41:23 +0000",
    "user" : {
      "name" : "\u5899\u5916\u697C",
      "screen_name" : "letscorp",
      "protected" : false,
      "id_str" : "230973714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2176611614\/AnboundViewerNew_Logo_Icon_512x512_normal.png",
      "id" : 230973714,
      "verified" : false
    }
  },
  "id" : 934710043072745472,
  "created_at" : "2017-11-26 09:06:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EBA\u751F\u54A9\u70B9\u670D\u52A1\u4E2D\u5FC3\u2022\u7D05\u8389\u6816(\u6316\u8111\u6D1E)",
      "screen_name" : "miemiekurisu",
      "indices" : [ 0, 13 ],
      "id_str" : "147217241",
      "id" : 147217241
    }, {
      "name" : "iTZQing",
      "screen_name" : "iTZQing",
      "indices" : [ 14, 22 ],
      "id_str" : "613074635",
      "id" : 613074635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934387192822222848",
  "geo" : { },
  "id_str" : "934660400456589312",
  "in_reply_to_user_id" : 147217241,
  "text" : "@miemiekurisu @iTZQing QQ\u7A7A\u9593\u6709OCR\u3002",
  "id" : 934660400456589312,
  "in_reply_to_status_id" : 934387192822222848,
  "created_at" : "2017-11-26 05:49:39 +0000",
  "in_reply_to_screen_name" : "miemiekurisu",
  "in_reply_to_user_id_str" : "147217241",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/Q0Lkze7WKA",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/11\/blog-post_166.html",
      "display_url" : "molihua.org\/2017\/11\/blog-p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "934645165880377345",
  "geo" : { },
  "id_str" : "934645930833346560",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u4E00\u4E9B\u731C\u6E2C\uFF1Ahttps:\/\/t.co\/Q0Lkze7WKA",
  "id" : 934645930833346560,
  "in_reply_to_status_id" : 934645165880377345,
  "created_at" : "2017-11-26 04:52:09 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/RdH9urH1Fj",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/934370636050333696",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "934645083823108096",
  "geo" : { },
  "id_str" : "934645165880377345",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u9810\u8A00\u6210\u771F\uFF1Ahttps:\/\/t.co\/RdH9urH1Fj",
  "id" : 934645165880377345,
  "in_reply_to_status_id" : 934645083823108096,
  "created_at" : "2017-11-26 04:49:07 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/zy8BNt55P0",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/934370637547745280",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "933862398364209152",
  "geo" : { },
  "id_str" : "934645083823108096",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u5750\u5BE6\uFF1Ahttps:\/\/t.co\/zy8BNt55P0",
  "id" : 934645083823108096,
  "in_reply_to_status_id" : 933862398364209152,
  "created_at" : "2017-11-26 04:48:47 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/1zBgRATBdw",
      "expanded_url" : "https:\/\/archive.is\/Nd6ZB",
      "display_url" : "archive.is\/Nd6ZB"
    } ]
  },
  "geo" : { },
  "id_str" : "934620618317860864",
  "text" : "Telegram\u56E0Google\u548CApple\u7684\u5A01\u8105\u5BE6\u884C\u5BE9\u67E5\uFF1Ahttps:\/\/t.co\/1zBgRATBdw",
  "id" : 934620618317860864,
  "created_at" : "2017-11-26 03:11:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/934616586702475265\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/QPAFkwUZa8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPhs0RtW4AUhZWH.jpg",
      "id_str" : "934616568042020869",
      "id" : 934616568042020869,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPhs0RtW4AUhZWH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 532
      } ],
      "display_url" : "pic.twitter.com\/QPAFkwUZa8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934328200141959168",
  "geo" : { },
  "id_str" : "934616586702475265",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/QPAFkwUZa8",
  "id" : 934616586702475265,
  "in_reply_to_status_id" : 934328200141959168,
  "created_at" : "2017-11-26 02:55:33 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/9B9qvcYTcU",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=22677525",
      "display_url" : "music.163.com\/#\/song?id=2267\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "934354933515784192",
  "text" : "Project Diva desu.\uFF1Ahttps:\/\/t.co\/9B9qvcYTcU",
  "id" : 934354933515784192,
  "created_at" : "2017-11-25 09:35:50 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 0, 9 ],
      "id_str" : "45630895",
      "id" : 45630895
    }, {
      "name" : "I Need A Doctor",
      "screen_name" : "Redotzz",
      "indices" : [ 10, 18 ],
      "id_str" : "1700758927",
      "id" : 1700758927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934344821208055809",
  "geo" : { },
  "id_str" : "934346055646359552",
  "in_reply_to_user_id" : 45630895,
  "text" : "@chengr28 @Redotzz \u9177\u777F\u59CB\u65BC2006\u5E74\u3002",
  "id" : 934346055646359552,
  "in_reply_to_status_id" : 934344821208055809,
  "created_at" : "2017-11-25 09:00:33 +0000",
  "in_reply_to_screen_name" : "chengr28",
  "in_reply_to_user_id_str" : "45630895",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xxnet",
      "screen_name" : "XXNetDev",
      "indices" : [ 0, 9 ],
      "id_str" : "2998823642",
      "id" : 2998823642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934343343315783681",
  "geo" : { },
  "id_str" : "934343506491002880",
  "in_reply_to_user_id" : 2998823642,
  "text" : "@XXNetDev \u8D70\u8DF3\u677F\u624D\u662F\u63D0\u901F\u7684\u6B63\u8DEF\u3002",
  "id" : 934343506491002880,
  "in_reply_to_status_id" : 934343343315783681,
  "created_at" : "2017-11-25 08:50:25 +0000",
  "in_reply_to_screen_name" : "XXNetDev",
  "in_reply_to_user_id_str" : "2998823642",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/934342395805732864\/photo\/1",
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/bLmsTCRaQI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPdzcOIXUAE2CWW.jpg",
      "id_str" : "934342376369377281",
      "id" : 934342376369377281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPdzcOIXUAE2CWW.jpg",
      "sizes" : [ {
        "h" : 523,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 986,
        "resize" : "fit",
        "w" : 1282
      }, {
        "h" : 986,
        "resize" : "fit",
        "w" : 1282
      }, {
        "h" : 923,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/bLmsTCRaQI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924514789912711168",
  "geo" : { },
  "id_str" : "934342395805732864",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u8A55\u8AD6\u4E5F\u6C92\u4E86\uFF1A https:\/\/t.co\/bLmsTCRaQI",
  "id" : 934342395805732864,
  "in_reply_to_status_id" : 924514789912711168,
  "created_at" : "2017-11-25 08:46:01 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "934341304485588992",
  "text" : "\u7169",
  "id" : 934341304485588992,
  "created_at" : "2017-11-25 08:41:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/934328200141959168\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/UcHS26xZLA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPdmVjzX0AAOdfi.jpg",
      "id_str" : "934327968276664320",
      "id" : 934327968276664320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPdmVjzX0AAOdfi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 666
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 666
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 666
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 666
      } ],
      "display_url" : "pic.twitter.com\/UcHS26xZLA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933903165254197248",
  "geo" : { },
  "id_str" : "934328200141959168",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/UcHS26xZLA",
  "id" : 934328200141959168,
  "in_reply_to_status_id" : 933903165254197248,
  "created_at" : "2017-11-25 07:49:36 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 0, 9 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934297009934163969",
  "geo" : { },
  "id_str" : "934323208437882880",
  "in_reply_to_user_id" : 45630895,
  "text" : "@chengr28 \u6700\u8001\u7684\u6C92ME\u3002",
  "id" : 934323208437882880,
  "in_reply_to_status_id" : 934297009934163969,
  "created_at" : "2017-11-25 07:29:46 +0000",
  "in_reply_to_screen_name" : "chengr28",
  "in_reply_to_user_id_str" : "45630895",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u795E\u697D\u5742\u6CC9@\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "KagurazakaIzumi",
      "indices" : [ 0, 16 ],
      "id_str" : "482695937",
      "id" : 482695937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933984598345650176",
  "geo" : { },
  "id_str" : "934054901327515653",
  "in_reply_to_user_id" : 482695937,
  "text" : "@KagurazakaIzumi \u3002",
  "id" : 934054901327515653,
  "in_reply_to_status_id" : 933984598345650176,
  "created_at" : "2017-11-24 13:43:37 +0000",
  "in_reply_to_screen_name" : "KagurazakaIzumi",
  "in_reply_to_user_id_str" : "482695937",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/idix2tb2h9",
      "expanded_url" : "https:\/\/archive.is\/n9Vxf",
      "display_url" : "archive.is\/n9Vxf"
    } ]
  },
  "geo" : { },
  "id_str" : "934042819869765634",
  "text" : "Cloudflare\u8457\u624B\u964D\u4F4EFCC\u4E3B\u5E2DAjit Pai\u5BB6\u7684\u7DB2\u901F\uFF1Ahttps:\/\/t.co\/idix2tb2h9",
  "id" : 934042819869765634,
  "created_at" : "2017-11-24 12:55:36 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Explorare Seniorious",
      "screen_name" : "Explorare_",
      "indices" : [ 3, 14 ],
      "id_str" : "252897888",
      "id" : 252897888
    }, {
      "name" : "\u4F4E\u7AEF\u767D\u6CE0\u4E00\u5B9A\u6302\u79D1 #\u96FE",
      "screen_name" : "bailing64",
      "indices" : [ 16, 26 ],
      "id_str" : "318937389",
      "id" : 318937389
    }, {
      "name" : "peeMo",
      "screen_name" : "peeMoooo",
      "indices" : [ 27, 36 ],
      "id_str" : "2994469201",
      "id" : 2994469201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/YRzoJsh54F",
      "expanded_url" : "https:\/\/helpx.adobe.com\/photoshop\/how-to\/content-aware-crop-fill.html",
      "display_url" : "helpx.adobe.com\/photoshop\/how-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933920813908201475",
  "text" : "RT @Explorare_: @bailing64 @peeMoooo \u4F7F\u7528\u7684\u662F Adobe Photoshop CC 2017 \u65B0\u589E\u52A0\u7684 Content Aware Crop \u529F\u80FD\uFF0C\u81EA\u52A8\u586B\u5145\u4E86\u753B\u9762\u5DE6\u53F3\u4E24\u4FA7\u7684\u5185\u5BB9\uFF0C\u5B9E\u6D4B\u6548\u679C\u5F88\u68D2\u3002\nhttps:\/\/t.co\/YRzoJsh54F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u4F4E\u7AEF\u767D\u6CE0\u4E00\u5B9A\u6302\u79D1 #\u96FE",
        "screen_name" : "bailing64",
        "indices" : [ 0, 10 ],
        "id_str" : "318937389",
        "id" : 318937389
      }, {
        "name" : "peeMo",
        "screen_name" : "peeMoooo",
        "indices" : [ 11, 20 ],
        "id_str" : "2994469201",
        "id" : 2994469201
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/YRzoJsh54F",
        "expanded_url" : "https:\/\/helpx.adobe.com\/photoshop\/how-to\/content-aware-crop-fill.html",
        "display_url" : "helpx.adobe.com\/photoshop\/how-\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "931092291854385152",
    "geo" : { },
    "id_str" : "931343435721670656",
    "in_reply_to_user_id" : 318937389,
    "text" : "@bailing64 @peeMoooo \u4F7F\u7528\u7684\u662F Adobe Photoshop CC 2017 \u65B0\u589E\u52A0\u7684 Content Aware Crop \u529F\u80FD\uFF0C\u81EA\u52A8\u586B\u5145\u4E86\u753B\u9762\u5DE6\u53F3\u4E24\u4FA7\u7684\u5185\u5BB9\uFF0C\u5B9E\u6D4B\u6548\u679C\u5F88\u68D2\u3002\nhttps:\/\/t.co\/YRzoJsh54F",
    "id" : 931343435721670656,
    "in_reply_to_status_id" : 931092291854385152,
    "created_at" : "2017-11-17 02:09:13 +0000",
    "in_reply_to_screen_name" : "bailing64",
    "in_reply_to_user_id_str" : "318937389",
    "user" : {
      "name" : "Explorare Seniorious",
      "screen_name" : "Explorare_",
      "protected" : false,
      "id_str" : "252897888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/881858646874791938\/XA7A1wZV_normal.jpg",
      "id" : 252897888,
      "verified" : false
    }
  },
  "id" : 933920813908201475,
  "created_at" : "2017-11-24 04:50:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/0gkONX2L4l",
      "expanded_url" : "https:\/\/www.fightforthefuture.org\/",
      "display_url" : "fightforthefuture.org"
    } ]
  },
  "geo" : { },
  "id_str" : "933906400375459840",
  "text" : "Fight for the Future\uFF1Ahttps:\/\/t.co\/0gkONX2L4l",
  "id" : 933906400375459840,
  "created_at" : "2017-11-24 03:53:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/933903165254197248\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/XXlPz7ijlO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPXj-QMUQAAfxd4.jpg",
      "id_str" : "933903156387266560",
      "id" : 933903156387266560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPXj-QMUQAAfxd4.jpg",
      "sizes" : [ {
        "h" : 481,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 533
      } ],
      "display_url" : "pic.twitter.com\/XXlPz7ijlO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/rwvkYS3ke7",
      "expanded_url" : "https:\/\/widget.battleforthenet.com\/widget.js",
      "display_url" : "widget.battleforthenet.com\/widget.js"
    } ]
  },
  "in_reply_to_status_id_str" : "933901210758893569",
  "geo" : { },
  "id_str" : "933903165254197248",
  "in_reply_to_user_id" : 3359880735,
  "text" : "widget script\uFF1Ahttps:\/\/t.co\/rwvkYS3ke7 https:\/\/t.co\/XXlPz7ijlO",
  "id" : 933903165254197248,
  "in_reply_to_status_id" : 933901210758893569,
  "created_at" : "2017-11-24 03:40:40 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/933901210758893569\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/vdsQS2fC46",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPXiH2eWkAASbqk.jpg",
      "id_str" : "933901122259030016",
      "id" : 933901122259030016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPXiH2eWkAASbqk.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/vdsQS2fC46"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/jjujRPXm2B",
      "expanded_url" : "https:\/\/www.battleforthenet.com\/",
      "display_url" : "battleforthenet.com"
    } ]
  },
  "geo" : { },
  "id_str" : "933901210758893569",
  "text" : "We have just 3 weeks to save net neutrality\uFF1Ahttps:\/\/t.co\/jjujRPXm2B https:\/\/t.co\/vdsQS2fC46",
  "id" : 933901210758893569,
  "created_at" : "2017-11-24 03:32:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933895007647535104",
  "text" : "V2EX\u7684\u5E16\u5B50\u9801\u9762\u5DF2\u4E0D\u80FD\u88AB\u641C\u7D22\u5F15\u64CE\u6293\u53D6\u3002",
  "id" : 933895007647535104,
  "created_at" : "2017-11-24 03:08:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6797\u7EFF\u5B50",
      "screen_name" : "lisalueng",
      "indices" : [ 3, 13 ],
      "id_str" : "183165854",
      "id" : 183165854
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lisalueng\/status\/927010195489792000\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/W9e02T67VI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN1m2IGUMAAR6hB.jpg",
      "id_str" : "927010178381131776",
      "id" : 927010178381131776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN1m2IGUMAAR6hB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 627
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 738
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 738
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 738
      } ],
      "display_url" : "pic.twitter.com\/W9e02T67VI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933888731395784704",
  "text" : "RT @lisalueng: \u6709\u4E2D\u56FD\u7279\u8272\u7684\u793E\u4F1A\u4E3B\u4E49\u5730\u533A\u4EE3\u5B55\u5408\u6CD5\u5316\uFF0C\u53C8\u6CA1\u6709\u76F8\u5E94\u7684\u6CD5\u6CBB\u73AF\u5883\uFF0C\u53EA\u4F1A\u8BA9\u66F4\u591A\u7684\u5973\u6027\u6CA6\u4E3A\u884C\u8D70\u7684\u5B50\u5BAB\uFF0C\u571F\u9E21\u56FD\u4E3A\u4E86\u7E41\u6B96\u5DF2\u7ECF\u4E0D\u60DC\u4E00\u5207\u4EE3\u4EF7\u5974\u5F79\u5987\u5973\u4E86\u3002 https:\/\/t.co\/W9e02T67VI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lisalueng\/status\/927010195489792000\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/W9e02T67VI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DN1m2IGUMAAR6hB.jpg",
        "id_str" : "927010178381131776",
        "id" : 927010178381131776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN1m2IGUMAAR6hB.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 627
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 738
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 738
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 738
        } ],
        "display_url" : "pic.twitter.com\/W9e02T67VI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927010195489792000",
    "text" : "\u6709\u4E2D\u56FD\u7279\u8272\u7684\u793E\u4F1A\u4E3B\u4E49\u5730\u533A\u4EE3\u5B55\u5408\u6CD5\u5316\uFF0C\u53C8\u6CA1\u6709\u76F8\u5E94\u7684\u6CD5\u6CBB\u73AF\u5883\uFF0C\u53EA\u4F1A\u8BA9\u66F4\u591A\u7684\u5973\u6027\u6CA6\u4E3A\u884C\u8D70\u7684\u5B50\u5BAB\uFF0C\u571F\u9E21\u56FD\u4E3A\u4E86\u7E41\u6B96\u5DF2\u7ECF\u4E0D\u60DC\u4E00\u5207\u4EE3\u4EF7\u5974\u5F79\u5987\u5973\u4E86\u3002 https:\/\/t.co\/W9e02T67VI",
    "id" : 927010195489792000,
    "created_at" : "2017-11-05 03:10:28 +0000",
    "user" : {
      "name" : "\u5C0F\u6797\u7EFF\u5B50",
      "screen_name" : "lisalueng",
      "protected" : false,
      "id_str" : "183165854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906494300082417664\/GFf3n5LY_normal.jpg",
      "id" : 183165854,
      "verified" : false
    }
  },
  "id" : 933888731395784704,
  "created_at" : "2017-11-24 02:43:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/Q3zb20iUc9",
      "expanded_url" : "https:\/\/archive.is\/G8vPr",
      "display_url" : "archive.is\/G8vPr"
    } ]
  },
  "geo" : { },
  "id_str" : "933862398364209152",
  "text" : "\u5317\u4EAC\u7D05\u9EC3\u85CD\u5E7C\u5152\u5712\u7325\u893B\u5B69\u7AE5\u6848\u662F\u96C6\u9AD4\u4F5C\u6848\uFF0C\u6216\u6D89\u53CA\u8ECD\u65B9\uFF1Ahttps:\/\/t.co\/Q3zb20iUc9",
  "id" : 933862398364209152,
  "created_at" : "2017-11-24 00:58:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/gLfGaM6yGe",
      "expanded_url" : "https:\/\/www.techdirt.com\/articles\/20171122\/09473038669\/fcc-releases-net-neutrality-killing-order-hopes-youre-too-busy-cooking-turkey-to-read-it.shtml",
      "display_url" : "techdirt.com\/articles\/20171\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933855010450018304",
  "text" : "FCC\u767C\u4F48Net Neutrality Killing Order\uFF1Ahttps:\/\/t.co\/gLfGaM6yGe",
  "id" : 933855010450018304,
  "created_at" : "2017-11-24 00:29:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6797\u7EFF\u5B50",
      "screen_name" : "lisalueng",
      "indices" : [ 3, 13 ],
      "id_str" : "183165854",
      "id" : 183165854
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lisalueng\/status\/933541230192951297\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/lnSq0WjeN6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPSayXyWsAEf4uG.jpg",
      "id_str" : "933541212941889537",
      "id" : 933541212941889537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPSayXyWsAEf4uG.jpg",
      "sizes" : [ {
        "h" : 325,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/lnSq0WjeN6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933836502391578624",
  "text" : "RT @lisalueng: \u6709\u94B1\u7684\u6709\u94B1\uFF0C\u6CA1\u94B1\u7684\u6B7B\u7EDD\uFF0C\u592A\u597D\u4E86\u3002\u4E00\u6B21\u6027\u89E3\u51B3\u8D2B\u7A77\u95EE\u9898\u3002 https:\/\/t.co\/lnSq0WjeN6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lisalueng\/status\/933541230192951297\/photo\/1",
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/lnSq0WjeN6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPSayXyWsAEf4uG.jpg",
        "id_str" : "933541212941889537",
        "id" : 933541212941889537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPSayXyWsAEf4uG.jpg",
        "sizes" : [ {
          "h" : 325,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/lnSq0WjeN6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "933541230192951297",
    "text" : "\u6709\u94B1\u7684\u6709\u94B1\uFF0C\u6CA1\u94B1\u7684\u6B7B\u7EDD\uFF0C\u592A\u597D\u4E86\u3002\u4E00\u6B21\u6027\u89E3\u51B3\u8D2B\u7A77\u95EE\u9898\u3002 https:\/\/t.co\/lnSq0WjeN6",
    "id" : 933541230192951297,
    "created_at" : "2017-11-23 03:42:28 +0000",
    "user" : {
      "name" : "\u5C0F\u6797\u7EFF\u5B50",
      "screen_name" : "lisalueng",
      "protected" : false,
      "id_str" : "183165854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906494300082417664\/GFf3n5LY_normal.jpg",
      "id" : 183165854,
      "verified" : false
    }
  },
  "id" : 933836502391578624,
  "created_at" : "2017-11-23 23:15:46 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "haor",
      "screen_name" : "iamhaor",
      "indices" : [ 0, 8 ],
      "id_str" : "2693151720",
      "id" : 2693151720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933686180754767872",
  "geo" : { },
  "id_str" : "933835693046091776",
  "in_reply_to_user_id" : 2693151720,
  "text" : "@iamhaor \u90A3\u500B\u5E74\u7D00\u559C\u6B61\u7684\u9084\u662F\u7537\u5B69\u5B50\u5427\uFF1F",
  "id" : 933835693046091776,
  "in_reply_to_status_id" : 933686180754767872,
  "created_at" : "2017-11-23 23:12:33 +0000",
  "in_reply_to_screen_name" : "iamhaor",
  "in_reply_to_user_id_str" : "2693151720",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u840C\u738B\u5343\u6B72",
      "screen_name" : "caringor",
      "indices" : [ 0, 9 ],
      "id_str" : "260663159",
      "id" : 260663159
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/933833821631508482\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/N3UfcKPjvC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPWk57aWAAEzdHT.jpg",
      "id_str" : "933833812856930305",
      "id" : 933833812856930305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPWk57aWAAEzdHT.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 1007
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 1007
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 1007
      } ],
      "display_url" : "pic.twitter.com\/N3UfcKPjvC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933179933190320128",
  "geo" : { },
  "id_str" : "933833821631508482",
  "in_reply_to_user_id" : 260663159,
  "text" : "@caringor \u7232\u4EC0\u9EBC\u4F60\u7684\u8C37\u6B4C\u662F\u9019\u7A2EUI\uFF1F\u6211\u7684\u9577\u9019\u6A23\uFF1A https:\/\/t.co\/N3UfcKPjvC",
  "id" : 933833821631508482,
  "in_reply_to_status_id" : 933179933190320128,
  "created_at" : "2017-11-23 23:05:07 +0000",
  "in_reply_to_screen_name" : "caringor",
  "in_reply_to_user_id_str" : "260663159",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/8d8nKZkTTd",
      "expanded_url" : "https:\/\/archive.is\/lTcEh",
      "display_url" : "archive.is\/lTcEh"
    } ]
  },
  "geo" : { },
  "id_str" : "933677620516085760",
  "text" : "Linus\u6307\u51FA\u5B89\u5168\u884C\u696D\u662F\u6D6A\u8CBB\u4EBA\u529B\uFF1Ahttps:\/\/t.co\/8d8nKZkTTd",
  "id" : 933677620516085760,
  "created_at" : "2017-11-23 12:44:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/Z8jZsECJlO",
      "expanded_url" : "https:\/\/archive.is\/YaWZA",
      "display_url" : "archive.is\/YaWZA"
    } ]
  },
  "geo" : { },
  "id_str" : "933676636322582528",
  "text" : "\u79FB\u52D5\u5BEC\u5E36\u7528\u6236\u783411\u5104\uFF1Ahttps:\/\/t.co\/Z8jZsECJlO",
  "id" : 933676636322582528,
  "created_at" : "2017-11-23 12:40:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/oRH7INXj6r",
      "expanded_url" : "https:\/\/archive.is\/tC2A7",
      "display_url" : "archive.is\/tC2A7"
    } ]
  },
  "geo" : { },
  "id_str" : "933676267760693250",
  "text" : "\u9996\u4F8B\u81EA\u52D5\u5316\u4E0B\u55AE\u88AB\u52243\u5E74\u5F92\u5211\uFF1Ahttps:\/\/t.co\/oRH7INXj6r",
  "id" : 933676267760693250,
  "created_at" : "2017-11-23 12:39:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/Y4tZUGNZDp",
      "expanded_url" : "https:\/\/archive.is\/mp3tp",
      "display_url" : "archive.is\/mp3tp"
    } ]
  },
  "geo" : { },
  "id_str" : "933673944586117120",
  "text" : "\u4FC4\u7F85\u65AF\u4EE5\u7248\u6B0A\u7232\u7531\u643A\u624BISP\u548C\u641C\u7D22\u5F15\u64CE\u53C8\u5C4F\u853D\u4E86786\u500B\u7AD9\u9EDE\uFF1Ahttps:\/\/t.co\/Y4tZUGNZDp",
  "id" : 933673944586117120,
  "created_at" : "2017-11-23 12:29:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933610637535727616",
  "text" : "\u8996\u529B\u66F4\u7CDF\u4E86",
  "id" : 933610637535727616,
  "created_at" : "2017-11-23 08:18:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/UUe1aFsbh4",
      "expanded_url" : "https:\/\/twitter.com\/bitinn\/status\/933324017921957888",
      "display_url" : "twitter.com\/bitinn\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933574299381878786",
  "text" : "\u65B0\u4E00\u8F2A\u5C01\u9396 https:\/\/t.co\/UUe1aFsbh4",
  "id" : 933574299381878786,
  "created_at" : "2017-11-23 05:53:52 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 3, 15 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    }, {
      "name" : "\u90ED\u6587\u8D35Guo Wengui \u270A\uFE0F\u270A\uFE0F\u270A\uFE0F",
      "screen_name" : "KwokMiles",
      "indices" : [ 17, 27 ],
      "id_str" : "3131350487",
      "id" : 3131350487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933566527500161024",
  "text" : "RT @DevinStever: @KwokMiles \u6587\u8D35\u5148\u751F\u7684Twitter\u770B\u4E0A\u53BB\u7EC8\u4E8E\u89E3\u5C01\u4E86\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u90ED\u6587\u8D35Guo Wengui \u270A\uFE0F\u270A\uFE0F\u270A\uFE0F",
        "screen_name" : "KwokMiles",
        "indices" : [ 0, 10 ],
        "id_str" : "3131350487",
        "id" : 3131350487
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "933490619053477888",
    "geo" : { },
    "id_str" : "933556925689626624",
    "in_reply_to_user_id" : 3131350487,
    "text" : "@KwokMiles \u6587\u8D35\u5148\u751F\u7684Twitter\u770B\u4E0A\u53BB\u7EC8\u4E8E\u89E3\u5C01\u4E86\u3002",
    "id" : 933556925689626624,
    "in_reply_to_status_id" : 933490619053477888,
    "created_at" : "2017-11-23 04:44:50 +0000",
    "in_reply_to_screen_name" : "KwokMiles",
    "in_reply_to_user_id_str" : "3131350487",
    "user" : {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "protected" : false,
      "id_str" : "745341593817747456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924484708607647744\/qIOYZnbn_normal.jpg",
      "id" : 745341593817747456,
      "verified" : false
    }
  },
  "id" : 933566527500161024,
  "created_at" : "2017-11-23 05:22:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/6Usi8p4a0d",
      "expanded_url" : "https:\/\/archive.is\/XwYOq",
      "display_url" : "archive.is\/XwYOq"
    } ]
  },
  "geo" : { },
  "id_str" : "933527062622691334",
  "text" : "\u4E2D\u5171\u63A2\u982D\u65783\u5E74\u5167\u5C07\u90546.3\u5104\uFF1Ahttps:\/\/t.co\/6Usi8p4a0d",
  "id" : 933527062622691334,
  "created_at" : "2017-11-23 02:46:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/3bLUXadkN3",
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/933491270890033152",
      "display_url" : "twitter.com\/ruanyf\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933522879618088960",
  "text" : "GONE ruanyf\nGONE yinwang https:\/\/t.co\/3bLUXadkN3",
  "id" : 933522879618088960,
  "created_at" : "2017-11-23 02:29:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/NohAYkFgeZ",
      "expanded_url" : "https:\/\/archive.is\/hqQqT",
      "display_url" : "archive.is\/hqQqT"
    } ]
  },
  "geo" : { },
  "id_str" : "933516616960237568",
  "text" : "\u570B\u7522\u700F\u89BD\u5668\u66F4\u65B0\u5F8C\u9ED8\u8A8D\u5FFD\u7565\u8B49\u66F8\u932F\u8AA4\uFF1Ahttps:\/\/t.co\/NohAYkFgeZ",
  "id" : 933516616960237568,
  "created_at" : "2017-11-23 02:04:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/uRdxfD7g7U",
      "expanded_url" : "https:\/\/archive.is\/8eT4t",
      "display_url" : "archive.is\/8eT4t"
    }, {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/BGb6iGErW7",
      "expanded_url" : "https:\/\/archive.is\/7kIRp",
      "display_url" : "archive.is\/7kIRp"
    }, {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/UaLoZZZX3M",
      "expanded_url" : "https:\/\/www.v2ex.com\/t\/408463",
      "display_url" : "v2ex.com\/t\/408463"
    } ]
  },
  "geo" : { },
  "id_str" : "933515235394244609",
  "text" : "\u61C9\u76E3\u7BA1\u8981\u6C42\uFF0C\u5927\u5EE0\u624B\u6A5F\u61C9\u7528\u6FEB\u7528\u6B0A\u9650\uFF0C\u96B1\u79C1\u4FE1\u606F\u88AB\u8C37\u6B4C\u7D22\u5F15\u2014\u2014\np1\uFF1Ahttps:\/\/t.co\/uRdxfD7g7U\np2\uFF1Ahttps:\/\/t.co\/BGb6iGErW7\nhttps:\/\/t.co\/UaLoZZZX3M",
  "id" : 933515235394244609,
  "created_at" : "2017-11-23 01:59:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krome",
      "screen_name" : "CaKrome",
      "indices" : [ 0, 8 ],
      "id_str" : "3344890713",
      "id" : 3344890713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933322885569105921",
  "geo" : { },
  "id_str" : "933327180100198403",
  "in_reply_to_user_id" : 3344890713,
  "text" : "@CaKrome Libreboot\u6B61\u8FCE\u4F60\uFF01",
  "id" : 933327180100198403,
  "in_reply_to_status_id" : 933322885569105921,
  "created_at" : "2017-11-22 13:31:54 +0000",
  "in_reply_to_screen_name" : "CaKrome",
  "in_reply_to_user_id_str" : "3344890713",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/933321824942870530\/photo\/1",
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/X1CLhVNzoB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPPTPXqVoAELyvy.jpg",
      "id_str" : "933321808798916609",
      "id" : 933321808798916609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPPTPXqVoAELyvy.jpg",
      "sizes" : [ {
        "h" : 643,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 817
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 817
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 817
      } ],
      "display_url" : "pic.twitter.com\/X1CLhVNzoB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933320205098512385",
  "geo" : { },
  "id_str" : "933321824942870530",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u6211\u60F3\u54ED\uFF1A https:\/\/t.co\/X1CLhVNzoB",
  "id" : 933321824942870530,
  "in_reply_to_status_id" : 933320205098512385,
  "created_at" : "2017-11-22 13:10:38 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/mcL4QMTJaR",
      "expanded_url" : "https:\/\/archive.is\/oic97",
      "display_url" : "archive.is\/oic97"
    } ]
  },
  "geo" : { },
  "id_str" : "933320922223857665",
  "text" : "\u83EF\u78A9\u9996\u767CRyzen\u6E38\u6232\u672C\uFF1Ahttps:\/\/t.co\/mcL4QMTJaR",
  "id" : 933320922223857665,
  "created_at" : "2017-11-22 13:07:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/Lu2ypFqkAu",
      "expanded_url" : "https:\/\/archive.is\/5wiXD",
      "display_url" : "archive.is\/5wiXD"
    } ]
  },
  "geo" : { },
  "id_str" : "933320205098512385",
  "text" : "Intel ME\u7206\u91CD\u5927\u6F0F\u6D1E\uFF0C\u6CE2\u53CA\u90323\u4EE3\u6240\u6709CPU\uFF1Ahttps:\/\/t.co\/Lu2ypFqkAu",
  "id" : 933320205098512385,
  "created_at" : "2017-11-22 13:04:11 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/epeiysrnOO",
      "expanded_url" : "https:\/\/linuxtoy.org\/archives\/reading-boot-guard-and-coreboot.html",
      "display_url" : "linuxtoy.org\/archives\/readi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "933298766672683009",
  "geo" : { },
  "id_str" : "933316112292499456",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u5EF6\u4F38\u95B2\u8B80\uFF1Ahttps:\/\/t.co\/epeiysrnOO",
  "id" : 933316112292499456,
  "in_reply_to_status_id" : 933298766672683009,
  "created_at" : "2017-11-22 12:47:56 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6731\u5229\u5B89\u5927\u738B",
      "screen_name" : "julieninside",
      "indices" : [ 3, 16 ],
      "id_str" : "906055564362264576",
      "id" : 906055564362264576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933301791315447808",
  "text" : "RT @julieninside: \u672C\u5355\u4F4D\uFF0C\u672C\u7701\u6700\u5927\u7684\u533B\u9662\u4E4B\u4E00\uFF0C\u5DF2\u9010\u6E10\u505C\u6B62\u4F7F\u7528\u8FDB\u53E3\u5668\u68B0\uFF0C\u6309\u8981\u6C42\u5168\u90E8\u56FD\u4EA7\u5316\u3002\n\n\u6240\u4EE5\u6211\u5E38\u5E38\u544A\u8BC9\u670B\u53CB\u4EEC\uFF0C\u53BB\u534E\u897F\u770B\u75C5\uFF0C\u4E0D\u8981\u6765\u6211\u4EEC\u535E\u8FD9\u513F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "932793978625257472",
    "text" : "\u672C\u5355\u4F4D\uFF0C\u672C\u7701\u6700\u5927\u7684\u533B\u9662\u4E4B\u4E00\uFF0C\u5DF2\u9010\u6E10\u505C\u6B62\u4F7F\u7528\u8FDB\u53E3\u5668\u68B0\uFF0C\u6309\u8981\u6C42\u5168\u90E8\u56FD\u4EA7\u5316\u3002\n\n\u6240\u4EE5\u6211\u5E38\u5E38\u544A\u8BC9\u670B\u53CB\u4EEC\uFF0C\u53BB\u534E\u897F\u770B\u75C5\uFF0C\u4E0D\u8981\u6765\u6211\u4EEC\u535E\u8FD9\u513F\u3002",
    "id" : 932793978625257472,
    "created_at" : "2017-11-21 02:13:09 +0000",
    "user" : {
      "name" : "\u6731\u5229\u5B89\u5927\u738B",
      "screen_name" : "julieninside",
      "protected" : false,
      "id_str" : "906055564362264576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943778899111985152\/9NDBLWeJ_normal.jpg",
      "id" : 906055564362264576,
      "verified" : false
    }
  },
  "id" : 933301791315447808,
  "created_at" : "2017-11-22 11:51:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/zVxyTeUjhg",
      "expanded_url" : "https:\/\/archive.is\/8lUtd",
      "display_url" : "archive.is\/8lUtd"
    } ]
  },
  "geo" : { },
  "id_str" : "933298766672683009",
  "text" : "Intel\u5C07\u65BC2020\u5E74\u505C\u6B62\u652F\u6301BIOS\uFF0C\u70BAUEFI\u7684\u58DF\u65B7\u92EA\u8DEF\uFF1Ahttps:\/\/t.co\/zVxyTeUjhg",
  "id" : 933298766672683009,
  "created_at" : "2017-11-22 11:39:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TualatriX",
      "screen_name" : "tualatrix",
      "indices" : [ 3, 13 ],
      "id_str" : "121908437",
      "id" : 121908437
    }, {
      "name" : "Allen Wang",
      "screen_name" : "creativewang",
      "indices" : [ 97, 110 ],
      "id_str" : "538330383",
      "id" : 538330383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933270995300790272",
  "text" : "RT @tualatrix: \u5927\u5BB6\u597D\uFF0C\u6211\u662F\u56FE\u62C9\u9F0E\u3002\u5148\u548C\u5927\u5BB6\u8BF4\u58F0\u8C22\u8C22\uFF0C\u8C22\u8C22\u4F60\u4EEC\u7684\u5173\u5FC3\u548C\u652F\u6301\u3002\u6211\u4E3B\u8981\u60F3\u548C\u5927\u5BB6\u62A5\u58F0\u5E73\u5B89\uFF0C\u8FC7\u53BB\u4E09\u5341\u5929\u9664\u88AB\u9650\u5236\u81EA\u7531\u5916\uFF0C\u7CBE\u795E\u548C\u8EAB\u4F53\u7B49\u90FD\u5B89\u597D\u3002\u5173\u4E8E\u7F51\u7EDC\u4E0A\u4E00\u4E9B\u4E0D\u5B9E\u4F20\u95FB\uFF0C\u6211\u7684\u670B\u53CB @creativewang \u5341\u4F59\u5929\u524D\u5728\u4ED6\u7684\u63A8\u4E0A\u8BF4\u5F97\u5F88\u6E05\u695A\u4E86\uFF0C\u4E0D\u518D\u89E3\u91CA\u3002\u76EE\u524D\u6682\u65F6\u5C31\u8FD9\u4E9B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allen Wang",
        "screen_name" : "creativewang",
        "indices" : [ 82, 95 ],
        "id_str" : "538330383",
        "id" : 538330383
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "933216227547275264",
    "text" : "\u5927\u5BB6\u597D\uFF0C\u6211\u662F\u56FE\u62C9\u9F0E\u3002\u5148\u548C\u5927\u5BB6\u8BF4\u58F0\u8C22\u8C22\uFF0C\u8C22\u8C22\u4F60\u4EEC\u7684\u5173\u5FC3\u548C\u652F\u6301\u3002\u6211\u4E3B\u8981\u60F3\u548C\u5927\u5BB6\u62A5\u58F0\u5E73\u5B89\uFF0C\u8FC7\u53BB\u4E09\u5341\u5929\u9664\u88AB\u9650\u5236\u81EA\u7531\u5916\uFF0C\u7CBE\u795E\u548C\u8EAB\u4F53\u7B49\u90FD\u5B89\u597D\u3002\u5173\u4E8E\u7F51\u7EDC\u4E0A\u4E00\u4E9B\u4E0D\u5B9E\u4F20\u95FB\uFF0C\u6211\u7684\u670B\u53CB @creativewang \u5341\u4F59\u5929\u524D\u5728\u4ED6\u7684\u63A8\u4E0A\u8BF4\u5F97\u5F88\u6E05\u695A\u4E86\uFF0C\u4E0D\u518D\u89E3\u91CA\u3002\u76EE\u524D\u6682\u65F6\u5C31\u8FD9\u4E9B\uFF0C\u6211\u5F97\u53BB\u6536\u62FE\u6211\u7684\u751F\u6D3B\u4E86\u2026",
    "id" : 933216227547275264,
    "created_at" : "2017-11-22 06:11:01 +0000",
    "user" : {
      "name" : "TualatriX",
      "screen_name" : "tualatrix",
      "protected" : false,
      "id_str" : "121908437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675270246509350912\/lV9-F5ey_normal.jpg",
      "id" : 121908437,
      "verified" : false
    }
  },
  "id" : 933270995300790272,
  "created_at" : "2017-11-22 09:48:39 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/uUF4l8v9i1",
      "expanded_url" : "https:\/\/twitter.com\/MarisaVeryMoe\/status\/933036159755800578",
      "display_url" : "twitter.com\/MarisaVeryMoe\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933182250669129729",
  "text" : "\uD83D\uDC8A https:\/\/t.co\/uUF4l8v9i1",
  "id" : 933182250669129729,
  "created_at" : "2017-11-22 03:56:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GFW Blog \u529F\u592B\u7F51\u4E0E\u7FFB\u5899",
      "screen_name" : "chinagfw",
      "indices" : [ 0, 9 ],
      "id_str" : "13008422",
      "id" : 13008422
    }, {
      "name" : "\u5317\u98CE\uFF08\u6E29\u4E91\u8D85, Yunchao Wen\uFF09",
      "screen_name" : "wenyunchao",
      "indices" : [ 10, 21 ],
      "id_str" : "14581421",
      "id" : 14581421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932246270923571200",
  "geo" : { },
  "id_str" : "933142847280132096",
  "in_reply_to_user_id" : 13008422,
  "text" : "@chinagfw @wenyunchao \u9084\u6709Opera\u3002",
  "id" : 933142847280132096,
  "in_reply_to_status_id" : 932246270923571200,
  "created_at" : "2017-11-22 01:19:26 +0000",
  "in_reply_to_screen_name" : "chinagfw",
  "in_reply_to_user_id_str" : "13008422",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JapanChina",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933141572983705601",
  "text" : "RT @iyouport_news: \uFF3B\u65E5\u672C\u5B66\u751F\u5728\u65E5\u5185\u74E6\u7684\u548C\u5E73\u6F14\u8BB2\u56E0\u4E2D\u56FD\u65BD\u538B\u800C\u88AB\u53D6\u6D88\uFF3D\uFF03JapanChina \u636E\u65E5\u672C\u653F\u5E9C\u6D88\u606F\u4EBA\u58EB\u900F\u9732\uFF0C\u65E5\u672C\u5B66\u751F\u548C\u5E73\u5927\u4F7F8\u6708\u4EFD\u5728\u65E5\u5185\u74E6\u4E3E\u884C\u7684\u56FD\u9645\u88C1\u519B\u4F1A\u8BAE\u4E0A\u53D1\u8868\u8BB2\u8BDD\uFF0C\u4F46\u56E0\u4E2D\u56FD\u653F\u5E9C\u7684\u65BD\u538B\u800C\u88AB\u53D6\u6D88\u3002\u81EA2014\u5E74\u4EE5\u6765\uFF0C\u6BCF\u5E74\u4E00\u5EA6\u7684\u88C1\u519B\u8C08\u5224\u4F1A\u8BAE\u90FD\u4F1A\u53D1\u8868\u8981\u6C42\u5E9F\u9664\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/932963760263667713\/photo\/1",
        "indices" : [ 152, 175 ],
        "url" : "https:\/\/t.co\/VgREERSmcs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPKNfRvUIAEA7l8.jpg",
        "id_str" : "932963641296429057",
        "id" : 932963641296429057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPKNfRvUIAEA7l8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1088,
          "resize" : "fit",
          "w" : 1740
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1088,
          "resize" : "fit",
          "w" : 1740
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/VgREERSmcs"
      } ],
      "hashtags" : [ {
        "text" : "JapanChina",
        "indices" : [ 24, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/xtvPrBYeNe",
        "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1723042147726922",
        "display_url" : "facebook.com\/iyouport\/posts\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932963760263667713",
    "text" : "\uFF3B\u65E5\u672C\u5B66\u751F\u5728\u65E5\u5185\u74E6\u7684\u548C\u5E73\u6F14\u8BB2\u56E0\u4E2D\u56FD\u65BD\u538B\u800C\u88AB\u53D6\u6D88\uFF3D\uFF03JapanChina \u636E\u65E5\u672C\u653F\u5E9C\u6D88\u606F\u4EBA\u58EB\u900F\u9732\uFF0C\u65E5\u672C\u5B66\u751F\u548C\u5E73\u5927\u4F7F8\u6708\u4EFD\u5728\u65E5\u5185\u74E6\u4E3E\u884C\u7684\u56FD\u9645\u88C1\u519B\u4F1A\u8BAE\u4E0A\u53D1\u8868\u8BB2\u8BDD\uFF0C\u4F46\u56E0\u4E2D\u56FD\u653F\u5E9C\u7684\u65BD\u538B\u800C\u88AB\u53D6\u6D88\u3002\u81EA2014\u5E74\u4EE5\u6765\uFF0C\u6BCF\u5E74\u4E00\u5EA6\u7684\u88C1\u519B\u8C08\u5224\u4F1A\u8BAE\u90FD\u4F1A\u53D1\u8868\u8981\u6C42\u5E9F\u9664\u6838\u6B66\u5668\u7684\u6F14\u8BB2\u2026\u2026https:\/\/t.co\/xtvPrBYeNe https:\/\/t.co\/VgREERSmcs",
    "id" : 932963760263667713,
    "created_at" : "2017-11-21 13:27:48 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 933141572983705601,
  "created_at" : "2017-11-22 01:14:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "9to5Mac \uF8FF",
      "screen_name" : "9to5mac",
      "indices" : [ 3, 11 ],
      "id_str" : "15944436",
      "id" : 15944436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/CnXgZi327p",
      "expanded_url" : "https:\/\/9to5mac.com\/2017\/11\/21\/skype-china-app-store\/",
      "display_url" : "9to5mac.com\/2017\/11\/21\/sky\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "933136727706947584",
  "text" : "RT @9to5mac: Apple removes Skype from Chinese app store after request from Ministry of Public\u00A0Security https:\/\/t.co\/CnXgZi327p https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/9to5mac\/status\/932966686575202305\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/tseTjV0acE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPKQOv2VQAEKJJD.jpg",
        "id_str" : "932966655856033793",
        "id" : 932966655856033793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPKQOv2VQAEKJJD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/tseTjV0acE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/CnXgZi327p",
        "expanded_url" : "https:\/\/9to5mac.com\/2017\/11\/21\/skype-china-app-store\/",
        "display_url" : "9to5mac.com\/2017\/11\/21\/sky\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932966686575202305",
    "text" : "Apple removes Skype from Chinese app store after request from Ministry of Public\u00A0Security https:\/\/t.co\/CnXgZi327p https:\/\/t.co\/tseTjV0acE",
    "id" : 932966686575202305,
    "created_at" : "2017-11-21 13:39:26 +0000",
    "user" : {
      "name" : "9to5Mac \uF8FF",
      "screen_name" : "9to5mac",
      "protected" : false,
      "id_str" : "15944436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659486593649012736\/-TGFT8rs_normal.png",
      "id" : 15944436,
      "verified" : true
    }
  },
  "id" : 933136727706947584,
  "created_at" : "2017-11-22 00:55:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Times",
      "screen_name" : "globaltimesnews",
      "indices" : [ 3, 19 ],
      "id_str" : "49616273",
      "id" : 49616273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BREAKING",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933134132296732674",
  "text" : "RT @globaltimesnews: #BREAKING: Former cyberspace administration official Lu Wei is under investigation for alleged serious disciplinary vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/globaltimesnews\/status\/932977904467800066\/photo\/1",
        "indices" : [ 152, 175 ],
        "url" : "https:\/\/t.co\/IeksWb6XBH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPKadXMU8AMgRes.jpg",
        "id_str" : "932977902051717123",
        "id" : 932977902051717123,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPKadXMU8AMgRes.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/IeksWb6XBH"
      } ],
      "hashtags" : [ {
        "text" : "BREAKING",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/bIdOH7XxdC",
        "expanded_url" : "http:\/\/ccdi.gov.cn",
        "display_url" : "ccdi.gov.cn"
      } ]
    },
    "geo" : { },
    "id_str" : "932977904467800066",
    "text" : "#BREAKING: Former cyberspace administration official Lu Wei is under investigation for alleged serious disciplinary violations: https:\/\/t.co\/bIdOH7XxdC https:\/\/t.co\/IeksWb6XBH",
    "id" : 932977904467800066,
    "created_at" : "2017-11-21 14:24:00 +0000",
    "user" : {
      "name" : "Global Times",
      "screen_name" : "globaltimesnews",
      "protected" : false,
      "id_str" : "49616273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928529100360183808\/srD3SI1x_normal.jpg",
      "id" : 49616273,
      "verified" : true
    }
  },
  "id" : 933134132296732674,
  "created_at" : "2017-11-22 00:44:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Huang",
      "screen_name" : "hjc4869",
      "indices" : [ 0, 8 ],
      "id_str" : "996744811",
      "id" : 996744811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932889105800638464",
  "geo" : { },
  "id_str" : "932890476721725441",
  "in_reply_to_user_id" : 996744811,
  "text" : "@hjc4869 **\u7684\u51E0\u5343\u4E07\u5206\u4E4B\u4E00**",
  "id" : 932890476721725441,
  "in_reply_to_status_id" : 932889105800638464,
  "created_at" : "2017-11-21 08:36:36 +0000",
  "in_reply_to_screen_name" : "hjc4869",
  "in_reply_to_user_id_str" : "996744811",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/X5Z4ScTpWE",
      "expanded_url" : "https:\/\/archive.is\/FyljI",
      "display_url" : "archive.is\/FyljI"
    } ]
  },
  "geo" : { },
  "id_str" : "932813007301857285",
  "text" : "1BTC\u7684gay\u60C5\u6545\u4E8B\uFF1Ahttps:\/\/t.co\/X5Z4ScTpWE",
  "id" : 932813007301857285,
  "created_at" : "2017-11-21 03:28:46 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fenng",
      "screen_name" : "Fenng",
      "indices" : [ 3, 9 ],
      "id_str" : "1490631",
      "id" : 1490631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Fenng\/status\/931209066898014209\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/aU1WVcjGLX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DOxRo-cVwAAgV7Z.jpg",
      "id_str" : "931208987357331456",
      "id" : 931208987357331456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOxRo-cVwAAgV7Z.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/aU1WVcjGLX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932769983460990976",
  "text" : "RT @Fenng: \u63A8\u7279\u4E2D\u6587\u5708\u5174\u8870\uFF0C2012 \u5E74\u53D1\u751F\u4E86\u4EC0\u4E48\uFF1F\u4F60\u731C https:\/\/t.co\/aU1WVcjGLX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fenng\/status\/931209066898014209\/photo\/1",
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/aU1WVcjGLX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DOxRo-cVwAAgV7Z.jpg",
        "id_str" : "931208987357331456",
        "id" : 931208987357331456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOxRo-cVwAAgV7Z.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/aU1WVcjGLX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "931209066898014209",
    "text" : "\u63A8\u7279\u4E2D\u6587\u5708\u5174\u8870\uFF0C2012 \u5E74\u53D1\u751F\u4E86\u4EC0\u4E48\uFF1F\u4F60\u731C https:\/\/t.co\/aU1WVcjGLX",
    "id" : 931209066898014209,
    "created_at" : "2017-11-16 17:15:17 +0000",
    "user" : {
      "name" : "Fenng",
      "screen_name" : "Fenng",
      "protected" : false,
      "id_str" : "1490631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727549907616157696\/WxPKEeRb_normal.jpg",
      "id" : 1490631,
      "verified" : false
    }
  },
  "id" : 932769983460990976,
  "created_at" : "2017-11-21 00:37:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/dkc112hSXJ",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/932534198681980934",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932535991214202882",
  "text" : "\u81EA\u5F9E\u4E0A\u4E86\u77E5\u4E4E\u548C\u63A8\u7279\uFF0C\u611F\u89BA\u81EA\u5DF1\u8D8A\u4F86\u8D8A\u653E\u6D6A\u4E86\u3002\u3002 https:\/\/t.co\/dkc112hSXJ",
  "id" : 932535991214202882,
  "created_at" : "2017-11-20 09:08:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u62B9\u8336\u706C\u5E03\u4E01",
      "screen_name" : "ikaros_qwq",
      "indices" : [ 0, 11 ],
      "id_str" : "828413584082235397",
      "id" : 828413584082235397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932340937438650368",
  "geo" : { },
  "id_str" : "932534198681980934",
  "in_reply_to_user_id" : 828413584082235397,
  "text" : "@ikaros_qwq \u6EBC\u7684\u8A71\u8D95\u7DCA\u8214\u6389\u554A~\n\u6211\u6BCF\u6B21\u9192\u4F86\u6642\u90FD\u4E7E\u4E86\u3002\u3002",
  "id" : 932534198681980934,
  "in_reply_to_status_id" : 932340937438650368,
  "created_at" : "2017-11-20 09:00:53 +0000",
  "in_reply_to_screen_name" : "ikaros_qwq",
  "in_reply_to_user_id_str" : "828413584082235397",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u96E8\u5A77",
      "screen_name" : "cherylnatsu",
      "indices" : [ 0, 12 ],
      "id_str" : "188330055",
      "id" : 188330055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932526960760229888",
  "geo" : { },
  "id_str" : "932528741305278464",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@cherylnatsu emmmm....\n\u91CC\u2192\u88CF",
  "id" : 932528741305278464,
  "in_reply_to_status_id" : 932526960760229888,
  "created_at" : "2017-11-20 08:39:12 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "\u590F\u96E8\u5A77",
      "screen_name" : "cherylnatsu",
      "indices" : [ 12, 24 ],
      "id_str" : "188330055",
      "id" : 188330055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932527042054246400",
  "text" : "RT @dou4cc: @cherylnatsu \u800C\u4E14cortana\u7684\u8A2D\u7F6E\u91CC\u95DC\u4E0D\u6389\uFF0C\n\u6211\u73FE\u5728\u5DF2\u7D93\u7981\u6B62cortana\u5F48\u901A\u77E5\u4E86\u3002\u3002\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u590F\u96E8\u5A77",
        "screen_name" : "cherylnatsu",
        "indices" : [ 0, 12 ],
        "id_str" : "188330055",
        "id" : 188330055
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926463922122526720",
    "geo" : { },
    "id_str" : "932526960760229888",
    "in_reply_to_user_id" : 188330055,
    "text" : "@cherylnatsu \u800C\u4E14cortana\u7684\u8A2D\u7F6E\u91CC\u95DC\u4E0D\u6389\uFF0C\n\u6211\u73FE\u5728\u5DF2\u7D93\u7981\u6B62cortana\u5F48\u901A\u77E5\u4E86\u3002\u3002\u3002",
    "id" : 932526960760229888,
    "in_reply_to_status_id" : 926463922122526720,
    "created_at" : "2017-11-20 08:32:07 +0000",
    "in_reply_to_screen_name" : "cherylnatsu",
    "in_reply_to_user_id_str" : "188330055",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 932527042054246400,
  "created_at" : "2017-11-20 08:32:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u96E8\u5A77",
      "screen_name" : "cherylnatsu",
      "indices" : [ 0, 12 ],
      "id_str" : "188330055",
      "id" : 188330055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926463922122526720",
  "geo" : { },
  "id_str" : "932526960760229888",
  "in_reply_to_user_id" : 188330055,
  "text" : "@cherylnatsu \u800C\u4E14cortana\u7684\u8A2D\u7F6E\u91CC\u95DC\u4E0D\u6389\uFF0C\n\u6211\u73FE\u5728\u5DF2\u7D93\u7981\u6B62cortana\u5F48\u901A\u77E5\u4E86\u3002\u3002\u3002",
  "id" : 932526960760229888,
  "in_reply_to_status_id" : 926463922122526720,
  "created_at" : "2017-11-20 08:32:07 +0000",
  "in_reply_to_screen_name" : "cherylnatsu",
  "in_reply_to_user_id_str" : "188330055",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/932521026944229377\/photo\/1",
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/9y8njecUty",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPD65ahXUAA7UPP.jpg",
      "id_str" : "932520987144441856",
      "id" : 932520987144441856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPD65ahXUAA7UPP.jpg",
      "sizes" : [ {
        "h" : 33,
        "resize" : "fit",
        "w" : 371
      }, {
        "h" : 33,
        "resize" : "fit",
        "w" : 371
      }, {
        "h" : 33,
        "resize" : "fit",
        "w" : 371
      }, {
        "h" : 33,
        "resize" : "fit",
        "w" : 371
      }, {
        "h" : 33,
        "resize" : "crop",
        "w" : 33
      } ],
      "display_url" : "pic.twitter.com\/9y8njecUty"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932519098382209024",
  "geo" : { },
  "id_str" : "932521026944229377",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u597D\u5427\uFF0C\u670D\u4F60\uFF1A https:\/\/t.co\/9y8njecUty",
  "id" : 932521026944229377,
  "in_reply_to_status_id" : 932519098382209024,
  "created_at" : "2017-11-20 08:08:32 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/932519098382209024\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/aDsK9IcZug",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPD5KI1UEAAfdi5.jpg",
      "id_str" : "932519075430797312",
      "id" : 932519075430797312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPD5KI1UEAAfdi5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 533
      } ],
      "display_url" : "pic.twitter.com\/aDsK9IcZug"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932519098382209024",
  "text" : "\u5F37\u8FEB\u75C7\u60A3\u8005\u5225\u5B78js\uFF0C\u50B7\u4E0D\u8D77\uFF1A https:\/\/t.co\/aDsK9IcZug",
  "id" : 932519098382209024,
  "created_at" : "2017-11-20 08:00:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/NvR4iad4a6",
      "expanded_url" : "http:\/\/southpark.wikia.com\/wiki\/Shitter",
      "display_url" : "southpark.wikia.com\/wiki\/Shitter"
    } ]
  },
  "geo" : { },
  "id_str" : "932512839826333696",
  "text" : "\u807D\u8AAA\u4E0D\u5C11\u63A8\u53CB\u90FD\u662F\u62FF\u9019\u7A2E\u6771\u897F\u767C\u63A8\u7684\uFF1Ahttps:\/\/t.co\/NvR4iad4a6",
  "id" : 932512839826333696,
  "created_at" : "2017-11-20 07:36:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932263846034546688",
  "geo" : { },
  "id_str" : "932510182436982784",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u4E0D\u5920\u6296\u54E6\uFF01",
  "id" : 932510182436982784,
  "in_reply_to_status_id" : 932263846034546688,
  "created_at" : "2017-11-20 07:25:27 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u795E\u697D\u5742\u6CC9@\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "KagurazakaIzumi",
      "indices" : [ 0, 16 ],
      "id_str" : "482695937",
      "id" : 482695937
    }, {
      "name" : "\u53D7\u55B5",
      "screen_name" : "shoumiao",
      "indices" : [ 17, 26 ],
      "id_str" : "2995860974",
      "id" : 2995860974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932229492877115392",
  "geo" : { },
  "id_str" : "932419216480796672",
  "in_reply_to_user_id" : 482695937,
  "text" : "@KagurazakaIzumi @shoumiao \u8ACB\u5206\u6E05G\u548CT\u3002",
  "id" : 932419216480796672,
  "in_reply_to_status_id" : 932229492877115392,
  "created_at" : "2017-11-20 01:23:59 +0000",
  "in_reply_to_screen_name" : "KagurazakaIzumi",
  "in_reply_to_user_id_str" : "482695937",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932225049427312645",
  "text" : "\u6709\u4EBA\u77E5\u9053\u6CE8\u518AProtonmail\u6642\u54EA\u4E9B\u90F5\u4EF6\u670D\u52D9\u57DF\u540D\u4E0D\u80FD\u7528\u65BC\u6A5F\u5668\u4EBA\u9A57\u8B49\u55CE\uFF1F",
  "id" : 932225049427312645,
  "created_at" : "2017-11-19 12:32:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932167572899762176",
  "geo" : { },
  "id_str" : "932186522677334016",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u770B\u96FB\u5F71\u6642\u4E0D\u8981\u73A9\u624B\u6A5F\u3002",
  "id" : 932186522677334016,
  "in_reply_to_status_id" : 932167572899762176,
  "created_at" : "2017-11-19 09:59:20 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/OcRWAyGGJx",
      "expanded_url" : "https:\/\/archive.is\/9HmHT",
      "display_url" : "archive.is\/9HmHT"
    } ]
  },
  "geo" : { },
  "id_str" : "932186135144620032",
  "text" : "GitHub\u6210\u7232\u5DE8\u982D\uFF1Ahttps:\/\/t.co\/OcRWAyGGJx",
  "id" : 932186135144620032,
  "created_at" : "2017-11-19 09:57:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931416732534788096",
  "geo" : { },
  "id_str" : "932125465665507328",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u624D35\u4EBA\u5C31\u5DF2\u662FQQ\u7A7A\u9593\u5373\u8996\u611F\uFF0C\u5728\u8003\u616E\u662F\u5426\u503C\u5F97\u7E7C\u7E8C\u3002\u3002",
  "id" : 932125465665507328,
  "in_reply_to_status_id" : 931416732534788096,
  "created_at" : "2017-11-19 05:56:43 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 0, 12 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931576426695938048",
  "geo" : { },
  "id_str" : "932121768080429056",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@DevinStever \u4F60\u662F\u8AAAChrome\uFF1F",
  "id" : 932121768080429056,
  "in_reply_to_status_id" : 931576426695938048,
  "created_at" : "2017-11-19 05:42:02 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u62A0\u811A\u80A5\u5B85\u5927\u6C49",
      "screen_name" : "hakureyuyuko",
      "indices" : [ 0, 13 ],
      "id_str" : "967252740",
      "id" : 967252740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930068086207660032",
  "geo" : { },
  "id_str" : "932115755491045376",
  "in_reply_to_user_id" : 967252740,
  "text" : "@hakureyuyuko \u6211\u770B\u5230\u4E86\u52A0\u901F\u7403\u3002\u3002",
  "id" : 932115755491045376,
  "in_reply_to_status_id" : 930068086207660032,
  "created_at" : "2017-11-19 05:18:08 +0000",
  "in_reply_to_screen_name" : "hakureyuyuko",
  "in_reply_to_user_id_str" : "967252740",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u62A0\u811A\u80A5\u5B85\u5927\u6C49",
      "screen_name" : "hakureyuyuko",
      "indices" : [ 0, 13 ],
      "id_str" : "967252740",
      "id" : 967252740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930633515464400896",
  "geo" : { },
  "id_str" : "932115047903580160",
  "in_reply_to_user_id" : 967252740,
  "text" : "@hakureyuyuko QQ\u7A7A\u9593\u90FD\u628A\u201C\u66B4\u8D70\u5927\u4E8B\u4EF6\u201D\u5217\u5165\u654F\u611F\u8A5E\u4E86\u3002\u6C92\u6709\u9670\u8B00\u3002",
  "id" : 932115047903580160,
  "in_reply_to_status_id" : 930633515464400896,
  "created_at" : "2017-11-19 05:15:19 +0000",
  "in_reply_to_screen_name" : "hakureyuyuko",
  "in_reply_to_user_id_str" : "967252740",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Huang",
      "screen_name" : "hjc4869",
      "indices" : [ 3, 11 ],
      "id_str" : "996744811",
      "id" : 996744811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931783026316595200",
  "text" : "RT @hjc4869: \u6BD4\u8D77ME\uFF0COEM\u5728\u56FA\u4EF6\u91CC\u7559\u7684\u540E\u95E8\u624D\u662F\u771F\u7684\u53EF\u6015\uFF0C\u6BD4\u5982\u957F\u671F\u88AB\u70B9\u540D\u6279\u8BC4\u7684\u8054\u60F3\u53CA\u5176\u65D7\u4E0B\u7684\u90E8\u5206Thinkpad\u3002BIOS\u53EF\u4EE5\u5728\u542F\u52A8OS\u524D\u4EFB\u610F\u8BBF\u95EE\u786C\u76D8\uFF0C\u56FA\u4EF6\u81EA\u5E26\u4E00\u4E2ANTFS\u9A71\u52A8\u5C31\u53EF\u4EE5\u5728\u542F\u52A8\u524D\u5BF9\u4F60\u7684Windows\u505A\u4EFB\u4F55\u4E8B\u60C5\u3002\u5C31\u7B97\u4F60\u4E0A\u4E86\u52A0\u5BC6\uFF0CTPM\u7531BIOS\u521D\u59CB\u5316\uFF1B\u5C31\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "929946570807582721",
    "text" : "\u6BD4\u8D77ME\uFF0COEM\u5728\u56FA\u4EF6\u91CC\u7559\u7684\u540E\u95E8\u624D\u662F\u771F\u7684\u53EF\u6015\uFF0C\u6BD4\u5982\u957F\u671F\u88AB\u70B9\u540D\u6279\u8BC4\u7684\u8054\u60F3\u53CA\u5176\u65D7\u4E0B\u7684\u90E8\u5206Thinkpad\u3002BIOS\u53EF\u4EE5\u5728\u542F\u52A8OS\u524D\u4EFB\u610F\u8BBF\u95EE\u786C\u76D8\uFF0C\u56FA\u4EF6\u81EA\u5E26\u4E00\u4E2ANTFS\u9A71\u52A8\u5C31\u53EF\u4EE5\u5728\u542F\u52A8\u524D\u5BF9\u4F60\u7684Windows\u505A\u4EFB\u4F55\u4E8B\u60C5\u3002\u5C31\u7B97\u4F60\u4E0A\u4E86\u52A0\u5BC6\uFF0CTPM\u7531BIOS\u521D\u59CB\u5316\uFF1B\u5C31\u7B97\u4F60\u4E0D\u7528TPM\uFF0C\u8F93\u5165\u5BC6\u7801\u7684EFI\u7A0B\u5E8F\u8FD0\u884C\u5728UEFI\u73AF\u5883\u4E0B\uFF0C\u7406\u8BBA\u4E0A\u4E5F\u53EF\u4EE5\u5750\u5230",
    "id" : 929946570807582721,
    "created_at" : "2017-11-13 05:38:34 +0000",
    "user" : {
      "name" : "David Huang",
      "screen_name" : "hjc4869",
      "protected" : false,
      "id_str" : "996744811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713724591865270273\/mYrXhD5M_normal.jpg",
      "id" : 996744811,
      "verified" : false
    }
  },
  "id" : 931783026316595200,
  "created_at" : "2017-11-18 07:15:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/931770975296872448\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/i9hQ7Jnvbv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DO5QwY1X0AAeYVL.jpg",
      "id_str" : "931770965142523904",
      "id" : 931770965142523904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DO5QwY1X0AAeYVL.jpg",
      "sizes" : [ {
        "h" : 72,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 72,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 72,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 72,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 72,
        "resize" : "crop",
        "w" : 72
      } ],
      "display_url" : "pic.twitter.com\/i9hQ7Jnvbv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931770975296872448",
  "text" : "Chrome\u5F9ESafari\u5B78\u4F86\u7684\u5947\u602A\u4E0B\u5283\u7DAB\uFF1A https:\/\/t.co\/i9hQ7Jnvbv",
  "id" : 931770975296872448,
  "created_at" : "2017-11-18 06:28:06 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/cfi2aJSCiw",
      "expanded_url" : "https:\/\/archive.is\/MXMCy",
      "display_url" : "archive.is\/MXMCy"
    } ]
  },
  "geo" : { },
  "id_str" : "931769657526190080",
  "text" : "\u8C37\u6B4C\u4EE5\u60E1\u5236\u60E1\uFF1Ahttps:\/\/t.co\/cfi2aJSCiw",
  "id" : 931769657526190080,
  "created_at" : "2017-11-18 06:22:52 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Yan",
      "screen_name" : "felixonmars",
      "indices" : [ 3, 15 ],
      "id_str" : "18282310",
      "id" : 18282310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/clskciNfKt",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/mozilla.dev.security.policy\/LM1SpKHJ-oc",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931768446043459585",
  "text" : "RT @felixonmars: \u5947\u864E 360 CTO \u5BA3\u5E03 StartCom \u660E\u5E74 1 \u6708 1 \u65E5\u8D77\u7EC8\u6B62\u7B7E\u53D1\u8BC1\u4E66\uFF0C\u6E05\u7B97\uFF0C\u5E76\u5728\u4E24\u5E74\u540E\u9500\u6BC1\u73B0\u6709\u7684\u4E09\u5BF9\u6839\u8BC1\u4E66\u3002 https:\/\/t.co\/clskciNfKt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/clskciNfKt",
        "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/mozilla.dev.security.policy\/LM1SpKHJ-oc",
        "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "931542088293826560",
    "text" : "\u5947\u864E 360 CTO \u5BA3\u5E03 StartCom \u660E\u5E74 1 \u6708 1 \u65E5\u8D77\u7EC8\u6B62\u7B7E\u53D1\u8BC1\u4E66\uFF0C\u6E05\u7B97\uFF0C\u5E76\u5728\u4E24\u5E74\u540E\u9500\u6BC1\u73B0\u6709\u7684\u4E09\u5BF9\u6839\u8BC1\u4E66\u3002 https:\/\/t.co\/clskciNfKt",
    "id" : 931542088293826560,
    "created_at" : "2017-11-17 15:18:35 +0000",
    "user" : {
      "name" : "Felix Yan",
      "screen_name" : "felixonmars",
      "protected" : false,
      "id_str" : "18282310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2665417000\/62b553551cd29762e9a7214ff4f7ed80_normal.jpeg",
      "id" : 18282310,
      "verified" : false
    }
  },
  "id" : 931768446043459585,
  "created_at" : "2017-11-18 06:18:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/HI10JBPV8R",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=1306222",
      "display_url" : "music.163.com\/#\/song?id=1306\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931508595375689733",
  "text" : "Noon\uFF1Ahttps:\/\/t.co\/HI10JBPV8R",
  "id" : 931508595375689733,
  "created_at" : "2017-11-17 13:05:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/931508461170552832\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/ZX7h4lh5rD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DO1h_W0X0AAmmyU.jpg",
      "id_str" : "931508439020457984",
      "id" : 931508439020457984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DO1h_W0X0AAmmyU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 621
      } ],
      "display_url" : "pic.twitter.com\/ZX7h4lh5rD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931508461170552832",
  "text" : "\u7232\u4EC0\u9EBDPPPoE\u4E0D\u80FD\u6DFB\u52A0\u8D85\u904E2\u500BDNS\u670D\u52D9\u5668\uFF1F https:\/\/t.co\/ZX7h4lh5rD",
  "id" : 931508461170552832,
  "created_at" : "2017-11-17 13:04:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931465524776710144",
  "geo" : { },
  "id_str" : "931498256135278592",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u65BC\u662F\u6539\u6210\u4E86\u9A30\u8A0A\u7684119.29.29.29\u4F86\u7A7F\u900F\u79FB\u52D5\u7684\u58BB\u4E2D\u58BB\u3002",
  "id" : 931498256135278592,
  "in_reply_to_status_id" : 931465524776710144,
  "created_at" : "2017-11-17 12:24:25 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/7l17QMNMwZ",
      "expanded_url" : "https:\/\/cnodejs.org\/topic\/5a0e895d063352387759add4",
      "display_url" : "cnodejs.org\/topic\/5a0e895d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931483206620205059",
  "text" : "\u6F38\u9032\u7DE8\u8B6F\uFF0C\u96A8\u6642\u62CD\u7167\uFF1Ahttps:\/\/t.co\/7l17QMNMwZ",
  "id" : 931483206620205059,
  "created_at" : "2017-11-17 11:24:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "FiveYellowMice",
      "screen_name" : "FiveYellowMice",
      "indices" : [ 12, 27 ],
      "id_str" : "2359873747",
      "id" : 2359873747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931482251111563264",
  "text" : "RT @dou4cc: @FiveYellowMice \u7E2E\u9032\u672C\u4F86\u5C31\u662F\u591A\u6A23\u7684\u3002\n\u2014\u2014Lisp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FiveYellowMice",
        "screen_name" : "FiveYellowMice",
        "indices" : [ 0, 15 ],
        "id_str" : "2359873747",
        "id" : 2359873747
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "891514228296699904",
    "geo" : { },
    "id_str" : "931482048476348416",
    "in_reply_to_user_id" : 2359873747,
    "text" : "@FiveYellowMice \u7E2E\u9032\u672C\u4F86\u5C31\u662F\u591A\u6A23\u7684\u3002\n\u2014\u2014Lisp",
    "id" : 931482048476348416,
    "in_reply_to_status_id" : 891514228296699904,
    "created_at" : "2017-11-17 11:20:01 +0000",
    "in_reply_to_screen_name" : "FiveYellowMice",
    "in_reply_to_user_id_str" : "2359873747",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 931482251111563264,
  "created_at" : "2017-11-17 11:20:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FiveYellowMice",
      "screen_name" : "FiveYellowMice",
      "indices" : [ 0, 15 ],
      "id_str" : "2359873747",
      "id" : 2359873747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "891514228296699904",
  "geo" : { },
  "id_str" : "931482048476348416",
  "in_reply_to_user_id" : 2359873747,
  "text" : "@FiveYellowMice \u7E2E\u9032\u672C\u4F86\u5C31\u662F\u591A\u6A23\u7684\u3002\n\u2014\u2014Lisp",
  "id" : 931482048476348416,
  "in_reply_to_status_id" : 891514228296699904,
  "created_at" : "2017-11-17 11:20:01 +0000",
  "in_reply_to_screen_name" : "FiveYellowMice",
  "in_reply_to_user_id_str" : "2359873747",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931416732534788096",
  "geo" : { },
  "id_str" : "931481683727134721",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u975E\u5E38\u6176\u5E78\u81EA\u5DF1\u4EE51998\u5E74\u7232\u754C\uFF0C1997\u5E74\u751F\u7684\u63A8\u53CB\u50F9\u503C\u6578\u4E0D\u904E\u4F86\u3002",
  "id" : 931481683727134721,
  "in_reply_to_status_id" : 931416732534788096,
  "created_at" : "2017-11-17 11:18:34 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/931465524776710144\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/1grCmJo5bn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DO068yWXcAA4tyn.jpg",
      "id_str" : "931465513917706240",
      "id" : 931465513917706240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DO068yWXcAA4tyn.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 1343
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 1343
      } ],
      "display_url" : "pic.twitter.com\/1grCmJo5bn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931465524776710144",
  "text" : "\u5357\u4EAC\u79FB\u52D5\u4F3C\u4E4E\u4E0D\u52AB\u6301UDP53\u7AEF\u53E3\u4E86\uFF1A https:\/\/t.co\/1grCmJo5bn",
  "id" : 931465524776710144,
  "created_at" : "2017-11-17 10:14:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/xNRrdVRvTS",
      "expanded_url" : "https:\/\/twitter.com\/kujou_rin\/status\/931454046547845120",
      "display_url" : "twitter.com\/kujou_rin\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931459092572528640",
  "text" : "\u597D\u8001\u3002\u3002 https:\/\/t.co\/xNRrdVRvTS",
  "id" : 931459092572528640,
  "created_at" : "2017-11-17 09:48:47 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/6Geql6QJ8K",
      "expanded_url" : "https:\/\/twitter.com\/chengr28\/status\/931167258314924037",
      "display_url" : "twitter.com\/chengr28\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931456027597443072",
  "text" : "\u90A3\u9EBD\u6C61\u5C31\u5225\u7528\u9019\u7A2E\u982D\u50CF\u4E86\u561B\uFF01 https:\/\/t.co\/6Geql6QJ8K",
  "id" : 931456027597443072,
  "created_at" : "2017-11-17 09:36:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/YrOIZqE3sv",
      "expanded_url" : "https:\/\/archive.is\/oc8hy",
      "display_url" : "archive.is\/oc8hy"
    } ]
  },
  "geo" : { },
  "id_str" : "931455136471355392",
  "text" : "Intel HAXM\u4EE5BSD3\u958B\u6E90\uFF1Ahttps:\/\/t.co\/YrOIZqE3sv",
  "id" : 931455136471355392,
  "created_at" : "2017-11-17 09:33:04 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/VKIc7XqM3F",
      "expanded_url" : "https:\/\/archive.is\/PbQLX",
      "display_url" : "archive.is\/PbQLX"
    } ]
  },
  "geo" : { },
  "id_str" : "931454538950815744",
  "text" : "\u5FAE\u8EDF\u63A8\u52D5GVFS\u8DE8\u5E73\u81FA\uFF1Ahttps:\/\/t.co\/VKIc7XqM3F",
  "id" : 931454538950815744,
  "created_at" : "2017-11-17 09:30:42 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 3, 15 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    }, {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 17, 24 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931452866723753984",
  "text" : "RT @jichi_zhang: @dou4cc \u4F60\u8A3B\u518A\u7684\u5E74\u4EFD\u6E1B13\uFF0C\u5C31\u662F\u4F60\u53EF\u4EE5\u8A2D\u5B9A\u7684\u6700\u665A\u7684\u51FA\u751F\u5E74\u4EFD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
        "screen_name" : "dou4cc",
        "indices" : [ 0, 7 ],
        "id_str" : "3359880735",
        "id" : 3359880735
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "931419568807047170",
    "geo" : { },
    "id_str" : "931436062575955968",
    "in_reply_to_user_id" : 3359880735,
    "text" : "@dou4cc \u4F60\u8A3B\u518A\u7684\u5E74\u4EFD\u6E1B13\uFF0C\u5C31\u662F\u4F60\u53EF\u4EE5\u8A2D\u5B9A\u7684\u6700\u665A\u7684\u51FA\u751F\u5E74\u4EFD",
    "id" : 931436062575955968,
    "in_reply_to_status_id" : 931419568807047170,
    "created_at" : "2017-11-17 08:17:17 +0000",
    "in_reply_to_screen_name" : "dou4cc",
    "in_reply_to_user_id_str" : "3359880735",
    "user" : {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "protected" : false,
      "id_str" : "4628523253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941625178471112706\/oqVlIkSk_normal.jpg",
      "id" : 4628523253,
      "verified" : false
    }
  },
  "id" : 931452866723753984,
  "created_at" : "2017-11-17 09:24:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931433011823788032",
  "geo" : { },
  "id_str" : "931452622162333696",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u5C0Dusername\u7684\u4FEE\u6539\u662F\u7834\u58DE\u6027\u7684\u3002",
  "id" : 931452622162333696,
  "in_reply_to_status_id" : 931433011823788032,
  "created_at" : "2017-11-17 09:23:05 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/931419568807047170\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/RpW5dYbPW7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DO0RKAYUIAEc5Mf.jpg",
      "id_str" : "931419561533906945",
      "id" : 931419561533906945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DO0RKAYUIAEc5Mf.jpg",
      "sizes" : [ {
        "h" : 146,
        "resize" : "crop",
        "w" : 146
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 295
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 295
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 295
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 295
      } ],
      "display_url" : "pic.twitter.com\/RpW5dYbPW7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931419568807047170",
  "text" : "\u610F\u5916\u5730\u767C\u73FE\u63A8\u7279\u5141\u8A31\u7684\u6700\u665A\u51FA\u751F\u65E5\u671F\u662F2002\/07\/03\uFF1B\u63A8\u7279\u4E0D\u5141\u8A31\u672A\u6210\u5E74\u4EBA\u516C\u958B\u81EA\u5DF1\u672A\u6210\u5E74\u3002 https:\/\/t.co\/RpW5dYbPW7",
  "id" : 931419568807047170,
  "created_at" : "2017-11-17 07:11:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/4D2zSjCQpx",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/lists\/list\/members",
      "display_url" : "twitter.com\/dou4cc\/lists\/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931416732534788096",
  "text" : "\u6211\u6B63\u5728\u6536\u96C6\u4E16\u7D00\u4E4B\u4EA4\u51FA\u751F\u7684\u4E2D\u570B\u5927\u9678\u63A8\u53CB\uFF1Ahttps:\/\/t.co\/4D2zSjCQpx",
  "id" : 931416732534788096,
  "created_at" : "2017-11-17 07:00:28 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u307E\u3064\u69D8\u25BD\u3071\u3093\u3064\u306E\u59EB",
      "screen_name" : "R_Ap8_",
      "indices" : [ 3, 10 ],
      "id_str" : "778553559893716993",
      "id" : 778553559893716993
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/R_Ap8_\/status\/927705660275306496\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/YNuWUTEWVd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_fX4PU8AAIKBk.jpg",
      "id_str" : "927705649588269056",
      "id" : 927705649588269056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_fX4PU8AAIKBk.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/YNuWUTEWVd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/R_Ap8_\/status\/927705660275306496\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/YNuWUTEWVd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_fX4UUIAAcWf4.jpg",
      "id_str" : "927705649609187328",
      "id" : 927705649609187328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_fX4UUIAAcWf4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/YNuWUTEWVd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/R_Ap8_\/status\/927705660275306496\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/YNuWUTEWVd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_fX4OV4AElETr.jpg",
      "id_str" : "927705649584136193",
      "id" : 927705649584136193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_fX4OV4AElETr.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/YNuWUTEWVd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/R_Ap8_\/status\/927705660275306496\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/YNuWUTEWVd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_fX4RV4AABSI2.jpg",
      "id_str" : "927705649596719104",
      "id" : 927705649596719104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_fX4RV4AABSI2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1366
      } ],
      "display_url" : "pic.twitter.com\/YNuWUTEWVd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931386046083948545",
  "text" : "RT @R_Ap8_: \u305F\u3060\u3001\u611B\u3057\u3066\u6B32\u3057\u3044\u3002 https:\/\/t.co\/YNuWUTEWVd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/R_Ap8_\/status\/927705660275306496\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/YNuWUTEWVd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_fX4PU8AAIKBk.jpg",
        "id_str" : "927705649588269056",
        "id" : 927705649588269056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_fX4PU8AAIKBk.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YNuWUTEWVd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/R_Ap8_\/status\/927705660275306496\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/YNuWUTEWVd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_fX4UUIAAcWf4.jpg",
        "id_str" : "927705649609187328",
        "id" : 927705649609187328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_fX4UUIAAcWf4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YNuWUTEWVd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/R_Ap8_\/status\/927705660275306496\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/YNuWUTEWVd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_fX4OV4AElETr.jpg",
        "id_str" : "927705649584136193",
        "id" : 927705649584136193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_fX4OV4AElETr.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YNuWUTEWVd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/R_Ap8_\/status\/927705660275306496\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/YNuWUTEWVd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_fX4RV4AABSI2.jpg",
        "id_str" : "927705649596719104",
        "id" : 927705649596719104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_fX4RV4AABSI2.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 454
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1366
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1366
        } ],
        "display_url" : "pic.twitter.com\/YNuWUTEWVd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927705660275306496",
    "text" : "\u305F\u3060\u3001\u611B\u3057\u3066\u6B32\u3057\u3044\u3002 https:\/\/t.co\/YNuWUTEWVd",
    "id" : 927705660275306496,
    "created_at" : "2017-11-07 01:14:00 +0000",
    "user" : {
      "name" : "\u3042\u307E\u3064\u69D8\u25BD\u3071\u3093\u3064\u306E\u59EB",
      "screen_name" : "R_Ap8_",
      "protected" : false,
      "id_str" : "778553559893716993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945468434120241152\/EgWT4e-x_normal.jpg",
      "id" : 778553559893716993,
      "verified" : false
    }
  },
  "id" : 931386046083948545,
  "created_at" : "2017-11-17 04:58:32 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931347305172791296",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u4F60\u7684\u535A\u5BA2\u548Cgithub\u90FD\u4E0D\u898B\u4E86\uFF1F\uFF1F",
  "id" : 931347305172791296,
  "created_at" : "2017-11-17 02:24:35 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 12, 27 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931334456241262592",
  "text" : "RT @dou4cc: @GreatFireChina \u8B8A\u6210\u5211\u5075\u5F8C\u4E0D\u7C4C\u9322\u9084\u767C\u9322\u4E86\uFF1F\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GreatFire.org",
        "screen_name" : "GreatFireChina",
        "indices" : [ 0, 15 ],
        "id_str" : "254148157",
        "id" : 254148157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "931093878001643521",
    "geo" : { },
    "id_str" : "931334380034953216",
    "in_reply_to_user_id" : 254148157,
    "text" : "@GreatFireChina \u8B8A\u6210\u5211\u5075\u5F8C\u4E0D\u7C4C\u9322\u9084\u767C\u9322\u4E86\uFF1F\uFF01",
    "id" : 931334380034953216,
    "in_reply_to_status_id" : 931093878001643521,
    "created_at" : "2017-11-17 01:33:14 +0000",
    "in_reply_to_screen_name" : "GreatFireChina",
    "in_reply_to_user_id_str" : "254148157",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 931334456241262592,
  "created_at" : "2017-11-17 01:33:32 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 0, 15 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931093878001643521",
  "geo" : { },
  "id_str" : "931334380034953216",
  "in_reply_to_user_id" : 254148157,
  "text" : "@GreatFireChina \u8B8A\u6210\u5211\u5075\u5F8C\u4E0D\u7C4C\u9322\u9084\u767C\u9322\u4E86\uFF1F\uFF01",
  "id" : 931334380034953216,
  "in_reply_to_status_id" : 931093878001643521,
  "created_at" : "2017-11-17 01:33:14 +0000",
  "in_reply_to_screen_name" : "GreatFireChina",
  "in_reply_to_user_id_str" : "254148157",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 3, 15 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    }, {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 17, 24 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931032890296684544",
  "text" : "RT @jichi_zhang: @dou4cc \u653F\u5E9C\u5728\u7528\u62FC\u97F3\uFF0C\u53EF\u662F\u53F0\u7063\u4EBA\u4E0D\u6703\u62FC\u97F3\u554A\uFF0C\u5B78\u6821\u88E1\u53EA\u6559\u6CE8\u97F3\uFF0C\u6240\u4EE5\u7576\u7136\u5F88\u5C11\u4EBA\u7528\u62FC\u97F3\u8F38\u5165\u6CD5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
        "screen_name" : "dou4cc",
        "indices" : [ 0, 7 ],
        "id_str" : "3359880735",
        "id" : 3359880735
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "931032084466032641",
    "geo" : { },
    "id_str" : "931032519926939648",
    "in_reply_to_user_id" : 3359880735,
    "text" : "@dou4cc \u653F\u5E9C\u5728\u7528\u62FC\u97F3\uFF0C\u53EF\u662F\u53F0\u7063\u4EBA\u4E0D\u6703\u62FC\u97F3\u554A\uFF0C\u5B78\u6821\u88E1\u53EA\u6559\u6CE8\u97F3\uFF0C\u6240\u4EE5\u7576\u7136\u5F88\u5C11\u4EBA\u7528\u62FC\u97F3\u8F38\u5165\u6CD5",
    "id" : 931032519926939648,
    "in_reply_to_status_id" : 931032084466032641,
    "created_at" : "2017-11-16 05:33:45 +0000",
    "in_reply_to_screen_name" : "dou4cc",
    "in_reply_to_user_id_str" : "3359880735",
    "user" : {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "protected" : false,
      "id_str" : "4628523253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941625178471112706\/oqVlIkSk_normal.jpg",
      "id" : 4628523253,
      "verified" : false
    }
  },
  "id" : 931032890296684544,
  "created_at" : "2017-11-16 05:35:13 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931032519926939648",
  "geo" : { },
  "id_str" : "931032762357899264",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u554A\u3002\u597D\u5427\u3002",
  "id" : 931032762357899264,
  "in_reply_to_status_id" : 931032519926939648,
  "created_at" : "2017-11-16 05:34:42 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/zKl6uhpWsc",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E5%8F%B0%E7%81%A3%E7%9A%84%E6%8B%BC%E9%9F%B3%E7%B3%BB%E7%B5%B1%E7%88%AD%E8%AD%B0",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E5%8F%B\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "931031514384441345",
  "geo" : { },
  "id_str" : "931032084466032641",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u81FA\u7063\u8B6F\u97F3\u6A19\u6E96\u81EA2009\u5E74\u8D77\u6539\u7232\u6F22\u8A9E\u62FC\u97F3\uFF1Ahttps:\/\/t.co\/zKl6uhpWsc",
  "id" : 931032084466032641,
  "in_reply_to_status_id" : 931031514384441345,
  "created_at" : "2017-11-16 05:32:01 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "glyceraldehyde",
      "screen_name" : "Sueharu_Nakano",
      "indices" : [ 12, 27 ],
      "id_str" : "4713166412",
      "id" : 4713166412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931031514116186112",
  "text" : "RT @dou4cc: @Sueharu_Nakano \u4E00\u76F4\u4EE5\u7232\u4F60\u5011\u7528\u5973\u5B69\u5B50\u505A\u982D\u50CF\u7684\u81EA\u6170\u90FD\u7528\u632F\u52D5\u68D2\u6216\u8005\u8DF3\u86CB\u4F86\u7740\u3002\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "glyceraldehyde",
        "screen_name" : "Sueharu_Nakano",
        "indices" : [ 0, 15 ],
        "id_str" : "4713166412",
        "id" : 4713166412
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "928462982216081413",
    "geo" : { },
    "id_str" : "931031472068284416",
    "in_reply_to_user_id" : 4713166412,
    "text" : "@Sueharu_Nakano \u4E00\u76F4\u4EE5\u7232\u4F60\u5011\u7528\u5973\u5B69\u5B50\u505A\u982D\u50CF\u7684\u81EA\u6170\u90FD\u7528\u632F\u52D5\u68D2\u6216\u8005\u8DF3\u86CB\u4F86\u7740\u3002\u3002",
    "id" : 931031472068284416,
    "in_reply_to_status_id" : 928462982216081413,
    "created_at" : "2017-11-16 05:29:35 +0000",
    "in_reply_to_screen_name" : "Sueharu_Nakano",
    "in_reply_to_user_id_str" : "4713166412",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 931031514116186112,
  "created_at" : "2017-11-16 05:29:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "glyceraldehyde",
      "screen_name" : "Sueharu_Nakano",
      "indices" : [ 0, 15 ],
      "id_str" : "4713166412",
      "id" : 4713166412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928462982216081413",
  "geo" : { },
  "id_str" : "931031472068284416",
  "in_reply_to_user_id" : 4713166412,
  "text" : "@Sueharu_Nakano \u4E00\u76F4\u4EE5\u7232\u4F60\u5011\u7528\u5973\u5B69\u5B50\u505A\u982D\u50CF\u7684\u81EA\u6170\u90FD\u7528\u632F\u52D5\u68D2\u6216\u8005\u8DF3\u86CB\u4F86\u7740\u3002\u3002",
  "id" : 931031472068284416,
  "in_reply_to_status_id" : 928462982216081413,
  "created_at" : "2017-11-16 05:29:35 +0000",
  "in_reply_to_screen_name" : "Sueharu_Nakano",
  "in_reply_to_user_id_str" : "4713166412",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/3qG6gC0UMI",
      "expanded_url" : "https:\/\/archive.is\/rTYcq",
      "display_url" : "archive.is\/rTYcq"
    } ]
  },
  "in_reply_to_status_id_str" : "931025298304352257",
  "geo" : { },
  "id_str" : "931027146130313216",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u4F60\u9019\u6A23\u9ED1Windows\u771F\u7684\u597D\u561B\uFF1F\u81FA\u7063\u4EBA\u4E0D\u7528Windows\uFF1Fhttps:\/\/t.co\/3qG6gC0UMI",
  "id" : 931027146130313216,
  "in_reply_to_status_id" : 931025298304352257,
  "created_at" : "2017-11-16 05:12:23 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930668443128475648",
  "geo" : { },
  "id_str" : "931025509416349697",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u800C\u4E14\u5F88\u591A\u6642\u5019\u95DC\u6CE8\u4E00\u500B\u4EBA\u662F\u56E0\u7232ta\u9396\u4E86\u63A8\uFF0C\u800C\u975E\u5E0C\u671B\u5728\u6642\u9593\u7DDA\u4E0A\u8B80ta\u7684\u63A8\u3002",
  "id" : 931025509416349697,
  "in_reply_to_status_id" : 930668443128475648,
  "created_at" : "2017-11-16 05:05:53 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931024578637385728",
  "geo" : { },
  "id_str" : "931024760535994368",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@jichi_zhang \u662F\u767E\u5EA6\u8F38\u5165\u6CD5\uFF08\u4E0D\u662F\u6211\u96FB\u8166\uFF09\u3002",
  "id" : 931024760535994368,
  "in_reply_to_status_id" : 931024578637385728,
  "created_at" : "2017-11-16 05:02:55 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930498912829431808",
  "geo" : { },
  "id_str" : "931024578637385728",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u7232\u4EC0\u9EBC\u6211\u5728\u7E41\u9AD4\u4E2D\u6587\u6A21\u5F0F\u4E0B\u6253\u4E0D\u51FA\u201C\u88E1\u201D\uFF0C\u53EA\u80FD\u6253\u51FA\u201C\u91CC\u201D\uFF1F",
  "id" : 931024578637385728,
  "in_reply_to_status_id" : 930498912829431808,
  "created_at" : "2017-11-16 05:02:11 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 0, 12 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931023588920037376",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@DevinStever \u7232\u4F55\u66F4\u6539username\uFF1F\u8FD9\u6837\u6703\u4F7F\u4EE5\u5F80\u7684@\u5931\u6548\u3002",
  "id" : 931023588920037376,
  "created_at" : "2017-11-16 04:58:15 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/vUSFWbfIcF",
      "expanded_url" : "https:\/\/pin-cong.com",
      "display_url" : "pin-cong.com"
    }, {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/UBT2x5X57X",
      "expanded_url" : "https:\/\/twitter.com\/SW_CMM\/status\/930664803726708736",
      "display_url" : "twitter.com\/SW_CMM\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931022792467894272",
  "text" : "https:\/\/t.co\/vUSFWbfIcF https:\/\/t.co\/UBT2x5X57X",
  "id" : 931022792467894272,
  "created_at" : "2017-11-16 04:55:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/znpR7BwDWI",
      "expanded_url" : "https:\/\/archive.is\/GRumG",
      "display_url" : "archive.is\/GRumG"
    } ]
  },
  "geo" : { },
  "id_str" : "931018461861597184",
  "text" : "\u767D\u540D\u55AE\u7684\u96F2\uFF1Ahttps:\/\/t.co\/znpR7BwDWI",
  "id" : 931018461861597184,
  "created_at" : "2017-11-16 04:37:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/ORP6wE2W9J",
      "expanded_url" : "https:\/\/archive.is\/UhBH4",
      "display_url" : "archive.is\/UhBH4"
    } ]
  },
  "geo" : { },
  "id_str" : "931017798985437184",
  "text" : "\u4E09\u661F\u7232\u64E1\u9AD8\u5167\u5B58\u50F9\u683C\u4E0D\u60DC\u88FD\u9020\u97D3\u570B\u5730\u9707\uFF1Ahttps:\/\/t.co\/ORP6wE2W9J",
  "id" : 931017798985437184,
  "created_at" : "2017-11-16 04:35:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/Ut73AnrQDg",
      "expanded_url" : "https:\/\/archive.is\/2Eevo#selection-1679.4-1687.7",
      "display_url" : "archive.is\/2Eevo#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930757046831583232",
  "text" : "\u5728Firefox\u4E2D\u5553\u7528ReadableStream\u7684\u65B9\u6CD5\uFF1Ahttps:\/\/t.co\/Ut73AnrQDg",
  "id" : 930757046831583232,
  "created_at" : "2017-11-15 11:19:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930385030953791488",
  "geo" : { },
  "id_str" : "930669228499374080",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u963F\u91CC\u7684\u9F20\u6A19\u4F60\u6562\u7528\u55CE\uFF1F\u6015\u4E0D\u6015\u518D\u5728\u9A45\u52D5\u91CC\u52A0\u6599\uFF1F",
  "id" : 930669228499374080,
  "in_reply_to_status_id" : 930385030953791488,
  "created_at" : "2017-11-15 05:30:09 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930668443128475648",
  "text" : "\u611F\u89BA\u61C9\u8A72\u81EA\u5DF1\u505A\u500B\u6642\u9593\u7DDA\uFF0C\u9019\u6A23\u5225\u4EBA\u5C31\u4E0D\u77E5\u9053\u6211\u95DC\u6CE8\u4E86\u8AB0\u3002",
  "id" : 930668443128475648,
  "created_at" : "2017-11-15 05:27:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/55akLFYDu8",
      "expanded_url" : "https:\/\/twitter.com\/SphericalSuki\/status\/930666959519272960",
      "display_url" : "twitter.com\/SphericalSuki\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930667956274630656",
  "text" : "\u6211\u628A\u4F60\u52A0\u8FDB\u5217\u8868\u4F1A\u5BF9\u4F60\u4EA7\u751F\u5F71\u54CD\u5417\uFF1F https:\/\/t.co\/55akLFYDu8",
  "id" : 930667956274630656,
  "created_at" : "2017-11-15 05:25:06 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6DF1\u84DD\u4E4B\u9083",
      "screen_name" : "SL_Deongaree",
      "indices" : [ 0, 13 ],
      "id_str" : "761865426263343104",
      "id" : 761865426263343104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929357967408771073",
  "geo" : { },
  "id_str" : "930662347387097088",
  "in_reply_to_user_id" : 761865426263343104,
  "text" : "@SL_Deongaree \u90FD\u602Anodejs\uD83D\uDE02",
  "id" : 930662347387097088,
  "in_reply_to_status_id" : 929357967408771073,
  "created_at" : "2017-11-15 05:02:49 +0000",
  "in_reply_to_screen_name" : "SL_Deongaree",
  "in_reply_to_user_id_str" : "761865426263343104",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/uyXhn7UHTk",
      "expanded_url" : "https:\/\/twitter.com\/GreatFireChina\/status\/930446102544994304",
      "display_url" : "twitter.com\/GreatFireChina\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930658402015088640",
  "text" : "\u570B\u5916\u65B0\u805E\u4E3B\u6301\u4EBA\u90FD\u90A3\u9EBC\u5E25\u7684\u561B\uFF1F\nemmmm...\u4EE5\u5F8C\u4E0D\u770B\u6587\u5B57\uFF0C\u6539\u770B\u76F4\u64AD\u597D\u4E86\uD83D\uDE01 https:\/\/t.co\/uyXhn7UHTk",
  "id" : 930658402015088640,
  "created_at" : "2017-11-15 04:47:08 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/930655285496164352\/photo\/1",
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/awU58YaK0K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DOpaCnmXkAApasO.jpg",
      "id_str" : "930655274041577472",
      "id" : 930655274041577472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOpaCnmXkAApasO.jpg",
      "sizes" : [ {
        "h" : 265,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/awU58YaK0K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930655285496164352",
  "text" : "\u5475\u5475 https:\/\/t.co\/awU58YaK0K",
  "id" : 930655285496164352,
  "created_at" : "2017-11-15 04:34:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/nErprJXnpw",
      "expanded_url" : "https:\/\/www.v2ex.com\/t\/340231",
      "display_url" : "v2ex.com\/t\/340231"
    }, {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/XGQxF9bUMZ",
      "expanded_url" : "https:\/\/twitter.com\/housecor\/status\/930108010558640128",
      "display_url" : "twitter.com\/housecor\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930654704786395136",
  "text" : "\u7136\u800C\u672C\u4F8B\u6703\u4F7Fawait\u5C0Dtick\u7684\u6D6A\u8CBB\u5C24\u7232\u660E\u986F\uFF1Ahttps:\/\/t.co\/nErprJXnpw https:\/\/t.co\/XGQxF9bUMZ",
  "id" : 930654704786395136,
  "created_at" : "2017-11-15 04:32:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930653878613348357",
  "text" : "RT @williamlong: \u3010\u6D77\u4FE1\u7535\u5668\u5BA3\u5E03129\u4EBF\u65E5\u5143\u6536\u8D2D\u4E1C\u829D\u7535\u89C6\u3011\u6D77\u4FE1\u96C6\u56E2\u4E0E\u4E1C\u829D\u7535\u89C6\u5728\u4E1C\u4EAC\u8054\u5408\u5BA3\u5E03\uFF1A\u4E1C\u829D\u6620\u50CF\u89E3\u51B3\u65B9\u6848\u516C\u53F8\u80A1\u6743\u768495%\u6B63\u5F0F\u8F6C\u8BA9\u6D77\u4FE1\uFF0C\u8F6C\u8BA9\u5B8C\u6210\u540E\uFF0C\u6D77\u4FE1\u7535\u5668\u5C06\u4EAB\u6709\u4E1C\u829D\u7535\u89C6\u4EA7\u54C1\u3001\u54C1\u724C\u3001\u8FD0\u8425\u670D\u52A1\u7B49\u4E00\u63FD\u5B50\u4E1A\u52A1\uFF0C\u5E76\u62E5\u6709\u4E1C\u829D\u7535\u89C6\u5168\u740340\u5E74\u54C1\u724C\u6388\u6743\u3002\u8BE5\u9879\u80A1\u6743\u8F6C\u8BA9\u91D1\u989D\u6682\u8BA1\u4E3A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "930615139786686466",
    "text" : "\u3010\u6D77\u4FE1\u7535\u5668\u5BA3\u5E03129\u4EBF\u65E5\u5143\u6536\u8D2D\u4E1C\u829D\u7535\u89C6\u3011\u6D77\u4FE1\u96C6\u56E2\u4E0E\u4E1C\u829D\u7535\u89C6\u5728\u4E1C\u4EAC\u8054\u5408\u5BA3\u5E03\uFF1A\u4E1C\u829D\u6620\u50CF\u89E3\u51B3\u65B9\u6848\u516C\u53F8\u80A1\u6743\u768495%\u6B63\u5F0F\u8F6C\u8BA9\u6D77\u4FE1\uFF0C\u8F6C\u8BA9\u5B8C\u6210\u540E\uFF0C\u6D77\u4FE1\u7535\u5668\u5C06\u4EAB\u6709\u4E1C\u829D\u7535\u89C6\u4EA7\u54C1\u3001\u54C1\u724C\u3001\u8FD0\u8425\u670D\u52A1\u7B49\u4E00\u63FD\u5B50\u4E1A\u52A1\uFF0C\u5E76\u62E5\u6709\u4E1C\u829D\u7535\u89C6\u5168\u740340\u5E74\u54C1\u724C\u6388\u6743\u3002\u8BE5\u9879\u80A1\u6743\u8F6C\u8BA9\u91D1\u989D\u6682\u8BA1\u4E3A129\u4EBF\u65E5\u5143\u3002",
    "id" : 930615139786686466,
    "created_at" : "2017-11-15 01:55:13 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 930653878613348357,
  "created_at" : "2017-11-15 04:29:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/8FaKRecxku",
      "expanded_url" : "https:\/\/archive.is\/2zTwc",
      "display_url" : "archive.is\/2zTwc"
    } ]
  },
  "in_reply_to_status_id_str" : "930430319832059904",
  "geo" : { },
  "id_str" : "930432585058148352",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u77E5\u4E4E\u76F8\u95DC\u63D0\u554F\u7121\u4EBA\u554F\u6D25\uFF1Ahttps:\/\/t.co\/8FaKRecxku",
  "id" : 930432585058148352,
  "in_reply_to_status_id" : 930430319832059904,
  "created_at" : "2017-11-14 13:49:49 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/89HfjRwYuO",
      "expanded_url" : "https:\/\/archive.is\/BCWuT",
      "display_url" : "archive.is\/BCWuT"
    } ]
  },
  "geo" : { },
  "id_str" : "930430319832059904",
  "text" : "\u7DAD\u57FA\u89E3\u5BC6\u88AB\u66DD\u79D8\u5BC6\u806F\u7D61\u5C0F\u5DDD\u666E\uFF0C\u6216\u4E0D\u518D\u4E2D\u7ACB\uFF1Ahttps:\/\/t.co\/89HfjRwYuO",
  "id" : 930430319832059904,
  "created_at" : "2017-11-14 13:40:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wuyu",
      "screen_name" : "SW_CMM",
      "indices" : [ 0, 7 ],
      "id_str" : "2336783467",
      "id" : 2336783467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930290367366291456",
  "geo" : { },
  "id_str" : "930357972269719552",
  "in_reply_to_user_id" : 2336783467,
  "text" : "@SW_CMM amazon\u4E2D\u56FD\u4E0D\u80FD\u7E2E\u5BEB\u6210amazon\u3002",
  "id" : 930357972269719552,
  "in_reply_to_status_id" : 930290367366291456,
  "created_at" : "2017-11-14 08:53:20 +0000",
  "in_reply_to_screen_name" : "SW_CMM",
  "in_reply_to_user_id_str" : "2336783467",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5DF4\u4E22\u8349  Badiucao",
      "screen_name" : "badiucao",
      "indices" : [ 3, 12 ],
      "id_str" : "267695291",
      "id" : 267695291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6FB3\u6D32\u836F\u4E38",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930278955059437570",
  "text" : "RT @badiucao: \u6FB3\u6D32\u672C\u571F\u5B66\u8005\u5728\u6FB3\u6D32\u51FA\u7248\u6279\u8BC4\u4E2D\u56FD\u4E66\u7C4D\u53D7\u5230\u963B\u6320\uFF0C\u4E2A\u4EBA\u53D7\u5230\u5A01\u80C1\u3002#\u6FB3\u6D32\u836F\u4E38 Australian academic says he has been silenced by Chinese Government https:\/\/t.co\/Zrb702Jlm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News",
        "screen_name" : "abcnews",
        "indices" : [ 130, 138 ],
        "id_str" : "2768501",
        "id" : 2768501
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u6FB3\u6D32\u836F\u4E38",
        "indices" : [ 29, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/Zrb702JlmS",
        "expanded_url" : "http:\/\/www.abc.net.au\/news\/2017-11-13\/academic-claims-hes-been-silenced-by-chinese-government\/9142694",
        "display_url" : "abc.net.au\/news\/2017-11-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "929812973618585600",
    "text" : "\u6FB3\u6D32\u672C\u571F\u5B66\u8005\u5728\u6FB3\u6D32\u51FA\u7248\u6279\u8BC4\u4E2D\u56FD\u4E66\u7C4D\u53D7\u5230\u963B\u6320\uFF0C\u4E2A\u4EBA\u53D7\u5230\u5A01\u80C1\u3002#\u6FB3\u6D32\u836F\u4E38 Australian academic says he has been silenced by Chinese Government https:\/\/t.co\/Zrb702JlmS \u6765\u81EA @ABCNews",
    "id" : 929812973618585600,
    "created_at" : "2017-11-12 20:47:42 +0000",
    "user" : {
      "name" : "\u5DF4\u4E22\u8349  Badiucao",
      "screen_name" : "badiucao",
      "protected" : false,
      "id_str" : "267695291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3473285548\/b198f85d10f8cefe75604978594a065f_normal.jpeg",
      "id" : 267695291,
      "verified" : false
    }
  },
  "id" : 930278955059437570,
  "created_at" : "2017-11-14 03:39:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/GdS1RrzRnx",
      "expanded_url" : "https:\/\/twitter.com\/newsycombinator\/status\/930103271053721600",
      "display_url" : "twitter.com\/newsycombinato\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930276400149553152",
  "text" : "Again\uFF1F https:\/\/t.co\/GdS1RrzRnx",
  "id" : 930276400149553152,
  "created_at" : "2017-11-14 03:29:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/2sUstHrvRu",
      "expanded_url" : "https:\/\/archive.is\/fm5jZ",
      "display_url" : "archive.is\/fm5jZ"
    }, {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/R61a8yUN3l",
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/930274555087564800",
      "display_url" : "twitter.com\/ruanyf\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930276052508839937",
  "text" : "https:\/\/t.co\/2sUstHrvRu https:\/\/t.co\/R61a8yUN3l",
  "id" : 930276052508839937,
  "created_at" : "2017-11-14 03:27:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/YpkBBwk9Ba",
      "expanded_url" : "https:\/\/archive.is\/RLOkd",
      "display_url" : "archive.is\/RLOkd"
    } ]
  },
  "geo" : { },
  "id_str" : "930019668382842880",
  "text" : "\u4E2D\u5171\u63A2\u982D\u904D\u4F48\u5168\u7F8E\uFF1Ahttps:\/\/t.co\/YpkBBwk9Ba",
  "id" : 930019668382842880,
  "created_at" : "2017-11-13 10:29:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 12, 24 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930019460890742784",
  "text" : "RT @dou4cc: @jichi_zhang \u6211\u5C0F\u5B78\u4E09\u5E74\u7D1A\u7B2C\u4E00\u6B21\u4E0A\u7DB2\u6CE8\u518A\u8CEC\u865F\uFF0C\u56DB\u5E74\u7D1A\u5F97\u5230\u9996\u81FA\u96FB\u8166\uFF0C\u516D\u5E74\u7D1A\u958B\u59CB\u7FFB\u58BB\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
        "screen_name" : "jichi_zhang",
        "indices" : [ 0, 12 ],
        "id_str" : "4628523253",
        "id" : 4628523253
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "929969834766483456",
    "geo" : { },
    "id_str" : "930018080058695680",
    "in_reply_to_user_id" : 4628523253,
    "text" : "@jichi_zhang \u6211\u5C0F\u5B78\u4E09\u5E74\u7D1A\u7B2C\u4E00\u6B21\u4E0A\u7DB2\u6CE8\u518A\u8CEC\u865F\uFF0C\u56DB\u5E74\u7D1A\u5F97\u5230\u9996\u81FA\u96FB\u8166\uFF0C\u516D\u5E74\u7D1A\u958B\u59CB\u7FFB\u58BB\u3002",
    "id" : 930018080058695680,
    "in_reply_to_status_id" : 929969834766483456,
    "created_at" : "2017-11-13 10:22:43 +0000",
    "in_reply_to_screen_name" : "jichi_zhang",
    "in_reply_to_user_id_str" : "4628523253",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 930019460890742784,
  "created_at" : "2017-11-13 10:28:13 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929969834766483456",
  "geo" : { },
  "id_str" : "930018080058695680",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u6211\u5C0F\u5B78\u4E09\u5E74\u7D1A\u7B2C\u4E00\u6B21\u4E0A\u7DB2\u6CE8\u518A\u8CEC\u865F\uFF0C\u56DB\u5E74\u7D1A\u5F97\u5230\u9996\u81FA\u96FB\u8166\uFF0C\u516D\u5E74\u7D1A\u958B\u59CB\u7FFB\u58BB\u3002",
  "id" : 930018080058695680,
  "in_reply_to_status_id" : 929969834766483456,
  "created_at" : "2017-11-13 10:22:43 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929792670246912000",
  "geo" : { },
  "id_str" : "929917995161448448",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u570B\u5C0F=\u5C0F\u5B78\n\u570B\u4E00\u5230\u570B\u56DB=\u5C0F\u5B78\u4E00\u5E74\u7D1A\u5230\u56DB\u5E74\u7D1A\n\uFF1F\n\u4F60\u4E0A\u7DB2\u90A3\u9EBC\u65E9\u554A\uFF01",
  "id" : 929917995161448448,
  "in_reply_to_status_id" : 929792670246912000,
  "created_at" : "2017-11-13 03:45:01 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929914898527735808",
  "text" : "BBC\u4E0D\u4F46\u4E0D\u4E0AHTTPS\uFF0C\u9023\u8996\u983B\u4E5F\u662FFlash\u3002\uFF08\u624B\u52D5\u518D\u898B",
  "id" : 929914898527735808,
  "created_at" : "2017-11-13 03:32:43 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MusicBoxW",
      "screen_name" : "Wither_Block",
      "indices" : [ 3, 16 ],
      "id_str" : "739595008836149253",
      "id" : 739595008836149253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u66B4\u8D70\u5927\u4E8B\u4EF6",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929880688039428097",
  "text" : "RT @Wither_Block: \u5F88\u96BE\u53D7\uFF0C#\u66B4\u8D70\u5927\u4E8B\u4EF6 \u5C31\u8FD9\u4E48\u6CA1\u4E86\n\u8FD9\u6700\u540E\u4E00\u671F\u7684\u98CE\u683C\u5C31\u4E0E\u4E4B\u524D\u4E0D\u540C\uFF0C\u4EFF\u4F5B\u5DF2\u7ECF\u77E5\u9053\u662F\u5C3D\u529B\u4E00\u640F\n\u6700\u540E\u7684\u5C3C\u739B\u544A\u89E3\u5BA4\uFF0C\u518D\u4E5F\u6CA1\u6709\u7528\u4EE5\u5F80\u7684\u53E3\u6C14\uFF0C\u4EE5\u9017\u4EBA\u4E00\u7B11\uFF0C\u800C\u662F\u8868\u660E\u201C\u6211\u65E0\u6CD5\u5728\u8FD9\u91CC\u5E2E\u4F60\u4EEC\u4E00\u8F88\u5B50\uFF0C\u53CD\u6297\u554A\uFF0C\u77E5\u9053\u5427  \u53CD\u6297\u554A\uFF0C\u670B\u53CB\uFF01\u201D\u7ED3\u5C3E\u7684\u8BED\u6C14\u6CA1\u6709\u4EE5\u5F80\u90A3\u6837\u660E\u5FEB\uFF0C\u751A\u81F3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Wither_Block\/status\/929528998199095296\/photo\/1",
        "indices" : [ 146, 169 ],
        "url" : "https:\/\/t.co\/bFlOH6e7PJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DOZZkgGV4AAr8kh.jpg",
        "id_str" : "929528856725282816",
        "id" : 929528856725282816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOZZkgGV4AAr8kh.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/bFlOH6e7PJ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Wither_Block\/status\/929528998199095296\/photo\/1",
        "indices" : [ 146, 169 ],
        "url" : "https:\/\/t.co\/bFlOH6e7PJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DOZZkgGVAAAqwO0.jpg",
        "id_str" : "929528856725225472",
        "id" : 929528856725225472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOZZkgGVAAAqwO0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/bFlOH6e7PJ"
      } ],
      "hashtags" : [ {
        "text" : "\u66B4\u8D70\u5927\u4E8B\u4EF6",
        "indices" : [ 4, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "929528998199095296",
    "text" : "\u5F88\u96BE\u53D7\uFF0C#\u66B4\u8D70\u5927\u4E8B\u4EF6 \u5C31\u8FD9\u4E48\u6CA1\u4E86\n\u8FD9\u6700\u540E\u4E00\u671F\u7684\u98CE\u683C\u5C31\u4E0E\u4E4B\u524D\u4E0D\u540C\uFF0C\u4EFF\u4F5B\u5DF2\u7ECF\u77E5\u9053\u662F\u5C3D\u529B\u4E00\u640F\n\u6700\u540E\u7684\u5C3C\u739B\u544A\u89E3\u5BA4\uFF0C\u518D\u4E5F\u6CA1\u6709\u7528\u4EE5\u5F80\u7684\u53E3\u6C14\uFF0C\u4EE5\u9017\u4EBA\u4E00\u7B11\uFF0C\u800C\u662F\u8868\u660E\u201C\u6211\u65E0\u6CD5\u5728\u8FD9\u91CC\u5E2E\u4F60\u4EEC\u4E00\u8F88\u5B50\uFF0C\u53CD\u6297\u554A\uFF0C\u77E5\u9053\u5427  \u53CD\u6297\u554A\uFF0C\u670B\u53CB\uFF01\u201D\u7ED3\u5C3E\u7684\u8BED\u6C14\u6CA1\u6709\u4EE5\u5F80\u90A3\u6837\u660E\u5FEB\uFF0C\u751A\u81F3\u6709\u4E9B\u6FC0\u52A8\n\u8BDD\u4E0D\u591A\u8BF4\uFF0C\u6211\u4E5F\u4E0D\u592A\u4F1A\u8BF4 \u6B64\u751F\u65E0\u6094\u5165\u66B4\u6F2B https:\/\/t.co\/bFlOH6e7PJ",
    "id" : 929528998199095296,
    "created_at" : "2017-11-12 01:59:17 +0000",
    "user" : {
      "name" : "MusicBoxW",
      "screen_name" : "Wither_Block",
      "protected" : false,
      "id_str" : "739595008836149253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/944528938281328640\/rmNjyqQJ_normal.jpg",
      "id" : 739595008836149253,
      "verified" : false
    }
  },
  "id" : 929880688039428097,
  "created_at" : "2017-11-13 01:16:47 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/JizLaZbWGT",
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/929213744483201025",
      "display_url" : "twitter.com\/ruanyf\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "929688578577313792",
  "geo" : { },
  "id_str" : "929688891472404480",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u6240\u4EE5\u962E\u4E00\u5CF0\u7684\u9019\u53E5\u8A71\u600E\u8B1B\uFF1Fhttps:\/\/t.co\/JizLaZbWGT",
  "id" : 929688891472404480,
  "in_reply_to_status_id" : 929688578577313792,
  "created_at" : "2017-11-12 12:34:39 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krome",
      "screen_name" : "CaKrome",
      "indices" : [ 0, 8 ],
      "id_str" : "3344890713",
      "id" : 3344890713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929688465469472770",
  "geo" : { },
  "id_str" : "929688720462184448",
  "in_reply_to_user_id" : 3344890713,
  "text" : "@CaKrome \u6211\u4E00\u76F4\u5168\u958Bflag\uFF0C\u6700\u8FD1\u5169\u5E74Chrome\u90FD\u662F538\u5206\u3002",
  "id" : 929688720462184448,
  "in_reply_to_status_id" : 929688465469472770,
  "created_at" : "2017-11-12 12:33:58 +0000",
  "in_reply_to_screen_name" : "CaKrome",
  "in_reply_to_user_id_str" : "3344890713",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929687125481742336",
  "geo" : { },
  "id_str" : "929688578577313792",
  "in_reply_to_user_id" : 3359880735,
  "text" : "WritableStream\u5728Chrome\u4E0A\u9023\u5F71\u5B50\u90FD\u6C92\u6709\uFF0CFirefox\u66F4\u662F\u9023ReadableStream\u90FD\u4E0D\u652F\u6301\uFF0C\u6559\u4EBA\u600E\u9EBD\u73A9fetch\u3002\u3002\u3002",
  "id" : 929688578577313792,
  "in_reply_to_status_id" : 929687125481742336,
  "created_at" : "2017-11-12 12:33:24 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929686504330362880",
  "geo" : { },
  "id_str" : "929687125481742336",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u662F\u56E0\u7232\u6211\u4E00\u76F4\u628Aflag\u5168\u958B\u55CE\uFF1F\uD83D\uDE02",
  "id" : 929687125481742336,
  "in_reply_to_status_id" : 929686504330362880,
  "created_at" : "2017-11-12 12:27:38 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929686504330362880",
  "text" : "\u7232\u4EC0\u9EBD\u6574\u6574\u4E00\u5E74Chrome\u548CFirefox\u90FD\u5728HTML5\u5F97\u5206\u4E0A\u6C92\u6709\u4EFB\u4F55\u9577\u9032\uFF1F",
  "id" : 929686504330362880,
  "created_at" : "2017-11-12 12:25:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/KT6do4OXR7",
      "expanded_url" : "https:\/\/archive.is\/GQ4hl",
      "display_url" : "archive.is\/GQ4hl"
    } ]
  },
  "geo" : { },
  "id_str" : "929660911492714506",
  "text" : "CIA Hive\uFF1Ahttps:\/\/t.co\/KT6do4OXR7",
  "id" : 929660911492714506,
  "created_at" : "2017-11-12 10:43:28 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/P9MY1Zx8LU",
      "expanded_url" : "https:\/\/archive.is\/DLN8s#selection-1019.1-1019.113",
      "display_url" : "archive.is\/DLN8s#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "929265189903654912",
  "text" : "Google\u7A31\u5176\u80FD\u9060\u7A0B\u63A7\u5236Chrome\u5404flag\u7684\u958B\u95DC\uFF1Ahttps:\/\/t.co\/P9MY1Zx8LU",
  "id" : 929265189903654912,
  "created_at" : "2017-11-11 08:31:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/928935123654918145\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/idzmo3zdrg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DOQ9iAsU8AADzaU.jpg",
      "id_str" : "928935077655932928",
      "id" : 928935077655932928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOQ9iAsU8AADzaU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/idzmo3zdrg"
    } ],
    "hashtags" : [ {
      "text" : "\u7981\u4EE4",
      "indices" : [ 19, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929000379894910976",
  "text" : "RT @iyouport_news: \uFF03\u7981\u4EE4 https:\/\/t.co\/idzmo3zdrg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/928935123654918145\/photo\/1",
        "indices" : [ 4, 27 ],
        "url" : "https:\/\/t.co\/idzmo3zdrg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DOQ9iAsU8AADzaU.jpg",
        "id_str" : "928935077655932928",
        "id" : 928935077655932928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOQ9iAsU8AADzaU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/idzmo3zdrg"
      } ],
      "hashtags" : [ {
        "text" : "\u7981\u4EE4",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "928935123654918145",
    "text" : "\uFF03\u7981\u4EE4 https:\/\/t.co\/idzmo3zdrg",
    "id" : 928935123654918145,
    "created_at" : "2017-11-10 10:39:26 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 929000379894910976,
  "created_at" : "2017-11-10 14:58:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Wang",
      "screen_name" : "creativewang",
      "indices" : [ 3, 16 ],
      "id_str" : "538330383",
      "id" : 538330383
    }, {
      "name" : "TualatriX",
      "screen_name" : "tualatrix",
      "indices" : [ 21, 31 ],
      "id_str" : "121908437",
      "id" : 121908437
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/creativewang\/status\/928958282747715586\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/v4NzIDYI70",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DORSn7MUEAAtO6-.jpg",
      "id_str" : "928958269002878976",
      "id" : 928958269002878976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DORSn7MUEAAtO6-.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/v4NzIDYI70"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928999003106299910",
  "text" : "RT @creativewang: \u5173\u4E8E @tualatrix . https:\/\/t.co\/v4NzIDYI70",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TualatriX",
        "screen_name" : "tualatrix",
        "indices" : [ 3, 13 ],
        "id_str" : "121908437",
        "id" : 121908437
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/creativewang\/status\/928958282747715586\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/v4NzIDYI70",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DORSn7MUEAAtO6-.jpg",
        "id_str" : "928958269002878976",
        "id" : 928958269002878976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DORSn7MUEAAtO6-.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/v4NzIDYI70"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "928958282747715586",
    "text" : "\u5173\u4E8E @tualatrix . https:\/\/t.co\/v4NzIDYI70",
    "id" : 928958282747715586,
    "created_at" : "2017-11-10 12:11:28 +0000",
    "user" : {
      "name" : "Allen Wang",
      "screen_name" : "creativewang",
      "protected" : false,
      "id_str" : "538330383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701706388519555072\/Z4uVQFQk_normal.png",
      "id" : 538330383,
      "verified" : false
    }
  },
  "id" : 928999003106299910,
  "created_at" : "2017-11-10 14:53:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DIYgod",
      "screen_name" : "DIYgod",
      "indices" : [ 3, 10 ],
      "id_str" : "1553713718",
      "id" : 1553713718
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DIYgod\/status\/928828832487956483\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/Uaksewea5m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DOPc5MwV4AAXq3X.jpg",
      "id_str" : "928828823403094016",
      "id" : 928828823403094016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOPc5MwV4AAXq3X.jpg",
      "sizes" : [ {
        "h" : 1198,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1198,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Uaksewea5m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928989655579668480",
  "text" : "RT @DIYgod: \u8FD9\u671F\u66B4\u8D70\u5927\u4E8B\u4EF6\u5168\u88AB\u5220\u4E86\uFF0C\u96BE\u53D7(\u30CE\u0414\uFF34)\n\u53EF\u80FD\u662F\u56E0\u4E3A\u8C6B\u7AE0\u5B66\u9662\u90A3\u6BB5(\u30CE\u0414\uFF34) https:\/\/t.co\/Uaksewea5m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DIYgod\/status\/928828832487956483\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/Uaksewea5m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DOPc5MwV4AAXq3X.jpg",
        "id_str" : "928828823403094016",
        "id" : 928828823403094016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOPc5MwV4AAXq3X.jpg",
        "sizes" : [ {
          "h" : 1198,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 702,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1198,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Uaksewea5m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "928828832487956483",
    "text" : "\u8FD9\u671F\u66B4\u8D70\u5927\u4E8B\u4EF6\u5168\u88AB\u5220\u4E86\uFF0C\u96BE\u53D7(\u30CE\u0414\uFF34)\n\u53EF\u80FD\u662F\u56E0\u4E3A\u8C6B\u7AE0\u5B66\u9662\u90A3\u6BB5(\u30CE\u0414\uFF34) https:\/\/t.co\/Uaksewea5m",
    "id" : 928828832487956483,
    "created_at" : "2017-11-10 03:37:05 +0000",
    "user" : {
      "name" : "DIYgod",
      "screen_name" : "DIYgod",
      "protected" : false,
      "id_str" : "1553713718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682549571650650112\/ZzKvuV-a_normal.jpg",
      "id" : 1553713718,
      "verified" : false
    }
  },
  "id" : 928989655579668480,
  "created_at" : "2017-11-10 14:16:08 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/vQ8MWwwyyb",
      "expanded_url" : "https:\/\/stallman.org",
      "display_url" : "stallman.org"
    } ]
  },
  "geo" : { },
  "id_str" : "928852830961782784",
  "text" : "RMS's Site\uFF1Ahttps:\/\/t.co\/vQ8MWwwyyb",
  "id" : 928852830961782784,
  "created_at" : "2017-11-10 05:12:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Frank",
      "screen_name" : "bitinn",
      "indices" : [ 0, 7 ],
      "id_str" : "71971243",
      "id" : 71971243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928132050057535488",
  "geo" : { },
  "id_str" : "928760569322143745",
  "in_reply_to_user_id" : 71971243,
  "text" : "@bitinn \u900F\u660EJPEG\u4E5F\u662F\u5F88\u9EBB\u7169\u7684\u683C\u5F0F\u3002",
  "id" : 928760569322143745,
  "in_reply_to_status_id" : 928132050057535488,
  "created_at" : "2017-11-09 23:05:49 +0000",
  "in_reply_to_screen_name" : "bitinn",
  "in_reply_to_user_id_str" : "71971243",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "out",
      "indices" : [ 32, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926675559148589056",
  "geo" : { },
  "id_str" : "928624561217855488",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u5DF2\u78BA\u8A8D\u662F\u5553\u7528\u4E86\u9019\u500Bflag\u5C0E\u81F4\u7684\uFF1Achrome:\/\/flags\/#out-of-blink-cors",
  "id" : 928624561217855488,
  "in_reply_to_status_id" : 926675559148589056,
  "created_at" : "2017-11-09 14:05:23 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928624259924193281",
  "text" : "RT @dou4cc: @wangDevming \u628AUA\u6539\u6210iPad\u518D\u5237\u65B0\u9801\u9762\u5C31\u770B\u5230iso\u4E0B\u8F09\u6309\u9215\u4E86\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "928620506936250369",
    "geo" : { },
    "id_str" : "928621492757303297",
    "in_reply_to_user_id" : 745341593817747456,
    "text" : "@wangDevming \u628AUA\u6539\u6210iPad\u518D\u5237\u65B0\u9801\u9762\u5C31\u770B\u5230iso\u4E0B\u8F09\u6309\u9215\u4E86\u3002",
    "id" : 928621492757303297,
    "in_reply_to_status_id" : 928620506936250369,
    "created_at" : "2017-11-09 13:53:11 +0000",
    "in_reply_to_screen_name" : "DevinStever",
    "in_reply_to_user_id_str" : "745341593817747456",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 928624259924193281,
  "created_at" : "2017-11-09 14:04:11 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928620690206543872",
  "geo" : { },
  "id_str" : "928621670759268352",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u8ACB\u516C\u958B\u8A72\u8A2D\u5099\u3002",
  "id" : 928621670759268352,
  "in_reply_to_status_id" : 928620690206543872,
  "created_at" : "2017-11-09 13:53:53 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928620506936250369",
  "geo" : { },
  "id_str" : "928621492757303297",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u628AUA\u6539\u6210iPad\u518D\u5237\u65B0\u9801\u9762\u5C31\u770B\u5230iso\u4E0B\u8F09\u6309\u9215\u4E86\u3002",
  "id" : 928621492757303297,
  "in_reply_to_status_id" : 928620506936250369,
  "created_at" : "2017-11-09 13:53:11 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928599920994607105",
  "geo" : { },
  "id_str" : "928604409138958343",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u597D\u5427\uFF0C\u539F\u4F86\u662F\u7D14\u51C0\u7248\u3002\u3002\u3002\u795D\u4F60\u597D\u904B~",
  "id" : 928604409138958343,
  "in_reply_to_status_id" : 928599920994607105,
  "created_at" : "2017-11-09 12:45:18 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928599920994607105",
  "geo" : { },
  "id_str" : "928603876034514944",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming \u4F60\u5C31\u4E0D\u80FD\u5F9E\u5B98\u7DB2\u4E0B\u55CE\uFF1F",
  "id" : 928603876034514944,
  "in_reply_to_status_id" : 928599920994607105,
  "created_at" : "2017-11-09 12:43:11 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/V8RLBLqz8Z",
      "expanded_url" : "https:\/\/archive.is\/sH7MO",
      "display_url" : "archive.is\/sH7MO"
    } ]
  },
  "geo" : { },
  "id_str" : "928601865801158656",
  "text" : "\u7DAD\u57FA\u767E\u79D11%\u7684\u7528\u6237\u8CA2\u737B\u4E8677%\u7684\u5185\u5BB9\uFF1Ahttps:\/\/t.co\/V8RLBLqz8Z",
  "id" : 928601865801158656,
  "created_at" : "2017-11-09 12:35:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/928399230628069378\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ZGYlsy5yu2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DOJWLEdVwAAYDnv.jpg",
      "id_str" : "928399221367095296",
      "id" : 928399221367095296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOJWLEdVwAAYDnv.jpg",
      "sizes" : [ {
        "h" : 501,
        "resize" : "fit",
        "w" : 771
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 771
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 771
      } ],
      "display_url" : "pic.twitter.com\/ZGYlsy5yu2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928560730269503489",
  "text" : "RT @ruanyf: 2017\u5E74\uFF0C\u5168\u4E16\u754C\u4E0A\u7F51\u4EBA\u6570\u589E\u52A0\u4E868%\uFF0C\u4E2D\u56FD\u8FD8\u4F4E\u4E8E\u8FD9\u4E2A\u6570\u5B57\u3002\u6240\u4EE5\uFF0C\u5982\u679C\u4F60\u7684\u7F51\u7AD9\u8FC7\u53BB\u4E00\u5E74\u7684\u8BBF\u95EE\u91CF\uFF0C\u589E\u957F\u8D85\u8FC78%\uFF0C\u5C31\u4F18\u4E8E\u5E73\u5747\u6570\u4E86\u3002\n\n\u518D\u8FC7\u51E0\u5E74\uFF0C\u4E92\u8054\u7F51\u7684\u9AD8\u901F\u589E\u957F\u65F6\u4EE3\u5C31\u4F1A\u6210\u4E3A\u56DE\u5FC6\u4E86\u3002 https:\/\/t.co\/ZGYlsy5yu2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/928399230628069378\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/ZGYlsy5yu2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DOJWLEdVwAAYDnv.jpg",
        "id_str" : "928399221367095296",
        "id" : 928399221367095296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOJWLEdVwAAYDnv.jpg",
        "sizes" : [ {
          "h" : 501,
          "resize" : "fit",
          "w" : 771
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 771
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 771
        } ],
        "display_url" : "pic.twitter.com\/ZGYlsy5yu2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "928399230628069378",
    "text" : "2017\u5E74\uFF0C\u5168\u4E16\u754C\u4E0A\u7F51\u4EBA\u6570\u589E\u52A0\u4E868%\uFF0C\u4E2D\u56FD\u8FD8\u4F4E\u4E8E\u8FD9\u4E2A\u6570\u5B57\u3002\u6240\u4EE5\uFF0C\u5982\u679C\u4F60\u7684\u7F51\u7AD9\u8FC7\u53BB\u4E00\u5E74\u7684\u8BBF\u95EE\u91CF\uFF0C\u589E\u957F\u8D85\u8FC78%\uFF0C\u5C31\u4F18\u4E8E\u5E73\u5747\u6570\u4E86\u3002\n\n\u518D\u8FC7\u51E0\u5E74\uFF0C\u4E92\u8054\u7F51\u7684\u9AD8\u901F\u589E\u957F\u65F6\u4EE3\u5C31\u4F1A\u6210\u4E3A\u56DE\u5FC6\u4E86\u3002 https:\/\/t.co\/ZGYlsy5yu2",
    "id" : 928399230628069378,
    "created_at" : "2017-11-08 23:10:00 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 928560730269503489,
  "created_at" : "2017-11-09 09:51:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D62\u9999 \u732B @New Year \uD83C\uDF86",
      "screen_name" : "ayakaneko",
      "indices" : [ 0, 10 ],
      "id_str" : "791155015360667649",
      "id" : 791155015360667649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927518407951491072",
  "geo" : { },
  "id_str" : "928560241196830721",
  "in_reply_to_user_id" : 791155015360667649,
  "text" : "@ayakaneko \u4F60\u7684\u535A\u5BA2\u9084\u5728\u55CE\uFF1F",
  "id" : 928560241196830721,
  "in_reply_to_status_id" : 927518407951491072,
  "created_at" : "2017-11-09 09:49:47 +0000",
  "in_reply_to_screen_name" : "ayakaneko",
  "in_reply_to_user_id_str" : "791155015360667649",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/6TcMzw56Eb",
      "expanded_url" : "https:\/\/archive.is\/S7QHj",
      "display_url" : "archive.is\/S7QHj"
    } ]
  },
  "geo" : { },
  "id_str" : "928559984132149248",
  "text" : "\u6578\u5B57\u7C3D\u540D\u4E0D\u518D\u53EF\u9760\uFF1Ahttps:\/\/t.co\/6TcMzw56Eb",
  "id" : 928559984132149248,
  "created_at" : "2017-11-09 09:48:46 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gravis!",
      "screen_name" : "gravislizard",
      "indices" : [ 3, 16 ],
      "id_str" : "267370489",
      "id" : 267370489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928236414638153729",
  "text" : "RT @gravislizard: almost everything on computers is perceptually slower than it was in 1983",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927593460642615296",
    "text" : "almost everything on computers is perceptually slower than it was in 1983",
    "id" : 927593460642615296,
    "created_at" : "2017-11-06 17:48:09 +0000",
    "user" : {
      "name" : "Gravis!",
      "screen_name" : "gravislizard",
      "protected" : false,
      "id_str" : "267370489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919649418843848704\/yhWMTFCz_normal.jpg",
      "id" : 267370489,
      "verified" : false
    }
  },
  "id" : 928236414638153729,
  "created_at" : "2017-11-08 12:23:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David",
      "screen_name" : "David24316614",
      "indices" : [ 0, 14 ],
      "id_str" : "866281522310991872",
      "id" : 866281522310991872
    }, {
      "name" : "\u90ED\u6587\u8D35Guo Wengui \u270A\uFE0F\u270A\uFE0F\u270A\uFE0F",
      "screen_name" : "KwokMiles",
      "indices" : [ 28, 38 ],
      "id_str" : "3131350487",
      "id" : 3131350487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927959169587732480",
  "geo" : { },
  "id_str" : "928225703648223232",
  "in_reply_to_user_id" : 866281522310991872,
  "text" : "@David24316614 @wangDevming @KwokMiles \u738B\u6625\u660E\u81BD\u5927\u662F\u56E0\u7232\u4ED6\u9032\u53BB\u904E\uFF0C\u65E9\u5C31\u88AB\u76EF\u4E0A\u4E86\u3002",
  "id" : 928225703648223232,
  "in_reply_to_status_id" : 927959169587732480,
  "created_at" : "2017-11-08 11:40:28 +0000",
  "in_reply_to_screen_name" : "David24316614",
  "in_reply_to_user_id_str" : "866281522310991872",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 12, 27 ],
      "id_str" : "254148157",
      "id" : 254148157
    }, {
      "name" : "Rebecca MacKinnon",
      "screen_name" : "rmack",
      "indices" : [ 28, 34 ],
      "id_str" : "810129",
      "id" : 810129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928223926731378688",
  "text" : "RT @dou4cc: @GreatFireChina @rmack \u907F\u514D\u201C@\u201D\u8D77\u982D\u7684\u63A8\u6587\u88AB\u8A8D\u4F5C\u56DE\u5FA9\u4E0D\u51FA\u73FE\u5728\u9ED8\u8A8D\u6642\u9593\u7DAB\u4E2D\uFF0C\u8879\u9700\u4E00\u500B\u984D\u5916\u7684\u8F49\u767C\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GreatFire.org",
        "screen_name" : "GreatFireChina",
        "indices" : [ 0, 15 ],
        "id_str" : "254148157",
        "id" : 254148157
      }, {
        "name" : "Rebecca MacKinnon",
        "screen_name" : "rmack",
        "indices" : [ 16, 22 ],
        "id_str" : "810129",
        "id" : 810129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "928202621336289281",
    "geo" : { },
    "id_str" : "928223432633921537",
    "in_reply_to_user_id" : 254148157,
    "text" : "@GreatFireChina @rmack \u907F\u514D\u201C@\u201D\u8D77\u982D\u7684\u63A8\u6587\u88AB\u8A8D\u4F5C\u56DE\u5FA9\u4E0D\u51FA\u73FE\u5728\u9ED8\u8A8D\u6642\u9593\u7DAB\u4E2D\uFF0C\u8879\u9700\u4E00\u500B\u984D\u5916\u7684\u8F49\u767C\u3002",
    "id" : 928223432633921537,
    "in_reply_to_status_id" : 928202621336289281,
    "created_at" : "2017-11-08 11:31:26 +0000",
    "in_reply_to_screen_name" : "GreatFireChina",
    "in_reply_to_user_id_str" : "254148157",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 928223926731378688,
  "created_at" : "2017-11-08 11:33:24 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 0, 15 ],
      "id_str" : "254148157",
      "id" : 254148157
    }, {
      "name" : "Rebecca MacKinnon",
      "screen_name" : "rmack",
      "indices" : [ 16, 22 ],
      "id_str" : "810129",
      "id" : 810129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928202621336289281",
  "geo" : { },
  "id_str" : "928223432633921537",
  "in_reply_to_user_id" : 254148157,
  "text" : "@GreatFireChina @rmack \u907F\u514D\u201C@\u201D\u8D77\u982D\u7684\u63A8\u6587\u88AB\u8A8D\u4F5C\u56DE\u5FA9\u4E0D\u51FA\u73FE\u5728\u9ED8\u8A8D\u6642\u9593\u7DAB\u4E2D\uFF0C\u8879\u9700\u4E00\u500B\u984D\u5916\u7684\u8F49\u767C\u3002",
  "id" : 928223432633921537,
  "in_reply_to_status_id" : 928202621336289281,
  "created_at" : "2017-11-08 11:31:26 +0000",
  "in_reply_to_screen_name" : "GreatFireChina",
  "in_reply_to_user_id_str" : "254148157",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/ALN41d84q6",
      "expanded_url" : "https:\/\/archive.is\/HI3VY",
      "display_url" : "archive.is\/HI3VY"
    } ]
  },
  "geo" : { },
  "id_str" : "928221421226119168",
  "text" : "\u4E2D\u5171\u64EC\u63A8\u300A\u76E3\u5BDF\u6CD5\u300B\u4EE5\u5408\u6CD5\u5316\u96D9\u898F\uFF1Ahttps:\/\/t.co\/ALN41d84q6",
  "id" : 928221421226119168,
  "created_at" : "2017-11-08 11:23:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/UjhjVjQP6L",
      "expanded_url" : "https:\/\/archive.is\/Gfb3i",
      "display_url" : "archive.is\/Gfb3i"
    } ]
  },
  "geo" : { },
  "id_str" : "928220436235726848",
  "text" : "\u4E2D\u570B\u7522\u9375\u76E4\u88AB\u767C\u73FE\u5185\u7F6E\u8A18\u9304\u5668\uFF1Ahttps:\/\/t.co\/UjhjVjQP6L",
  "id" : 928220436235726848,
  "created_at" : "2017-11-08 11:19:32 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/OVFFs9yGbX",
      "expanded_url" : "https:\/\/archive.is\/sGSYu",
      "display_url" : "archive.is\/sGSYu"
    } ]
  },
  "geo" : { },
  "id_str" : "928219908449755141",
  "text" : "MINIX\u4F5C\u8005Andrew Tanenbaum\u7A31Intel\u7684\u5F8C\u9580\u8207\u4ED6\u7121\u95DC\uFF1Ahttps:\/\/t.co\/OVFFs9yGbX",
  "id" : 928219908449755141,
  "created_at" : "2017-11-08 11:17:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/XmWEsV55yg",
      "expanded_url" : "https:\/\/archive.is\/kD1S5",
      "display_url" : "archive.is\/kD1S5"
    } ]
  },
  "geo" : { },
  "id_str" : "928218784703315968",
  "text" : "Intel\u643A\u624BAMD\uFF1Ahttps:\/\/t.co\/XmWEsV55yg",
  "id" : 928218784703315968,
  "created_at" : "2017-11-08 11:12:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/L92GL7mBRC",
      "expanded_url" : "https:\/\/archive.is\/wIK9q",
      "display_url" : "archive.is\/wIK9q"
    } ]
  },
  "geo" : { },
  "id_str" : "928217978616864768",
  "text" : "\u81ED\u6C27\u5C64\u7A7A\u6D1E29\u5E74\u4F86\u6700\u5C0F\uFF1Ahttps:\/\/t.co\/L92GL7mBRC",
  "id" : 928217978616864768,
  "created_at" : "2017-11-08 11:09:46 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/DhGiz2xJqR",
      "expanded_url" : "https:\/\/archive.is\/jbVtv",
      "display_url" : "archive.is\/jbVtv"
    } ]
  },
  "geo" : { },
  "id_str" : "928213917557514240",
  "text" : "TPE\u6D77\u7E9C\u6545\u969C\uFF1Ahttps:\/\/t.co\/DhGiz2xJqR",
  "id" : 928213917557514240,
  "created_at" : "2017-11-08 10:53:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/E8HQfZtBwo",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=15634609",
      "display_url" : "news.ycombinator.com\/item?id=156346\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927806655806533632",
  "text" : "Why Chrome sucks\uFF1Ahttps:\/\/t.co\/E8HQfZtBwo",
  "id" : 927806655806533632,
  "created_at" : "2017-11-07 07:55:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/dix9o87f1q",
      "expanded_url" : "https:\/\/archive.is\/U8z46",
      "display_url" : "archive.is\/U8z46"
    } ]
  },
  "geo" : { },
  "id_str" : "927460861584789504",
  "text" : "\u8D8A\u767C\u4E2D\u5FC3\u5316\u7684\u4E92\u806F\u7DB2\u5728\u9AD4\u9A57\u4E0A\u8D8A\u767C\u53BB\u4E2D\u5FC3\u5316\uFF1Ahttps:\/\/t.co\/dix9o87f1q",
  "id" : 927460861584789504,
  "created_at" : "2017-11-06 09:01:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/3e8eK2EJa8",
      "expanded_url" : "https:\/\/www.bleepingcomputer.com\/news\/security\/mozilla-wants-to-distrust-dutch-https-provider-because-of-local-dystopian-law\/",
      "display_url" : "bleepingcomputer.com\/news\/security\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927455210624180224",
  "text" : "\u8377\u862D\u7ACB\u6CD5\u5141\u8A31\u653F\u5E9C\u633E\u6301CA\u548CISP\u9032\u884C\u4E2D\u9593\u4EBA\u653B\u64CA\uFF1Ahttps:\/\/t.co\/3e8eK2EJa8",
  "id" : 927455210624180224,
  "created_at" : "2017-11-06 08:38:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/L9HpukZoud",
      "expanded_url" : "https:\/\/archive.is\/Q4bRI",
      "display_url" : "archive.is\/Q4bRI"
    } ]
  },
  "geo" : { },
  "id_str" : "927128416993898496",
  "text" : "BTC\u5728\u6D25\u5DF4\u5E03\u97CB\u8D85$12k\uFF1Ahttps:\/\/t.co\/L9HpukZoud",
  "id" : 927128416993898496,
  "created_at" : "2017-11-05 11:00:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u795E\u697D\u5742\u6CC9@\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "KagurazakaIzumi",
      "indices" : [ 0, 16 ],
      "id_str" : "482695937",
      "id" : 482695937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925720844063481861",
  "geo" : { },
  "id_str" : "926806648890580992",
  "in_reply_to_user_id" : 482695937,
  "text" : "@KagurazakaIzumi Chrome\u2192F12\u2192Network\u2192Offline",
  "id" : 926806648890580992,
  "in_reply_to_status_id" : 925720844063481861,
  "created_at" : "2017-11-04 13:41:38 +0000",
  "in_reply_to_screen_name" : "KagurazakaIzumi",
  "in_reply_to_user_id_str" : "482695937",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926790882682114049",
  "text" : "\u525B\u525B\u770B\u4E86\u68AF\u5B50\u7684\u65E5\u5FD7\uFF0C\u624D\u767C\u73FEchrome\u7684\u5347\u7D1A\u7FFB\u8B6F\u548C\u8C37\u6B4C\u7684\u5B57\u9AD4\u90FD\u4E0D\u9700\u8981\u7FFB\u58BB\u4E86\u3002",
  "id" : 926790882682114049,
  "created_at" : "2017-11-04 12:39:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u53E4\u5DF4",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926781370533318656",
  "geo" : { },
  "id_str" : "926782457713537030",
  "in_reply_to_user_id" : 3359880735,
  "text" : "#\u53E4\u5DF4",
  "id" : 926782457713537030,
  "in_reply_to_status_id" : 926781370533318656,
  "created_at" : "2017-11-04 12:05:31 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/FX33HeQl29",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E4%BF%A1%E9%B8%BDIP%E9%80%9A%E8%AE%AF",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E4%BF%A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926781370533318656",
  "text" : "\u9069\u914D\u9AD8\u5EF6\u9072\u3001\u5927\u5E36\u5BEC\u5834\u666F\u7684\u901A\u8A0A\u5354\u8B70\uFF1Ahttps:\/\/t.co\/FX33HeQl29",
  "id" : 926781370533318656,
  "created_at" : "2017-11-04 12:01:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/YaVWmthtLz",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E8%B6%85%E6%96%87%E6%9C%AC%E5%92%96%E5%95%A1%E5%A3%B6%E6%8E%A7%E5%88%B6%E5%8D%8F%E8%AE%AE",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E8%B6%8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926773319881363456",
  "text" : "HTTP\u8336\u58F6\uFF1Ahttps:\/\/t.co\/YaVWmthtLz",
  "id" : 926773319881363456,
  "created_at" : "2017-11-04 11:29:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/K3IImBPw5d",
      "expanded_url" : "https:\/\/archive.is\/rCLeT",
      "display_url" : "archive.is\/rCLeT"
    } ]
  },
  "geo" : { },
  "id_str" : "926723478182617089",
  "text" : "\u5929\u7FFC\u5BA2\u6236\u7AEF\u81EA2015\u5E74\u8D77\u5E36\u6BD2\uFF1Ahttps:\/\/t.co\/K3IImBPw5d",
  "id" : 926723478182617089,
  "created_at" : "2017-11-04 08:11:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/p9R7sLKIaL",
      "expanded_url" : "https:\/\/archive.is\/IPQHg#selection-2689.2-2695.37",
      "display_url" : "archive.is\/IPQHg#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926717624301613063",
  "text" : "\u5468\u9E3F\u794E\u5728\u81EA\u50B3\u4E2D\u63D0\u5230\uFF0C2010\u5E7410\u6708\uFF0C\u9A30\u8A0A\u6D3E\u51FA\u6578\u5341\u540D\u8B66\u5BDF\u95D6\u5165\u5947\u864E\u6293\u6355\u5468\u9E3F\u794E\uFF1Ahttps:\/\/t.co\/p9R7sLKIaL",
  "id" : 926717624301613063,
  "created_at" : "2017-11-04 07:47:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926714662489640960",
  "text" : "solidot\u6B63\u5F0F\u5553\u7528\u5BE6\u540D\u5236\u3002",
  "id" : 926714662489640960,
  "created_at" : "2017-11-04 07:36:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5154\u5B50\u9C9C\u7B19\uD83C\uDF84",
      "screen_name" : "tuzi_moe",
      "indices" : [ 3, 12 ],
      "id_str" : "3857563102",
      "id" : 3857563102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7948\u798FEric",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/RmIO67jBFb",
      "expanded_url" : "https:\/\/twitter.com\/i\/moments\/926538371702317056",
      "display_url" : "twitter.com\/i\/moments\/9265\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926696787968249856",
  "text" : "RT @tuzi_moe: #\u7948\u798FEric\nhttps:\/\/t.co\/RmIO67jBFb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u7948\u798FEric",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/RmIO67jBFb",
        "expanded_url" : "https:\/\/twitter.com\/i\/moments\/926538371702317056",
        "display_url" : "twitter.com\/i\/moments\/9265\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926579632689766400",
    "text" : "#\u7948\u798FEric\nhttps:\/\/t.co\/RmIO67jBFb",
    "id" : 926579632689766400,
    "created_at" : "2017-11-03 22:39:34 +0000",
    "user" : {
      "name" : "\u5154\u5B50\u9C9C\u7B19\uD83C\uDF84",
      "screen_name" : "tuzi_moe",
      "protected" : false,
      "id_str" : "3857563102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943406865219600385\/TUyOl70E_normal.jpg",
      "id" : 3857563102,
      "verified" : false
    }
  },
  "id" : 926696787968249856,
  "created_at" : "2017-11-04 06:25:06 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926673513506836481",
  "geo" : { },
  "id_str" : "926675559148589056",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u5DF2\u78BA\u8A8D\u662Fchrome64.0.3257.0\u51FAbug\u4E86\u3002",
  "id" : 926675559148589056,
  "in_reply_to_status_id" : 926673513506836481,
  "created_at" : "2017-11-04 05:00:44 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/926673513506836481\/photo\/1",
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/UmXIqWdaRO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNw0nH4WAAAa6xK.jpg",
      "id_str" : "926673470066393088",
      "id" : 926673470066393088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNw0nH4WAAAa6xK.jpg",
      "sizes" : [ {
        "h" : 32,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 57,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 60,
        "resize" : "fit",
        "w" : 1262
      }, {
        "h" : 60,
        "resize" : "fit",
        "w" : 1262
      }, {
        "h" : 60,
        "resize" : "crop",
        "w" : 60
      } ],
      "display_url" : "pic.twitter.com\/UmXIqWdaRO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926673513506836481",
  "text" : "tg\u53C8\u6302\u4E86\uFF1F https:\/\/t.co\/UmXIqWdaRO",
  "id" : 926673513506836481,
  "created_at" : "2017-11-04 04:52:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Zhang",
      "screen_name" : "shawnwzhang",
      "indices" : [ 3, 15 ],
      "id_str" : "49992191",
      "id" : 49992191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926653292364615680",
  "text" : "RT @shawnwzhang: Chinese surveillance technology: once your phone is connected to wifi, police will identify your ID, social accounts, phon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/shawnwzhang\/status\/926617408814571522\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/hFErA2hzdA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNwBHstUQAAWo01.jpg",
        "id_str" : "926616855103422464",
        "id" : 926616855103422464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNwBHstUQAAWo01.jpg",
        "sizes" : [ {
          "h" : 359,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 690
        } ],
        "display_url" : "pic.twitter.com\/hFErA2hzdA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926617408814571522",
    "text" : "Chinese surveillance technology: once your phone is connected to wifi, police will identify your ID, social accounts, phone MAC address. https:\/\/t.co\/hFErA2hzdA",
    "id" : 926617408814571522,
    "created_at" : "2017-11-04 01:09:40 +0000",
    "user" : {
      "name" : "Shawn Zhang",
      "screen_name" : "shawnwzhang",
      "protected" : false,
      "id_str" : "49992191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888036746658684928\/h28C_fJx_normal.jpg",
      "id" : 49992191,
      "verified" : false
    }
  },
  "id" : 926653292364615680,
  "created_at" : "2017-11-04 03:32:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/ePq4Z1pta7",
      "expanded_url" : "https:\/\/archive.is\/G2OYU",
      "display_url" : "archive.is\/G2OYU"
    } ]
  },
  "geo" : { },
  "id_str" : "926440787696672768",
  "text" : "CSDN\u7981\u6B62\u672A\u5BE6\u540D\u8005\u67E5\u770B\u5168\u6587\uFF1Ahttps:\/\/t.co\/ePq4Z1pta7",
  "id" : 926440787696672768,
  "created_at" : "2017-11-03 13:27:50 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/UKKp9QPkzZ",
      "expanded_url" : "https:\/\/archive.is\/yh5ut",
      "display_url" : "archive.is\/yh5ut"
    } ]
  },
  "geo" : { },
  "id_str" : "926436814344392704",
  "text" : "\u965D\u897F\u806F\u901A\u5C01\u9396\u6771\u4EACLinode80\u7AEF\u53E3\uFF1Ahttps:\/\/t.co\/UKKp9QPkzZ",
  "id" : 926436814344392704,
  "created_at" : "2017-11-03 13:12:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926436664414752768",
  "text" : "\u5230\u4E86\u5468\u672B\uFF0C\u7232\u4EC0\u9EBD\u6642\u9593\u7DAB\u53CD\u800C\u4E0D\u52D5\u4E86\u5462\uFF1F",
  "id" : 926436664414752768,
  "created_at" : "2017-11-03 13:11:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/X9ajBN8fpU",
      "expanded_url" : "https:\/\/archive.is\/jPEGf",
      "display_url" : "archive.is\/jPEGf"
    } ]
  },
  "geo" : { },
  "id_str" : "926420915805671424",
  "text" : "BTC\u8D8A\u6230\u8D8A\u52C7\uFF1Ahttps:\/\/t.co\/X9ajBN8fpU",
  "id" : 926420915805671424,
  "created_at" : "2017-11-03 12:08:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/f32fPafdGb",
      "expanded_url" : "https:\/\/twitter.com\/gfwrev\/status\/530245910203478016",
      "display_url" : "twitter.com\/gfwrev\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926416982223806465",
  "text" : "\u5509~ https:\/\/t.co\/f32fPafdGb",
  "id" : 926416982223806465,
  "created_at" : "2017-11-03 11:53:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 3, 18 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Vmow9FOeM4",
      "expanded_url" : "https:\/\/www.bloomberg.com\/news\/articles\/2017-10-30\/google-plots-grassroots-path-into-china-through-ai-investments",
      "display_url" : "bloomberg.com\/news\/articles\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926415580143521792",
  "text" : "RT @GreatFireChina: Google's new plan is made for China self-censorship across all products, not AI https:\/\/t.co\/Vmow9FOeM4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/Vmow9FOeM4",
        "expanded_url" : "https:\/\/www.bloomberg.com\/news\/articles\/2017-10-30\/google-plots-grassroots-path-into-china-through-ai-investments",
        "display_url" : "bloomberg.com\/news\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926257372770787328",
    "text" : "Google's new plan is made for China self-censorship across all products, not AI https:\/\/t.co\/Vmow9FOeM4",
    "id" : 926257372770787328,
    "created_at" : "2017-11-03 01:19:01 +0000",
    "user" : {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "protected" : false,
      "id_str" : "254148157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794103496836517888\/BE7Ek2ae_normal.jpg",
      "id" : 254148157,
      "verified" : true
    }
  },
  "id" : 926415580143521792,
  "created_at" : "2017-11-03 11:47:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/wYB2neKzns",
      "expanded_url" : "https:\/\/twitter.com\/gfwrev\/status\/46067036610248705",
      "display_url" : "twitter.com\/gfwrev\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926412380271235074",
  "text" : "\u5509~ https:\/\/t.co\/wYB2neKzns",
  "id" : 926412380271235074,
  "created_at" : "2017-11-03 11:34:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/XFO4ZLiCfe",
      "expanded_url" : "https:\/\/twitter.com\/gfwrev\/status\/926243253531369473",
      "display_url" : "twitter.com\/gfwrev\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926405878613528576",
  "text" : "gfwrev\u56DE\u5F52\uFF01 https:\/\/t.co\/XFO4ZLiCfe",
  "id" : 926405878613528576,
  "created_at" : "2017-11-03 11:09:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/o7RvxhQvNY",
      "expanded_url" : "https:\/\/archive.is\/2zJno",
      "display_url" : "archive.is\/2zJno"
    } ]
  },
  "geo" : { },
  "id_str" : "926404679273189376",
  "text" : "\u5317\u4EAC\u8B00\u8077\u7684\u91CD\u8981\u901A\u77E5\uFF1Ahttps:\/\/t.co\/o7RvxhQvNY",
  "id" : 926404679273189376,
  "created_at" : "2017-11-03 11:04:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/wogx1SFncv",
      "expanded_url" : "https:\/\/twitter.com\/Wordless_Echo\/status\/926329703908044801",
      "display_url" : "twitter.com\/Wordless_Echo\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926348103782891520",
  "text" : "\u6211\u932F\u4E86\u3002\u3002\u6211\u518D\u4E5F\u4E0D\u731C\u63A8\u53CB\u6027\u5225\u4E86\u3002\u3002\u3002 https:\/\/t.co\/wogx1SFncv",
  "id" : 926348103782891520,
  "created_at" : "2017-11-03 07:19:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E00\u683C",
      "screen_name" : "1gre",
      "indices" : [ 3, 8 ],
      "id_str" : "121092803",
      "id" : 121092803
    }, {
      "name" : "Lawrence Li (\u4E0D\u9CE5\u842C\u5982\u4E00)",
      "screen_name" : "liruyi",
      "indices" : [ 13, 20 ],
      "id_str" : "177547360",
      "id" : 177547360
    }, {
      "name" : "\u6C38\u8FDC18\u5C81\u7684 Kgen",
      "screen_name" : "kgen",
      "indices" : [ 41, 46 ],
      "id_str" : "15688192",
      "id" : 15688192
    }, {
      "name" : "TualatriX",
      "screen_name" : "tualatrix",
      "indices" : [ 49, 59 ],
      "id_str" : "121908437",
      "id" : 121908437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926343950419615744",
  "text" : "RT @1gre: RT @liruyi: \u5F9E\u5927\u7D04\u5341\u5929\u524D\u958B\u59CB\uFF0C\u6BCF\u5929\u65E9\u4E0A\u6211\u90FD\u6703\u770B\u770B @kgen \u548C @tualatrix \u6709\u6C92\u6709\u66F4\u65B0\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lawrence Li (\u4E0D\u9CE5\u842C\u5982\u4E00)",
        "screen_name" : "liruyi",
        "indices" : [ 3, 10 ],
        "id_str" : "177547360",
        "id" : 177547360
      }, {
        "name" : "\u6C38\u8FDC18\u5C81\u7684 Kgen",
        "screen_name" : "kgen",
        "indices" : [ 31, 36 ],
        "id_str" : "15688192",
        "id" : 15688192
      }, {
        "name" : "TualatriX",
        "screen_name" : "tualatrix",
        "indices" : [ 39, 49 ],
        "id_str" : "121908437",
        "id" : 121908437
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926043110810906624",
    "text" : "RT @liruyi: \u5F9E\u5927\u7D04\u5341\u5929\u524D\u958B\u59CB\uFF0C\u6BCF\u5929\u65E9\u4E0A\u6211\u90FD\u6703\u770B\u770B @kgen \u548C @tualatrix \u6709\u6C92\u6709\u66F4\u65B0\u3002",
    "id" : 926043110810906624,
    "created_at" : "2017-11-02 11:07:37 +0000",
    "user" : {
      "name" : "\u4E00\u683C",
      "screen_name" : "1gre",
      "protected" : false,
      "id_str" : "121092803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/858585763511808001\/-LqjCeoO_normal.jpg",
      "id" : 121092803,
      "verified" : false
    }
  },
  "id" : 926343950419615744,
  "created_at" : "2017-11-03 07:03:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926342549870186496",
  "text" : "RT @williamlong: \u63A8\u7279\u5B98\u65B9\u53D1\u516C\u544A\u79F0\uFF0C\u201C\u901A\u8FC7\u6211\u4EEC\u7684\u8C03\u67E5, \u6211\u4EEC\u4E86\u89E3\u5230,\u2018\u7279\u6717\u666E\u63A8\u7279\u88AB\u505C\u7528\u4E8B\u4EF6\u2019\u662F\u7531\u4E00\u4E2A\u63A8\u7279\u5BA2\u670D\u5458\u5DE5\u5728\u5DE5\u4F5C\u7684\u6700\u540E\u4E00\u5929\u5B8C\u6210\u7684\u3002\u6211\u4EEC\u6B63\u5728\u8FDB\u884C\u5168\u9762\u7684\u5185\u90E8\u5BA1\u67E5\u3002\u201D  \uFF08\u5FAE\u8BC4\uFF1A\u539F\u6765\u662F\u4E34\u65F6\u5DE5\u5E72\u7684\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926286893343440896",
    "text" : "\u63A8\u7279\u5B98\u65B9\u53D1\u516C\u544A\u79F0\uFF0C\u201C\u901A\u8FC7\u6211\u4EEC\u7684\u8C03\u67E5, \u6211\u4EEC\u4E86\u89E3\u5230,\u2018\u7279\u6717\u666E\u63A8\u7279\u88AB\u505C\u7528\u4E8B\u4EF6\u2019\u662F\u7531\u4E00\u4E2A\u63A8\u7279\u5BA2\u670D\u5458\u5DE5\u5728\u5DE5\u4F5C\u7684\u6700\u540E\u4E00\u5929\u5B8C\u6210\u7684\u3002\u6211\u4EEC\u6B63\u5728\u8FDB\u884C\u5168\u9762\u7684\u5185\u90E8\u5BA1\u67E5\u3002\u201D  \uFF08\u5FAE\u8BC4\uFF1A\u539F\u6765\u662F\u4E34\u65F6\u5DE5\u5E72\u7684\uFF09",
    "id" : 926286893343440896,
    "created_at" : "2017-11-03 03:16:19 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 926342549870186496,
  "created_at" : "2017-11-03 06:57:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926024120705445893",
  "text" : "\u6C38\u9060\u4E0D\u8981\u6307\u671B\u63A8\u7279\u7684\u81EA\u6BBA\u8209\u5831\u300210\u5929\u524D\u8209\u5831\uFF0C\u4ECA\u5929\u624D\u544A\u8A34\u6211\u8655\u7406\u5B8C\uFF0C\u800C\u63A8\u7279\u6240\u505A\u7684\u4E00\u5207\u53EA\u662F\u767C\u4E86\u4E00\u5C01\u90F5\u4EF6\u3002",
  "id" : 926024120705445893,
  "created_at" : "2017-11-02 09:52:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/ckWJjHojOC",
      "expanded_url" : "https:\/\/twitter.com\/chinashiyu\/status\/925954264047828992",
      "display_url" : "twitter.com\/chinashiyu\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926005914171314176",
  "text" : "\u77F3\u6591\u9C7C\u5FA9\u6D3B\u3002 https:\/\/t.co\/ckWJjHojOC",
  "id" : 926005914171314176,
  "created_at" : "2017-11-02 08:39:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D62\u9999 \u732B @New Year \uD83C\uDF86",
      "screen_name" : "ayakaneko",
      "indices" : [ 0, 10 ],
      "id_str" : "791155015360667649",
      "id" : 791155015360667649
    }, {
      "name" : "Belleve Invis",
      "screen_name" : "belleveinvis",
      "indices" : [ 11, 24 ],
      "id_str" : "127834438",
      "id" : 127834438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925998596738052097",
  "geo" : { },
  "id_str" : "925998754657914880",
  "in_reply_to_user_id" : 791155015360667649,
  "text" : "@ayakaneko @belleveinvis \u55EF\uFF0C\u5373\u4F7F\u88AB\u6A21\u7CCA\u904E\u4E5F\u4E0D\u5E0C\u671B\u88AB\u7372\u53D6\u3002",
  "id" : 925998754657914880,
  "in_reply_to_status_id" : 925998596738052097,
  "created_at" : "2017-11-02 08:11:21 +0000",
  "in_reply_to_screen_name" : "ayakaneko",
  "in_reply_to_user_id_str" : "791155015360667649",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D62\u9999 \u732B @New Year \uD83C\uDF86",
      "screen_name" : "ayakaneko",
      "indices" : [ 0, 10 ],
      "id_str" : "791155015360667649",
      "id" : 791155015360667649
    }, {
      "name" : "Belleve Invis",
      "screen_name" : "belleveinvis",
      "indices" : [ 55, 68 ],
      "id_str" : "127834438",
      "id" : 127834438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925997047752171521",
  "geo" : { },
  "id_str" : "925998286472871936",
  "in_reply_to_user_id" : 791155015360667649,
  "text" : "@ayakaneko \u8A2D\u7F6E\u91CC\u53EF\u4EE5\u95DC\u6389\u6BDB\u73BB\u7483\uFF0C\u95DC\u6389\u4E4B\u5F8Cuwp\u61C9\u7528\u61C9\u8A72\u5C31\u62FF\u4E0D\u5230\u6A21\u7CCA\u4E86\u7684\u7A97\u53E3\u4E0B\u65B9\u7684\u6A23\u5B50\u4E86\u3002\u662F\u9019\u6A23\u55CE\uFF1F@belleveinvis",
  "id" : 925998286472871936,
  "in_reply_to_status_id" : 925997047752171521,
  "created_at" : "2017-11-02 08:09:30 +0000",
  "in_reply_to_screen_name" : "ayakaneko",
  "in_reply_to_user_id_str" : "791155015360667649",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D62\u9999 \u732B @New Year \uD83C\uDF86",
      "screen_name" : "ayakaneko",
      "indices" : [ 0, 10 ],
      "id_str" : "791155015360667649",
      "id" : 791155015360667649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925755776278208513",
  "geo" : { },
  "id_str" : "925995919476224000",
  "in_reply_to_user_id" : 791155015360667649,
  "text" : "@ayakaneko \u95DC\u6389\u6BDB\u73BB\u7483\u6BD4\u8F03\u5B89\u5168\u3002",
  "id" : 925995919476224000,
  "in_reply_to_status_id" : 925755776278208513,
  "created_at" : "2017-11-02 08:00:06 +0000",
  "in_reply_to_screen_name" : "ayakaneko",
  "in_reply_to_user_id_str" : "791155015360667649",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925984254781218816",
  "text" : "\u611F\u89BA\u63A8\u7279\u4E2D\u6587\u5708\u4EE3\u8CFC\u597D\u5BEC\uFF0C\u5BEB\u4E868\u5E74\u7368\u7ACB\u535A\u5BA2\u3001\u73A9\u904D\u500BOS\u548C\u8A9E\u8A00\u7684\u4EBA\u7684\u95DC\u8A3B\u8005\u6578\u5C45\u7136\u624D\u5230\u9AD8\u4E2D\u751F\u7DB2\u7D05\u7684\u4E00\u534A\u3002",
  "id" : 925984254781218816,
  "created_at" : "2017-11-02 07:13:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoR",
      "screen_name" : "jumping_cheese",
      "indices" : [ 3, 18 ],
      "id_str" : "104464057",
      "id" : 104464057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925980636468469761",
  "text" : "RT @jumping_cheese: \u8DDF\u4F60\u8BF4\u4E2A\u4E8B\u513F\u3002\u5FAE\u4FE1\uFF0C100\u591A\u4E2A\u4EBA\u7684\u7FA4\uFF0C\u6628\u5929\u5F00\u59CB\u7684\u3002\u6D77\u5916\u7684\u51E0\u4E2A\u53EF\u4EE5\u770B\u5230\u5F7C\u6B64\uFF0C\u7EE7\u7EED\u804A\u5929\u3002\u56FD\u5185\u7684\uFF0C\u53EA\u80FD\u770B\u81EA\u5DF1\u53D1\u51FA\u7684\u4FE1\u606F\uFF0C\u4EE5\u4E3A\u7FA4\u91CC\u4E00\u6574\u5929\u6CA1\u4EBA\u8BF4\u8BDD\u3002\u53EA\u6709\u7FA4\u4E3B\uFF08\u4E5F\u662F\u56FD\u5916\u7684\uFF09\u53EF\u4EE5\u770B\u5230\u5F88\u591A\u56FD\u5185\u53D1\u51FA\u7684\u4FE1\u606F\uFF0C\u4F46\u662F\u4ED6\u56DE\u590D\uFF0C\u56FD\u5185\u7684\u770B\u4E0D\u5230\uFF0C\u5C31\u7B97at\uFF0C\u4E5F\u770B\u4E0D\u5230\u3002\u4E09\u4F53\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "923521773395623936",
    "text" : "\u8DDF\u4F60\u8BF4\u4E2A\u4E8B\u513F\u3002\u5FAE\u4FE1\uFF0C100\u591A\u4E2A\u4EBA\u7684\u7FA4\uFF0C\u6628\u5929\u5F00\u59CB\u7684\u3002\u6D77\u5916\u7684\u51E0\u4E2A\u53EF\u4EE5\u770B\u5230\u5F7C\u6B64\uFF0C\u7EE7\u7EED\u804A\u5929\u3002\u56FD\u5185\u7684\uFF0C\u53EA\u80FD\u770B\u81EA\u5DF1\u53D1\u51FA\u7684\u4FE1\u606F\uFF0C\u4EE5\u4E3A\u7FA4\u91CC\u4E00\u6574\u5929\u6CA1\u4EBA\u8BF4\u8BDD\u3002\u53EA\u6709\u7FA4\u4E3B\uFF08\u4E5F\u662F\u56FD\u5916\u7684\uFF09\u53EF\u4EE5\u770B\u5230\u5F88\u591A\u56FD\u5185\u53D1\u51FA\u7684\u4FE1\u606F\uFF0C\u4F46\u662F\u4ED6\u56DE\u590D\uFF0C\u56FD\u5185\u7684\u770B\u4E0D\u5230\uFF0C\u5C31\u7B97at\uFF0C\u4E5F\u770B\u4E0D\u5230\u3002\u4E09\u4F53\u5E73\u884C\u7A7A\u95F4\u4E86\u3002nb\u5927\u4E86\u3002\u3002\u3002\uD83D\uDE06",
    "id" : 923521773395623936,
    "created_at" : "2017-10-26 12:08:43 +0000",
    "user" : {
      "name" : "CoR",
      "screen_name" : "jumping_cheese",
      "protected" : false,
      "id_str" : "104464057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838784539052797952\/j_BGQjwf_normal.jpg",
      "id" : 104464057,
      "verified" : false
    }
  },
  "id" : 925980636468469761,
  "created_at" : "2017-11-02 06:59:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7EA2x",
      "screen_name" : "redsnow7",
      "indices" : [ 3, 12 ],
      "id_str" : "95572637",
      "id" : 95572637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925661990168690689",
  "text" : "RT @redsnow7: 10\u670831\u65E5\uFF0C\u5341\u4E8C\u5C4A\u4EBA\u5927\u7B2C\u4E09\u5341\u6B21\u4F1A\u8BAE\u5BA1\u8BAE\u4E86\u300A\u5173\u4E8E\u4E2D\u56FD\u4EBA\u6C11\u6B66\u88C5\u8B66\u5BDF\u90E8\u961F\u6539\u9769\u671F\u95F4\u6682\u65F6\u8C03\u6574\u9002\u7528\u76F8\u5173\u6CD5\u5F8B\u89C4\u5B9A\u7684\u51B3\u5B9A\uFF08\u8349\u6848\uFF09\u300B\uFF0C\u6B66\u8B66\u90E8\u961F\u5C06\u7531\u4E2D\u592E\u519B\u59D4\u7BA1\u7406\uFF0C\u5730\u65B9\u653F\u5E9C\u4E0D\u518D\u62E5\u6709\u5BF9\u6B66\u8B66\u90E8\u961F\u7684\u6307\u6325\u6743\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925659900457271296",
    "text" : "10\u670831\u65E5\uFF0C\u5341\u4E8C\u5C4A\u4EBA\u5927\u7B2C\u4E09\u5341\u6B21\u4F1A\u8BAE\u5BA1\u8BAE\u4E86\u300A\u5173\u4E8E\u4E2D\u56FD\u4EBA\u6C11\u6B66\u88C5\u8B66\u5BDF\u90E8\u961F\u6539\u9769\u671F\u95F4\u6682\u65F6\u8C03\u6574\u9002\u7528\u76F8\u5173\u6CD5\u5F8B\u89C4\u5B9A\u7684\u51B3\u5B9A\uFF08\u8349\u6848\uFF09\u300B\uFF0C\u6B66\u8B66\u90E8\u961F\u5C06\u7531\u4E2D\u592E\u519B\u59D4\u7BA1\u7406\uFF0C\u5730\u65B9\u653F\u5E9C\u4E0D\u518D\u62E5\u6709\u5BF9\u6B66\u8B66\u90E8\u961F\u7684\u6307\u6325\u6743\u3002",
    "id" : 925659900457271296,
    "created_at" : "2017-11-01 09:44:52 +0000",
    "user" : {
      "name" : "\u7EA2x",
      "screen_name" : "redsnow7",
      "protected" : false,
      "id_str" : "95572637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425318569962786816\/8DhJkJ-1_normal.png",
      "id" : 95572637,
      "verified" : false
    }
  },
  "id" : 925661990168690689,
  "created_at" : "2017-11-01 09:53:11 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925649930043224064",
  "text" : "\u7232\u4EC0\u9EBCherokuapp\u540D\u4E0D\u80FD\u6578\u5B57\u6253\u982D\uFF1F",
  "id" : 925649930043224064,
  "created_at" : "2017-11-01 09:05:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/925639058889592832\/photo\/1",
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/n1AXTUYHid",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNiHyuTW4AEQNdf.jpg",
      "id_str" : "925639028917067777",
      "id" : 925639028917067777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNiHyuTW4AEQNdf.jpg",
      "sizes" : [ {
        "h" : 58,
        "resize" : "crop",
        "w" : 58
      }, {
        "h" : 58,
        "resize" : "fit",
        "w" : 319
      }, {
        "h" : 58,
        "resize" : "fit",
        "w" : 319
      }, {
        "h" : 58,
        "resize" : "fit",
        "w" : 319
      }, {
        "h" : 58,
        "resize" : "fit",
        "w" : 319
      } ],
      "display_url" : "pic.twitter.com\/n1AXTUYHid"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925639058889592832",
  "text" : "\u5206\u88C2\u7684\u4E92\u806F\u7DB2\uFF1A https:\/\/t.co\/n1AXTUYHid",
  "id" : 925639058889592832,
  "created_at" : "2017-11-01 08:22:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925596126404849667",
  "text" : "\u7232\u4EC0\u9EBC\u6211\u95DC\u6CE8\u7684\u6642\u9593\u7DDA\u53EA\u5728\u5C01\u9396\u56B4\u91CD\u6642\u6D3B\u8E8D\uFF1F",
  "id" : 925596126404849667,
  "created_at" : "2017-11-01 05:31:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Voong",
      "screen_name" : "buildthatapp",
      "indices" : [ 0, 13 ],
      "id_str" : "702235116685242368",
      "id" : 702235116685242368
    }, {
      "name" : "xxnet",
      "screen_name" : "XXNetDev",
      "indices" : [ 14, 23 ],
      "id_str" : "2998823642",
      "id" : 2998823642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925270808905236480",
  "geo" : { },
  "id_str" : "925501253106454534",
  "in_reply_to_user_id" : 702235116685242368,
  "text" : "@buildthatapp @XXNetDev \u6240\u6709\u7F8E\u5340app\u90FD\u8981\u91CD\u65B0deploy\u3002",
  "id" : 925501253106454534,
  "in_reply_to_status_id" : 925270808905236480,
  "created_at" : "2017-10-31 23:14:28 +0000",
  "in_reply_to_screen_name" : "buildthatapp",
  "in_reply_to_user_id_str" : "702235116685242368",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]