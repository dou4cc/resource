Grailbird.data.tweets_2017_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/pudUrNFbCP",
      "expanded_url" : "https:\/\/github.com\/XX-net\/XX-Net-dev\/issues\/27",
      "display_url" : "github.com\/XX-net\/XX-Net-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903240204223467522",
  "text" : "xxnet\u590D\u6D3B\uFF1Ahttps:\/\/t.co\/pudUrNFbCP",
  "id" : 903240204223467522,
  "created_at" : "2017-08-31 12:57:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/KtJ8RMYvZL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1guDFwPSCG0",
      "display_url" : "youtube.com\/watch?v=1guDFw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903235237538344960",
  "text" : "\u4EE4\u5B8C\u6210\u53C2\u4E0E\u7206\u6599\uFF1Ahttps:\/\/t.co\/KtJ8RMYvZL",
  "id" : 903235237538344960,
  "created_at" : "2017-08-31 12:37:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/If6Itiihyu",
      "expanded_url" : "https:\/\/github.com\/phuslu\/goproxy\/issues\/1990",
      "display_url" : "github.com\/phuslu\/goproxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903228541273329664",
  "text" : "\uFF08\u672A\u7ECF\u8BC1\u5B9E\uFF09https:\/\/t.co\/If6Itiihyu",
  "id" : 903228541273329664,
  "created_at" : "2017-08-31 12:10:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/xdXLUt7VgY",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53659",
      "display_url" : "solidot.org\/story?sid=53659"
    } ]
  },
  "geo" : { },
  "id_str" : "902878197997559808",
  "text" : "Intel Management Engine\u7684\u79D8\u5BC6\u5F00\u5173\uFF1Ahttps:\/\/t.co\/xdXLUt7VgY",
  "id" : 902878197997559808,
  "created_at" : "2017-08-30 12:58:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902514006946177024",
  "text" : "\u7F51\u6613\u4E91\u97F3\u4E50\u6536\u85CF\u5355\u66F2\u6EE1100(*^_^*)",
  "id" : 902514006946177024,
  "created_at" : "2017-08-29 12:51:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7279\u52D9\u6A5F\u95A2NERV",
      "screen_name" : "UN_NERV",
      "indices" : [ 3, 11 ],
      "id_str" : "116548789",
      "id" : 116548789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902507599303778304",
  "text" : "RT @UN_NERV: \u3010\u5317\u671D\u9BAE\u30DF\u30B5\u30A4\u30EB \u895F\u88F3\u5CAC\u6771\u65B9\u306E\u592A\u5E73\u6D0B\u4E0A\u843D\u4E0B\u304B\u3011\uFF08\u7D9A\u304D\uFF09\n\u30DF\u30B5\u30A4\u30EB\u306F3\u3064\u306B\u5206\u96E2\u3057\u30013\u3064\u3068\u3082\u3001\u5348\u524D6\u664212\u5206\u3054\u308D\u3001\u5317\u6D77\u9053\u306E\u895F\u88F3\u5CAC\u6771\u65B9\u306E\u6771\u3001\u304A\u3088\u305D1180\u30AD\u30ED\u306E\u592A\u5E73\u6D0B\u4E0A\u306B\u843D\u4E0B\u3057\u305F\u3082\u306E\u3068\u63A8\u5B9A\u3055\u308C\u307E\u3059\u3002\u7834\u58CA\u63AA\u7F6E\u306E\u5B9F\u65BD\u306F\u3042\u308A\u307E\u305B\u3093\u300D\u3068\u4F1D\u3048\u307E\u3057\u305F\u3002\n\uFF082017\u5E748\u6708\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/unnerv.jp\/@UN_NERV\" rel=\"nofollow\"\u003E\u7279\u52D9\u6A5F\u95A2NERV MAGI\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "902284919950344192",
    "text" : "\u3010\u5317\u671D\u9BAE\u30DF\u30B5\u30A4\u30EB \u895F\u88F3\u5CAC\u6771\u65B9\u306E\u592A\u5E73\u6D0B\u4E0A\u843D\u4E0B\u304B\u3011\uFF08\u7D9A\u304D\uFF09\n\u30DF\u30B5\u30A4\u30EB\u306F3\u3064\u306B\u5206\u96E2\u3057\u30013\u3064\u3068\u3082\u3001\u5348\u524D6\u664212\u5206\u3054\u308D\u3001\u5317\u6D77\u9053\u306E\u895F\u88F3\u5CAC\u6771\u65B9\u306E\u6771\u3001\u304A\u3088\u305D1180\u30AD\u30ED\u306E\u592A\u5E73\u6D0B\u4E0A\u306B\u843D\u4E0B\u3057\u305F\u3082\u306E\u3068\u63A8\u5B9A\u3055\u308C\u307E\u3059\u3002\u7834\u58CA\u63AA\u7F6E\u306E\u5B9F\u65BD\u306F\u3042\u308A\u307E\u305B\u3093\u300D\u3068\u4F1D\u3048\u307E\u3057\u305F\u3002\n\uFF082017\u5E748\u670829\u65E5 6:41 NHK\uFF09",
    "id" : 902284919950344192,
    "created_at" : "2017-08-28 21:41:03 +0000",
    "user" : {
      "name" : "\u7279\u52D9\u6A5F\u95A2NERV",
      "screen_name" : "UN_NERV",
      "protected" : false,
      "id_str" : "116548789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1874890040\/un_nerv_normal.png",
      "id" : 116548789,
      "verified" : false
    }
  },
  "id" : 902507599303778304,
  "created_at" : "2017-08-29 12:25:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humanrights",
      "indices" : [ 71, 83 ]
    }, {
      "text" : "China",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "\u6C5F\u5929\u52C7",
      "indices" : [ 91, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902426689552228354",
  "text" : "RT @iyouport_news: \u201C\u5982\u679C\u6709\u4E00\u5929\u6211\u627F\u8BA4\u4EFB\u4F55\u7F6A\u884C\uFF0C\u65E0\u8BBA\u662F\u4E66\u9762\u5F62\u5F0F\u8FD8\u662F\u5F55\u97F3\uFF0C\u7EDD\u5BF9\u4E0D\u662F\u6211\u7684\u672C\u610F\u201D\u3010\u57FA\u7763\u6559\u4EBA\u6743\u5F8B\u5E08\u88AB\u8FEB\u627F\u8BA4\u72AF\u7F6A\u884C\u4E3A\u3011#humanrights #China #\u6C5F\u5929\u52C7 \u57FA\u7763\u6559\u4EBA\u6743\u5F8B\u5E08\u6628\u5929\u88AB\u8FEB\u627F\u8BA4\u56FD\u5BB6\u98A0\u8986\u7F6A\u540D\uFF0C\u5E76\u5C06\u9177\u5211\u4F20\u95FB\u79F0\u4E4B\u4E3A\u6240\u8C13\u7684\u201C\u8C23\u8A00\u201D\uFF1Ahttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/902033657673670656\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/24HMX9bsIq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DISq0uEUMAAECHc.jpg",
        "id_str" : "902033648076992512",
        "id" : 902033648076992512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DISq0uEUMAAECHc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/24HMX9bsIq"
      } ],
      "hashtags" : [ {
        "text" : "humanrights",
        "indices" : [ 52, 64 ]
      }, {
        "text" : "China",
        "indices" : [ 65, 71 ]
      }, {
        "text" : "\u6C5F\u5929\u52C7",
        "indices" : [ 72, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/YZCVJ9eYaa",
        "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1640257502672054",
        "display_url" : "facebook.com\/iyouport\/posts\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "902033657673670656",
    "text" : "\u201C\u5982\u679C\u6709\u4E00\u5929\u6211\u627F\u8BA4\u4EFB\u4F55\u7F6A\u884C\uFF0C\u65E0\u8BBA\u662F\u4E66\u9762\u5F62\u5F0F\u8FD8\u662F\u5F55\u97F3\uFF0C\u7EDD\u5BF9\u4E0D\u662F\u6211\u7684\u672C\u610F\u201D\u3010\u57FA\u7763\u6559\u4EBA\u6743\u5F8B\u5E08\u88AB\u8FEB\u627F\u8BA4\u72AF\u7F6A\u884C\u4E3A\u3011#humanrights #China #\u6C5F\u5929\u52C7 \u57FA\u7763\u6559\u4EBA\u6743\u5F8B\u5E08\u6628\u5929\u88AB\u8FEB\u627F\u8BA4\u56FD\u5BB6\u98A0\u8986\u7F6A\u540D\uFF0C\u5E76\u5C06\u9177\u5211\u4F20\u95FB\u79F0\u4E4B\u4E3A\u6240\u8C13\u7684\u201C\u8C23\u8A00\u201D\uFF1Ahttps:\/\/t.co\/YZCVJ9eYaa https:\/\/t.co\/24HMX9bsIq",
    "id" : 902033657673670656,
    "created_at" : "2017-08-28 05:02:37 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 902426689552228354,
  "created_at" : "2017-08-29 07:04:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/Wyh5Oik2bs",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53627",
      "display_url" : "solidot.org\/story?sid=53627"
    } ]
  },
  "geo" : { },
  "id_str" : "902408391343124481",
  "text" : "\u8BED\u53F2\u653F\u672C\u8D28\u66B4\u9732\uFF1Ahttps:\/\/t.co\/Wyh5Oik2bs",
  "id" : 902408391343124481,
  "created_at" : "2017-08-29 05:51:41 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902402995442339841",
  "text" : "RT @williamlong: \u636E\u77E5\u60C5\u4EBA\u58EB\u900F\u9732\uFF0C\u4E2D\u56FD\u82F9\u679C\u5E94\u7528\u5546\u5E97App Store\u5C06\u4E8E\u672C\u5468\u5185\u5F00\u59CB\u652F\u6301\u5FAE\u4FE1\u652F\u4ED8\u3002\u8FD9\u662F\u7EE7\u652F\u6301\u652F\u4ED8\u5B9D\u4ED8\u6B3E10\u4E2A\u6708\u540E\uFF0C\u82F9\u679C\u9488\u5BF9\u4E2D\u56FD\u5E02\u573A\u7684\u53C8\u4E00\u5927\u52A8\u4F5C\uFF0C\u5BF9\u4E8E\u6CA1\u6709\u6216\u4E0D\u7528\u652F\u4ED8\u5B9D\u7684\u7528\u6237\u6765\u8BF4\uFF0C\u5728\u5E94\u7528\u5546\u5E97\u4ED8\u6B3E\u66F4\u5BB9\u6613\u4E86\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "902335262549823488",
    "text" : "\u636E\u77E5\u60C5\u4EBA\u58EB\u900F\u9732\uFF0C\u4E2D\u56FD\u82F9\u679C\u5E94\u7528\u5546\u5E97App Store\u5C06\u4E8E\u672C\u5468\u5185\u5F00\u59CB\u652F\u6301\u5FAE\u4FE1\u652F\u4ED8\u3002\u8FD9\u662F\u7EE7\u652F\u6301\u652F\u4ED8\u5B9D\u4ED8\u6B3E10\u4E2A\u6708\u540E\uFF0C\u82F9\u679C\u9488\u5BF9\u4E2D\u56FD\u5E02\u573A\u7684\u53C8\u4E00\u5927\u52A8\u4F5C\uFF0C\u5BF9\u4E8E\u6CA1\u6709\u6216\u4E0D\u7528\u652F\u4ED8\u5B9D\u7684\u7528\u6237\u6765\u8BF4\uFF0C\u5728\u5E94\u7528\u5546\u5E97\u4ED8\u6B3E\u66F4\u5BB9\u6613\u4E86\u3002",
    "id" : 902335262549823488,
    "created_at" : "2017-08-29 01:01:05 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 902402995442339841,
  "created_at" : "2017-08-29 05:30:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902136228929314816",
  "text" : "\u8BDD\u8BF4\u672C\u6765\u5F88\u77ED\u7684\u7F51\u5740\u88AB\u63A8\u7279\u81EA\u52A8\u6362\u6210\u77ED\u7F51\u5740\u540E\u53CD\u800C\u53D8\u957F\u4E86~",
  "id" : 902136228929314816,
  "created_at" : "2017-08-28 11:50:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/ZNn5HwqapB",
      "expanded_url" : "https:\/\/www.tikitiki.cn",
      "display_url" : "tikitiki.cn"
    } ]
  },
  "geo" : { },
  "id_str" : "902114974188883968",
  "text" : "\u514D\u8D39\u4E0B\u8F7D\u7248\u6743\u97F3\u4E50\uFF1Ahttps:\/\/t.co\/ZNn5HwqapB",
  "id" : 902114974188883968,
  "created_at" : "2017-08-28 10:25:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902077098088681473",
  "text" : "Firefox Developer\u7684\u7248\u672C\u4ECEalpha\u6539\u4E3Abeta\u3002",
  "id" : 902077098088681473,
  "created_at" : "2017-08-28 07:55:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/6YgwvnJfoY",
      "expanded_url" : "https:\/\/motherboard.vice.com\/en_us\/article\/a33j5a\/a-redditor-archived-nearly-2-million-gigabytes-of-porn-to-test-amazons-unlimited-cloud-storage",
      "display_url" : "motherboard.vice.com\/en_us\/article\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902030496170987520",
  "text" : "\u4E14\u884C\u4E14\u73CD\u60DC\uFF1Ahttps:\/\/t.co\/6YgwvnJfoY",
  "id" : 902030496170987520,
  "created_at" : "2017-08-28 04:50:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/7IRjFIPrWP",
      "expanded_url" : "https:\/\/web.archive.org\/web\/20170828044100\/https:\/\/www.sohu.com\/a\/167643407_582534",
      "display_url" : "web.archive.org\/web\/2017082804\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902028674148511744",
  "text" : "\u75DB\u6253\u843D\u6C34\u72D7\uFF1Ahttps:\/\/t.co\/7IRjFIPrWP",
  "id" : 902028674148511744,
  "created_at" : "2017-08-28 04:42:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/902022143231320066\/photo\/1",
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/vb1qWlv46i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DISgWcSWAAA-P6b.jpg",
      "id_str" : "902022132791640064",
      "id" : 902022132791640064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DISgWcSWAAA-P6b.jpg",
      "sizes" : [ {
        "h" : 473,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 963
      } ],
      "display_url" : "pic.twitter.com\/vb1qWlv46i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902022143231320066",
  "text" : "\u6D41\u91CF\u6DF7\u6DC6\u4E0D\u662F\u94F6\u5F39\uFF1A https:\/\/t.co\/vb1qWlv46i",
  "id" : 902022143231320066,
  "created_at" : "2017-08-28 04:16:52 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/WiZ8tx4jbz",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53618",
      "display_url" : "solidot.org\/story?sid=53618"
    } ]
  },
  "geo" : { },
  "id_str" : "902018465275547648",
  "text" : "Google\u6210\u4E3A\u8DE8\u56FDISP\uFF1Ahttps:\/\/t.co\/WiZ8tx4jbz",
  "id" : 902018465275547648,
  "created_at" : "2017-08-28 04:02:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/tGHI8wMDxx",
      "expanded_url" : "https:\/\/httpbin.org\/",
      "display_url" : "httpbin.org"
    } ]
  },
  "geo" : { },
  "id_str" : "901744654965727232",
  "text" : "HTTP Request &amp; Response Service\uFF1Ahttps:\/\/t.co\/tGHI8wMDxx",
  "id" : 901744654965727232,
  "created_at" : "2017-08-27 09:54:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/5dviAbzzRG",
      "expanded_url" : "http:\/\/help.yyets.com\/",
      "display_url" : "help.yyets.com"
    } ]
  },
  "geo" : { },
  "id_str" : "901718594773508096",
  "text" : "\u4EBA\u4EBA\u5F71\u89C6\u7531\u4E8E\u67D0\u4E9B\u539F\u56E0\u4E0D\u80FD\u63A5\u53D7\u76F4\u63A5\u6350\u52A9\uFF1Ahttps:\/\/t.co\/5dviAbzzRG",
  "id" : 901718594773508096,
  "created_at" : "2017-08-27 08:10:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/tUyE6frmNO",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/08\/blog-post_972.html",
      "display_url" : "molihua.org\/2017\/08\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "901713215201173504",
  "text" : "\u738B\u5065\u6797\u7684\u5931\u7B97\uFF1Ahttps:\/\/t.co\/tUyE6frmNO",
  "id" : 901713215201173504,
  "created_at" : "2017-08-27 07:49:18 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "901697296190099456",
  "text" : "\u4E00\u5929\u4E4B\u95F4\u6DA8\u4E00\u534Afo\u5413\u5F97\u6211\u628A\u81EA\u5DF1\u6807\u8BB0\u6210\u654F\u611F~",
  "id" : 901697296190099456,
  "created_at" : "2017-08-27 06:46:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/2NhWy3Lapx",
      "expanded_url" : "https:\/\/twitter.com\/hashtag\/%E6%9C%B4%E7%B4%A0%E4%B8%80%E9%A4%90",
      "display_url" : "twitter.com\/hashtag\/%E6%9C\u2026"
    }, {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/YEJ3F7Eudg",
      "expanded_url" : "https:\/\/twitter.com\/hashtag\/%E6%A8%B8%E7%B4%A0%E4%B8%80%E9%A4%90",
      "display_url" : "twitter.com\/hashtag\/%E6%A8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "901373406280650752",
  "text" : "\u6734\u7D20\u4E00\u9910\uFF1Ahttps:\/\/t.co\/2NhWy3Lapx\uFF0Chttps:\/\/t.co\/YEJ3F7Eudg",
  "id" : 901373406280650752,
  "created_at" : "2017-08-26 09:19:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom",
      "screen_name" : "aboutbl",
      "indices" : [ 3, 11 ],
      "id_str" : "3226744891",
      "id" : 3226744891
    }, {
      "name" : "\u8C26\u8C26 xqq",
      "screen_name" : "magicxqq",
      "indices" : [ 13, 22 ],
      "id_str" : "756901332",
      "id" : 756901332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/GStmTJBoki",
      "expanded_url" : "https:\/\/citizenlab.ca\/2015\/04\/chinas-great-cannon\/",
      "display_url" : "citizenlab.ca\/2015\/04\/chinas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "901367285306327040",
  "text" : "RT @aboutbl: @magicxqq \u521A\u624D\u7FFB\u4E86\u4E00\u4E0B 15 \u5E74\u5206\u6790\u5927\u70AE\u7684\u6587\u7AE0\uFF0C\u8BF4\u88AB\u690D\u5165\u6076\u610F\u811A\u672C\u7684\u6982\u7387\u4E3A 1.75%\uFF0C\u4F30\u8BA1\u662F\u4E0D\u597D\u91CD\u73B0\u4E86\u3002 https:\/\/t.co\/GStmTJBoki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u8C26\u8C26 xqq",
        "screen_name" : "magicxqq",
        "indices" : [ 0, 9 ],
        "id_str" : "756901332",
        "id" : 756901332
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/GStmTJBoki",
        "expanded_url" : "https:\/\/citizenlab.ca\/2015\/04\/chinas-great-cannon\/",
        "display_url" : "citizenlab.ca\/2015\/04\/chinas\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "901088429118701568",
    "geo" : { },
    "id_str" : "901092880244256771",
    "in_reply_to_user_id" : 756901332,
    "text" : "@magicxqq \u521A\u624D\u7FFB\u4E86\u4E00\u4E0B 15 \u5E74\u5206\u6790\u5927\u70AE\u7684\u6587\u7AE0\uFF0C\u8BF4\u88AB\u690D\u5165\u6076\u610F\u811A\u672C\u7684\u6982\u7387\u4E3A 1.75%\uFF0C\u4F30\u8BA1\u662F\u4E0D\u597D\u91CD\u73B0\u4E86\u3002 https:\/\/t.co\/GStmTJBoki",
    "id" : 901092880244256771,
    "in_reply_to_status_id" : 901088429118701568,
    "created_at" : "2017-08-25 14:44:18 +0000",
    "in_reply_to_screen_name" : "magicxqq",
    "in_reply_to_user_id_str" : "756901332",
    "user" : {
      "name" : "Tom",
      "screen_name" : "aboutbl",
      "protected" : false,
      "id_str" : "3226744891",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_normal.png",
      "id" : 3226744891,
      "verified" : false
    }
  },
  "id" : 901367285306327040,
  "created_at" : "2017-08-26 08:54:42 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "901085151819702272",
  "text" : "Tor Browser\u81F3\u4ECA\u4FDD\u7559CNNIC CA\uFF0C\u7528\u6237\u8FD8\u4E0D\u80FD\u81EA\u884C\u5220\u9664\uFF0C\u5426\u5219\u635F\u5931\u533F\u540D\u6027\u3002",
  "id" : 901085151819702272,
  "created_at" : "2017-08-25 14:13:36 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chih",
      "screen_name" : "chih758",
      "indices" : [ 0, 8 ],
      "id_str" : "730488883",
      "id" : 730488883
    }, {
      "name" : "\u8C26\u8C26 xqq",
      "screen_name" : "magicxqq",
      "indices" : [ 9, 18 ],
      "id_str" : "756901332",
      "id" : 756901332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901069377251926018",
  "geo" : { },
  "id_str" : "901079238140448768",
  "in_reply_to_user_id" : 730488883,
  "text" : "@chih758 @magicxqq \u7136\u800C\u4F60\u6B4C\u81F3\u4ECA\u4E0D\u8BA9\u4EE3\u7406\u8BBF\u95EE\u5B66\u672F\u3001\u5F3A\u5236\u5BA1\u67E5\u4E2D\u56FD\u7248\u641C\u7D22\u3002",
  "id" : 901079238140448768,
  "in_reply_to_status_id" : 901069377251926018,
  "created_at" : "2017-08-25 13:50:06 +0000",
  "in_reply_to_screen_name" : "chih758",
  "in_reply_to_user_id_str" : "730488883",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/901078037252460544\/photo\/1",
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/A6mh8voPZa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DIFFqB6WsAEVbL3.jpg",
      "id_str" : "901077988820824065",
      "id" : 901077988820824065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DIFFqB6WsAEVbL3.jpg",
      "sizes" : [ {
        "h" : 273,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 609
      } ],
      "display_url" : "pic.twitter.com\/A6mh8voPZa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "901078037252460544",
  "text" : "\u8FD9\u4E9B\u989C\u8272\u662F\u4EC0\u4E48\u610F\u601D\uFF1F https:\/\/t.co\/A6mh8voPZa",
  "id" : 901078037252460544,
  "created_at" : "2017-08-25 13:45:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8C26\u8C26 xqq",
      "screen_name" : "magicxqq",
      "indices" : [ 0, 9 ],
      "id_str" : "756901332",
      "id" : 756901332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/N2RrKfMkin",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/899143448850296832",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "901048442092347392",
  "geo" : { },
  "id_str" : "901071992127934464",
  "in_reply_to_user_id" : 756901332,
  "text" : "@magicxqq 5\u5929\u524D\u5C31\u5F00\u59CB\u4E86\uFF1Ahttps:\/\/t.co\/N2RrKfMkin",
  "id" : 901071992127934464,
  "in_reply_to_status_id" : 901048442092347392,
  "created_at" : "2017-08-25 13:21:18 +0000",
  "in_reply_to_screen_name" : "magicxqq",
  "in_reply_to_user_id_str" : "756901332",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/ekdlzK0OlP",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/08\/blog-post_366.html",
      "display_url" : "molihua.org\/2017\/08\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900995401888739328",
  "text" : "\u5185\u5FE7\u5916\u60A3\uFF1Ahttps:\/\/t.co\/ekdlzK0OlP",
  "id" : 900995401888739328,
  "created_at" : "2017-08-25 08:16:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/6SbhjjglYc",
      "expanded_url" : "https:\/\/slashdot.org\/",
      "display_url" : "slashdot.org"
    } ]
  },
  "geo" : { },
  "id_str" : "900992252272664576",
  "text" : "Slashdot\uFF1Ahttps:\/\/t.co\/6SbhjjglYc",
  "id" : 900992252272664576,
  "created_at" : "2017-08-25 08:04:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/6ETYH2eA7I",
      "expanded_url" : "https:\/\/github.com\/lemonce\/svg-captcha\/",
      "display_url" : "github.com\/lemonce\/svg-ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900980468673380352",
  "text" : "SVG\u9A8C\u8BC1\u7801\uFF1Ahttps:\/\/t.co\/6ETYH2eA7I",
  "id" : 900980468673380352,
  "created_at" : "2017-08-25 07:17:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 3, 12 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/P2v1qq5nwg",
      "expanded_url" : "http:\/\/www.cnbeta.com\/articles\/tech\/644873.htm",
      "display_url" : "cnbeta.com\/articles\/tech\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900979671642386432",
  "text" : "RT @chengr28: WoSign \u8BC1\u4E66\u6765\u4E00\u4E2A\u6B7B\u4E00\u4E2A \uD83D\uDE01\uD83D\uDE01\n\n\u6C83\u901A\u53D8\u66F4\u540D\u79F0\u4E3A WoTrus \u540C\u65F6\u66F4\u6362 Logo https:\/\/t.co\/P2v1qq5nwg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/P2v1qq5nwg",
        "expanded_url" : "http:\/\/www.cnbeta.com\/articles\/tech\/644873.htm",
        "display_url" : "cnbeta.com\/articles\/tech\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "900954518552064000",
    "text" : "WoSign \u8BC1\u4E66\u6765\u4E00\u4E2A\u6B7B\u4E00\u4E2A \uD83D\uDE01\uD83D\uDE01\n\n\u6C83\u901A\u53D8\u66F4\u540D\u79F0\u4E3A WoTrus \u540C\u65F6\u66F4\u6362 Logo https:\/\/t.co\/P2v1qq5nwg",
    "id" : 900954518552064000,
    "created_at" : "2017-08-25 05:34:30 +0000",
    "user" : {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "protected" : false,
      "id_str" : "45630895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261578265248\/b9796e25ac61a417b0832b8f322f119f_normal.png",
      "id" : 45630895,
      "verified" : false
    }
  },
  "id" : 900979671642386432,
  "created_at" : "2017-08-25 07:14:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/900961596897345537\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/koOZkJ0yKu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DIDbx6_UQAAdiMA.jpg",
      "id_str" : "900961576168996864",
      "id" : 900961576168996864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DIDbx6_UQAAdiMA.jpg",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 1393
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 1393
      } ],
      "display_url" : "pic.twitter.com\/koOZkJ0yKu"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/900961596897345537\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/koOZkJ0yKu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DIDbyWGVYAUIhNV.jpg",
      "id_str" : "900961583446188037",
      "id" : 900961583446188037,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DIDbyWGVYAUIhNV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 1117
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 1117
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 1117
      } ],
      "display_url" : "pic.twitter.com\/koOZkJ0yKu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "900961596897345537",
  "text" : "https:\/\/t.co\/koOZkJ0yKu",
  "id" : 900961596897345537,
  "created_at" : "2017-08-25 06:02:38 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/VWeAZDieNc",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53595",
      "display_url" : "solidot.org\/story?sid=53595"
    } ]
  },
  "geo" : { },
  "id_str" : "900932733836427264",
  "text" : "\u56FA\u70B9\u8981\u5B8C\uFF1Ahttps:\/\/t.co\/VWeAZDieNc",
  "id" : 900932733836427264,
  "created_at" : "2017-08-25 04:07:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "900931125907947521",
  "text" : "\u4E3A218.254.1.15\u70E7\u9999\uFF08",
  "id" : 900931125907947521,
  "created_at" : "2017-08-25 04:01:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/MyR1JlO2RY",
      "expanded_url" : "https:\/\/github.com\/ayojs\/ayo\/",
      "display_url" : "github.com\/ayojs\/ayo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "900726394552020992",
  "text" : "Node.js\u7684\u5206\u5206\u5408\u5408\uFF1Ahttps:\/\/t.co\/MyR1JlO2RY",
  "id" : 900726394552020992,
  "created_at" : "2017-08-24 14:28:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "900723401551204352",
  "text" : "\u79FB\u52A8\u544A\u8BC9\u4F60\u4E3A\u4EC0\u4E48\u901F\u5EA6\u66F2\u7EBF\u662F\u4E00\u79CD\u827A\u672F\u3002",
  "id" : 900723401551204352,
  "created_at" : "2017-08-24 14:16:08 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8521\u82F1\u6587 Tsai Ing-wen",
      "screen_name" : "iingwen",
      "indices" : [ 3, 11 ],
      "id_str" : "155814794",
      "id" : 155814794
    }, {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 27, 34 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Formosat",
      "indices" : [ 47, 56 ]
    }, {
      "text" : "Taiwan",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "satellite",
      "indices" : [ 108, 118 ]
    }, {
      "text" : "Vandenberg",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "900711960995659778",
  "text" : "RT @iingwen: In few hours, @SpaceX will launch #Formosat-5, #Taiwan's 1st indigenously designed &amp; built #satellite, from #Vandenberg AFB, #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ 14, 21 ],
        "id_str" : "34743251",
        "id" : 34743251
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iingwen\/status\/900711672733507585\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/lNtdTMmVcN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DH_4ecDUQAAh3QR.jpg",
        "id_str" : "900711652307255296",
        "id" : 900711652307255296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DH_4ecDUQAAh3QR.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/lNtdTMmVcN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/iingwen\/status\/900711672733507585\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/lNtdTMmVcN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DH_4ecOVwAIpEyQ.jpg",
        "id_str" : "900711652353490946",
        "id" : 900711652353490946,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DH_4ecOVwAIpEyQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/lNtdTMmVcN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/iingwen\/status\/900711672733507585\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/lNtdTMmVcN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DH_4ecCUQAA2-rW.jpg",
        "id_str" : "900711652303060992",
        "id" : 900711652303060992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DH_4ecCUQAA2-rW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/lNtdTMmVcN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/iingwen\/status\/900711672733507585\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/lNtdTMmVcN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DH_4ecBVoAALkhY.jpg",
        "id_str" : "900711652298956800",
        "id" : 900711652298956800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DH_4ecBVoAALkhY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/lNtdTMmVcN"
      } ],
      "hashtags" : [ {
        "text" : "Formosat",
        "indices" : [ 34, 43 ]
      }, {
        "text" : "Taiwan",
        "indices" : [ 47, 54 ]
      }, {
        "text" : "satellite",
        "indices" : [ 95, 105 ]
      }, {
        "text" : "Vandenberg",
        "indices" : [ 112, 123 ]
      }, {
        "text" : "California",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "900711672733507585",
    "text" : "In few hours, @SpaceX will launch #Formosat-5, #Taiwan's 1st indigenously designed &amp; built #satellite, from #Vandenberg AFB, #California https:\/\/t.co\/lNtdTMmVcN",
    "id" : 900711672733507585,
    "created_at" : "2017-08-24 13:29:31 +0000",
    "user" : {
      "name" : "\u8521\u82F1\u6587 Tsai Ing-wen",
      "screen_name" : "iingwen",
      "protected" : false,
      "id_str" : "155814794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820454076618047493\/ErIM-bsD_normal.jpg",
      "id" : 155814794,
      "verified" : true
    }
  },
  "id" : 900711960995659778,
  "created_at" : "2017-08-24 13:30:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/3HopkdB4sf",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53578",
      "display_url" : "solidot.org\/story?sid=53578"
    } ]
  },
  "geo" : { },
  "id_str" : "900346701600501760",
  "text" : "mozilla\u5411Google\u9760\u62E2\uFF1Ahttps:\/\/t.co\/3HopkdB4sf",
  "id" : 900346701600501760,
  "created_at" : "2017-08-23 13:19:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Fire Age",
      "screen_name" : "redfireage",
      "indices" : [ 3, 14 ],
      "id_str" : "3198352106",
      "id" : 3198352106
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/redfireage\/status\/899315154235539456\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/SE9AityEJZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHsCW4JUIAABBAh.jpg",
      "id_str" : "899315142642376704",
      "id" : 899315142642376704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHsCW4JUIAABBAh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/SE9AityEJZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "899934260169236480",
  "text" : "RT @redfireage: \u8D77\u4F86\uFF0C\u9999\u6E2F\u4E0D\u613F\u505A\u5974\u96B6\u7684\u4EBA\u4EEC\uFF01\n\u6700\u65B0\u6D88\u606F\u6307\u51FA\u8D85\u904E14\u842C\u4EBA\u904A\u884C\uFF01\u8FEB\u7206\u7063\u4ED4\uFF01 https:\/\/t.co\/SE9AityEJZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/redfireage\/status\/899315154235539456\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/SE9AityEJZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DHsCW4JUIAABBAh.jpg",
        "id_str" : "899315142642376704",
        "id" : 899315142642376704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHsCW4JUIAABBAh.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/SE9AityEJZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.1992263, -122.9165483 ]
    },
    "id_str" : "899315154235539456",
    "text" : "\u8D77\u4F86\uFF0C\u9999\u6E2F\u4E0D\u613F\u505A\u5974\u96B6\u7684\u4EBA\u4EEC\uFF01\n\u6700\u65B0\u6D88\u606F\u6307\u51FA\u8D85\u904E14\u842C\u4EBA\u904A\u884C\uFF01\u8FEB\u7206\u7063\u4ED4\uFF01 https:\/\/t.co\/SE9AityEJZ",
    "id" : 899315154235539456,
    "created_at" : "2017-08-20 17:00:15 +0000",
    "user" : {
      "name" : "Red Fire Age",
      "screen_name" : "redfireage",
      "protected" : false,
      "id_str" : "3198352106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605426712264871936\/Op9qCPII_normal.jpg",
      "id" : 3198352106,
      "verified" : false
    }
  },
  "id" : 899934260169236480,
  "created_at" : "2017-08-22 10:00:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/HeCnNlX2vZ",
      "expanded_url" : "https:\/\/twitter.com\/JulianAssange\/status\/898929148223041536",
      "display_url" : "twitter.com\/JulianAssange\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "899932891974684672",
  "text" : "\u77E5\u4E4E\u89C2\u5149\u56E2 https:\/\/t.co\/HeCnNlX2vZ",
  "id" : 899932891974684672,
  "created_at" : "2017-08-22 09:54:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/tFgASciRf4",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53534",
      "display_url" : "solidot.org\/story?sid=53534"
    } ]
  },
  "geo" : { },
  "id_str" : "899509011506188288",
  "text" : "\u6298\u5C04\u7F51\u7EDC\uFF1Ahttps:\/\/t.co\/tFgASciRf4",
  "id" : 899509011506188288,
  "created_at" : "2017-08-21 05:50:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/899507542526767104\/photo\/1",
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/FEL11hZoQ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHuxVcMXcAITMHZ.jpg",
      "id_str" : "899507532493975554",
      "id" : 899507532493975554,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHuxVcMXcAITMHZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 1231,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 374
      }, {
        "h" : 1231,
        "resize" : "fit",
        "w" : 677
      } ],
      "display_url" : "pic.twitter.com\/FEL11hZoQ8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "899507542526767104",
  "text" : "VPN\u5C01\u9501\u5F00\u59CB\uFF1A https:\/\/t.co\/FEL11hZoQ8",
  "id" : 899507542526767104,
  "created_at" : "2017-08-21 05:44:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 3, 13 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "899503911085776896",
  "text" : "RT @kujou_rin: \u5C31\u5728\u525B\u624D\uFF0CCloudFlare\u7684CDN\u7BC0\u9EDE\u88AB\u7246\u4E86...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "899292385057755137",
    "text" : "\u5C31\u5728\u525B\u624D\uFF0CCloudFlare\u7684CDN\u7BC0\u9EDE\u88AB\u7246\u4E86...",
    "id" : 899292385057755137,
    "created_at" : "2017-08-20 15:29:47 +0000",
    "user" : {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "protected" : false,
      "id_str" : "1700784456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745048870908899328\/oeWnHP7Q_normal.jpg",
      "id" : 1700784456,
      "verified" : false
    }
  },
  "id" : 899503911085776896,
  "created_at" : "2017-08-21 05:30:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "899498567097778176",
  "text" : "\u597D\u60F3\u90A3\u4E2A..",
  "id" : 899498567097778176,
  "created_at" : "2017-08-21 05:09:04 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/pOXh38eOJX",
      "expanded_url" : "https:\/\/groups.google.com\/a\/chromium.org\/forum\/#!topic\/chromium-dev\/K2SWOcoDpAw",
      "display_url" : "groups.google.com\/a\/chromium.org\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "899284535367610368",
  "text" : "HTTP\u4E2DRange\u548CEncoding\u7684\u51B2\u7A81\u5728chromium-dev\u7684\u8BA8\u8BBA\uFF1Ahttps:\/\/t.co\/pOXh38eOJX",
  "id" : 899284535367610368,
  "created_at" : "2017-08-20 14:58:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rikki",
      "screen_name" : "rikki_lv",
      "indices" : [ 3, 12 ],
      "id_str" : "9875002",
      "id" : 9875002
    }, {
      "name" : "TualatriX",
      "screen_name" : "tualatrix",
      "indices" : [ 14, 24 ],
      "id_str" : "121908437",
      "id" : 121908437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "899157806405885952",
  "text" : "RT @rikki_lv: @tualatrix \u5176\u5B9E\u8BB0\u5F55\u8BBE\u5907\u4FE1\u606F\u662F\u73B0\u5728\u6CD5\u5F8B\u5F3A\u5236\u8981\u6C42\u7684",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TualatriX",
        "screen_name" : "tualatrix",
        "indices" : [ 0, 10 ],
        "id_str" : "121908437",
        "id" : 121908437
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "897068179851157504",
    "geo" : { },
    "id_str" : "897100802178785280",
    "in_reply_to_user_id" : 121908437,
    "text" : "@tualatrix \u5176\u5B9E\u8BB0\u5F55\u8BBE\u5907\u4FE1\u606F\u662F\u73B0\u5728\u6CD5\u5F8B\u5F3A\u5236\u8981\u6C42\u7684",
    "id" : 897100802178785280,
    "in_reply_to_status_id" : 897068179851157504,
    "created_at" : "2017-08-14 14:21:13 +0000",
    "in_reply_to_screen_name" : "tualatrix",
    "in_reply_to_user_id_str" : "121908437",
    "user" : {
      "name" : "rikki",
      "screen_name" : "rikki_lv",
      "protected" : false,
      "id_str" : "9875002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/134144567\/Eva057_normal.jpg",
      "id" : 9875002,
      "verified" : false
    }
  },
  "id" : 899157806405885952,
  "created_at" : "2017-08-20 06:35:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/899143448850296832\/photo\/1",
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/rRRyGB5wON",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHpmMVOXsAApSsu.jpg",
      "id_str" : "899143437655715840",
      "id" : 899143437655715840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHpmMVOXsAApSsu.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 255
      }, {
        "h" : 3180,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 145
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 436
      } ],
      "display_url" : "pic.twitter.com\/rRRyGB5wON"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "899143448850296832",
  "text" : "\u5927\u70AE\u5BF9\u51C6\u660E\u955C\uFF1A https:\/\/t.co\/rRRyGB5wON",
  "id" : 899143448850296832,
  "created_at" : "2017-08-20 05:37:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 3, 15 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    }, {
      "name" : "\u4E0D\u5B58\u5728 \u2160 AFK",
      "screen_name" : "donotexist_A",
      "indices" : [ 17, 30 ],
      "id_str" : "2995342938",
      "id" : 2995342938
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jichi_zhang\/status\/897831337498783745\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/lSWqbSxTJ4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHW81WoUMAEpaK3.jpg",
      "id_str" : "897831325524045825",
      "id" : 897831325524045825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHW81WoUMAEpaK3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1138
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1138
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1138
      } ],
      "display_url" : "pic.twitter.com\/lSWqbSxTJ4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "898855478343733248",
  "text" : "RT @jichi_zhang: @donotexist_A  https:\/\/t.co\/lSWqbSxTJ4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u4E0D\u5B58\u5728 \u2160 AFK",
        "screen_name" : "donotexist_A",
        "indices" : [ 0, 13 ],
        "id_str" : "2995342938",
        "id" : 2995342938
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jichi_zhang\/status\/897831337498783745\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/lSWqbSxTJ4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DHW81WoUMAEpaK3.jpg",
        "id_str" : "897831325524045825",
        "id" : 897831325524045825,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHW81WoUMAEpaK3.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 1138
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 1138
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 1138
        } ],
        "display_url" : "pic.twitter.com\/lSWqbSxTJ4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "897447578819637248",
    "geo" : { },
    "id_str" : "897831337498783745",
    "in_reply_to_user_id" : 2995342938,
    "text" : "@donotexist_A  https:\/\/t.co\/lSWqbSxTJ4",
    "id" : 897831337498783745,
    "in_reply_to_status_id" : 897447578819637248,
    "created_at" : "2017-08-16 14:44:06 +0000",
    "in_reply_to_screen_name" : "donotexist_A",
    "in_reply_to_user_id_str" : "2995342938",
    "user" : {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "protected" : false,
      "id_str" : "4628523253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941625178471112706\/oqVlIkSk_normal.jpg",
      "id" : 4628523253,
      "verified" : false
    }
  },
  "id" : 898855478343733248,
  "created_at" : "2017-08-19 10:33:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/898854261295120384\/photo\/1",
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/rjW5yAYVlN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHlfKUqXgAAJcWv.jpg",
      "id_str" : "898854231586865152",
      "id" : 898854231586865152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHlfKUqXgAAJcWv.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1282
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1282
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/rjW5yAYVlN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "898854261295120384",
  "text" : "ww https:\/\/t.co\/rjW5yAYVlN",
  "id" : 898854261295120384,
  "created_at" : "2017-08-19 10:28:50 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/AUAg48TNWq",
      "expanded_url" : "http:\/\/make.girls.moe\/#\/",
      "display_url" : "make.girls.moe\/#\/"
    } ]
  },
  "geo" : { },
  "id_str" : "898823964109135872",
  "text" : "https:\/\/t.co\/AUAg48TNWq",
  "id" : 898823964109135872,
  "created_at" : "2017-08-19 08:28:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/xzgpTKxPJ9",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53519",
      "display_url" : "solidot.org\/story?sid=53519"
    } ]
  },
  "geo" : { },
  "id_str" : "898818336611377153",
  "text" : "\u6BD4\u7279\u5E01\u7684\u5206\u5F62\u827A\u672F\uFF1Ahttps:\/\/t.co\/xzgpTKxPJ9",
  "id" : 898818336611377153,
  "created_at" : "2017-08-19 08:06:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/898814038905425920\/photo\/1",
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/kJWoMsGy6b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHk6mSBXoAMEQXA.jpg",
      "id_str" : "898814029984145411",
      "id" : 898814029984145411,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHk6mSBXoAMEQXA.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 839
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 839
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 839
      } ],
      "display_url" : "pic.twitter.com\/kJWoMsGy6b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "898814038905425920",
  "text" : "mdzz https:\/\/t.co\/kJWoMsGy6b",
  "id" : 898814038905425920,
  "created_at" : "2017-08-19 07:49:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/yuNywrxbJh",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/07\/blog-post_633.html",
      "display_url" : "molihua.org\/2017\/07\/blog-p\u2026"
    }, {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/DRt8ktArtg",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/890099048618840064",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "898558938857185282",
  "text" : "\u8309\u8389\u82B1\u5220\u9664\u5173\u7AD9\u58F0\u660E\uFF1Ahttps:\/\/t.co\/yuNywrxbJh https:\/\/t.co\/DRt8ktArtg",
  "id" : 898558938857185282,
  "created_at" : "2017-08-18 14:55:20 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/nZdI20jJJy",
      "expanded_url" : "https:\/\/raw.githubusercontent.com\/dou4cc\/resource\/master\/fq.7z.zip",
      "display_url" : "raw.githubusercontent.com\/dou4cc\/resourc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "898557764410130432",
  "text" : "GoGoTunnel\u548CGoProxy\u6DF7\u7528\uFF08fq.7z\u6539\u6210fq.exe\u53EF\u81EA\u89E3\u538B\uFF09\uFF1Ahttps:\/\/t.co\/nZdI20jJJy",
  "id" : 898557764410130432,
  "created_at" : "2017-08-18 14:50:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "898478530312511489",
  "text" : "1\u7F8E\u5143 = 6.67730584\u4EBA\u6C11\u5E01",
  "id" : 898478530312511489,
  "created_at" : "2017-08-18 09:35:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/BVroHsJ6TW",
      "expanded_url" : "https:\/\/www.eff.org\/deeplinks\/2017\/08\/fighting-neo-nazis-future-free-expression",
      "display_url" : "eff.org\/deeplinks\/2017\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "898477540112773120",
  "text" : "\u653F\u6CBB\u6B63\u786E&amp;\u8A00\u8BBA\u81EA\u7531\uFF1Ahttps:\/\/t.co\/BVroHsJ6TW",
  "id" : 898477540112773120,
  "created_at" : "2017-08-18 09:31:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EC\u30F3\u30B8\uD83C\uDF5A",
      "screen_name" : "stove_de_chin",
      "indices" : [ 3, 17 ],
      "id_str" : "852526734716960768",
      "id" : 852526734716960768
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/stove_de_chin\/status\/898077378542411777\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/jCepiEUroY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHacmLnUIAAVfEj.jpg",
      "id_str" : "898077355473641472",
      "id" : 898077355473641472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHacmLnUIAAVfEj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/jCepiEUroY"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/stove_de_chin\/status\/898077378542411777\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/jCepiEUroY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHacmLqUMAEsmgV.jpg",
      "id_str" : "898077355486228481",
      "id" : 898077355486228481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHacmLqUMAEsmgV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/jCepiEUroY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "898475529141194752",
  "text" : "RT @stove_de_chin: \u304A\u3089\u767E\u5408\u3048\u3063\u3061\u3060\u3088 https:\/\/t.co\/jCepiEUroY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stove_de_chin\/status\/898077378542411777\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/jCepiEUroY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DHacmLnUIAAVfEj.jpg",
        "id_str" : "898077355473641472",
        "id" : 898077355473641472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHacmLnUIAAVfEj.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/jCepiEUroY"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/stove_de_chin\/status\/898077378542411777\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/jCepiEUroY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DHacmLqUMAEsmgV.jpg",
        "id_str" : "898077355486228481",
        "id" : 898077355486228481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHacmLqUMAEsmgV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/jCepiEUroY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "898077378542411777",
    "text" : "\u304A\u3089\u767E\u5408\u3048\u3063\u3061\u3060\u3088 https:\/\/t.co\/jCepiEUroY",
    "id" : 898077378542411777,
    "created_at" : "2017-08-17 07:01:47 +0000",
    "user" : {
      "name" : "\u30EC\u30F3\u30B8\uD83C\uDF5A",
      "screen_name" : "stove_de_chin",
      "protected" : false,
      "id_str" : "852526734716960768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945491712150945792\/DrE1mQFh_normal.png",
      "id" : 852526734716960768,
      "verified" : false
    }
  },
  "id" : 898475529141194752,
  "created_at" : "2017-08-18 09:23:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/XSeRpVqY4M",
      "expanded_url" : "https:\/\/www.change.org",
      "display_url" : "change.org"
    } ]
  },
  "geo" : { },
  "id_str" : "898471234010271745",
  "text" : "\u5FAE\u5C0F\u7684\u6539\u53D8\uFF1Ahttps:\/\/t.co\/XSeRpVqY4M",
  "id" : 898471234010271745,
  "created_at" : "2017-08-18 09:06:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 3, 12 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/uSDk6b0jHF",
      "expanded_url" : "https:\/\/www.thestandnews.com\/politics\/%E4%B8%8A%E8%A8%B4%E5%BA%AD%E5%8A%A0%E5%88%91-%E9%87%8D%E5%A5%AA%E5%85%AC%E6%B0%91%E5%BB%A3%E5%A0%B4%E6%A1%88-%E7%BE%85%E5%86%A0%E8%81%B0%E9%BB%83%E4%B9%8B%E9%8B%92%E5%91%A8%E6%B0%B8%E5%BA%B7%E5%9B%9A\/",
      "display_url" : "thestandnews.com\/politics\/%E4%B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "898426726224613376",
  "text" : "RT @chengr28: \u91CD\u596A\u516C\u6C11\u5EE3\u5834\u6848\u3000\u7F85\u51A0\u8070\u9EC3\u4E4B\u92D2\u5468\u6C38\u5EB7\u6539\u5224\u56DA 6 \u81F3 8 \u500B\u6708\u3000\u5373\u6642\u76E3\u7981 https:\/\/t.co\/uSDk6b0jHF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/uSDk6b0jHF",
        "expanded_url" : "https:\/\/www.thestandnews.com\/politics\/%E4%B8%8A%E8%A8%B4%E5%BA%AD%E5%8A%A0%E5%88%91-%E9%87%8D%E5%A5%AA%E5%85%AC%E6%B0%91%E5%BB%A3%E5%A0%B4%E6%A1%88-%E7%BE%85%E5%86%A0%E8%81%B0%E9%BB%83%E4%B9%8B%E9%8B%92%E5%91%A8%E6%B0%B8%E5%BA%B7%E5%9B%9A\/",
        "display_url" : "thestandnews.com\/politics\/%E4%B\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "898139587754590208",
    "text" : "\u91CD\u596A\u516C\u6C11\u5EE3\u5834\u6848\u3000\u7F85\u51A0\u8070\u9EC3\u4E4B\u92D2\u5468\u6C38\u5EB7\u6539\u5224\u56DA 6 \u81F3 8 \u500B\u6708\u3000\u5373\u6642\u76E3\u7981 https:\/\/t.co\/uSDk6b0jHF",
    "id" : 898139587754590208,
    "created_at" : "2017-08-17 11:08:59 +0000",
    "user" : {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "protected" : false,
      "id_str" : "45630895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261578265248\/b9796e25ac61a417b0832b8f322f119f_normal.png",
      "id" : 45630895,
      "verified" : false
    }
  },
  "id" : 898426726224613376,
  "created_at" : "2017-08-18 06:09:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/LkvMUZkqMp",
      "expanded_url" : "http:\/\/www.bbc.com\/zhongwen\/simp\/40958157",
      "display_url" : "bbc.com\/zhongwen\/simp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "898143087964368896",
  "text" : "\u53F0\u6E7E\u5927\u89C4\u6A21\u505C\u7535\uFF1Ahttps:\/\/t.co\/LkvMUZkqMp",
  "id" : 898143087964368896,
  "created_at" : "2017-08-17 11:22:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/nX2igOxssa",
      "expanded_url" : "https:\/\/cn.nytimes.com\/asia-pacific\/20170815\/south-korea-trump-north-korea\/",
      "display_url" : "cn.nytimes.com\/asia-pacific\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "898138734746587137",
  "text" : "\u7EE5\u9756\u5230\u5E95\uFF1Ahttps:\/\/t.co\/nX2igOxssa",
  "id" : 898138734746587137,
  "created_at" : "2017-08-17 11:05:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not N\u03C3t \uD83E\uDD88",
      "screen_name" : "marogatari",
      "indices" : [ 3, 14 ],
      "id_str" : "909945245843861504",
      "id" : 909945245843861504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "898131308496527360",
  "text" : "RT @marogatari: \uFF33\uFF29\uFF2D\uFF30\uFF2C\uFF25\n\u3000\u3000\u3000\u3000\u3000\uFF38\n\u3000\uFF39\u3000\u3000\u3000\uFF23\n\u3000\uFF2F\u3000\uFF27\uFF35\uFF29\uFF34\uFF21\uFF32\n\u3000\uFF35\u3000\u3000\u3000\uFF34\u3000\uFF2E\n\u3000\uFF2E\uFF21\uFF29\uFF36\uFF25\u3000\uFF27\n\u3000\uFF27\u3000\u3000\u3000\uFF24\u3000\uFF32\n\u3000\u3000\u3000\u3000\u3000\u3000\u3000\uFF39",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "897965300116852737",
    "text" : "\uFF33\uFF29\uFF2D\uFF30\uFF2C\uFF25\n\u3000\u3000\u3000\u3000\u3000\uFF38\n\u3000\uFF39\u3000\u3000\u3000\uFF23\n\u3000\uFF2F\u3000\uFF27\uFF35\uFF29\uFF34\uFF21\uFF32\n\u3000\uFF35\u3000\u3000\u3000\uFF34\u3000\uFF2E\n\u3000\uFF2E\uFF21\uFF29\uFF36\uFF25\u3000\uFF27\n\u3000\uFF27\u3000\u3000\u3000\uFF24\u3000\uFF32\n\u3000\u3000\u3000\u3000\u3000\u3000\u3000\uFF39",
    "id" : 897965300116852737,
    "created_at" : "2017-08-16 23:36:25 +0000",
    "user" : {
      "name" : "N\u03C3t \uD83E\uDD88",
      "screen_name" : "Moedrian",
      "protected" : false,
      "id_str" : "3623662692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916603816417660929\/xlf3CtAc_normal.jpg",
      "id" : 3623662692,
      "verified" : false
    }
  },
  "id" : 898131308496527360,
  "created_at" : "2017-08-17 10:36:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "897831764185493505",
  "text" : "Firefox Nightly\u56FE\u6807\u7EC8\u4E8E\u4E0D\u50BB\u903C\u4E86\u3002\u3002",
  "id" : 897831764185493505,
  "created_at" : "2017-08-16 14:45:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "qinyuhang",
      "screen_name" : "Har1g",
      "indices" : [ 0, 6 ],
      "id_str" : "2669239878",
      "id" : 2669239878
    }, {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 7, 19 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897782934559522817",
  "geo" : { },
  "id_str" : "897783586425843712",
  "in_reply_to_user_id" : 2669239878,
  "text" : "@Har1g @williamlong \u5A01\u5EC9\u5927\u53D4\u53EF\u4EE5\u8BB2\u4E00\u4E0B\u57DF\u540D\u5C4F\u853D\u5417\uFF1FDNS\u6C61\u67D3\uFF1F",
  "id" : 897783586425843712,
  "in_reply_to_status_id" : 897782934559522817,
  "created_at" : "2017-08-16 11:34:21 +0000",
  "in_reply_to_screen_name" : "Har1g",
  "in_reply_to_user_id_str" : "2669239878",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF61\uFF65\u04E9\uFF65\uFF61) \u2744\uFE0F",
      "screen_name" : "SphericalSuki",
      "indices" : [ 0, 14 ],
      "id_str" : "3018108065",
      "id" : 3018108065
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/897777823548657666\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/tUlrJFzzqU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHWMKMMUAAESiyQ.jpg",
      "id_str" : "897777807429730305",
      "id" : 897777807429730305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHWMKMMUAAESiyQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1030,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1030,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/tUlrJFzzqU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897715697702273025",
  "geo" : { },
  "id_str" : "897777823548657666",
  "in_reply_to_user_id" : 3018108065,
  "text" : "@SphericalSuki  https:\/\/t.co\/tUlrJFzzqU",
  "id" : 897777823548657666,
  "in_reply_to_status_id" : 897715697702273025,
  "created_at" : "2017-08-16 11:11:27 +0000",
  "in_reply_to_screen_name" : "SphericalSuki",
  "in_reply_to_user_id_str" : "3018108065",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 0, 12 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897775501653278720",
  "geo" : { },
  "id_str" : "897777557877215233",
  "in_reply_to_user_id" : 2786701,
  "text" : "@williamlong \u8BF4\u660E\u662F\u654F\u611F\u8BCD\u5427~~",
  "id" : 897777557877215233,
  "in_reply_to_status_id" : 897775501653278720,
  "created_at" : "2017-08-16 11:10:24 +0000",
  "in_reply_to_screen_name" : "williamlong",
  "in_reply_to_user_id_str" : "2786701",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChineseRMB",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "897763741105827840",
  "text" : "RT @iyouport_news: \u3010\u770B\u7A7A\u4E2D\u56FD\u7684\u6295\u8D44\u8005\u8868\u793A\uFF0C\u672A\u676512\u4E2A\u6708\u4EBA\u6C11\u5E01\u53EF\u80FD\u4F1A\u8DCC70\uFF05\u3011#ChineseRMB \u51EF\u6587\u53F2\u5BC6\u65AF\u8BF4\uFF0C\u968F\u7740\u4E2D\u56FD\u7684\u4FE1\u8D37\u6CE1\u6CAB\u7EC8\u4E8E\u7206\u53D1\uFF0C\u4EBA\u6C11\u5E01\u5728\u672A\u676512\u4E2A\u6708\u53EF\u80FD\u4E0B\u8DCC70\uFF05\u3002\u5F6D\u535A\u793E\u8C03\u67E5\u7684\u5E73\u5747\u4EBA\u6C11\u5E01\u9884\u6D4B\u5458\u73B0\u5728\u9884\u6D4B\uFF0C\u52302018\u5E74\u4E2D\u671F\u4E0B\u964D3.6\uFF05\uFF1Ahttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/897320598426103808\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/UdmcjtBiir",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DHPsUedVwAANKXP.jpg",
        "id_str" : "897320587294523392",
        "id" : 897320587294523392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHPsUedVwAANKXP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/UdmcjtBiir"
      } ],
      "hashtags" : [ {
        "text" : "ChineseRMB",
        "indices" : [ 29, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/y7oTYh4x20",
        "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1628462287184909",
        "display_url" : "facebook.com\/iyouport\/posts\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "897320598426103808",
    "text" : "\u3010\u770B\u7A7A\u4E2D\u56FD\u7684\u6295\u8D44\u8005\u8868\u793A\uFF0C\u672A\u676512\u4E2A\u6708\u4EBA\u6C11\u5E01\u53EF\u80FD\u4F1A\u8DCC70\uFF05\u3011#ChineseRMB \u51EF\u6587\u53F2\u5BC6\u65AF\u8BF4\uFF0C\u968F\u7740\u4E2D\u56FD\u7684\u4FE1\u8D37\u6CE1\u6CAB\u7EC8\u4E8E\u7206\u53D1\uFF0C\u4EBA\u6C11\u5E01\u5728\u672A\u676512\u4E2A\u6708\u53EF\u80FD\u4E0B\u8DCC70\uFF05\u3002\u5F6D\u535A\u793E\u8C03\u67E5\u7684\u5E73\u5747\u4EBA\u6C11\u5E01\u9884\u6D4B\u5458\u73B0\u5728\u9884\u6D4B\uFF0C\u52302018\u5E74\u4E2D\u671F\u4E0B\u964D3.6\uFF05\uFF1Ahttps:\/\/t.co\/y7oTYh4x20 https:\/\/t.co\/UdmcjtBiir",
    "id" : 897320598426103808,
    "created_at" : "2017-08-15 04:54:36 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 897763741105827840,
  "created_at" : "2017-08-16 10:15:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF61\uFF65\u04E9\uFF65\uFF61) \u2744\uFE0F",
      "screen_name" : "SphericalSuki",
      "indices" : [ 3, 17 ],
      "id_str" : "3018108065",
      "id" : 3018108065
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SphericalSuki\/status\/897715697702273025\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/R4RPhS2FRT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHVTpPIXoAE5ArP.jpg",
      "id_str" : "897715668631658497",
      "id" : 897715668631658497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHVTpPIXoAE5ArP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/R4RPhS2FRT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "897763329711759360",
  "text" : "RT @SphericalSuki: \u90A3\u4E48\u8FD9\u4E2A\u5206\u503C\u5E94\u8BE5\u86EE\u5BB9\u6613\u6539\u53D8\u7684\u5427\u2026\n\u81F3\u5C11\u4ECE\u9898\u76EE\u6765\u770B\u4EE5\u524D\u7684\u6211\u7537\u6027\u5316\u5F97\u5206\u5E94\u8BE5\u633A\u9AD8\u7684_(:\u0437\u300D\u2220)_ https:\/\/t.co\/R4RPhS2FRT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SphericalSuki\/status\/897715697702273025\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/R4RPhS2FRT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DHVTpPIXoAE5ArP.jpg",
        "id_str" : "897715668631658497",
        "id" : 897715668631658497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHVTpPIXoAE5ArP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        } ],
        "display_url" : "pic.twitter.com\/R4RPhS2FRT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "897715697702273025",
    "text" : "\u90A3\u4E48\u8FD9\u4E2A\u5206\u503C\u5E94\u8BE5\u86EE\u5BB9\u6613\u6539\u53D8\u7684\u5427\u2026\n\u81F3\u5C11\u4ECE\u9898\u76EE\u6765\u770B\u4EE5\u524D\u7684\u6211\u7537\u6027\u5316\u5F97\u5206\u5E94\u8BE5\u633A\u9AD8\u7684_(:\u0437\u300D\u2220)_ https:\/\/t.co\/R4RPhS2FRT",
    "id" : 897715697702273025,
    "created_at" : "2017-08-16 07:04:35 +0000",
    "user" : {
      "name" : "(\uFF61\uFF65\u04E9\uFF65\uFF61) \u2744\uFE0F",
      "screen_name" : "SphericalSuki",
      "protected" : false,
      "id_str" : "3018108065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945975142290620418\/Bfc6y5Qh_normal.jpg",
      "id" : 3018108065,
      "verified" : false
    }
  },
  "id" : 897763329711759360,
  "created_at" : "2017-08-16 10:13:52 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/Uj2bGvGMe0",
      "expanded_url" : "https:\/\/imququ.com\/post\/content-encoding-header-in-http.html",
      "display_url" : "imququ.com\/post\/content-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "897451597722140672",
  "text" : "HTTP\u54CD\u5E94\u4F7F\u7528gzip\u800C\u975Edeflate\u538B\u7F29\u662F\u4E3A\u4E86\u517C\u5BB9\u800C\u975E\u9AD8\u6548\uFF1Ahttps:\/\/t.co\/Uj2bGvGMe0",
  "id" : 897451597722140672,
  "created_at" : "2017-08-15 13:35:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/iSlBOvkIKY",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E4%BA%9E%E6%96%AF%E4%BC%AF%E6%A0%BC%E7%97%87%E5%80%99%E7%BE%A4",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E4%BA%9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "897347731664097280",
  "text" : "\u963F\u65AF\u4F2F\u683C\u7EFC\u5408\u5F81\uFF1Ahttps:\/\/t.co\/iSlBOvkIKY",
  "id" : 897347731664097280,
  "created_at" : "2017-08-15 06:42:25 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 13, 25 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896212520524021761",
  "geo" : { },
  "id_str" : "896219847545192448",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@wangDevming @williamlong \u7A7A\u95F4\u53D1709\u7684wiki\u622A\u56FE\uFF0C\u626D\u66F2\u540E\u4ECD\u88AB\u51BB\uFF08\u8FD8\u597D\u662F\u5C0F\u53F7",
  "id" : 896219847545192448,
  "in_reply_to_status_id" : 896212520524021761,
  "created_at" : "2017-08-12 04:00:37 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/GZIROshpFO",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E8%BA%81%E9%AC%B1%E7%97%87",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E8%BA%8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "896014500985528320",
  "text" : "\u8E81\u90C1\u75C7\uFF08\u53CC\u76F8\u60C5\u611F\u969C\u788D\uFF09\uFF1Ahttps:\/\/t.co\/GZIROshpFO",
  "id" : 896014500985528320,
  "created_at" : "2017-08-11 14:24:38 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poi\u2642next\u2642door",
      "screen_name" : "v2_poi",
      "indices" : [ 3, 10 ],
      "id_str" : "1092469987",
      "id" : 1092469987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "895999856879165442",
  "text" : "RT @v2_poi: @nekomeowww10 \u662F\u559C\u6B22\u7684\u4EBA\u7684\u8BDD\uFF0C\u65E0\u8BBA\u662F\u5360\u6709\u8FD8\u662F\u88AB\u5360\u6709\u4EC0\u4E48\u7684\uFF0C\u611F\u89C9\u5B8C\u5168\u662F\u6709\u8DA3\u7684\u4E8B\u60C5\u8BF6\uD83D\uDE3C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "893161047267262464",
    "geo" : { },
    "id_str" : "893163403707011072",
    "in_reply_to_user_id" : 791155015360667649,
    "text" : "@nekomeowww10 \u662F\u559C\u6B22\u7684\u4EBA\u7684\u8BDD\uFF0C\u65E0\u8BBA\u662F\u5360\u6709\u8FD8\u662F\u88AB\u5360\u6709\u4EC0\u4E48\u7684\uFF0C\u611F\u89C9\u5B8C\u5168\u662F\u6709\u8DA3\u7684\u4E8B\u60C5\u8BF6\uD83D\uDE3C",
    "id" : 893163403707011072,
    "in_reply_to_status_id" : 893161047267262464,
    "created_at" : "2017-08-03 17:35:24 +0000",
    "in_reply_to_screen_name" : "ayakaneko",
    "in_reply_to_user_id_str" : "791155015360667649",
    "user" : {
      "name" : "Poi\u2642next\u2642door",
      "screen_name" : "v2_poi",
      "protected" : false,
      "id_str" : "1092469987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945268621063766017\/qVD0Pnr4_normal.jpg",
      "id" : 1092469987,
      "verified" : false
    }
  },
  "id" : 895999856879165442,
  "created_at" : "2017-08-11 13:26:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "glyceraldehyde",
      "screen_name" : "Sueharu_Nakano",
      "indices" : [ 3, 18 ],
      "id_str" : "4713166412",
      "id" : 4713166412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "895608763335487488",
  "text" : "RT @Sueharu_Nakano: \u60F3\u5690\u5690\u5176\u4ED6\u7537\u5B69\u5B50\u7CBE\u5B50\u7684\u5473\u9053\uFF08",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "894432782599847936",
    "text" : "\u60F3\u5690\u5690\u5176\u4ED6\u7537\u5B69\u5B50\u7CBE\u5B50\u7684\u5473\u9053\uFF08",
    "id" : 894432782599847936,
    "created_at" : "2017-08-07 05:39:27 +0000",
    "user" : {
      "name" : "glyceraldehyde",
      "screen_name" : "Sueharu_Nakano",
      "protected" : false,
      "id_str" : "4713166412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848468693411483649\/LQyPONew_normal.jpg",
      "id" : 4713166412,
      "verified" : false
    }
  },
  "id" : 895608763335487488,
  "created_at" : "2017-08-10 11:32:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/Rirrgo2Bx8",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E5%88%97%E5%A4%AB%C2%B7%E8%BE%BE%E7%BB%B4%E5%A4%9A%E7%BB%B4%E5%A5%87%C2%B7%E6%89%98%E6%B4%9B%E8%8C%A8%E5%9F%BA",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E5%88%9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "895574989818089473",
  "text" : "\u041B\u0435\u0432 \u0414\u0430\u0432\u0438\u0434\u043E\u0432\u0438\u0447 \u0422\u0440\u043E\u0446\u043A\u0438\u0439\uFF1Ahttps:\/\/t.co\/Rirrgo2Bx8",
  "id" : 895574989818089473,
  "created_at" : "2017-08-10 09:18:11 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/mPYzJwfpSI",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E5%8B%BF%E8%AC%82%E8%A8%80%E4%B9%8B%E4%B8%8D%E9%A0%90%E4%B9%9F",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E5%8B%B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "895540324168224768",
  "text" : "\u52FF\u8C13\u8A00\u4E4B\u4E0D\u9884\u4E5F\uFF1Ahttps:\/\/t.co\/mPYzJwfpSI",
  "id" : 895540324168224768,
  "created_at" : "2017-08-10 07:00:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bhuztez",
      "screen_name" : "bhuztez",
      "indices" : [ 0, 8 ],
      "id_str" : "97817250",
      "id" : 97817250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/ueOUC6zTqr",
      "expanded_url" : "http:\/\/www.rubyconfchina.org",
      "display_url" : "rubyconfchina.org"
    } ]
  },
  "geo" : { },
  "id_str" : "895503330478137344",
  "in_reply_to_user_id" : 97817250,
  "text" : "@bhuztez\u505A\u5BA2RubyConfChina2017\uFF1Ahttps:\/\/t.co\/ueOUC6zTqr",
  "id" : 895503330478137344,
  "created_at" : "2017-08-10 04:33:26 +0000",
  "in_reply_to_screen_name" : "bhuztez",
  "in_reply_to_user_id_str" : "97817250",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/khi4oxQBRr",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53402",
      "display_url" : "solidot.org\/story?sid=53402"
    } ]
  },
  "geo" : { },
  "id_str" : "895480394165870592",
  "text" : "\u6765\u81EA\u67E5\u7406\u7684\u5DE7\u514B\u529B\u5DE5\u5382\uFF1Ahttps:\/\/t.co\/khi4oxQBRr",
  "id" : 895480394165870592,
  "created_at" : "2017-08-10 03:02:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/bgpbDnWYIc",
      "expanded_url" : "https:\/\/twitter.com\/iingwen\/status\/895141898448388096",
      "display_url" : "twitter.com\/iingwen\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "895242409721909249",
  "text" : "\u4E09\u5E74\u6765\u7B2C\u4E00\u6761\u4E2D\u6587\u63A8 https:\/\/t.co\/bgpbDnWYIc",
  "id" : 895242409721909249,
  "created_at" : "2017-08-09 11:16:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7279\u52D9\u6A5F\u95A2NERV",
      "screen_name" : "UN_NERV",
      "indices" : [ 3, 11 ],
      "id_str" : "116548789",
      "id" : 116548789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/2mObuWd5gC",
      "expanded_url" : "http:\/\/nerv.link\/EY52ux",
      "display_url" : "nerv.link\/EY52ux"
    } ]
  },
  "geo" : { },
  "id_str" : "895241287477207040",
  "text" : "RT @UN_NERV: \u3010\u4E2D\u56FD \u56DB\u5DDD\u7701 \u4E5D\u5BE8\u6E9D\u3067\uFF2D\uFF16\uFF0E\uFF15\u306E\u5730\u9707\u3011\n\u30A2\u30E1\u30EA\u30AB\u306EUSGS=\u5730\u8CEA\u8ABF\u67FB\u6240\u306A\u3069\u306B\u3088\u308A\u307E\u3059\u3068\u3001\u65E5\u672C\u6642\u9593\u306E8\u65E5\u5348\u5F8C10\u664219\u5206\u3054\u308D\u3001\u4E2D\u56FD\u30FB\u56DB\u5DDD\u7701\u306E\u4E5D\u5BE8\u6E9D\u3092\u9707\u6E90\u3068\u3059\u308B\u30DE\u30B0\u30CB\u30C1\u30E5\u30FC\u30C96.5\u306E\u5730\u9707\u304C\u3042\u308A\u307E\u3057\u305F\u3002\nhttps:\/\/t.co\/2mObuWd5gC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/unnerv.jp\/@UN_NERV\" rel=\"nofollow\"\u003E\u7279\u52D9\u6A5F\u95A2NERV MAGI\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/2mObuWd5gC",
        "expanded_url" : "http:\/\/nerv.link\/EY52ux",
        "display_url" : "nerv.link\/EY52ux"
      } ]
    },
    "geo" : { },
    "id_str" : "894923989436346369",
    "text" : "\u3010\u4E2D\u56FD \u56DB\u5DDD\u7701 \u4E5D\u5BE8\u6E9D\u3067\uFF2D\uFF16\uFF0E\uFF15\u306E\u5730\u9707\u3011\n\u30A2\u30E1\u30EA\u30AB\u306EUSGS=\u5730\u8CEA\u8ABF\u67FB\u6240\u306A\u3069\u306B\u3088\u308A\u307E\u3059\u3068\u3001\u65E5\u672C\u6642\u9593\u306E8\u65E5\u5348\u5F8C10\u664219\u5206\u3054\u308D\u3001\u4E2D\u56FD\u30FB\u56DB\u5DDD\u7701\u306E\u4E5D\u5BE8\u6E9D\u3092\u9707\u6E90\u3068\u3059\u308B\u30DE\u30B0\u30CB\u30C1\u30E5\u30FC\u30C96.5\u306E\u5730\u9707\u304C\u3042\u308A\u307E\u3057\u305F\u3002\nhttps:\/\/t.co\/2mObuWd5gC",
    "id" : 894923989436346369,
    "created_at" : "2017-08-08 14:11:20 +0000",
    "user" : {
      "name" : "\u7279\u52D9\u6A5F\u95A2NERV",
      "screen_name" : "UN_NERV",
      "protected" : false,
      "id_str" : "116548789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1874890040\/un_nerv_normal.png",
      "id" : 116548789,
      "verified" : false
    }
  },
  "id" : 895241287477207040,
  "created_at" : "2017-08-09 11:12:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/exY0iaTwNs",
      "expanded_url" : "https:\/\/web.archive.org\/web\/20170808135906\/https:\/\/www.v2ex.com\/t\/380993",
      "display_url" : "web.archive.org\/web\/2017080813\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "894921276107747329",
  "text" : "https:\/\/t.co\/exY0iaTwNs",
  "id" : 894921276107747329,
  "created_at" : "2017-08-08 14:00:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "894860443180838912",
  "text" : "\u98CE\u96E8\u6B32\u6765",
  "id" : 894860443180838912,
  "created_at" : "2017-08-08 09:58:50 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/i2U9H48ebU",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=53367",
      "display_url" : "solidot.org\/story?sid=53367"
    } ]
  },
  "geo" : { },
  "id_str" : "894860361815425025",
  "text" : "\u53D9\u5229\u4E9A\u662F\u4E2D\u5171\u7684\u670B\u53CB\uFF1Ahttps:\/\/t.co\/i2U9H48ebU",
  "id" : 894860361815425025,
  "created_at" : "2017-08-08 09:58:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "894196145278390272",
  "text" : "\u79FB\u52A8\uD83D\uDC8A",
  "id" : 894196145278390272,
  "created_at" : "2017-08-06 13:59:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/894167787459010560\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/6zk9J8ZYS3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DGi405iWAAEbeg7.jpg",
      "id_str" : "894167744970620929",
      "id" : 894167744970620929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DGi405iWAAEbeg7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 398
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 2902,
        "resize" : "fit",
        "w" : 962
      } ],
      "display_url" : "pic.twitter.com\/6zk9J8ZYS3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "894167787459010560",
  "text" : "https:\/\/t.co\/6zk9J8ZYS3",
  "id" : 894167787459010560,
  "created_at" : "2017-08-06 12:06:28 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/MgjOToE5JE",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/08\/blog-post_29.html",
      "display_url" : "molihua.org\/2017\/08\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "893810689340563456",
  "text" : "\u4E00\u635F\u4FF1\u635F\uFF0C\u4E00\u8363\u4FF1\u8363\uFF1Ahttps:\/\/t.co\/MgjOToE5JE",
  "id" : 893810689340563456,
  "created_at" : "2017-08-05 12:27:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 3, 12 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chengr28\/status\/893434671337398272\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/hQMQXWT3ew",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DGYeDJVU0AEEbTD.jpg",
      "id_str" : "893434615473426433",
      "id" : 893434615473426433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DGYeDJVU0AEEbTD.jpg",
      "sizes" : [ {
        "h" : 560,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 1357
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 1357
      } ],
      "display_url" : "pic.twitter.com\/hQMQXWT3ew"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "893437858479996929",
  "text" : "RT @chengr28: \u6C38\u8FDC\u7684 28 \u5C81 \uD83D\uDE06\uD83D\uDE06 https:\/\/t.co\/hQMQXWT3ew",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chengr28\/status\/893434671337398272\/photo\/1",
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/hQMQXWT3ew",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DGYeDJVU0AEEbTD.jpg",
        "id_str" : "893434615473426433",
        "id" : 893434615473426433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DGYeDJVU0AEEbTD.jpg",
        "sizes" : [ {
          "h" : 560,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 317,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 1357
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 1357
        } ],
        "display_url" : "pic.twitter.com\/hQMQXWT3ew"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "893434671337398272",
    "text" : "\u6C38\u8FDC\u7684 28 \u5C81 \uD83D\uDE06\uD83D\uDE06 https:\/\/t.co\/hQMQXWT3ew",
    "id" : 893434671337398272,
    "created_at" : "2017-08-04 11:33:19 +0000",
    "user" : {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "protected" : false,
      "id_str" : "45630895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261578265248\/b9796e25ac61a417b0832b8f322f119f_normal.png",
      "id" : 45630895,
      "verified" : false
    }
  },
  "id" : 893437858479996929,
  "created_at" : "2017-08-04 11:45:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "893395101778628608",
  "text" : "RT @williamlong: \u3010\u6DD8\u5B9D\u7981\u552E\u65E5\u6587\u6E38\u620F\u3011\u6DD8\u5B9D\u5B98\u65B9\u53D1\u516C\u544A\u8981\u6C42\u6240\u6709\u6E38\u620F\u8F6F\u4EF6\u53CA\u6E38\u620F\u8F6F\u4EF6\u5E73\u53F0\u5356\u5BB6\u5BF9\u5E97\u94FA\u7C7B\u65E5\u6587\u8F6F\u4EF6\u5546\u54C1\u8FDB\u884C\u6574\u6539\uFF0C\u6240\u6709\u76F8\u5173\u6E38\u620F\u8F6F\u4EF6\u5546\u54C1\uFF0C\u4E0D\u5F97\u5728\u5B9D\u8D1D\u6807\u9898\u3001\u5B9D\u8D1D\u56FE\u7247\u3001\u5B9D\u8D1D\u8BE6\u60C5\u9875\u51FA\u73B0\u8BED\u8A00\u7248\u672C\u4E3A\u65E5\u6587\u7684\u7248\u672C\u4FE1\u606F\u3002\u6DD8\u5B9D\u7535\u73A9\u5C06\u5BF9\u5168\u5E73\u53F0\u6E38\u620F\u8F6F\u4EF6\u8FDB\u884C\u6392\u67E5\uFF0C\u4E0D\u7B26\u5408\u4E0A\u8FF0\u89C4\u5B9A\u7684\u5546\u54C1\uFF0C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "893394087331729409",
    "text" : "\u3010\u6DD8\u5B9D\u7981\u552E\u65E5\u6587\u6E38\u620F\u3011\u6DD8\u5B9D\u5B98\u65B9\u53D1\u516C\u544A\u8981\u6C42\u6240\u6709\u6E38\u620F\u8F6F\u4EF6\u53CA\u6E38\u620F\u8F6F\u4EF6\u5E73\u53F0\u5356\u5BB6\u5BF9\u5E97\u94FA\u7C7B\u65E5\u6587\u8F6F\u4EF6\u5546\u54C1\u8FDB\u884C\u6574\u6539\uFF0C\u6240\u6709\u76F8\u5173\u6E38\u620F\u8F6F\u4EF6\u5546\u54C1\uFF0C\u4E0D\u5F97\u5728\u5B9D\u8D1D\u6807\u9898\u3001\u5B9D\u8D1D\u56FE\u7247\u3001\u5B9D\u8D1D\u8BE6\u60C5\u9875\u51FA\u73B0\u8BED\u8A00\u7248\u672C\u4E3A\u65E5\u6587\u7684\u7248\u672C\u4FE1\u606F\u3002\u6DD8\u5B9D\u7535\u73A9\u5C06\u5BF9\u5168\u5E73\u53F0\u6E38\u620F\u8F6F\u4EF6\u8FDB\u884C\u6392\u67E5\uFF0C\u4E0D\u7B26\u5408\u4E0A\u8FF0\u89C4\u5B9A\u7684\u5546\u54C1\uFF0C\u5C06\u88AB\u4E0B\u67B6\u3001\u5220\u9664\u6216\u6263\u5206\u5904\u7406\u3002",
    "id" : 893394087331729409,
    "created_at" : "2017-08-04 08:52:03 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 893395101778628608,
  "created_at" : "2017-08-04 08:56:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/fM4jvAIYmf",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/893278507198955520",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "893309336558206977",
  "text" : "\u5C3D\u65E9\u5B58\u7247 https:\/\/t.co\/fM4jvAIYmf",
  "id" : 893309336558206977,
  "created_at" : "2017-08-04 03:15:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9EC4\u9DB4",
      "screen_name" : "huangheone",
      "indices" : [ 0, 11 ],
      "id_str" : "344702930",
      "id" : 344702930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893298120586477569",
  "geo" : { },
  "id_str" : "893308979077685248",
  "in_reply_to_user_id" : 344702930,
  "text" : "@huangheone \u4F60\u8DDFAkkariiin\u8BF4\u53BB\u554A\uFF0C\u6211\u53EA\u662F\u8DEF\u4EBA",
  "id" : 893308979077685248,
  "in_reply_to_status_id" : 893298120586477569,
  "created_at" : "2017-08-04 03:13:52 +0000",
  "in_reply_to_screen_name" : "huangheone",
  "in_reply_to_user_id_str" : "344702930",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/JUEmleiqzi",
      "expanded_url" : "http:\/\/telegra.ph\/%E6%8E%A5%E6%89%8B%E7%A0%B4%E5%A8%83%E5%B0%8F%E5%A7%90%E5%A7%90SSR%E9%A1%B9%E7%9B%AE%E6%96%B0%E7%AE%97%E6%B3%95%E6%B5%8B%E8%AF%95-08-02",
      "display_url" : "telegra.ph\/%E6%8E%A5%E6%8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "893106718497964033",
  "text" : "ssr\u88AB\u7EED\uFF1Ahttps:\/\/t.co\/JUEmleiqzi",
  "id" : 893106718497964033,
  "created_at" : "2017-08-03 13:50:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/Ot7Z53zvIK",
      "expanded_url" : "https:\/\/www.sslchina.com\/google-chrome-final-action-symantec\/",
      "display_url" : "sslchina.com\/google-chrome-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892987782133682176",
  "text" : "\u5E9F\u6B62\u8D5B\u95E8\u94C1\u514B\u65D7\u4E0BCA\u7684\u8DEF\u7EBF\u56FE\uFF1Ahttps:\/\/t.co\/Ot7Z53zvIK",
  "id" : 892987782133682176,
  "created_at" : "2017-08-03 05:57:32 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u738B\u8354\u857B",
      "screen_name" : "wlh8964",
      "indices" : [ 3, 11 ],
      "id_str" : "173910489",
      "id" : 173910489
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wlh8964\/status\/891168937441808384\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/hreua7xwZ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DF4RZ4nU0AAIDLI.jpg",
      "id_str" : "891168912657666048",
      "id" : 891168912657666048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DF4RZ4nU0AAIDLI.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/hreua7xwZ3"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/wlh8964\/status\/891168937441808384\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/hreua7xwZ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DF4Rad4UQAAPq5H.jpg",
      "id_str" : "891168922661044224",
      "id" : 891168922661044224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DF4Rad4UQAAPq5H.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/hreua7xwZ3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "892971852133543936",
  "text" : "RT @wlh8964: \u65B0\u7586\u96E2\u6211\u5011\u6709\u591A\u9060\uFF1F https:\/\/t.co\/hreua7xwZ3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wlh8964\/status\/891168937441808384\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/hreua7xwZ3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DF4RZ4nU0AAIDLI.jpg",
        "id_str" : "891168912657666048",
        "id" : 891168912657666048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DF4RZ4nU0AAIDLI.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/hreua7xwZ3"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/wlh8964\/status\/891168937441808384\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/hreua7xwZ3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DF4Rad4UQAAPq5H.jpg",
        "id_str" : "891168922661044224",
        "id" : 891168922661044224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DF4Rad4UQAAPq5H.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/hreua7xwZ3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "891168937441808384",
    "text" : "\u65B0\u7586\u96E2\u6211\u5011\u6709\u591A\u9060\uFF1F https:\/\/t.co\/hreua7xwZ3",
    "id" : 891168937441808384,
    "created_at" : "2017-07-29 05:30:06 +0000",
    "user" : {
      "name" : "\u738B\u8354\u857B",
      "screen_name" : "wlh8964",
      "protected" : false,
      "id_str" : "173910489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945944655073443841\/kF3yvWCR_normal.jpg",
      "id" : 173910489,
      "verified" : false
    }
  },
  "id" : 892971852133543936,
  "created_at" : "2017-08-03 04:54:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/IcbkAj5y5F",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E5%90%8C%E6%80%81%E5%8A%A0%E5%AF%86",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E5%90%8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892969624903569408",
  "text" : "\u540C\u6001\u52A0\u5BC6\uFF1Ahttps:\/\/t.co\/IcbkAj5y5F",
  "id" : 892969624903569408,
  "created_at" : "2017-08-03 04:45:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Im1wsQJcZs",
      "expanded_url" : "https:\/\/archive.is\/T5Mpc",
      "display_url" : "archive.is\/T5Mpc"
    } ]
  },
  "geo" : { },
  "id_str" : "892968242851008512",
  "text" : "\u00ABRAISE Act\u00BB\uFF1Ahttps:\/\/t.co\/Im1wsQJcZs",
  "id" : 892968242851008512,
  "created_at" : "2017-08-03 04:39:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/tasrWMtIom",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/08\/blog-post_65.html",
      "display_url" : "molihua.org\/2017\/08\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892963661349834752",
  "text" : "\u653F\u53D8\u5728\u5373\uFF1Ahttps:\/\/t.co\/tasrWMtIom",
  "id" : 892963661349834752,
  "created_at" : "2017-08-03 04:21:41 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/HgvVvK0kR9",
      "expanded_url" : "https:\/\/web.archive.org\/save\/https:\/\/fast.v2ex.com\/t\/380033",
      "display_url" : "web.archive.org\/save\/https:\/\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "892959978415325184",
  "text" : "\u516C\u5B89\u90E8\u5F00\u5C55\u7F51\u7AD9\u4E00\u952E\u5173\u505C\u6F14\u7EC3\uFF1Ahttps:\/\/t.co\/HgvVvK0kR9",
  "id" : 892959978415325184,
  "created_at" : "2017-08-03 04:07:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "892958520496226304",
  "text" : "\u201C\u7834\u5A03\u9171Telegram\u8D26\u53F7\u5DF2\u7ECF\u5220\u9664\uFF0CSSR\u5B98\u65B9\u7FA4\u4E5F\u5DF2\u7ECF\u4E0D\u5B58\u5728\uFF0C\u52FF\u6302\u5FF5\u201D",
  "id" : 892958520496226304,
  "created_at" : "2017-08-03 04:01:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Windows",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "892755429394132992",
  "text" : "\u540C\u4E00\u5F20\u9009\u9879\u5361\u4E0A\uFF0C\u4F60\u6C38\u8FDC\u731C\u4E0D\u5230\u54EA\u4E9B\u8BBE\u7F6E\u5E94\u7528\u4E8E\u6240\u6709\u8D26\u6237\uFF0C\u54EA\u4E9B\u4EC5\u5E94\u7528\u4E8E\u672C\u5E10\u6237\u3002 #Windows",
  "id" : 892755429394132992,
  "created_at" : "2017-08-02 14:34:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/WxP80ZGwxE",
      "expanded_url" : "https:\/\/cnews.com.tw\/003170801-01\/",
      "display_url" : "cnews.com.tw\/003170801-01\/"
    } ]
  },
  "geo" : { },
  "id_str" : "892653679907659776",
  "text" : "Today is the day\uFF1Ahttps:\/\/t.co\/WxP80ZGwxE",
  "id" : 892653679907659776,
  "created_at" : "2017-08-02 07:49:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oia",
      "screen_name" : "oiax",
      "indices" : [ 3, 8 ],
      "id_str" : "284847838",
      "id" : 284847838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "892653095225884672",
  "text" : "RT @oiax: Google \u5BA3\u5E03\u7684 \u300C\u9644\u8FD1\u8FDE\u63A5\u300D\uFF08Nearby Connections\uFF09API 2.0 \u5B9E\u73B0\u4E86\u8BBE\u5907\u95F4\u901A\u4FE1\u5B8C\u5168\u79BB\u7EBF\u3001\u9AD8\u5E26\u5BBD\u3001\u52A0\u5BC6\u3001P2P \u7F51\u7EDC\u53CA\u7F51\u72B6\u7F51\u7EDC\u3002\u597D\u6D88\u606F\u662F Briar \u548C FireChat \u8FD9\u6837\u7684\u65AD\u7F51\u5E94\u7528\u4F1A\u66F4\u597D\u7528\uFF0C\u574F\u6D88\u606F\u662F Google Play 1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "892290412676653056",
    "text" : "Google \u5BA3\u5E03\u7684 \u300C\u9644\u8FD1\u8FDE\u63A5\u300D\uFF08Nearby Connections\uFF09API 2.0 \u5B9E\u73B0\u4E86\u8BBE\u5907\u95F4\u901A\u4FE1\u5B8C\u5168\u79BB\u7EBF\u3001\u9AD8\u5E26\u5BBD\u3001\u52A0\u5BC6\u3001P2P \u7F51\u7EDC\u53CA\u7F51\u72B6\u7F51\u7EDC\u3002\u597D\u6D88\u606F\u662F Briar \u548C FireChat \u8FD9\u6837\u7684\u65AD\u7F51\u5E94\u7528\u4F1A\u66F4\u597D\u7528\uFF0C\u574F\u6D88\u606F\u662F Google Play 11 \u53CA\u66F4\u9AD8\u7248\u672C\u624D\u884C\u3002",
    "id" : 892290412676653056,
    "created_at" : "2017-08-01 07:46:26 +0000",
    "user" : {
      "name" : "oia",
      "screen_name" : "oiax",
      "protected" : false,
      "id_str" : "284847838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945953045581520896\/w6yKbzGJ_normal.jpg",
      "id" : 284847838,
      "verified" : false
    }
  },
  "id" : 892653095225884672,
  "created_at" : "2017-08-02 07:47:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5800\u5DDD\u3000\u3061\u3083\u308A",
      "screen_name" : "charliechou",
      "indices" : [ 3, 15 ],
      "id_str" : "14373703",
      "id" : 14373703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "892587715111378944",
  "text" : "RT @charliechou: \u4E13\u8425\u4EBA\u8089\u7FFB\u5899\u4E1A\u52A1 24\u5C81\u4EE5\u4E0B\u8F6F\u59B9\u4F18\u5148 \u521D\u671F\u514D\u8D39 \u975E\u8BDA\u52FF\u6270",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "892050246192291840",
    "text" : "\u4E13\u8425\u4EBA\u8089\u7FFB\u5899\u4E1A\u52A1 24\u5C81\u4EE5\u4E0B\u8F6F\u59B9\u4F18\u5148 \u521D\u671F\u514D\u8D39 \u975E\u8BDA\u52FF\u6270",
    "id" : 892050246192291840,
    "created_at" : "2017-07-31 15:52:06 +0000",
    "user" : {
      "name" : "\u5800\u5DDD\u3000\u3061\u3083\u308A",
      "screen_name" : "charliechou",
      "protected" : false,
      "id_str" : "14373703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/910184510058303489\/9d7QQ7GN_normal.jpg",
      "id" : 14373703,
      "verified" : false
    }
  },
  "id" : 892587715111378944,
  "created_at" : "2017-08-02 03:27:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]