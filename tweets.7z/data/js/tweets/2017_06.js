Grailbird.data.tweets_2017_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/Rg8MmKkLMa",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52927",
      "display_url" : "solidot.org\/story?sid=52927"
    } ]
  },
  "geo" : { },
  "id_str" : "880717934020239360",
  "text" : "Windows10\u5C06\u652F\u6301\u66F4\u7EC6\u7684\u6587\u4EF6\u8BBF\u95EE\u63A7\u5236\uFF1Ahttps:\/\/t.co\/Rg8MmKkLMa",
  "id" : 880717934020239360,
  "created_at" : "2017-06-30 09:21:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53D8\u6001\u8FA3\u6912",
      "screen_name" : "remonwangxt",
      "indices" : [ 3, 15 ],
      "id_str" : "245354027",
      "id" : 245354027
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/remonwangxt\/status\/836765230323490816\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/CLUB328dkw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C5zJiZ0UsAAiywU.jpg",
      "id_str" : "836765223667150848",
      "id" : 836765223667150848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5zJiZ0UsAAiywU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 879
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 879
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 879
      } ],
      "display_url" : "pic.twitter.com\/CLUB328dkw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880637636838379522",
  "text" : "RT @remonwangxt: \u6211\u63D0\u5230\u904E\u5F88\u591A\u6B21\uFF0C\u4E2D\u570B\u7684\u793E\u4EA4\u5A92\u9AD4\u5C0D\u4E2D\u5171\u8B66\u5BDF\u662F\u5168\u900F\u660E\u7684\uFF0C\u7D66\u4F60\u5011\u770B\u4E00\u4E0B\u8B49\u64DA https:\/\/t.co\/CLUB328dkw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/remonwangxt\/status\/836765230323490816\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/CLUB328dkw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C5zJiZ0UsAAiywU.jpg",
        "id_str" : "836765223667150848",
        "id" : 836765223667150848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5zJiZ0UsAAiywU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 879
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 879
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 879
        } ],
        "display_url" : "pic.twitter.com\/CLUB328dkw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "836765230323490816",
    "text" : "\u6211\u63D0\u5230\u904E\u5F88\u591A\u6B21\uFF0C\u4E2D\u570B\u7684\u793E\u4EA4\u5A92\u9AD4\u5C0D\u4E2D\u5171\u8B66\u5BDF\u662F\u5168\u900F\u660E\u7684\uFF0C\u7D66\u4F60\u5011\u770B\u4E00\u4E0B\u8B49\u64DA https:\/\/t.co\/CLUB328dkw",
    "id" : 836765230323490816,
    "created_at" : "2017-03-01 02:29:11 +0000",
    "user" : {
      "name" : "\u53D8\u6001\u8FA3\u6912",
      "screen_name" : "remonwangxt",
      "protected" : false,
      "id_str" : "245354027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1630123218\/03_normal.jpg",
      "id" : 245354027,
      "verified" : false
    }
  },
  "id" : 880637636838379522,
  "created_at" : "2017-06-30 04:02:28 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880636487259344897",
  "text" : "\u653E\u5047\u5C31\u4E0B\u96E8\uFF0C\u96E8\u505C\u5C31\u5F00\u5B66\uFF0C\u545C\u545C\u545C~\u545C\u545C\u545C~",
  "id" : 880636487259344897,
  "created_at" : "2017-06-30 03:57:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/8Vyjd6TtWa",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52917",
      "display_url" : "solidot.org\/story?sid=52917"
    } ]
  },
  "geo" : { },
  "id_str" : "880413140361650176",
  "text" : "\u672C\u6B21\u7206\u51FA\u7684Skylake\u7684bug\u540E\u679C\u5F88\u91CD\uFF0C\u7136\u800C\u6211\u795E\u821F\u673A\u5173\u4E0D\u4E86HT\uFF0C\u4E5F\u6CA1BIOS update\uFF0C\u53EA\u597D\u795D\u5FAE\u8F6F\u7238\u7238\u5FEB\u7ED9\u6211\u66F4\u65B0\u5FAE\u7801\uFF1Ahttps:\/\/t.co\/8Vyjd6TtWa",
  "id" : 880413140361650176,
  "created_at" : "2017-06-29 13:10:24 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880412111758929921",
  "text" : "\u521A\u521A\u5378\u8F7D\u4E86\u6240\u6709Windows\u5E94\u7528\u5546\u5E97\u4E4B\u5916\u7684\u4E2D\u56FD\u8F6F\u4EF6\u3002",
  "id" : 880412111758929921,
  "created_at" : "2017-06-29 13:06:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/xJX4QuJ5bG",
      "expanded_url" : "https:\/\/instant.io",
      "display_url" : "instant.io"
    } ]
  },
  "geo" : { },
  "id_str" : "880405695501410304",
  "text" : "\u7F51\u9875\u7248BT\uFF1Ahttps:\/\/t.co\/xJX4QuJ5bG",
  "id" : 880405695501410304,
  "created_at" : "2017-06-29 12:40:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880375513272995840",
  "text" : "\u597D\u60F3\u88AB\u9886\u517B(\u3002\uFE4F\u3002*)",
  "id" : 880375513272995840,
  "created_at" : "2017-06-29 10:40:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880033052055019521",
  "text" : "chrome canary\u7EC8\u4E8E\u80FD\u65B9\u4FBF\u5730\u770B\u8BC1\u4E66\u4E86",
  "id" : 880033052055019521,
  "created_at" : "2017-06-28 12:00:04 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/RPSLpPxjxW",
      "expanded_url" : "https:\/\/www.v2ex.com\/t\/371617",
      "display_url" : "v2ex.com\/t\/371617"
    } ]
  },
  "geo" : { },
  "id_str" : "880027766481137664",
  "text" : "27\u90E8\u7EAA\u5F55\u9ED1\u5BA2\u7684\u7535\u5F71\uFF1Ahttps:\/\/t.co\/RPSLpPxjxW",
  "id" : 880027766481137664,
  "created_at" : "2017-06-28 11:39:04 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880027358161457156",
  "text" : "124.248.220.17\u6628\u5929\u8FD8\u597D\u597D\u7684\uFF08\u70E7\u9999",
  "id" : 880027358161457156,
  "created_at" : "2017-06-28 11:37:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880026815909289987",
  "text" : "\u7535\u4FE1\u8FD9\u5E72\u6270\u8D77\u8D77\u4F0F\u4F0F\u641E\u5F97\u6211\u6BCF\u6B21\u6253\u7B97\u770Bu2b\u65F6\u90FD\u8981\u8188\u5E94\u4E00\u4E0B~",
  "id" : 880026815909289987,
  "created_at" : "2017-06-28 11:35:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/KBCF6Spo1r",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/06\/blog-post_920.html",
      "display_url" : "molihua.org\/2017\/06\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880021176004866048",
  "text" : "\u8BFA\u5956\u5F97\u4E3B\u5218\u6653\u6CE2\u906D\u4E2D\u5171\u53D8\u76F8\u9177\u5211\uFF1Ahttps:\/\/t.co\/KBCF6Spo1r",
  "id" : 880021176004866048,
  "created_at" : "2017-06-28 11:12:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/Mg0EXFTIYl",
      "expanded_url" : "https:\/\/zh.moegirl.org\/zh-hans\/Prpr",
      "display_url" : "zh.moegirl.org\/zh-hans\/Prpr"
    } ]
  },
  "geo" : { },
  "id_str" : "880020853261512704",
  "text" : "prpr\uFF1Ahttps:\/\/t.co\/Mg0EXFTIYl",
  "id" : 880020853261512704,
  "created_at" : "2017-06-28 11:11:36 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 3, 12 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/rPm6YB1pa8",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52875",
      "display_url" : "solidot.org\/story?sid=52875"
    } ]
  },
  "geo" : { },
  "id_str" : "879985553399304192",
  "text" : "RT @chengr28: \u4FC4\u7F57\u65AF\u5A01\u80C1\u5C4F\u853D Telegram https:\/\/t.co\/rPm6YB1pa8\n\n\u300E\u8FD8\u6CA1\u6709\u4EFB\u4F55\u56FD\u5BB6\u5C4F\u853D Telegram\u300F\uFF1F\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/rPm6YB1pa8",
        "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52875",
        "display_url" : "solidot.org\/story?sid=52875"
      } ]
    },
    "geo" : { },
    "id_str" : "879689715288489985",
    "text" : "\u4FC4\u7F57\u65AF\u5A01\u80C1\u5C4F\u853D Telegram https:\/\/t.co\/rPm6YB1pa8\n\n\u300E\u8FD8\u6CA1\u6709\u4EFB\u4F55\u56FD\u5BB6\u5C4F\u853D Telegram\u300F\uFF1F\uFF1F",
    "id" : 879689715288489985,
    "created_at" : "2017-06-27 13:15:46 +0000",
    "user" : {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "protected" : false,
      "id_str" : "45630895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261578265248\/b9796e25ac61a417b0832b8f322f119f_normal.png",
      "id" : 45630895,
      "verified" : false
    }
  },
  "id" : 879985553399304192,
  "created_at" : "2017-06-28 08:51:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/rs9VlNk6IS",
      "expanded_url" : "https:\/\/beijinglug.club\/lin-desktop-linux-gpl-openness\/",
      "display_url" : "beijinglug.club\/lin-desktop-li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "879872671605039109",
  "text" : "Linux\u57FA\u91D1\u4F1A\u7684\u6076\uFF1Ahttps:\/\/t.co\/rs9VlNk6IS",
  "id" : 879872671605039109,
  "created_at" : "2017-06-28 01:22:46 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/EcL4A3ePPN",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52869",
      "display_url" : "solidot.org\/story?sid=52869"
    } ]
  },
  "geo" : { },
  "id_str" : "879296701818949633",
  "text" : "\u6FB3\u5927\u5229\u4E9A\u662F\u4E2D\u5171\u7684\u670B\u53CB\uFF1Ahttps:\/\/t.co\/EcL4A3ePPN",
  "id" : 879296701818949633,
  "created_at" : "2017-06-26 11:14:04 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 3, 18 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "878891621798039552",
  "text" : "RT @GreatFireChina: \u65B0\u7586\u6CA1\u6536\u54C8\u8428\u514B\u65CF\u4EBA\u62A4\u7167 \u5173\u95ED\u6C11\u95F4\u7F51\u7AD9 Xinjiang authorities confiscate Kazakh residents\u2019 passports, shut down folk websites https:\/\/t.co\/3x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GreatFireChina\/status\/878869386374914052\/photo\/1",
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/LJhBUL0p7K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DDJfDE8W0AAvNNj.jpg",
        "id_str" : "878869383761809408",
        "id" : 878869383761809408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDJfDE8W0AAvNNj.jpg",
        "sizes" : [ {
          "h" : 405,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/LJhBUL0p7K"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/3xtUkG7mpm",
        "expanded_url" : "http:\/\/www.appledaily.com.tw\/realtimenews\/article\/new\/20170620\/1144138\/",
        "display_url" : "appledaily.com.tw\/realtimenews\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "878869386374914052",
    "text" : "\u65B0\u7586\u6CA1\u6536\u54C8\u8428\u514B\u65CF\u4EBA\u62A4\u7167 \u5173\u95ED\u6C11\u95F4\u7F51\u7AD9 Xinjiang authorities confiscate Kazakh residents\u2019 passports, shut down folk websites https:\/\/t.co\/3xtUkG7mpm https:\/\/t.co\/LJhBUL0p7K",
    "id" : 878869386374914052,
    "created_at" : "2017-06-25 06:56:04 +0000",
    "user" : {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "protected" : false,
      "id_str" : "254148157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794103496836517888\/BE7Ek2ae_normal.jpg",
      "id" : 254148157,
      "verified" : true
    }
  },
  "id" : 878891621798039552,
  "created_at" : "2017-06-25 08:24:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "878592184009859072",
  "text" : "u2b\u7F13\u51B2\u5B8C\u89C6\u9891\u4E5F\u4E0D\u60F3\u63D0\u9AD8\u6E05\u6670\u5EA6\u3002\u3002",
  "id" : 878592184009859072,
  "created_at" : "2017-06-24 12:34:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/I5e8ZaHQKO",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52799",
      "display_url" : "solidot.org\/story?sid=52799"
    } ]
  },
  "geo" : { },
  "id_str" : "878566171917910016",
  "text" : "\u7F8E\u56FD2\u4EBF\u9009\u6C11\u4FE1\u606F\u6CC4\u9732\uFF1Ahttps:\/\/t.co\/I5e8ZaHQKO",
  "id" : 878566171917910016,
  "created_at" : "2017-06-24 10:51:13 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/B5Uv7X7lDw",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52841",
      "display_url" : "solidot.org\/story?sid=52841"
    } ]
  },
  "geo" : { },
  "id_str" : "878565000843071489",
  "text" : "mozilla\u63A8\u53BB\u4E2D\u5FC3\u5316\uFF0C\u8BA9\u4E92\u8054\u7F51\u7115\u7136\u4E00\u65B0\uFF1Ahttps:\/\/t.co\/B5Uv7X7lDw",
  "id" : 878565000843071489,
  "created_at" : "2017-06-24 10:46:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/Wqe4pn02U0",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52835",
      "display_url" : "solidot.org\/story?sid=52835"
    } ]
  },
  "geo" : { },
  "id_str" : "878563633130766336",
  "text" : "Headless\uFF1Ahttps:\/\/t.co\/Wqe4pn02U0",
  "id" : 878563633130766336,
  "created_at" : "2017-06-24 10:41:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/aDJrxpdmke",
      "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1572163236148148",
      "display_url" : "facebook.com\/iyouport\/posts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878215398696603648",
  "text" : "RT @iyouport_news: \u26A0\uFE0F\uFF3B\u524D\u4E2D\u592E\u60C5\u62A5\u5C40\u5C40\u957F\u88AB\u6307\u63A7\u5411\u4E2D\u56FD\u51FA\u552E\u79D8\u5BC6\u4FE1\u606F\uFF3D\u6839\u636E\u5468\u56DB\u5728\u4E9A\u5386\u5C71\u5927\u8054\u90A6\u6CD5\u9662\u63D0\u51FA\u7684\u6307\u63A7\uFF0C\u524D\u4E2D\u592E\u60C5\u62A5\u5C40\u7684\u4E00\u540D\u5B98\u5458\u5411\u4E2D\u56FD\u60C5\u62A5\u5B98\u5458\u51FA\u552E\u4E86\u673A\u5BC6\u6587\u4EF6\u548C\u5176\u4ED6\u5206\u7C7B\u6587\u4EF6\uFF1Ahttps:\/\/t.co\/aDJrxpdmke https:\/\/t.co\/ukvZMI3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/878160717681008640\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/ukvZMI3IVS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DC_agwyUAAEFLNP.jpg",
        "id_str" : "878160708747132929",
        "id" : 878160708747132929,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DC_agwyUAAEFLNP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 987,
          "resize" : "fit",
          "w" : 1484
        }, {
          "h" : 987,
          "resize" : "fit",
          "w" : 1484
        } ],
        "display_url" : "pic.twitter.com\/ukvZMI3IVS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/aDJrxpdmke",
        "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1572163236148148",
        "display_url" : "facebook.com\/iyouport\/posts\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "878160717681008640",
    "text" : "\u26A0\uFE0F\uFF3B\u524D\u4E2D\u592E\u60C5\u62A5\u5C40\u5C40\u957F\u88AB\u6307\u63A7\u5411\u4E2D\u56FD\u51FA\u552E\u79D8\u5BC6\u4FE1\u606F\uFF3D\u6839\u636E\u5468\u56DB\u5728\u4E9A\u5386\u5C71\u5927\u8054\u90A6\u6CD5\u9662\u63D0\u51FA\u7684\u6307\u63A7\uFF0C\u524D\u4E2D\u592E\u60C5\u62A5\u5C40\u7684\u4E00\u540D\u5B98\u5458\u5411\u4E2D\u56FD\u60C5\u62A5\u5B98\u5458\u51FA\u552E\u4E86\u673A\u5BC6\u6587\u4EF6\u548C\u5176\u4ED6\u5206\u7C7B\u6587\u4EF6\uFF1Ahttps:\/\/t.co\/aDJrxpdmke https:\/\/t.co\/ukvZMI3IVS",
    "id" : 878160717681008640,
    "created_at" : "2017-06-23 08:00:05 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 878215398696603648,
  "created_at" : "2017-06-23 11:37:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/aDJrxpdmke",
      "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1572163236148148",
      "display_url" : "facebook.com\/iyouport\/posts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878215398751064065",
  "text" : "RT @iyouport_news: \u26A0\uFE0F\uFF3B\u524D\u4E2D\u592E\u60C5\u62A5\u5C40\u5C40\u957F\u88AB\u6307\u63A7\u5411\u4E2D\u56FD\u51FA\u552E\u79D8\u5BC6\u4FE1\u606F\uFF3D\u6839\u636E\u5468\u56DB\u5728\u4E9A\u5386\u5C71\u5927\u8054\u90A6\u6CD5\u9662\u63D0\u51FA\u7684\u6307\u63A7\uFF0C\u524D\u4E2D\u592E\u60C5\u62A5\u5C40\u7684\u4E00\u540D\u5B98\u5458\u5411\u4E2D\u56FD\u60C5\u62A5\u5B98\u5458\u51FA\u552E\u4E86\u673A\u5BC6\u6587\u4EF6\u548C\u5176\u4ED6\u5206\u7C7B\u6587\u4EF6\uFF1Ahttps:\/\/t.co\/aDJrxpdmke https:\/\/t.co\/ukvZMI3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/878160717681008640\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/ukvZMI3IVS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DC_agwyUAAEFLNP.jpg",
        "id_str" : "878160708747132929",
        "id" : 878160708747132929,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DC_agwyUAAEFLNP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 987,
          "resize" : "fit",
          "w" : 1484
        }, {
          "h" : 987,
          "resize" : "fit",
          "w" : 1484
        } ],
        "display_url" : "pic.twitter.com\/ukvZMI3IVS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/aDJrxpdmke",
        "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1572163236148148",
        "display_url" : "facebook.com\/iyouport\/posts\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "878160717681008640",
    "text" : "\u26A0\uFE0F\uFF3B\u524D\u4E2D\u592E\u60C5\u62A5\u5C40\u5C40\u957F\u88AB\u6307\u63A7\u5411\u4E2D\u56FD\u51FA\u552E\u79D8\u5BC6\u4FE1\u606F\uFF3D\u6839\u636E\u5468\u56DB\u5728\u4E9A\u5386\u5C71\u5927\u8054\u90A6\u6CD5\u9662\u63D0\u51FA\u7684\u6307\u63A7\uFF0C\u524D\u4E2D\u592E\u60C5\u62A5\u5C40\u7684\u4E00\u540D\u5B98\u5458\u5411\u4E2D\u56FD\u60C5\u62A5\u5B98\u5458\u51FA\u552E\u4E86\u673A\u5BC6\u6587\u4EF6\u548C\u5176\u4ED6\u5206\u7C7B\u6587\u4EF6\uFF1Ahttps:\/\/t.co\/aDJrxpdmke https:\/\/t.co\/ukvZMI3IVS",
    "id" : 878160717681008640,
    "created_at" : "2017-06-23 08:00:05 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 878215398751064065,
  "created_at" : "2017-06-23 11:37:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "878187440007110656",
  "text" : "RT @williamlong: \u65B0\u6D6A\u5FAE\u535A\uFF1A\u53EA\u6709\u53D6\u5F97\u300A\u4FE1\u606F\u7F51\u7EDC\u4F20\u64AD\u89C6\u542C\u8282\u76EE\u8BB8\u53EF\u8BC1\u300B\u7684\u5FAE\u535A\u7528\u6237\uFF0C\u624D\u80FD\u4E0A\u4F20\u89C6\u542C\u8282\u76EE\uFF0C\u65E0\u8BC1\u7528\u6237\u4E0D\u80FD\u4E0A\u4F20\u89C6\u542C\u8282\u76EE\u3002\u5FAE\u535A\u7528\u6237\u4E0A\u4F20\u975E\u8282\u76EE\u7C7B\u89C6\u9891\u4E0D\u53D7\u5F71\u54CD\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "877918760459317248",
    "text" : "\u65B0\u6D6A\u5FAE\u535A\uFF1A\u53EA\u6709\u53D6\u5F97\u300A\u4FE1\u606F\u7F51\u7EDC\u4F20\u64AD\u89C6\u542C\u8282\u76EE\u8BB8\u53EF\u8BC1\u300B\u7684\u5FAE\u535A\u7528\u6237\uFF0C\u624D\u80FD\u4E0A\u4F20\u89C6\u542C\u8282\u76EE\uFF0C\u65E0\u8BC1\u7528\u6237\u4E0D\u80FD\u4E0A\u4F20\u89C6\u542C\u8282\u76EE\u3002\u5FAE\u535A\u7528\u6237\u4E0A\u4F20\u975E\u8282\u76EE\u7C7B\u89C6\u9891\u4E0D\u53D7\u5F71\u54CD\u3002",
    "id" : 877918760459317248,
    "created_at" : "2017-06-22 15:58:38 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 878187440007110656,
  "created_at" : "2017-06-23 09:46:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "878186320937578498",
  "text" : "RT @williamlong: \u3010\u5E7F\u7535\u603B\u5C40\u8981\u6C42\u65B0\u6D6A\u5FAE\u535A\u51E4\u51F0\u7F51\u7B49\u5173\u95ED\u89C6\u542C\u8282\u76EE\u670D\u52A1\u3011\u9488\u5BF9\u201C\u65B0\u6D6A\u5FAE\u535A\u201D\u3001\u201CACFUN\u201D\u3001\u201C\u51E4\u51F0\u7F51\u201D\u7B49\u7F51\u7AD9\u5728\u4E0D\u5177\u5907\u300A\u4FE1\u606F\u7F51\u7EDC\u4F20\u64AD\u89C6\u542C\u8282\u76EE\u8BB8\u53EF\u8BC1\u300B\u7684\u60C5\u51B5\u4E0B\u5F00\u5C55\u89C6\u542C\u8282\u76EE\u670D\u52A1\uFF0C\u5E7F\u7535\u603B\u5C40\u4E8E\u8FD1\u65E5\u53D1\u51FD\u8D23\u6210\u5C5E\u5730\u7BA1\u7406\u90E8\u95E8\uFF0C\u91C7\u53D6\u6709\u6548\u63AA\u65BD\u5173\u505C\u4E0A\u8FF0\u7F51\u7AD9\u4E0A\u7684\u89C6\u542C\u8282\u76EE\u670D\u52A1\uFF0C\u8FDB\u884C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "878052033445715969",
    "text" : "\u3010\u5E7F\u7535\u603B\u5C40\u8981\u6C42\u65B0\u6D6A\u5FAE\u535A\u51E4\u51F0\u7F51\u7B49\u5173\u95ED\u89C6\u542C\u8282\u76EE\u670D\u52A1\u3011\u9488\u5BF9\u201C\u65B0\u6D6A\u5FAE\u535A\u201D\u3001\u201CACFUN\u201D\u3001\u201C\u51E4\u51F0\u7F51\u201D\u7B49\u7F51\u7AD9\u5728\u4E0D\u5177\u5907\u300A\u4FE1\u606F\u7F51\u7EDC\u4F20\u64AD\u89C6\u542C\u8282\u76EE\u8BB8\u53EF\u8BC1\u300B\u7684\u60C5\u51B5\u4E0B\u5F00\u5C55\u89C6\u542C\u8282\u76EE\u670D\u52A1\uFF0C\u5E7F\u7535\u603B\u5C40\u4E8E\u8FD1\u65E5\u53D1\u51FD\u8D23\u6210\u5C5E\u5730\u7BA1\u7406\u90E8\u95E8\uFF0C\u91C7\u53D6\u6709\u6548\u63AA\u65BD\u5173\u505C\u4E0A\u8FF0\u7F51\u7AD9\u4E0A\u7684\u89C6\u542C\u8282\u76EE\u670D\u52A1\uFF0C\u8FDB\u884C\u5168\u9762\u6574\u6539\u3002",
    "id" : 878052033445715969,
    "created_at" : "2017-06-23 00:48:12 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 878186320937578498,
  "created_at" : "2017-06-23 09:41:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877499727222321153",
  "text" : "\u6700\u8FD1\u7684\u5BAB\u6597\u603B\u6709\u8981\u5927\u7ED3\u5C40\u7684\u9519\u89C9\uD83D\uDE02",
  "id" : 877499727222321153,
  "created_at" : "2017-06-21 12:13:32 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "876971862001111041",
  "text" : "Firefox Nightly\u5B8C\u5168\u8FF7\u5931\u4E86\u81EA\u6211\u3002\u3002",
  "id" : 876971862001111041,
  "created_at" : "2017-06-20 01:15:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "876971704941195264",
  "text" : "RT @williamlong: \u3010\u4ECE\u671D\u9C9C\u83B7\u91CA\u7684\u7F8E\u56FD\u5927\u5B66\u751F\u6B7B\u4EA1 \u66FE\u5728\u671D\u5173\u62BC17\u4E2A\u6708\u30112016\u5E741\u6708\uFF0C\u4E00\u7F8E\u56FD\u5927\u5B66\u751F\u5728\u671D\u9C9C\u65C5\u884C\u4E2D\uFF0C\u56E0\u8BD5\u56FE\u7A83\u53D6\u4E00\u526F\u9152\u5E97\u5185\u7684\u5BA3\u4F20\u6D77\u62A5\u88AB\u6355\uFF0C\u88AB\u522415\u5E74\u52B3\u6559\uFF0C\u5728\u88AB\u5173\u62BC17\u4E2A\u6708\u540E\u83B7\u91CA\u3002\u8BE5\u540D\u5927\u5B66\u751F\u56DE\u7F8E\u56FD\u540E\u4E00\u76F4\u5904\u4E8E\u660F\u8FF7\u72B6\u6001\uFF0C\u7F8E\u56FD\u533B\u751F\u53D1\u73B0\u4ED6\u7684\u5927\u8111\u4E25\u91CD\u53D7\u635F\u3002 \u200B\uFF08\u5FAE\u8BC4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "876959652872957953",
    "text" : "\u3010\u4ECE\u671D\u9C9C\u83B7\u91CA\u7684\u7F8E\u56FD\u5927\u5B66\u751F\u6B7B\u4EA1 \u66FE\u5728\u671D\u5173\u62BC17\u4E2A\u6708\u30112016\u5E741\u6708\uFF0C\u4E00\u7F8E\u56FD\u5927\u5B66\u751F\u5728\u671D\u9C9C\u65C5\u884C\u4E2D\uFF0C\u56E0\u8BD5\u56FE\u7A83\u53D6\u4E00\u526F\u9152\u5E97\u5185\u7684\u5BA3\u4F20\u6D77\u62A5\u88AB\u6355\uFF0C\u88AB\u522415\u5E74\u52B3\u6559\uFF0C\u5728\u88AB\u5173\u62BC17\u4E2A\u6708\u540E\u83B7\u91CA\u3002\u8BE5\u540D\u5927\u5B66\u751F\u56DE\u7F8E\u56FD\u540E\u4E00\u76F4\u5904\u4E8E\u660F\u8FF7\u72B6\u6001\uFF0C\u7F8E\u56FD\u533B\u751F\u53D1\u73B0\u4ED6\u7684\u5927\u8111\u4E25\u91CD\u53D7\u635F\u3002 \u200B\uFF08\u5FAE\u8BC4\uFF1A\u671D\u9C9C\u771F\u662F\u5F53\u4E4B\u65E0\u6127\u7684\u6D41\u6C13\u56FD\u5BB6\u554A\uFF01\uFF09\u2026",
    "id" : 876959652872957953,
    "created_at" : "2017-06-20 00:27:29 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 876971704941195264,
  "created_at" : "2017-06-20 01:15:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/VEipnLyLZv",
      "expanded_url" : "http:\/\/www.bbc.com\/zhongwen\/simp\/world\/2016\/10\/161026_women_japan_virgins",
      "display_url" : "bbc.com\/zhongwen\/simp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "876764666592186368",
  "text" : "\u871C\u6C41\u65E5\u672C\uFF1Ahttps:\/\/t.co\/VEipnLyLZv",
  "id" : 876764666592186368,
  "created_at" : "2017-06-19 11:32:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/XXFFPLwrVf",
      "expanded_url" : "https:\/\/twitter.com\/solidotunoff\/status\/876425060961177600",
      "display_url" : "twitter.com\/solidotunoff\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "876434435750719488",
  "text" : "\u665A\u4E86\uFF0C\u597D\u597D\u60F3\u60F3\u600E\u4E48\u53BB\u4E2D\u5FC3\u5316\u5427~ https:\/\/t.co\/XXFFPLwrVf",
  "id" : 876434435750719488,
  "created_at" : "2017-06-18 13:40:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/dODv9gmVKo",
      "expanded_url" : "https:\/\/www.voachinese.com\/a\/taiwan-for-english-law-effort\/3905149.html",
      "display_url" : "voachinese.com\/a\/taiwan-for-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "876429275745923073",
  "text" : "\u4E2D\u534E\u6C11\u56FD\u4E0E\u652F\u90A3\u5212\u6E05\u754C\u9650\uFF1Ahttps:\/\/t.co\/dODv9gmVKo",
  "id" : 876429275745923073,
  "created_at" : "2017-06-18 13:19:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/DNiHJPQJ5E",
      "expanded_url" : "https:\/\/cn.nytimes.com\/asia-pacific\/20170607\/xi-jinping-china-jerry-brown-california-climate\/",
      "display_url" : "cn.nytimes.com\/asia-pacific\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "876427172780625920",
  "text" : "\u4E2D\u5171\u652F\u6301\u4E00\u7F8E\u4E00\u52A0\uFF1Ahttps:\/\/t.co\/DNiHJPQJ5E",
  "id" : 876427172780625920,
  "created_at" : "2017-06-18 13:11:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "876417394494910464",
  "text" : "\u4ECA\u5929\u7F51\u7EDC\u771F\u8BE1\u5F02\u3002\u3002",
  "id" : 876417394494910464,
  "created_at" : "2017-06-18 12:32:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 3, 12 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "876409304257089536",
  "text" : "RT @chengr28: \u4E4B\u524D\u4E00\u76F4\u6000\u7591 Chrome \u5728 Windows \u5E73\u53F0\u7528\u7684\u662F\u7CFB\u7EDF\u7684\u8BC1\u4E66\u9A8C\u8BC1\u7CFB\u7EDF\uFF0C\u5982\u679C\u7CFB\u7EDF\u81EA\u5E26\u7684\u8BC1\u4E66\u9A8C\u8BC1\u7CFB\u7EDF\u4FE1\u4EFB\u4E00\u4E2A\u8BC1\u4E66\u4F46 Chrome \u4E0D\u4FE1\u4EFB\uFF0C\u8FD9\u771F\u7684\u6709\u53EF\u80FD\u4F1A\u88AB\u62E6\u622A\u5417\u2026\u2026\u73B0\u5728\u770B\u6765\u867D\u7136\u662F\u4EE5\u7CFB\u7EDF\u7684\u505A\u57FA\u7840\uFF0C\u4F46\u4F3C\u4E4E Chrome \u81EA\u5DF1\u4E5F\u6709\u4E00\u5F20\u9ED1\u540D\u5355 https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chengr28\/status\/876002218742128644\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/FN6y8TZ5ee",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DCgvAv_VoAAlU-U.jpg",
        "id_str" : "876001817452191744",
        "id" : 876001817452191744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCgvAv_VoAAlU-U.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1328
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1328
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/FN6y8TZ5ee"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "876002218742128644",
    "text" : "\u4E4B\u524D\u4E00\u76F4\u6000\u7591 Chrome \u5728 Windows \u5E73\u53F0\u7528\u7684\u662F\u7CFB\u7EDF\u7684\u8BC1\u4E66\u9A8C\u8BC1\u7CFB\u7EDF\uFF0C\u5982\u679C\u7CFB\u7EDF\u81EA\u5E26\u7684\u8BC1\u4E66\u9A8C\u8BC1\u7CFB\u7EDF\u4FE1\u4EFB\u4E00\u4E2A\u8BC1\u4E66\u4F46 Chrome \u4E0D\u4FE1\u4EFB\uFF0C\u8FD9\u771F\u7684\u6709\u53EF\u80FD\u4F1A\u88AB\u62E6\u622A\u5417\u2026\u2026\u73B0\u5728\u770B\u6765\u867D\u7136\u662F\u4EE5\u7CFB\u7EDF\u7684\u505A\u57FA\u7840\uFF0C\u4F46\u4F3C\u4E4E Chrome \u81EA\u5DF1\u4E5F\u6709\u4E00\u5F20\u9ED1\u540D\u5355 https:\/\/t.co\/FN6y8TZ5ee",
    "id" : 876002218742128644,
    "created_at" : "2017-06-17 09:02:58 +0000",
    "user" : {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "protected" : false,
      "id_str" : "45630895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261578265248\/b9796e25ac61a417b0832b8f322f119f_normal.png",
      "id" : 45630895,
      "verified" : false
    }
  },
  "id" : 876409304257089536,
  "created_at" : "2017-06-18 12:00:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/876136907339464705\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/Z05dIBORUV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCip3YbU0AA7YGD.jpg",
      "id_str" : "876136896438521856",
      "id" : 876136896438521856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCip3YbU0AA7YGD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/Z05dIBORUV"
    } ],
    "hashtags" : [ {
      "text" : "China",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "876408638520340480",
  "text" : "RT @iyouport_news: \u65B0\u6982\u5FF5\uFF1A\u51BB\u623F\u4E00\u4E00\u4E2D\u56FD\u5F0F\u5E9F\u949E #China https:\/\/t.co\/Z05dIBORUV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/876136907339464705\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/Z05dIBORUV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DCip3YbU0AA7YGD.jpg",
        "id_str" : "876136896438521856",
        "id" : 876136896438521856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCip3YbU0AA7YGD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/Z05dIBORUV"
      } ],
      "hashtags" : [ {
        "text" : "China",
        "indices" : [ 14, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "876136907339464705",
    "text" : "\u65B0\u6982\u5FF5\uFF1A\u51BB\u623F\u4E00\u4E00\u4E2D\u56FD\u5F0F\u5E9F\u949E #China https:\/\/t.co\/Z05dIBORUV",
    "id" : 876136907339464705,
    "created_at" : "2017-06-17 17:58:11 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 876408638520340480,
  "created_at" : "2017-06-18 11:57:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/PoSLkce5sB",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/875925635515826177",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875962266503589888",
  "text" : "\u4E00\u76F4\u5728\u8650\u72D7\uFF0C\u5988\u5440\u6211\u4E0D\u770B\u4E86(T_T) https:\/\/t.co\/PoSLkce5sB",
  "id" : 875962266503589888,
  "created_at" : "2017-06-17 06:24:13 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/G8pKhUDXc7",
      "expanded_url" : "https:\/\/twitter.com\/Mariko3o\/status\/874952958709866497",
      "display_url" : "twitter.com\/Mariko3o\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875950607043112960",
  "text" : "wow~ \u2299o\u2299 https:\/\/t.co\/G8pKhUDXc7",
  "id" : 875950607043112960,
  "created_at" : "2017-06-17 05:37:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/875925635515826177\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/6kUjuv7u7K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCfptdOV0AAH3Hg.jpg",
      "id_str" : "875925619695013888",
      "id" : 875925619695013888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCfptdOV0AAH3Hg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/6kUjuv7u7K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875925635515826177",
  "text" : "https:\/\/t.co\/6kUjuv7u7K",
  "id" : 875925635515826177,
  "created_at" : "2017-06-17 03:58:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875736707450232832",
  "text" : "pptv\u8FD8\u6CA1u2b\u5FEB\u3002\u3002",
  "id" : 875736707450232832,
  "created_at" : "2017-06-16 15:27:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Ccx3k0l2Fc",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52765",
      "display_url" : "solidot.org\/story?sid=52765"
    } ]
  },
  "geo" : { },
  "id_str" : "875717216808972288",
  "text" : "Telegram\u4E0D\u5B89\u5168\uFF1Ahttps:\/\/t.co\/Ccx3k0l2Fc",
  "id" : 875717216808972288,
  "created_at" : "2017-06-16 14:10:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/PLZZ48w84O",
      "expanded_url" : "http:\/\/www.bbc.com\/zhongwen\/simp\/uk-40236649",
      "display_url" : "bbc.com\/zhongwen\/simp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875635447757586432",
  "text" : "Youthquake\uFF1Ahttps:\/\/t.co\/PLZZ48w84O",
  "id" : 875635447757586432,
  "created_at" : "2017-06-16 08:45:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/NJ9F18RCJD",
      "expanded_url" : "http:\/\/news.163.com\/photoview\/00AO0001\/2261094.html",
      "display_url" : "news.163.com\/photoview\/00AO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875613883452407810",
  "text" : "\u671D\u9C9C\u91CA\u653E\u7684\u7F8E\u56FD\u5927\u5B66\u751F\u5DF2\u6210\u690D\u7269\u4EBA\uFF1Ahttps:\/\/t.co\/NJ9F18RCJD",
  "id" : 875613883452407810,
  "created_at" : "2017-06-16 07:19:52 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875413688299249664",
  "text" : "\u4E92\u8054\u7F51\u518D\u6B21\u89C1\u8BC1\u4E00\u624B\u597D\u724C\u73A9\u70C2",
  "id" : 875413688299249664,
  "created_at" : "2017-06-15 18:04:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875412969705938944",
  "text" : "\u5176\u5B9E\u5927\u91CF\u4E2D\u56FD\u7528\u6237\u6D8C\u5165\u63A8\u7279\u65F6\uFF0C\u8A00\u8BBA\u81EA\u7531\u624D\u4F1A\u771F\u6B63\u5E7B\u706D~",
  "id" : 875412969705938944,
  "created_at" : "2017-06-15 18:01:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875397798975426560",
  "text" : "\u5C31\u9760pccw\u4E86\/(\u3112o\u3112)\/~~",
  "id" : 875397798975426560,
  "created_at" : "2017-06-15 17:01:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/UYZrRekzeh",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/06\/blog-post_979.html",
      "display_url" : "molihua.org\/2017\/06\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875228942696927232",
  "text" : "\u4E3A\u4EC0\u4E48\u56DB\u7EBF+\u7684\u5B69\u5B50\u5373\u4F7F\u8F8D\u5B66\u4E5F\u8981\u65E9\u65E9\u5728\u5927\u57CE\u5E02\u8C0B\u751F\uFF1Ahttps:\/\/t.co\/UYZrRekzeh",
  "id" : 875228942696927232,
  "created_at" : "2017-06-15 05:50:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/SsxXTpUPv6",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=4884490",
      "display_url" : "music.163.com\/#\/song?id=4884\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875210545523073024",
  "text" : "45\u5206\u306E\u604B\u4EBA\uFF1Ahttps:\/\/t.co\/SsxXTpUPv6",
  "id" : 875210545523073024,
  "created_at" : "2017-06-15 04:37:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874875404686897153",
  "geo" : { },
  "id_str" : "875202991099392002",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u5E0C\u671B\u91CD\u6784\u540E\u80FD\u653E\u5728\u5899\u5916\uFF0C\u4EE5\u4F5C\u8868\u7387",
  "id" : 875202991099392002,
  "in_reply_to_status_id" : 874875404686897153,
  "created_at" : "2017-06-15 04:07:08 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874875404686897153",
  "geo" : { },
  "id_str" : "875202346917167108",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \/tweets\u5462\uFF1F",
  "id" : 875202346917167108,
  "in_reply_to_status_id" : 874875404686897153,
  "created_at" : "2017-06-15 04:04:34 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/nUOjVJhs07",
      "expanded_url" : "https:\/\/github.com\/yingziwu\/v2ex_delete\/",
      "display_url" : "github.com\/yingziwu\/v2ex_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875199254993793026",
  "text" : "V2EX\u7684\u5815\u843D\uFF1Ahttps:\/\/t.co\/nUOjVJhs07",
  "id" : 875199254993793026,
  "created_at" : "2017-06-15 03:52:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875181810891849729",
  "text" : "RT @ruanyf: \u6211\u7684\u4E2A\u4EBA\u7F51\u7AD9\u4ECA\u5929\u88AB\u4E3B\u673A\u516C\u53F8\u505C\u673A\u4E86\u4E24\u4E2A\u5C0F\u65F6\uFF0C\u4ED6\u4EEC\u6000\u7591\u6709\u5B89\u5168\u6F0F\u6D1E\u3002\u6211\u6839\u672C\u65E0\u8BA1\u53EF\u65BD\uFF0C\u53EA\u80FD\u8DDF\u4ED6\u4EEC\u4EA4\u6D89\uFF0C\u6073\u6C42\u4ED6\u4EEC\u5F00\u653E\u8BBF\u95EE\u3002\n\n\u73B0\u5728\u7F51\u7AD9\u6062\u590D\u6B63\u5E38\u4E86\u3002\u75DB\u5B9A\u601D\u75DB\uFF0C\u51B3\u5B9A\u5F7B\u5E95\u91CD\u6784\uFF0C\u81F3\u5C11\u8981\u6709\u955C\u50CF\uFF0C\u4E3B\u7AD9\u51FA\u95EE\u9898\uFF0C\u53EF\u4EE5\u5207\u6362\u5230\u955C\u50CF\u8BBF\u95EE\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "874875404686897153",
    "text" : "\u6211\u7684\u4E2A\u4EBA\u7F51\u7AD9\u4ECA\u5929\u88AB\u4E3B\u673A\u516C\u53F8\u505C\u673A\u4E86\u4E24\u4E2A\u5C0F\u65F6\uFF0C\u4ED6\u4EEC\u6000\u7591\u6709\u5B89\u5168\u6F0F\u6D1E\u3002\u6211\u6839\u672C\u65E0\u8BA1\u53EF\u65BD\uFF0C\u53EA\u80FD\u8DDF\u4ED6\u4EEC\u4EA4\u6D89\uFF0C\u6073\u6C42\u4ED6\u4EEC\u5F00\u653E\u8BBF\u95EE\u3002\n\n\u73B0\u5728\u7F51\u7AD9\u6062\u590D\u6B63\u5E38\u4E86\u3002\u75DB\u5B9A\u601D\u75DB\uFF0C\u51B3\u5B9A\u5F7B\u5E95\u91CD\u6784\uFF0C\u81F3\u5C11\u8981\u6709\u955C\u50CF\uFF0C\u4E3B\u7AD9\u51FA\u95EE\u9898\uFF0C\u53EF\u4EE5\u5207\u6362\u5230\u955C\u50CF\u8BBF\u95EE\u3002",
    "id" : 874875404686897153,
    "created_at" : "2017-06-14 06:25:25 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 875181810891849729,
  "created_at" : "2017-06-15 02:42:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/kaK9iEUGdO",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/874979885537742848",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "875181032705806341",
  "text" : "\uD83D\uDC4F https:\/\/t.co\/kaK9iEUGdO",
  "id" : 875181032705806341,
  "created_at" : "2017-06-15 02:39:52 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "874943306500902913",
  "text" : "RT @williamlong: \u30102017\u5E746\u670815\u65E5\u524D\u672A\u5B8C\u6210\u5B9E\u540D\u7684\u57DF\u540D\u5C06\u6682\u505C\u89E3\u6790\u3011\u81EA\u4ECE6\u67081\u65E5\u300A\u7F51\u7EDC\u5B89\u5168\u6CD5\u300B\u5B9E\u65BD\u4EE5\u6765\uFF0C\u5404\u5927\u4E92\u8054\u7F51\u516C\u53F8\u5747\u5B9E\u884C\u4E86\u7528\u6237\u5B9E\u540D\u5236\u8BA4\u8BC1\u3002\u5C31\u8FDE\u56FD\u5185\u7684\u57DF\u540D\u6CE8\u518C\u5546\u4E5F\u4E0D\u4F8B\u5916\uFF0C\u57DF\u540D\u4E5F\u5C06\u5B9E\u540D\u5B9E\u540D\u5236\u653F\u7B56\uFF0C\u672A\u5B9E\u540D\u8BA4\u8BC1\u7684\u57DF\u540D\u4E8E6\u670815\u65E5\u5C06\u5F3A\u5236\u505C\u6B62\u89E3\u6790\u670D\u52A1\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "874825997698424833",
    "text" : "\u30102017\u5E746\u670815\u65E5\u524D\u672A\u5B8C\u6210\u5B9E\u540D\u7684\u57DF\u540D\u5C06\u6682\u505C\u89E3\u6790\u3011\u81EA\u4ECE6\u67081\u65E5\u300A\u7F51\u7EDC\u5B89\u5168\u6CD5\u300B\u5B9E\u65BD\u4EE5\u6765\uFF0C\u5404\u5927\u4E92\u8054\u7F51\u516C\u53F8\u5747\u5B9E\u884C\u4E86\u7528\u6237\u5B9E\u540D\u5236\u8BA4\u8BC1\u3002\u5C31\u8FDE\u56FD\u5185\u7684\u57DF\u540D\u6CE8\u518C\u5546\u4E5F\u4E0D\u4F8B\u5916\uFF0C\u57DF\u540D\u4E5F\u5C06\u5B9E\u540D\u5B9E\u540D\u5236\u653F\u7B56\uFF0C\u672A\u5B9E\u540D\u8BA4\u8BC1\u7684\u57DF\u540D\u4E8E6\u670815\u65E5\u5C06\u5F3A\u5236\u505C\u6B62\u89E3\u6790\u670D\u52A1\u3002",
    "id" : 874825997698424833,
    "created_at" : "2017-06-14 03:09:05 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 874943306500902913,
  "created_at" : "2017-06-14 10:55:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8521\u82F1\u6587 Tsai Ing-wen",
      "screen_name" : "iingwen",
      "indices" : [ 3, 11 ],
      "id_str" : "155814794",
      "id" : 155814794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "874942871526400000",
  "text" : "RT @iingwen: We must stand together &amp; ensure Taiwan's 23 million citizens continue to determine our own destiny. Full statement: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/798b4fEU4A",
        "expanded_url" : "http:\/\/bit.ly\/2rVYrZf",
        "display_url" : "bit.ly\/2rVYrZf"
      } ]
    },
    "geo" : { },
    "id_str" : "874586140887535618",
    "text" : "We must stand together &amp; ensure Taiwan's 23 million citizens continue to determine our own destiny. Full statement: https:\/\/t.co\/798b4fEU4A",
    "id" : 874586140887535618,
    "created_at" : "2017-06-13 11:15:59 +0000",
    "user" : {
      "name" : "\u8521\u82F1\u6587 Tsai Ing-wen",
      "screen_name" : "iingwen",
      "protected" : false,
      "id_str" : "155814794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820454076618047493\/ErIM-bsD_normal.jpg",
      "id" : 155814794,
      "verified" : true
    }
  },
  "id" : 874942871526400000,
  "created_at" : "2017-06-14 10:53:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9648\u5C11\u4E3E",
      "screen_name" : "chenshaoju",
      "indices" : [ 3, 14 ],
      "id_str" : "17482838",
      "id" : 17482838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/VGPwTnbhcx",
      "expanded_url" : "http:\/\/www.sohu.com\/a\/147672808_642965",
      "display_url" : "sohu.com\/a\/147672808_64\u2026"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/nkSMN4xxip",
      "expanded_url" : "https:\/\/twitter.com\/dajusha\/status\/874453723845599232",
      "display_url" : "twitter.com\/dajusha\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874824247662837760",
  "text" : "RT @chenshaoju: \u67E5\u4E86\u4E00\u4E0B\uFF1A\u201CETS\u7684\u8003\u8BD5\u7CFB\u7EDF\u65E0\u6CD5\u767B\u9646\u5230\u7F8E\u56FD\u7684\u670D\u52A1\u5668\uFF0C\u65E0\u6CD5\u62FF\u5230\u4ECA\u5929\u7684\u8003\u9898\uFF0C\u56E0\u6B64\u6D77\u91CF\u6258\u798F\u8003\u573A\u53D6\u6D88\u4E86\u4ECA\u5929\u7684\u6258\u798F\u8003\u8BD5\uFF0C\u4EA6\u6216\u8005\u662F\u63A8\u8FDF3\u4E2A\u5C0F\u65F6\u8003\u8BD5\u3002\u201D https:\/\/t.co\/VGPwTnbhcx https:\/\/t.co\/nkSMN4xxip",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/VGPwTnbhcx",
        "expanded_url" : "http:\/\/www.sohu.com\/a\/147672808_642965",
        "display_url" : "sohu.com\/a\/147672808_64\u2026"
      }, {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/nkSMN4xxip",
        "expanded_url" : "https:\/\/twitter.com\/dajusha\/status\/874453723845599232",
        "display_url" : "twitter.com\/dajusha\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "874460100332707840",
    "text" : "\u67E5\u4E86\u4E00\u4E0B\uFF1A\u201CETS\u7684\u8003\u8BD5\u7CFB\u7EDF\u65E0\u6CD5\u767B\u9646\u5230\u7F8E\u56FD\u7684\u670D\u52A1\u5668\uFF0C\u65E0\u6CD5\u62FF\u5230\u4ECA\u5929\u7684\u8003\u9898\uFF0C\u56E0\u6B64\u6D77\u91CF\u6258\u798F\u8003\u573A\u53D6\u6D88\u4E86\u4ECA\u5929\u7684\u6258\u798F\u8003\u8BD5\uFF0C\u4EA6\u6216\u8005\u662F\u63A8\u8FDF3\u4E2A\u5C0F\u65F6\u8003\u8BD5\u3002\u201D https:\/\/t.co\/VGPwTnbhcx https:\/\/t.co\/nkSMN4xxip",
    "id" : 874460100332707840,
    "created_at" : "2017-06-13 02:55:09 +0000",
    "user" : {
      "name" : "\u9648\u5C11\u4E3E",
      "screen_name" : "chenshaoju",
      "protected" : false,
      "id_str" : "17482838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431978219240038400\/s5n7jbKl_normal.png",
      "id" : 17482838,
      "verified" : false
    }
  },
  "id" : 874824247662837760,
  "created_at" : "2017-06-14 03:02:08 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 3, 12 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chengr28\/status\/874602677841178624\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/osKOL1VfrG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCM2cRoVoAAZQlU.jpg",
      "id_str" : "874602612036837376",
      "id" : 874602612036837376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCM2cRoVoAAZQlU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/osKOL1VfrG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "874824040946556929",
  "text" : "RT @chengr28: \u4F60\u65E0\u6CD5\u8DDF\u4E00\u4E2A\u65E0\u8D56\u8BB2\u9053\u7406 https:\/\/t.co\/osKOL1VfrG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chengr28\/status\/874602677841178624\/photo\/1",
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/osKOL1VfrG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DCM2cRoVoAAZQlU.jpg",
        "id_str" : "874602612036837376",
        "id" : 874602612036837376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCM2cRoVoAAZQlU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 403
        } ],
        "display_url" : "pic.twitter.com\/osKOL1VfrG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "874602677841178624",
    "text" : "\u4F60\u65E0\u6CD5\u8DDF\u4E00\u4E2A\u65E0\u8D56\u8BB2\u9053\u7406 https:\/\/t.co\/osKOL1VfrG",
    "id" : 874602677841178624,
    "created_at" : "2017-06-13 12:21:42 +0000",
    "user" : {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "protected" : false,
      "id_str" : "45630895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261578265248\/b9796e25ac61a417b0832b8f322f119f_normal.png",
      "id" : 45630895,
      "verified" : false
    }
  },
  "id" : 874824040946556929,
  "created_at" : "2017-06-14 03:01:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/saw1W1TNsu",
      "expanded_url" : "https:\/\/twitter.com\/breakwa11\/status\/874472065272750080",
      "display_url" : "twitter.com\/breakwa11\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "874576577560023040",
  "text" : "\u8DDF\u5BF9\u515A\uFF0C\u5929\u5929\u513F\u7AE5\u8282o(*\uFFE3\u25BD\uFFE3*)\u30D6 https:\/\/t.co\/saw1W1TNsu",
  "id" : 874576577560023040,
  "created_at" : "2017-06-13 10:37:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/873843265237381120\/photo\/1",
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/v7QuyoTQzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCCDztdU0AAXdML.jpg",
      "id_str" : "873843252109037568",
      "id" : 873843252109037568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCCDztdU0AAXdML.jpg",
      "sizes" : [ {
        "h" : 95,
        "resize" : "fit",
        "w" : 197
      }, {
        "h" : 95,
        "resize" : "fit",
        "w" : 197
      }, {
        "h" : 95,
        "resize" : "crop",
        "w" : 95
      }, {
        "h" : 95,
        "resize" : "fit",
        "w" : 197
      }, {
        "h" : 95,
        "resize" : "fit",
        "w" : 197
      } ],
      "display_url" : "pic.twitter.com\/v7QuyoTQzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873843265237381120",
  "text" : "\u53EF\uFF01\u7231\uFF01 https:\/\/t.co\/v7QuyoTQzR",
  "id" : 873843265237381120,
  "created_at" : "2017-06-11 10:04:04 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/XFRXB8QMmG",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52706",
      "display_url" : "solidot.org\/story?sid=52706"
    } ]
  },
  "geo" : { },
  "id_str" : "873534648042872832",
  "text" : "\u5F31\u4F20\u64AD\u75AB\u82D7\uFF1Ahttps:\/\/t.co\/XFRXB8QMmG",
  "id" : 873534648042872832,
  "created_at" : "2017-06-10 13:37:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/wvaivb6XlT",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=22709632#2645047301497100440634",
      "display_url" : "music.163.com\/#\/song?id=2270\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873529103646945280",
  "text" : "\u7F51\u6613\u4E5F\u73A9\u5047320kbps\uFF0C\u611F\u89C9\u4E0D\u4F1A\u518D\u7231\u4E86\uFF1Ahttps:\/\/t.co\/wvaivb6XlT",
  "id" : 873529103646945280,
  "created_at" : "2017-06-10 13:15:42 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/TKrmQGdyNd",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=406716121",
      "display_url" : "music.163.com\/#\/song?id=4067\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873527869623984129",
  "text" : "Miku\uFF1Ahttps:\/\/t.co\/TKrmQGdyNd",
  "id" : 873527869623984129,
  "created_at" : "2017-06-10 13:10:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/UiKaqlcAfU",
      "expanded_url" : "https:\/\/twitter.com\/jichi_zhang\/status\/873439217799512064",
      "display_url" : "twitter.com\/jichi_zhang\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873526061799284737",
  "text" : "\u5357\u4EAC\uFF0C\u540C https:\/\/t.co\/UiKaqlcAfU",
  "id" : 873526061799284737,
  "created_at" : "2017-06-10 13:03:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/OPLYzdahbm",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E4%B9%8C%E9%B2%81%E6%9C%A8%E9%BD%90%E4%B8%83%E4%BA%94%E4%BA%8B%E4%BB%B6",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E4%B9%8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873171241464733696",
  "text" : "\u4E4C\u9C81\u6728\u9F50\u4E03\u4E94\u4E8B\u4EF6\uFF1Ahttps:\/\/t.co\/OPLYzdahbm",
  "id" : 873171241464733696,
  "created_at" : "2017-06-09 13:33:41 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/0kxhSdlNxs",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=29308009",
      "display_url" : "music.163.com\/#\/song?id=2930\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "873100130097840128",
  "text" : "if\uFF1Ahttps:\/\/t.co\/0kxhSdlNxs",
  "id" : 873100130097840128,
  "created_at" : "2017-06-09 08:51:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873081903213010944",
  "text" : "\u53EB\u51FA\u6765\u597D\u723D\uD83D\uDE1D",
  "id" : 873081903213010944,
  "created_at" : "2017-06-09 07:38:41 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873067164718084098",
  "text" : "Chrome for Windows\u5BF9\u9AD8DPI\u7684\u652F\u6301\u7B80\u76F4\u3002",
  "id" : 873067164718084098,
  "created_at" : "2017-06-09 06:40:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873065632958267392",
  "text" : "Windows\u5E94\u7528\u5546\u5E97\u7684\u641C\u7D22\u5C45\u7136\u533A\u5206\u5927\u5C0F\u5199~",
  "id" : 873065632958267392,
  "created_at" : "2017-06-09 06:34:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873044612910243840",
  "text" : "\u7528\u60EF\u4E86\u8BB0\u4E8B\u672C\uFF0C\u611F\u89C9\u82B1\u82B1\u7EFF\u7EFF\u7684editor\u597D\u6076\u5FC3~",
  "id" : 873044612910243840,
  "created_at" : "2017-06-09 05:10:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873044439802892290",
  "text" : "RT @williamlong: \u7EE7\u201C\u5168\u6C11\u661F\u63A2\u201D\u201C\u4E2D\u56FD\u7B2C\u4E00\u72D7\u4ED4\u5353\u4F1F\u201D\u7B49\u8D26\u53F7\u88AB\u5173\u540E\uFF0C\u4ECA\u65E5\u53C8\u6709\u4E8C\u5341\u4E94\u4E2A\u5FAE\u4FE1\u53F7\u88AB\u5173\u95ED\uFF0C\u5206\u522B\u662F\uFF1A\u5173\u7231\u516B\u5366\u6210\u957F\u534F\u4F1A\u3001\u5A31\u4E50\u8BF4\u3001\u516B\u597D\u638C\u67DC\u3001\u8D85\u9AD8\u80FDE\u59D0\u3001\u5A31\u4E50\u516B\u5366\u8054\u5408\u4FC3\u8FDB\u4F1A\u3001\u7206\u6599\u4E00\u59D0\u3001\u5A31\u4E50\u5708\u5934\u6761\u3001\u5A31\u4E50\u5708\u6252\u76AE\u738B\u3001\u6252\u5708\u5A31\u8BB0\u3001\u5708\u5185\u6252\u7237\u3001\u6BD2\u820C\u7535\u5F71\u3001\u8BB8\u8001\u6E7F\u3001\u4E25\u8083\u516B\u5366\u3001\u82AD\u838E\u5A31\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "873037590856736769",
    "text" : "\u7EE7\u201C\u5168\u6C11\u661F\u63A2\u201D\u201C\u4E2D\u56FD\u7B2C\u4E00\u72D7\u4ED4\u5353\u4F1F\u201D\u7B49\u8D26\u53F7\u88AB\u5173\u540E\uFF0C\u4ECA\u65E5\u53C8\u6709\u4E8C\u5341\u4E94\u4E2A\u5FAE\u4FE1\u53F7\u88AB\u5173\u95ED\uFF0C\u5206\u522B\u662F\uFF1A\u5173\u7231\u516B\u5366\u6210\u957F\u534F\u4F1A\u3001\u5A31\u4E50\u8BF4\u3001\u516B\u597D\u638C\u67DC\u3001\u8D85\u9AD8\u80FDE\u59D0\u3001\u5A31\u4E50\u516B\u5366\u8054\u5408\u4FC3\u8FDB\u4F1A\u3001\u7206\u6599\u4E00\u59D0\u3001\u5A31\u4E50\u5708\u5934\u6761\u3001\u5A31\u4E50\u5708\u6252\u76AE\u738B\u3001\u6252\u5708\u5A31\u8BB0\u3001\u5708\u5185\u6252\u7237\u3001\u6BD2\u820C\u7535\u5F71\u3001\u8BB8\u8001\u6E7F\u3001\u4E25\u8083\u516B\u5366\u3001\u82AD\u838E\u5A31\u4E50\u3001\u5357\u90FD\u5A31\u4E50\u5468\u520A\u3001\u7537\u4EBA\u88C5\u7B49\u3002",
    "id" : 873037590856736769,
    "created_at" : "2017-06-09 04:42:36 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 873044439802892290,
  "created_at" : "2017-06-09 05:09:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/rmyLYpfMlA",
      "expanded_url" : "http:\/\/tech.163.com\/17\/0608\/10\/CMDCTP4600097U81.html",
      "display_url" : "tech.163.com\/17\/0608\/10\/CMD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872797843278499841",
  "text" : "\u706B\u661F\u72EC\u7ACB\uFF1Ahttps:\/\/t.co\/rmyLYpfMlA",
  "id" : 872797843278499841,
  "created_at" : "2017-06-08 12:49:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/eZurDdxlr9",
      "expanded_url" : "http:\/\/docs.huihoo.com\/homepage\/shredderyin\/",
      "display_url" : "docs.huihoo.com\/homepage\/shred\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872724916021407744",
  "text" : "10\u5E74\u6539\u53D8\u4E86\u738B\u57A0\uFF1Ahttps:\/\/t.co\/eZurDdxlr9",
  "id" : 872724916021407744,
  "created_at" : "2017-06-08 08:00:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/wX9c9tHriZ",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=52649",
      "display_url" : "solidot.org\/story?sid=52649"
    } ]
  },
  "geo" : { },
  "id_str" : "872692390577963008",
  "text" : "5nm\uFF1Ahttps:\/\/t.co\/wX9c9tHriZ",
  "id" : 872692390577963008,
  "created_at" : "2017-06-08 05:50:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5929\u4E09\u6708\u25C6\uFF11\u65E5\u76EE\u30B7-85b",
      "screen_name" : "amamitsuki12",
      "indices" : [ 3, 16 ],
      "id_str" : "958290270",
      "id" : 958290270
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/amamitsuki12\/status\/872282838795563008\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/QNN6NVSxpq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBr4jOCXoAEfboz.jpg",
      "id_str" : "872282761796755457",
      "id" : 872282761796755457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBr4jOCXoAEfboz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 777
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 777
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 777
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/QNN6NVSxpq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "872450740668727296",
  "text" : "RT @amamitsuki12: \u3051\u3044\u3042\u3044\u3048\u3059\u3048\u3059\u30AC\u30FC\u30EBs https:\/\/t.co\/QNN6NVSxpq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amamitsuki12\/status\/872282838795563008\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/QNN6NVSxpq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBr4jOCXoAEfboz.jpg",
        "id_str" : "872282761796755457",
        "id" : 872282761796755457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBr4jOCXoAEfboz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 777
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 777
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 777
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/QNN6NVSxpq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "872282838795563008",
    "text" : "\u3051\u3044\u3042\u3044\u3048\u3059\u3048\u3059\u30AC\u30FC\u30EBs https:\/\/t.co\/QNN6NVSxpq",
    "id" : 872282838795563008,
    "created_at" : "2017-06-07 02:43:29 +0000",
    "user" : {
      "name" : "\u5929\u4E09\u6708\u25C6\uFF11\u65E5\u76EE\u30B7-85b",
      "screen_name" : "amamitsuki12",
      "protected" : false,
      "id_str" : "958290270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923864786533728256\/oTZmBrz9_normal.png",
      "id" : 958290270,
      "verified" : false
    }
  },
  "id" : 872450740668727296,
  "created_at" : "2017-06-07 13:50:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oia",
      "screen_name" : "oiax",
      "indices" : [ 3, 8 ],
      "id_str" : "284847838",
      "id" : 284847838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/VpbRy2Gpmf",
      "expanded_url" : "https:\/\/neoatlantis.github.io\/%E7%94%B5%E5%B7%A5%E7%94%B5%E5%AD%90%E5%8F%8A%E4%BF%A1%E6%81%AF%E6%8A%80%E6%9C%AF\/2017\/01\/20\/printer-watermarking.html",
      "display_url" : "neoatlantis.github.io\/%E7%94%B5%E5%B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872442406876172289",
  "text" : "RT @oiax: \u88AB\u53D1\u73B0\u7684\u6253\u5370\u673A\u8DDF\u8E2A\u9EC4\u70B9\u3002\u7535\u5B50\u524D\u54E8\u57FA\u91D1\u4F1A\u6D4B\u8BD5\u3001\u5FD7\u613F\u8005\u6D4B\u8BD5\u548C\u6253\u5370\u673A\u5382\u5546\u58F0\u660E\u6709\u4E0A\u767E\u4E2A\u578B\u53F7\u7684\u5F69\u8272\u6253\u5370\u673A\u4F7F\u7528\u4E86\u8BBE\u5907\u8BBE\u522B\u6280\u672F\uFF0C\u6253\u5370\u673A\u9690\u85CF\u7684\u6C34\u5370\u6216\u9EC4\u70B9\u8DDF\u8E2A\u7801\u662F\u5E94\u653F\u5E9C\u8981\u6C42\u52A0\u5165\u7684\uFF0C\u5E76\u4E14\u6709\u591A\u5E74\u5386\u53F2\uFF0C\u5F69\u8272\u6253\u5370\u673A\u666E\u53CA\u4E4B\u524D\u662F\u9ED1\u767D\u6253\u5370\u673A\u3002https:\/\/t.co\/VpbRy2Gpmf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/VpbRy2Gpmf",
        "expanded_url" : "https:\/\/neoatlantis.github.io\/%E7%94%B5%E5%B7%A5%E7%94%B5%E5%AD%90%E5%8F%8A%E4%BF%A1%E6%81%AF%E6%8A%80%E6%9C%AF\/2017\/01\/20\/printer-watermarking.html",
        "display_url" : "neoatlantis.github.io\/%E7%94%B5%E5%B\u2026"
      }, {
        "indices" : [ 129, 152 ],
        "url" : "https:\/\/t.co\/Uw3sRjHtoB",
        "expanded_url" : "https:\/\/twitter.com\/quinnnorton\/status\/871883733032415236",
        "display_url" : "twitter.com\/quinnnorton\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "871919846073790466",
    "text" : "\u88AB\u53D1\u73B0\u7684\u6253\u5370\u673A\u8DDF\u8E2A\u9EC4\u70B9\u3002\u7535\u5B50\u524D\u54E8\u57FA\u91D1\u4F1A\u6D4B\u8BD5\u3001\u5FD7\u613F\u8005\u6D4B\u8BD5\u548C\u6253\u5370\u673A\u5382\u5546\u58F0\u660E\u6709\u4E0A\u767E\u4E2A\u578B\u53F7\u7684\u5F69\u8272\u6253\u5370\u673A\u4F7F\u7528\u4E86\u8BBE\u5907\u8BBE\u522B\u6280\u672F\uFF0C\u6253\u5370\u673A\u9690\u85CF\u7684\u6C34\u5370\u6216\u9EC4\u70B9\u8DDF\u8E2A\u7801\u662F\u5E94\u653F\u5E9C\u8981\u6C42\u52A0\u5165\u7684\uFF0C\u5E76\u4E14\u6709\u591A\u5E74\u5386\u53F2\uFF0C\u5F69\u8272\u6253\u5370\u673A\u666E\u53CA\u4E4B\u524D\u662F\u9ED1\u767D\u6253\u5370\u673A\u3002https:\/\/t.co\/VpbRy2Gpmf https:\/\/t.co\/Uw3sRjHtoB",
    "id" : 871919846073790466,
    "created_at" : "2017-06-06 02:41:05 +0000",
    "user" : {
      "name" : "oia",
      "screen_name" : "oiax",
      "protected" : false,
      "id_str" : "284847838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945953045581520896\/w6yKbzGJ_normal.jpg",
      "id" : 284847838,
      "verified" : false
    }
  },
  "id" : 872442406876172289,
  "created_at" : "2017-06-07 13:17:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "indices" : [ 3, 17 ],
      "id_str" : "731790773675417601",
      "id" : 731790773675417601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NSA",
      "indices" : [ 22, 26 ]
    }, {
      "text" : "RussiaAmerica",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "872029887007252482",
  "text" : "RT @iyouport_news: \u26A0\uFE0F\u3010#NSA \u673A\u5BC6\u62A5\u544A\u62AB\u9732\u4FC4\u7F57\u65AF\u5C1D\u8BD5\u5728\u5927\u9009\u524D\u5165\u4FB5\u7F8E\u56FD\u9009\u4E3E\u673A\u6784\u3011#RussiaAmerica \u6587\u4EF6\u663E\u793A \u4FC4\u7F57\u65AF\u53BB\u5E74 11 \u6708\u5728\u7F8E\u56FD\u5927\u9009\u524D\u5915\u5BF9\u81F3\u5C11\u4E00\u5BB6\u7F8E\u56FD\u6295\u7968\u8F6F\u4EF6\u4F9B\u5E94\u5546\u53D1\u52A8\u7F51\u7EDC\u653B\u51FB\u3001\u5E76\u5411\u8D85\u8FC7 100 \u5BB6\u5730\u65B9\u9009\u4E3E\u529E\u516C\u5BA4\u53D1\u9001\u9493\u9C7C\u90AE\u4EF6\uFF1Ahttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iyouport_news\/status\/871952649238663168\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/1Rwm2cK0rH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBnMTbHVwAAIqNH.jpg",
        "id_str" : "871952636941025280",
        "id" : 871952636941025280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBnMTbHVwAAIqNH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/1Rwm2cK0rH"
      } ],
      "hashtags" : [ {
        "text" : "NSA",
        "indices" : [ 3, 7 ]
      }, {
        "text" : "RussiaAmerica",
        "indices" : [ 32, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/1oKpZIkF5N",
        "expanded_url" : "https:\/\/www.facebook.com\/iyouport\/posts\/1553114881386317",
        "display_url" : "facebook.com\/iyouport\/posts\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "871952649238663168",
    "text" : "\u26A0\uFE0F\u3010#NSA \u673A\u5BC6\u62A5\u544A\u62AB\u9732\u4FC4\u7F57\u65AF\u5C1D\u8BD5\u5728\u5927\u9009\u524D\u5165\u4FB5\u7F8E\u56FD\u9009\u4E3E\u673A\u6784\u3011#RussiaAmerica \u6587\u4EF6\u663E\u793A \u4FC4\u7F57\u65AF\u53BB\u5E74 11 \u6708\u5728\u7F8E\u56FD\u5927\u9009\u524D\u5915\u5BF9\u81F3\u5C11\u4E00\u5BB6\u7F8E\u56FD\u6295\u7968\u8F6F\u4EF6\u4F9B\u5E94\u5546\u53D1\u52A8\u7F51\u7EDC\u653B\u51FB\u3001\u5E76\u5411\u8D85\u8FC7 100 \u5BB6\u5730\u65B9\u9009\u4E3E\u529E\u516C\u5BA4\u53D1\u9001\u9493\u9C7C\u90AE\u4EF6\uFF1Ahttps:\/\/t.co\/1oKpZIkF5N https:\/\/t.co\/1Rwm2cK0rH",
    "id" : 871952649238663168,
    "created_at" : "2017-06-06 04:51:26 +0000",
    "user" : {
      "name" : "iyouport",
      "screen_name" : "iyouport_news",
      "protected" : false,
      "id_str" : "731790773675417601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731792189932503040\/bsi38CwS_normal.jpg",
      "id" : 731790773675417601,
      "verified" : false
    }
  },
  "id" : 872029887007252482,
  "created_at" : "2017-06-06 09:58:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/Wa8YocrAD5",
      "expanded_url" : "https:\/\/tried-and-true.github.io\/",
      "display_url" : "tried-and-true.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "871967790613364738",
  "text" : "Tried And True\uFF1Ahttps:\/\/t.co\/Wa8YocrAD5",
  "id" : 871967790613364738,
  "created_at" : "2017-06-06 05:51:36 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ron Bowling",
      "screen_name" : "mrbcyber",
      "indices" : [ 3, 12 ],
      "id_str" : "3224540611",
      "id" : 3224540611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "871954894256615424",
  "text" : "RT @mrbcyber: Very little on Tiananmen Square in Reddit Worldnews this week &amp; not by accident I have been blocked from posting there  Censo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mrbcyber\/status\/871457128912793601\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/5U6uob073b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBgItjJUIAA5IFn.png",
        "id_str" : "871456106517635072",
        "id" : 871456106517635072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBgItjJUIAA5IFn.png",
        "sizes" : [ {
          "h" : 592,
          "resize" : "fit",
          "w" : 1061
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 1061
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 1061
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/5U6uob073b"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "871457128912793601",
    "text" : "Very little on Tiananmen Square in Reddit Worldnews this week &amp; not by accident I have been blocked from posting there  Censorship https:\/\/t.co\/5U6uob073b",
    "id" : 871457128912793601,
    "created_at" : "2017-06-04 20:02:25 +0000",
    "user" : {
      "name" : "Michael Ron Bowling",
      "screen_name" : "mrbcyber",
      "protected" : false,
      "id_str" : "3224540611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608717441208700931\/OG3Aat-D_normal.jpg",
      "id" : 3224540611,
      "verified" : false
    }
  },
  "id" : 871954894256615424,
  "created_at" : "2017-06-06 05:00:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Buckley \u50A8\u767E\u4EAE",
      "screen_name" : "ChuBailiang",
      "indices" : [ 3, 15 ],
      "id_str" : "19383099",
      "id" : 19383099
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChuBailiang\/status\/871201496620072965\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/a2IxyxQpdh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBchCnxVoAAlE9C.jpg",
      "id_str" : "871201381838856192",
      "id" : 871201381838856192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBchCnxVoAAlE9C.jpg",
      "sizes" : [ {
        "h" : 992,
        "resize" : "fit",
        "w" : 992
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 992,
        "resize" : "fit",
        "w" : 992
      }, {
        "h" : 992,
        "resize" : "fit",
        "w" : 992
      } ],
      "display_url" : "pic.twitter.com\/a2IxyxQpdh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "871952107733168128",
  "text" : "RT @ChuBailiang: https:\/\/t.co\/a2IxyxQpdh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChuBailiang\/status\/871201496620072965\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/a2IxyxQpdh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBchCnxVoAAlE9C.jpg",
        "id_str" : "871201381838856192",
        "id" : 871201381838856192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBchCnxVoAAlE9C.jpg",
        "sizes" : [ {
          "h" : 992,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 992,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 992,
          "resize" : "fit",
          "w" : 992
        } ],
        "display_url" : "pic.twitter.com\/a2IxyxQpdh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "871201496620072965",
    "text" : "https:\/\/t.co\/a2IxyxQpdh",
    "id" : 871201496620072965,
    "created_at" : "2017-06-04 03:06:37 +0000",
    "user" : {
      "name" : "Chris Buckley \u50A8\u767E\u4EAE",
      "screen_name" : "ChuBailiang",
      "protected" : false,
      "id_str" : "19383099",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3067768957\/8d3137ea8d8b5ee21641d56a2f504391_normal.jpeg",
      "id" : 19383099,
      "verified" : true
    }
  },
  "id" : 871952107733168128,
  "created_at" : "2017-06-06 04:49:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "871944630471995392",
  "text" : "\u66F4\u5C11\u7684\u539F\u5219\uFF0C\u66F4\u597D\u7684\u4EE3\u7801",
  "id" : 871944630471995392,
  "created_at" : "2017-06-06 04:19:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/epeiysrnOO",
      "expanded_url" : "https:\/\/linuxtoy.org\/archives\/reading-boot-guard-and-coreboot.html",
      "display_url" : "linuxtoy.org\/archives\/readi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "871944577187491841",
  "text" : "Boot Guard\u4E0ECoreboot\uFF1Ahttps:\/\/t.co\/epeiysrnOO",
  "id" : 871944577187491841,
  "created_at" : "2017-06-06 04:19:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8521\u82F1\u6587 Tsai Ing-wen",
      "screen_name" : "iingwen",
      "indices" : [ 3, 11 ],
      "id_str" : "155814794",
      "id" : 155814794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tiananmen",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "871306797767962624",
  "text" : "RT @iingwen: Today is 6\/4. 28 years ago in #Tiananmen, students &amp; citizens challenged political realities in China. Their actions inspired\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Tiananmen",
        "indices" : [ 30, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "871183529559810048",
    "text" : "Today is 6\/4. 28 years ago in #Tiananmen, students &amp; citizens challenged political realities in China. Their actions inspired a generation",
    "id" : 871183529559810048,
    "created_at" : "2017-06-04 01:55:13 +0000",
    "user" : {
      "name" : "\u8521\u82F1\u6587 Tsai Ing-wen",
      "screen_name" : "iingwen",
      "protected" : false,
      "id_str" : "155814794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820454076618047493\/ErIM-bsD_normal.jpg",
      "id" : 155814794,
      "verified" : true
    }
  },
  "id" : 871306797767962624,
  "created_at" : "2017-06-04 10:05:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870899458283900928",
  "text" : "RT @williamlong: \u65B0\u95FB\u51FA\u7248\u5E7F\u7535\u603B\u5C40\u65E5\u524D\u4E0B\u53D1\u901A\u77E5\uFF0C\u672A\u901A\u8FC7\u5BA1\u67E5\u7684\u7535\u89C6\u5267\u3001\u7535\u5F71\uFF0C\u4E0D\u5F97\u4F5C\u4E3A\u7F51\u7EDC\u5267\u3001\u7F51\u7EDC\u7535\u5F71\u4E0A\u7F51\u64AD\u51FA\u3002\u5BFC\u5411\u4E0D\u6B63\u786E\u7684\u7535\u89C6\u7EFC\u827A\u8282\u76EE\uFF0C\u4E5F\u4E0D\u5F97\u64AD\u51FA\u3002\u4E0D\u5141\u8BB8\u5728\u5E7F\u64AD\u7535\u89C6\u64AD\u51FA\u7684\u8282\u76EE\uFF0C\u540C\u6837\u4E0D\u5141\u8BB8\u5728\u4E92\u8054\u7F51\u4E0A\u64AD\u51FA\u3002\u4E0D\u5F97\u4EE5\u4EFB\u4F55\u5F62\u5F0F\u4F20\u64AD\u6240\u8C13\u201C\u5B8C\u6574\u7248\u201D\u201C\u672A\u5220\u51CF\u7248\u201D\u201C\u672A\u5220\u8282\u7248\u201D\u53CA\u201C\u88AB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "870881552267440128",
    "text" : "\u65B0\u95FB\u51FA\u7248\u5E7F\u7535\u603B\u5C40\u65E5\u524D\u4E0B\u53D1\u901A\u77E5\uFF0C\u672A\u901A\u8FC7\u5BA1\u67E5\u7684\u7535\u89C6\u5267\u3001\u7535\u5F71\uFF0C\u4E0D\u5F97\u4F5C\u4E3A\u7F51\u7EDC\u5267\u3001\u7F51\u7EDC\u7535\u5F71\u4E0A\u7F51\u64AD\u51FA\u3002\u5BFC\u5411\u4E0D\u6B63\u786E\u7684\u7535\u89C6\u7EFC\u827A\u8282\u76EE\uFF0C\u4E5F\u4E0D\u5F97\u64AD\u51FA\u3002\u4E0D\u5141\u8BB8\u5728\u5E7F\u64AD\u7535\u89C6\u64AD\u51FA\u7684\u8282\u76EE\uFF0C\u540C\u6837\u4E0D\u5141\u8BB8\u5728\u4E92\u8054\u7F51\u4E0A\u64AD\u51FA\u3002\u4E0D\u5F97\u4EE5\u4EFB\u4F55\u5F62\u5F0F\u4F20\u64AD\u6240\u8C13\u201C\u5B8C\u6574\u7248\u201D\u201C\u672A\u5220\u51CF\u7248\u201D\u201C\u672A\u5220\u8282\u7248\u201D\u53CA\u201C\u88AB\u5220\u7247\u6BB5\u201D\u7B49\u8282\u76EE\uFF08\u542B\u955C\u5934\u7247\u6BB5\uFF09\u3002",
    "id" : 870881552267440128,
    "created_at" : "2017-06-03 05:55:16 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 870899458283900928,
  "created_at" : "2017-06-03 07:06:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870823164565233665",
  "text" : "\u7CBE\u6C14\u597D\u9999",
  "id" : 870823164565233665,
  "created_at" : "2017-06-03 02:03:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 0, 9 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870645670943653889",
  "geo" : { },
  "id_str" : "870822965168021504",
  "in_reply_to_user_id" : 45630895,
  "text" : "@chengr28 \u542C\u8BF4\u8FC7\u83AB\u8FEA\u5E9F\u949E\u5417\uFF1F",
  "id" : 870822965168021504,
  "in_reply_to_status_id" : 870645670943653889,
  "created_at" : "2017-06-03 02:02:28 +0000",
  "in_reply_to_screen_name" : "chengr28",
  "in_reply_to_user_id_str" : "45630895",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870619687264145408",
  "text" : "RT @FoxFoxsafariosx: \u6740\u4E86\u6211\u5427\uFF01\u8FDE\u547C\u5438\u65B0\u9C9C\u7A7A\u6C14\u81EA\u7531\u90FD\u6CA1\u6709\uFF0C\u8FD8\u4E0D\u5982\u6B7B\u4E86\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "870606392549285888",
    "text" : "\u6740\u4E86\u6211\u5427\uFF01\u8FDE\u547C\u5438\u65B0\u9C9C\u7A7A\u6C14\u81EA\u7531\u90FD\u6CA1\u6709\uFF0C\u8FD8\u4E0D\u5982\u6B7B\u4E86\uFF01",
    "id" : 870606392549285888,
    "created_at" : "2017-06-02 11:41:53 +0000",
    "user" : {
      "name" : "fox&wolf",
      "screen_name" : "FoxXIIWolf",
      "protected" : false,
      "id_str" : "4735140074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821964516418195456\/fENZQmhk_normal.jpg",
      "id" : 4735140074,
      "verified" : false
    }
  },
  "id" : 870619687264145408,
  "created_at" : "2017-06-02 12:34:43 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/cf5P7KWiJH",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/06\/blog-post_71.html",
      "display_url" : "molihua.org\/2017\/06\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870607071233945601",
  "text" : "\u8F6C\u53D1\u90ED\u6587\u8D35\u63A8\u6587\u53EF\u83B7\u5211\uFF1Ahttps:\/\/t.co\/cf5P7KWiJH",
  "id" : 870607071233945601,
  "created_at" : "2017-06-02 11:44:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870597445956317184",
  "text" : "\u300AV\u602A\u5BA2\u300B\u6216\u6210\u9884\u8A00\u3002",
  "id" : 870597445956317184,
  "created_at" : "2017-06-02 11:06:20 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/n7N3fszlpl",
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/870439660123598848",
      "display_url" : "twitter.com\/ruanyf\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870593376479043584",
  "text" : "\u62B5\u5236Chrome\uFF0CFirefox\u4E07\u5C81\uFF01 https:\/\/t.co\/n7N3fszlpl",
  "id" : 870593376479043584,
  "created_at" : "2017-06-02 10:50:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/QrSjSXBz5x",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=22677570",
      "display_url" : "music.163.com\/#\/song?id=2267\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870593134094372868",
  "text" : "\u4E16\u754C\u7B2C\u4E00\u7684\u516C\u4E3B\u6BBF\u4E0B\uFF1Ahttps:\/\/t.co\/QrSjSXBz5x",
  "id" : 870593134094372868,
  "created_at" : "2017-06-02 10:49:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/2lcSfeBGNM",
      "expanded_url" : "http:\/\/aem1k.com\/",
      "display_url" : "aem1k.com"
    } ]
  },
  "geo" : { },
  "id_str" : "870593010597232644",
  "text" : "JS Hacks\uFF1Ahttps:\/\/t.co\/2lcSfeBGNM",
  "id" : 870593010597232644,
  "created_at" : "2017-06-02 10:48:43 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/cg6l2qhwUa",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/870586669929553920",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870590118586970112",
  "text" : "\u7269\u7269\u4EA4\u6362\u5927\u6CD5\u597D\uFF01 https:\/\/t.co\/cg6l2qhwUa",
  "id" : 870590118586970112,
  "created_at" : "2017-06-02 10:37:13 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/870438839390576640\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/KpF2swFEqa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBRrfSeUQAAonqY.jpg",
      "id_str" : "870438813268459520",
      "id" : 870438813268459520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBRrfSeUQAAonqY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 795
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 795
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 795
      } ],
      "display_url" : "pic.twitter.com\/KpF2swFEqa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/5GKQzYOWoA",
      "expanded_url" : "http:\/\/2ality.com\/2017\/05\/util-promisify.html",
      "display_url" : "2ality.com\/2017\/05\/util-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870533163910656000",
  "text" : "RT @ruanyf: Node \u5B98\u65B9\u4E5F\u51B3\u5B9A\u8981\u544A\u522B\u56DE\u8C03\u51FD\u6570\u4E86\u3002\n\nNode 8 \u63D0\u4F9B\u4E86util.promisify() \u65B9\u6CD5\uFF0C\u7528\u6765\u5C06\u6240\u6709\u63A5\u53D7\u56DE\u8C03\u51FD\u6570\u7684\u63A5\u53E3\uFF0C\u6539\u6210\u8FD4\u56DE Promise\u3002 \nhttps:\/\/t.co\/5GKQzYOWoA https:\/\/t.co\/KpF2swFEqa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/870438839390576640\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/KpF2swFEqa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBRrfSeUQAAonqY.jpg",
        "id_str" : "870438813268459520",
        "id" : 870438813268459520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBRrfSeUQAAonqY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 795
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 795
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 795
        } ],
        "display_url" : "pic.twitter.com\/KpF2swFEqa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/5GKQzYOWoA",
        "expanded_url" : "http:\/\/2ality.com\/2017\/05\/util-promisify.html",
        "display_url" : "2ality.com\/2017\/05\/util-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "870438839390576640",
    "text" : "Node \u5B98\u65B9\u4E5F\u51B3\u5B9A\u8981\u544A\u522B\u56DE\u8C03\u51FD\u6570\u4E86\u3002\n\nNode 8 \u63D0\u4F9B\u4E86util.promisify() \u65B9\u6CD5\uFF0C\u7528\u6765\u5C06\u6240\u6709\u63A5\u53D7\u56DE\u8C03\u51FD\u6570\u7684\u63A5\u53E3\uFF0C\u6539\u6210\u8FD4\u56DE Promise\u3002 \nhttps:\/\/t.co\/5GKQzYOWoA https:\/\/t.co\/KpF2swFEqa",
    "id" : 870438839390576640,
    "created_at" : "2017-06-02 00:36:05 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 870533163910656000,
  "created_at" : "2017-06-02 06:50:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/qfk1zGjIRg",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rStL7niR7gs",
      "display_url" : "youtube.com\/watch?v=rStL7n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870257082121019392",
  "text" : "The Rules For Rulers\uFF1Ahttps:\/\/t.co\/qfk1zGjIRg",
  "id" : 870257082121019392,
  "created_at" : "2017-06-01 12:33:51 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/MVXG2wRtpl",
      "expanded_url" : "http:\/\/www.bbc.com\/zhongwen\/simp\/world-40108667",
      "display_url" : "bbc.com\/zhongwen\/simp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870250110491471872",
  "text" : "Simplified English\uFF1Ahttps:\/\/t.co\/MVXG2wRtpl",
  "id" : 870250110491471872,
  "created_at" : "2017-06-01 12:06:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870244500458942464",
  "text" : "\u6B63\u5E38\u7684\u6B4C\u66F2\u5DF2\u7136\u4E0D\u80FD\u63D0\u795E\u4E86\uFF0C\u5929\u554A\u6211\u90FD\u5728\u542C\u4E9B\u4EC0\u4E48\u3002\u3002",
  "id" : 870244500458942464,
  "created_at" : "2017-06-01 11:43:51 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/Wp3PjIE3Qn",
      "expanded_url" : "https:\/\/program-think.blogspot.com\/2017\/05\/my-blog-under-government-backed-attack.html",
      "display_url" : "program-think.blogspot.com\/2017\/05\/my-blo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870214758527578112",
  "text" : "\u7F16\u7A0B\u968F\u60F3\u88AB\u91CD\u70B9\u5173\u7167\uFF1Ahttps:\/\/t.co\/Wp3PjIE3Qn",
  "id" : 870214758527578112,
  "created_at" : "2017-06-01 09:45:40 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/870209687316307968\/photo\/1",
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/p3hQcUewmg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBObF4mXcAIiHDd.jpg",
      "id_str" : "870209678407593986",
      "id" : 870209678407593986,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBObF4mXcAIiHDd.jpg",
      "sizes" : [ {
        "h" : 355,
        "resize" : "fit",
        "w" : 760
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 760
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 760
      } ],
      "display_url" : "pic.twitter.com\/p3hQcUewmg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870209687316307968",
  "text" : "\u4E2D\u65E5\u4E00\u5BB6\u4EB2\uFF1A https:\/\/t.co\/p3hQcUewmg",
  "id" : 870209687316307968,
  "created_at" : "2017-06-01 09:25:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/DehBsqcndk",
      "expanded_url" : "https:\/\/raw.githubusercontent.com\/dou4cc\/resource\/master\/fucking-ali.png",
      "display_url" : "raw.githubusercontent.com\/dou4cc\/resourc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870208202889191424",
  "text" : "\u5929\u7F51\u6062\u6062\uFF1Ahttps:\/\/t.co\/DehBsqcndk",
  "id" : 870208202889191424,
  "created_at" : "2017-06-01 09:19:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/8KBOco93lX",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/06\/blog-post_77.html",
      "display_url" : "molihua.org\/2017\/06\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870207696779313152",
  "text" : "\u4E2D\u7F8E\u4E00\u5BB6\u4EB2\uFF1Ahttps:\/\/t.co\/8KBOco93lX",
  "id" : 870207696779313152,
  "created_at" : "2017-06-01 09:17:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "indices" : [ 3, 18 ],
      "id_str" : "254148157",
      "id" : 254148157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870202666198204416",
  "text" : "RT @GreatFireChina: RFA journo: \n- police monitor WeChat in Tibet\n- jail if you talk to journos\n- asks source for comment, using WeChat \nht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GreatFireChina\/status\/870202262941036544\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/hQ8zIl4XvM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBOUWH-W0AABvw-.jpg",
        "id_str" : "870202260831260672",
        "id" : 870202260831260672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBOUWH-W0AABvw-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hQ8zIl4XvM"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/2puKQ8LTMg",
        "expanded_url" : "http:\/\/www.rfa.org\/english\/news\/tibet\/media-05302017150250.html",
        "display_url" : "rfa.org\/english\/news\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "870202262941036544",
    "text" : "RFA journo: \n- police monitor WeChat in Tibet\n- jail if you talk to journos\n- asks source for comment, using WeChat \nhttps:\/\/t.co\/2puKQ8LTMg https:\/\/t.co\/hQ8zIl4XvM",
    "id" : 870202262941036544,
    "created_at" : "2017-06-01 08:56:01 +0000",
    "user" : {
      "name" : "GreatFire.org",
      "screen_name" : "GreatFireChina",
      "protected" : false,
      "id_str" : "254148157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794103496836517888\/BE7Ek2ae_normal.jpg",
      "id" : 254148157,
      "verified" : true
    }
  },
  "id" : 870202666198204416,
  "created_at" : "2017-06-01 08:57:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870057800554164224",
  "text" : "\u4ECA\u5929\u8FC7\u8282\u8036\uFF08\u301C^\u3268^)\u301C",
  "id" : 870057800554164224,
  "created_at" : "2017-05-31 23:21:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]