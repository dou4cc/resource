Grailbird.data.tweets_2017_12 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/CrrbppMnrj",
      "expanded_url" : "https:\/\/wxw.moe\/about",
      "display_url" : "wxw.moe\/about"
    } ]
  },
  "in_reply_to_status_id_str" : "946282917252214784",
  "geo" : { },
  "id_str" : "946290688253153280",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u53E6\u4E00\u4E2A\u63A8\u8350\u7684\u5B9E\u4F8B\uFF1Ahttps:\/\/t.co\/CrrbppMnrj",
  "id" : 946290688253153280,
  "in_reply_to_status_id" : 946282917252214784,
  "created_at" : "2017-12-28 08:04:15 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/946282917252214784\/photo\/1",
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/LlNfXb2sJi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSHfRH1W4AAdbWV.jpg",
      "id_str" : "946282881978130432",
      "id" : 946282881978130432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSHfRH1W4AAdbWV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/LlNfXb2sJi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "946281238863712256",
  "geo" : { },
  "id_str" : "946282917252214784",
  "in_reply_to_user_id" : 3359880735,
  "text" : "WOW! https:\/\/t.co\/LlNfXb2sJi",
  "id" : 946282917252214784,
  "in_reply_to_status_id" : 946281238863712256,
  "created_at" : "2017-12-28 07:33:23 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/z8829TiUbe",
      "expanded_url" : "https:\/\/orz.uno\/@w27",
      "display_url" : "orz.uno\/@w27"
    } ]
  },
  "in_reply_to_status_id_str" : "946267366387798016",
  "geo" : { },
  "id_str" : "946281238863712256",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u897F\u4E8C\u65D7\uFF1Ahttps:\/\/t.co\/z8829TiUbe",
  "id" : 946281238863712256,
  "in_reply_to_status_id" : 946267366387798016,
  "created_at" : "2017-12-28 07:26:43 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/Ar5WCBNDuW",
      "expanded_url" : "https:\/\/wxw.moe\/@AnimeGirlsBot",
      "display_url" : "wxw.moe\/@AnimeGirlsBot"
    } ]
  },
  "in_reply_to_status_id_str" : "946264572826144768",
  "geo" : { },
  "id_str" : "946267366387798016",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u54EA\u88CF\u90FD\u4E0D\u7F3A\u7D19\u7247\u5C0F\u59D0\u59D0\uFF1Ahttps:\/\/t.co\/Ar5WCBNDuW",
  "id" : 946267366387798016,
  "in_reply_to_status_id" : 946264572826144768,
  "created_at" : "2017-12-28 06:31:35 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/gq4RamH3UL",
      "expanded_url" : "https:\/\/cmx.im\/about",
      "display_url" : "cmx.im\/about"
    } ]
  },
  "in_reply_to_status_id_str" : "946263264979283968",
  "geo" : { },
  "id_str" : "946264572826144768",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u63A8\u85A6\u4E00\u500B\u8A2D\u5728\u5883\u5916\u7684\u9577\u6BDB\u8C61\u4E2D\u6587\u7AD9\uFF1Ahttps:\/\/t.co\/gq4RamH3UL",
  "id" : 946264572826144768,
  "in_reply_to_status_id" : 946263264979283968,
  "created_at" : "2017-12-28 06:20:29 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/kSPfmQVVUc",
      "expanded_url" : "https:\/\/niu.moe\/@lilydjwg",
      "display_url" : "niu.moe\/@lilydjwg"
    }, {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/gpaYapTmdf",
      "expanded_url" : "https:\/\/mastodon.xyz\/@FiveYellowMice",
      "display_url" : "mastodon.xyz\/@FiveYellowMice"
    } ]
  },
  "in_reply_to_status_id_str" : "946256751636119552",
  "geo" : { },
  "id_str" : "946263264979283968",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u8F49\u4E86\u4E00\u5708\u53EA\u8A8D\u8B58\u4F9D\u4E91\uFF08https:\/\/t.co\/kSPfmQVVUc\uFF09\u548C\u4E94\u9EC4\u9F20\uFF08https:\/\/t.co\/gpaYapTmdf\uFF09\u3002",
  "id" : 946263264979283968,
  "in_reply_to_status_id" : 946256751636119552,
  "created_at" : "2017-12-28 06:15:17 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/YKwrTfJTnt",
      "expanded_url" : "https:\/\/mao.daizhige.org\/about",
      "display_url" : "mao.daizhige.org\/about"
    } ]
  },
  "in_reply_to_status_id_str" : "946254725091127296",
  "geo" : { },
  "id_str" : "946256751636119552",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u7232\u4EC0\u9EBC\u6703\u6709\u50BB\u903C\u7528\u5883\u5167\u5BE6\u4F8B\uFF1Fhttps:\/\/t.co\/YKwrTfJTnt",
  "id" : 946256751636119552,
  "in_reply_to_status_id" : 946254725091127296,
  "created_at" : "2017-12-28 05:49:24 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "946241292773797888",
  "geo" : { },
  "id_str" : "946254725091127296",
  "in_reply_to_user_id" : 3359880735,
  "text" : "Mastodon\u4EBA\u4E0D\u5C11\u554A\uFF0C\u672C\u4F86\u9084\u60F3\u628A\u4E2D\u570B\u4EBA\u95DC\u6CE8\u5168\u5462\u3002",
  "id" : 946254725091127296,
  "in_reply_to_status_id" : 946241292773797888,
  "created_at" : "2017-12-28 05:41:21 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Guan",
      "screen_name" : "guan_tom",
      "indices" : [ 0, 9 ],
      "id_str" : "821683432023437312",
      "id" : 821683432023437312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/V3c26GPXjz",
      "expanded_url" : "https:\/\/program-think.blogspot.com\/2014\/01\/doublethink.html",
      "display_url" : "program-think.blogspot.com\/2014\/01\/double\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "946229787307020288",
  "geo" : { },
  "id_str" : "946245293342937088",
  "in_reply_to_user_id" : 821683432023437312,
  "text" : "@guan_tom \u6ED1\u5761\u8B2C\u8AA4\u3002\nhttps:\/\/t.co\/V3c26GPXjz",
  "id" : 946245293342937088,
  "in_reply_to_status_id" : 946229787307020288,
  "created_at" : "2017-12-28 05:03:52 +0000",
  "in_reply_to_screen_name" : "guan_tom",
  "in_reply_to_user_id_str" : "821683432023437312",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/A0xDpJIMvF",
      "expanded_url" : "https:\/\/pawoo.net\/@dou4cc",
      "display_url" : "pawoo.net\/@dou4cc"
    } ]
  },
  "geo" : { },
  "id_str" : "946241292773797888",
  "text" : "\u6211\u6C7A\u5B9A\u68C4\u63A8\uFF0C\u6539\u7528\uFF1Ahttps:\/\/t.co\/A0xDpJIMvF\u3002",
  "id" : 946241292773797888,
  "created_at" : "2017-12-28 04:47:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "946238177534271488",
  "text" : "\u73FE\u5728\u8A3B\u518A\u63A8\u7279\u5F37\u5236\u7D81\u5B9A\u624B\u6A5F\u4E86\u55CE\uFF1F",
  "id" : 946238177534271488,
  "created_at" : "2017-12-28 04:35:36 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/946236706969280512\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/QMWhtWrwdf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSG1PZRWkAUa6me.jpg",
      "id_str" : "946236672810848261",
      "id" : 946236672810848261,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSG1PZRWkAUa6me.jpg",
      "sizes" : [ {
        "h" : 364,
        "resize" : "fit",
        "w" : 891
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 891
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 891
      } ],
      "display_url" : "pic.twitter.com\/QMWhtWrwdf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "946236706969280512",
  "text" : "https:\/\/t.co\/QMWhtWrwdf",
  "id" : 946236706969280512,
  "created_at" : "2017-12-28 04:29:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DIYgod",
      "screen_name" : "DIYgod",
      "indices" : [ 0, 7 ],
      "id_str" : "1553713718",
      "id" : 1553713718
    }, {
      "name" : "\u9648\u777F",
      "screen_name" : "ruich97",
      "indices" : [ 8, 16 ],
      "id_str" : "4336255332",
      "id" : 4336255332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945635676464099328",
  "geo" : { },
  "id_str" : "945998713960456192",
  "in_reply_to_user_id" : 1553713718,
  "text" : "@DIYgod @ruich97",
  "id" : 945998713960456192,
  "in_reply_to_status_id" : 945635676464099328,
  "created_at" : "2017-12-27 12:44:03 +0000",
  "in_reply_to_screen_name" : "DIYgod",
  "in_reply_to_user_id_str" : "1553713718",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 0, 9 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/XRjIrJyGRr",
      "expanded_url" : "https:\/\/twitter.com\/lifetimeusa\/status\/945756320531189761",
      "display_url" : "twitter.com\/lifetimeusa\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "945988379111391232",
  "geo" : { },
  "id_str" : "945997914870034432",
  "in_reply_to_user_id" : 45630895,
  "text" : "@chengr28 https:\/\/t.co\/XRjIrJyGRr",
  "id" : 945997914870034432,
  "in_reply_to_status_id" : 945988379111391232,
  "created_at" : "2017-12-27 12:40:53 +0000",
  "in_reply_to_screen_name" : "chengr28",
  "in_reply_to_user_id_str" : "45630895",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/vhTUMvHHyt",
      "expanded_url" : "https:\/\/archive.is\/4b0c8",
      "display_url" : "archive.is\/4b0c8"
    } ]
  },
  "geo" : { },
  "id_str" : "945993057178136577",
  "text" : "\u812B\u5317\u8005\u51FA\u73FE\u8F3B\u5C04\u66B4\u9732\u75C7\u72C0\uFF1Ahttps:\/\/t.co\/vhTUMvHHyt",
  "id" : 945993057178136577,
  "created_at" : "2017-12-27 12:21:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 0, 12 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    }, {
      "name" : "Psiphon China",
      "screen_name" : "PsiphonChina",
      "indices" : [ 13, 26 ],
      "id_str" : "47011113",
      "id" : 47011113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945907914346086400",
  "geo" : { },
  "id_str" : "945991388214235141",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@DevinStever @PsiphonChina psiphon3\u958B\u6E90\u5728bitbucket\u3002",
  "id" : 945991388214235141,
  "in_reply_to_status_id" : 945907914346086400,
  "created_at" : "2017-12-27 12:14:57 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u95EB\u6069\u94ED",
      "screen_name" : "TechyanWP",
      "indices" : [ 3, 13 ],
      "id_str" : "2986143630",
      "id" : 2986143630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TechyanWP\/status\/945923721918689288\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/SVvyN0N6GQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSCYVLMV4AADzo7.jpg",
      "id_str" : "945923411297034240",
      "id" : 945923411297034240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSCYVLMV4AADzo7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 1011
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 1011
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 1011
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/SVvyN0N6GQ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TechyanWP\/status\/945923721918689288\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/SVvyN0N6GQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSCYeHsUQAAj8-L.jpg",
      "id_str" : "945923564976226304",
      "id" : 945923564976226304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSCYeHsUQAAj8-L.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 1326
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 1326
      } ],
      "display_url" : "pic.twitter.com\/SVvyN0N6GQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "945991230361653248",
  "text" : "RT @TechyanWP: \u5367\u69FD\uFF0C\u8FD9TM\u8981\u6539\u5BAA\u6CD5\u4E86\u3002\u3002\n\n\u4F30\u8BA1 \u4E60\u8FD1\u5E73\u65B0\u65F6\u4EE3\u4E2D\u56FD\u7279\u8272\u793E\u4F1A\u4E3B\u4E49\u601D\u60F3 \u8981\u5199\u8FDB\u5BAA\u6CD5\u5E8F\u8A00\u4E86\u3002\u3002\u3002\uFF08 https:\/\/t.co\/SVvyN0N6GQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TechyanWP\/status\/945923721918689288\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/SVvyN0N6GQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DSCYVLMV4AADzo7.jpg",
        "id_str" : "945923411297034240",
        "id" : 945923411297034240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSCYVLMV4AADzo7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 1011
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 1011
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 1011
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/SVvyN0N6GQ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TechyanWP\/status\/945923721918689288\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/SVvyN0N6GQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DSCYeHsUQAAj8-L.jpg",
        "id_str" : "945923564976226304",
        "id" : 945923564976226304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSCYeHsUQAAj8-L.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 1326
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 1326
        } ],
        "display_url" : "pic.twitter.com\/SVvyN0N6GQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "945923721918689288",
    "text" : "\u5367\u69FD\uFF0C\u8FD9TM\u8981\u6539\u5BAA\u6CD5\u4E86\u3002\u3002\n\n\u4F30\u8BA1 \u4E60\u8FD1\u5E73\u65B0\u65F6\u4EE3\u4E2D\u56FD\u7279\u8272\u793E\u4F1A\u4E3B\u4E49\u601D\u60F3 \u8981\u5199\u8FDB\u5BAA\u6CD5\u5E8F\u8A00\u4E86\u3002\u3002\u3002\uFF08 https:\/\/t.co\/SVvyN0N6GQ",
    "id" : 945923721918689288,
    "created_at" : "2017-12-27 07:46:04 +0000",
    "user" : {
      "name" : "\u95EB\u6069\u94ED",
      "screen_name" : "TechyanWP",
      "protected" : false,
      "id_str" : "2986143630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911474193014808576\/dl_REU_0_normal.jpg",
      "id" : 2986143630,
      "verified" : false
    }
  },
  "id" : 945991230361653248,
  "created_at" : "2017-12-27 12:14:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 3, 12 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/qeFB6z51kB",
      "expanded_url" : "http:\/\/www.kwongwah.com.my\/?p=446825",
      "display_url" : "kwongwah.com.my\/?p=446825"
    } ]
  },
  "geo" : { },
  "id_str" : "945990713837346817",
  "text" : "RT @chengr28: \u53D8\u8282\u671D\u9C9C\u58EB\u5175 \u4F53\u5185\u53D1\u73B0\u70AD\u75BD\u6297\u4F53 https:\/\/t.co\/qeFB6z51kB\n\n\u5317\u68D2\u8FDF\u65E9\u4F1A\u62C9\u4E0A\u65C1\u8FB9\u7684\u4E24\u4F4D\u4E00\u8D77\u73A9\u6B7B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/qeFB6z51kB",
        "expanded_url" : "http:\/\/www.kwongwah.com.my\/?p=446825",
        "display_url" : "kwongwah.com.my\/?p=446825"
      } ]
    },
    "geo" : { },
    "id_str" : "945988379111391232",
    "text" : "\u53D8\u8282\u671D\u9C9C\u58EB\u5175 \u4F53\u5185\u53D1\u73B0\u70AD\u75BD\u6297\u4F53 https:\/\/t.co\/qeFB6z51kB\n\n\u5317\u68D2\u8FDF\u65E9\u4F1A\u62C9\u4E0A\u65C1\u8FB9\u7684\u4E24\u4F4D\u4E00\u8D77\u73A9\u6B7B",
    "id" : 945988379111391232,
    "created_at" : "2017-12-27 12:02:59 +0000",
    "user" : {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "protected" : false,
      "id_str" : "45630895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261578265248\/b9796e25ac61a417b0832b8f322f119f_normal.png",
      "id" : 45630895,
      "verified" : false
    }
  },
  "id" : 945990713837346817,
  "created_at" : "2017-12-27 12:12:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Huang",
      "screen_name" : "hjc4869",
      "indices" : [ 0, 8 ],
      "id_str" : "996744811",
      "id" : 996744811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945931818460520448",
  "geo" : { },
  "id_str" : "945946165593477120",
  "in_reply_to_user_id" : 996744811,
  "text" : "@hjc4869 \u9019\u5145\u96FB\u66F2\u7DDA\u770B\u8D77\u4F86\u4E0D\u592A\u771F\u5BE6~",
  "id" : 945946165593477120,
  "in_reply_to_status_id" : 945931818460520448,
  "created_at" : "2017-12-27 09:15:15 +0000",
  "in_reply_to_screen_name" : "hjc4869",
  "in_reply_to_user_id_str" : "996744811",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "945917444706766853",
  "text" : "\u7528\u5565\u5565\u51FAbug\u3002",
  "id" : 945917444706766853,
  "created_at" : "2017-12-27 07:21:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/YRDRABpHJr",
      "expanded_url" : "https:\/\/archive.is\/aM8aD",
      "display_url" : "archive.is\/aM8aD"
    } ]
  },
  "geo" : { },
  "id_str" : "945883417161490433",
  "text" : "\u5927\u91CF\u9A30\u8A0A\u96F2\u985E\u4F3C\u57DF\u540D\u6307\u5411\u963F\u91CC\u96F2\u4FC3\u92B7\u9801\u9762\uFF1Ahttps:\/\/t.co\/YRDRABpHJr",
  "id" : 945883417161490433,
  "created_at" : "2017-12-27 05:05:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/GWyrcm4iwD",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=26201879",
      "display_url" : "music.163.com\/#\/song?id=2620\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "945852713677533185",
  "text" : "\u3057\u3042\u308F\u305B\u65E5\u548C\uFF1Ahttps:\/\/t.co\/GWyrcm4iwD",
  "id" : 945852713677533185,
  "created_at" : "2017-12-27 03:03:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wordless Echo",
      "screen_name" : "Wordless_Echo",
      "indices" : [ 0, 14 ],
      "id_str" : "2675446437",
      "id" : 2675446437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945814188718358528",
  "geo" : { },
  "id_str" : "945817954066862080",
  "in_reply_to_user_id" : 2675446437,
  "text" : "@Wordless_Echo \uD83D\uDE43",
  "id" : 945817954066862080,
  "in_reply_to_status_id" : 945814188718358528,
  "created_at" : "2017-12-27 00:45:47 +0000",
  "in_reply_to_screen_name" : "Wordless_Echo",
  "in_reply_to_user_id_str" : "2675446437",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/wig9NO77JM",
      "expanded_url" : "https:\/\/archive.is\/HiuE6",
      "display_url" : "archive.is\/HiuE6"
    } ]
  },
  "geo" : { },
  "id_str" : "945604786098987008",
  "text" : "\u4EE5\u8272\u5217\u7981\u6B62\u6BD4\u7279\u5E63\u4EA4\u6613\u516C\u53F8\u4E0A\u5E02\uFF1Ahttps:\/\/t.co\/wig9NO77JM",
  "id" : 945604786098987008,
  "created_at" : "2017-12-26 10:38:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "945604380170113024",
  "text" : "1\u6BD4\u7279\u5E63 \u2248 14000\u7F8E\u5143",
  "id" : 945604380170113024,
  "created_at" : "2017-12-26 10:37:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/24t6FaKbua",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/926717624301613063",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "945529008707592193",
  "geo" : { },
  "id_str" : "945531491756531712",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u9A30\u8A0A\u7684\u52E2\u529B\u53EF\u898B\u4E00\u6591\uFF1Ahttps:\/\/t.co\/24t6FaKbua",
  "id" : 945531491756531712,
  "in_reply_to_status_id" : 945529008707592193,
  "created_at" : "2017-12-26 05:47:29 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/FFpmESDD25",
      "expanded_url" : "https:\/\/archive.is\/P1Mut#selection-2033.4-2033.26",
      "display_url" : "archive.is\/P1Mut#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "945529008707592193",
  "text" : "\u9A6C\u5316\u817E\u5C31\u5F48\u7A97\u81F4\u6B49\u7528\u6236\u5F8C\u706B\u7D68\u5B98\u7DB2\u7576\u6A5F\uFF1Ahttps:\/\/t.co\/FFpmESDD25",
  "id" : 945529008707592193,
  "created_at" : "2017-12-26 05:37:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u62B9\u8336\u706C\u5E03\u4E01",
      "screen_name" : "ikaros_qwq",
      "indices" : [ 0, 11 ],
      "id_str" : "828413584082235397",
      "id" : 828413584082235397
    }, {
      "name" : "\u54B8\u83DC",
      "screen_name" : "Hellokittyomi",
      "indices" : [ 12, 26 ],
      "id_str" : "846630775646707712",
      "id" : 846630775646707712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945343814805237760",
  "geo" : { },
  "id_str" : "945484363436822529",
  "in_reply_to_user_id" : 828413584082235397,
  "text" : "@ikaros_qwq @Hellokittyomi \u9E79\u83DC\u662F\u5973\u5B69\u5B50\u3002",
  "id" : 945484363436822529,
  "in_reply_to_status_id" : 945343814805237760,
  "created_at" : "2017-12-26 02:40:13 +0000",
  "in_reply_to_screen_name" : "ikaros_qwq",
  "in_reply_to_user_id_str" : "828413584082235397",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ibNost5eAM",
      "expanded_url" : "https:\/\/archive.is\/9Rold",
      "display_url" : "archive.is\/9Rold"
    } ]
  },
  "geo" : { },
  "id_str" : "945481312718282753",
  "text" : "PureOS\u88ABFSF\u5217\u7232GNU\/Linux\uFF1Ahttps:\/\/t.co\/ibNost5eAM",
  "id" : 945481312718282753,
  "created_at" : "2017-12-26 02:28:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u96E8\u5A77",
      "screen_name" : "cherylnatsu",
      "indices" : [ 0, 12 ],
      "id_str" : "188330055",
      "id" : 188330055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945230254129397760",
  "geo" : { },
  "id_str" : "945230706539671553",
  "in_reply_to_user_id" : 188330055,
  "text" : "@cherylnatsu \u5BB3\u6015.webp",
  "id" : 945230706539671553,
  "in_reply_to_status_id" : 945230254129397760,
  "created_at" : "2017-12-25 09:52:16 +0000",
  "in_reply_to_screen_name" : "cherylnatsu",
  "in_reply_to_user_id_str" : "188330055",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u96E8\u5A77",
      "screen_name" : "cherylnatsu",
      "indices" : [ 0, 12 ],
      "id_str" : "188330055",
      "id" : 188330055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/Lec0oIpNaD",
      "expanded_url" : "https:\/\/github.com\/cherylnatsu",
      "display_url" : "github.com\/cherylnatsu"
    } ]
  },
  "in_reply_to_status_id_str" : "945229587499294720",
  "geo" : { },
  "id_str" : "945230018732548096",
  "in_reply_to_user_id" : 188330055,
  "text" : "@cherylnatsu \u958B\u6E90\u55CE\uFF1F\u4F60\u7684GitHub\u8CEC\u865F\uFF08https:\/\/t.co\/Lec0oIpNaD\uFF09\u88CF\u5565\u4E5F\u6C92\u6709\u554A~",
  "id" : 945230018732548096,
  "in_reply_to_status_id" : 945229587499294720,
  "created_at" : "2017-12-25 09:49:32 +0000",
  "in_reply_to_screen_name" : "cherylnatsu",
  "in_reply_to_user_id_str" : "188330055",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u96E8\u5A77",
      "screen_name" : "cherylnatsu",
      "indices" : [ 0, 12 ],
      "id_str" : "188330055",
      "id" : 188330055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945228368525455360",
  "geo" : { },
  "id_str" : "945228987755835394",
  "in_reply_to_user_id" : 188330055,
  "text" : "@cherylnatsu \u5176\u5BE6\u6574\u500BJS Modules\u90FD\u597D\u5947\u602A\uFF0C\u9084\u641E\u51FA\u201C\u5F15\u7528\u201D\u7684\u6982\u5FF5\u3002",
  "id" : 945228987755835394,
  "in_reply_to_status_id" : 945228368525455360,
  "created_at" : "2017-12-25 09:45:26 +0000",
  "in_reply_to_screen_name" : "cherylnatsu",
  "in_reply_to_user_id_str" : "188330055",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u96E8\u5A77",
      "screen_name" : "cherylnatsu",
      "indices" : [ 0, 12 ],
      "id_str" : "188330055",
      "id" : 188330055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945227441261309952",
  "geo" : { },
  "id_str" : "945228111943266304",
  "in_reply_to_user_id" : 188330055,
  "text" : "@cherylnatsu \u9019\u500Bbug\u4F60\u6BD4\u5674\u7684feature\u56B4\u91CD\u591A\u4E86\u3002",
  "id" : 945228111943266304,
  "in_reply_to_status_id" : 945227441261309952,
  "created_at" : "2017-12-25 09:41:58 +0000",
  "in_reply_to_screen_name" : "cherylnatsu",
  "in_reply_to_user_id_str" : "188330055",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u96E8\u5A77",
      "screen_name" : "cherylnatsu",
      "indices" : [ 5, 17 ],
      "id_str" : "188330055",
      "id" : 188330055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945223862010236929",
  "geo" : { },
  "id_str" : "945226081497427969",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u60F3\u8D77\u500B\u4EBA\uFF1A@cherylnatsu",
  "id" : 945226081497427969,
  "in_reply_to_status_id" : 945223862010236929,
  "created_at" : "2017-12-25 09:33:53 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "945223862010236929",
  "text" : "JS Module\u53EF\u4EE5\u7570\u6B65import\uFF0C\u537B\u4E0D\u80FD\u7570\u6B65export\u3002",
  "id" : 945223862010236929,
  "created_at" : "2017-12-25 09:25:04 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/945128841990823938\/photo\/1",
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/ltOe5mACsp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DR3Fp9YVAAIFcrY.jpg",
      "id_str" : "945128821459582978",
      "id" : 945128821459582978,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DR3Fp9YVAAIFcrY.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ltOe5mACsp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "945128841990823938",
  "text" : "V8\u662F\u9019\u6A23\u4F7F\u7528git branch\u7684\uFF1A https:\/\/t.co\/ltOe5mACsp",
  "id" : 945128841990823938,
  "created_at" : "2017-12-25 03:07:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/945102388037406720\/photo\/1",
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/EtmY4WxXMW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DR2tmqnWAAAAlfS.jpg",
      "id_str" : "945102376603615232",
      "id" : 945102376603615232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DR2tmqnWAAAAlfS.jpg",
      "sizes" : [ {
        "h" : 221,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EtmY4WxXMW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944442318425395200",
  "geo" : { },
  "id_str" : "945102388037406720",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\uD83D\uDE43 https:\/\/t.co\/EtmY4WxXMW",
  "id" : 945102388037406720,
  "in_reply_to_status_id" : 944442318425395200,
  "created_at" : "2017-12-25 01:22:23 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 0, 9 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "945029398024949760",
  "geo" : { },
  "id_str" : "945099879801425920",
  "in_reply_to_user_id" : 45630895,
  "text" : "@chengr28 dalao",
  "id" : 945099879801425920,
  "in_reply_to_status_id" : 945029398024949760,
  "created_at" : "2017-12-25 01:12:25 +0000",
  "in_reply_to_screen_name" : "chengr28",
  "in_reply_to_user_id_str" : "45630895",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F9D\u4E91",
      "screen_name" : "lilydjwg",
      "indices" : [ 0, 9 ],
      "id_str" : "72293483",
      "id" : 72293483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944894631468195842",
  "geo" : { },
  "id_str" : "944903866738466816",
  "in_reply_to_user_id" : 72293483,
  "text" : "@lilydjwg \u5DF2unfo\u3002",
  "id" : 944903866738466816,
  "in_reply_to_status_id" : 944894631468195842,
  "created_at" : "2017-12-24 12:13:31 +0000",
  "in_reply_to_screen_name" : "lilydjwg",
  "in_reply_to_user_id_str" : "72293483",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/944903613087969280\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/X2EFWJ6KQg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRz4yZ3VAAAr76D.jpg",
      "id_str" : "944903566661058560",
      "id" : 944903566661058560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRz4yZ3VAAAr76D.jpg",
      "sizes" : [ {
        "h" : 970,
        "resize" : "fit",
        "w" : 1282
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 908,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 970,
        "resize" : "fit",
        "w" : 1282
      } ],
      "display_url" : "pic.twitter.com\/X2EFWJ6KQg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944903613087969280",
  "text" : "\u767C\u63A8\u5EE3\u7684\u6642\u5019\u80FD\u4E0D\u80FD\u8A8D\u771F\u9EDE\uFF1F https:\/\/t.co\/X2EFWJ6KQg",
  "id" : 944903613087969280,
  "created_at" : "2017-12-24 12:12:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/rlohX0a5DK",
      "expanded_url" : "https:\/\/twitter.com\/sakiiiiilly\/status\/944118788252766208",
      "display_url" : "twitter.com\/sakiiiiilly\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "944794815304216576",
  "text" : "\u90FD\u662Fdalao\u3002\u3002 https:\/\/t.co\/rlohX0a5DK",
  "id" : 944794815304216576,
  "created_at" : "2017-12-24 05:00:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/ke8vQMCHEQ",
      "expanded_url" : "http:\/\/news.ltn.com.tw\/news\/politics\/breakingnews\/2291395",
      "display_url" : "news.ltn.com.tw\/news\/politics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "944767694687088641",
  "text" : "\u81FA\u7063\u91CD\u56DE\u806F\u5408\u570B\uFF1Ahttps:\/\/t.co\/ke8vQMCHEQ",
  "id" : 944767694687088641,
  "created_at" : "2017-12-24 03:12:26 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944763802834423809",
  "text" : "archive.is\u5C01\u6389\u4E86Psiphon3\u7684\u65E5\u672C\u7BC0\u9EDE\u3002",
  "id" : 944763802834423809,
  "created_at" : "2017-12-24 02:56:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/d0GQkjoBvF",
      "expanded_url" : "https:\/\/archive.is\/tlUsf",
      "display_url" : "archive.is\/tlUsf"
    } ]
  },
  "geo" : { },
  "id_str" : "944763507324616704",
  "text" : "\u7DB2\u6613\u96F2\u97F3\u6A02\u8F38\u6389\u7248\u6B0A\u540E\u5927\u91CF\u6B4C\u66F2\u76F4\u63A5\u6D88\u5931\uFF0C\u6C92\u6709\u4EFB\u4F55\u63D0\u793A\uFF0C\u5269\u4E0B\u7684\u6B4C\u66F2\u4ECD\u7136\u7070\u4E86\u4E00\u7247\u3002\u6628\u5929\u5176\u7528\u6236\u88AB\u81EA\u52D5\u95DC\u6CE8\u201C\u7F51\u6613\u65B0\u95FB\u201D\uFF0C\u4E0D\u4F46\u5931\u53BB\u5E95\u7DAB\uFF0C\u9084\u66B4\u9732\u51FA\u5176\u771F\u5BE6\u7528\u6236\u91CF\u8879\u6709\u4E94\u5343\u842C\uFF1Ahttps:\/\/t.co\/d0GQkjoBvF",
  "id" : 944763507324616704,
  "created_at" : "2017-12-24 02:55:47 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944754274478837760",
  "text" : "\u7232\u4EC0\u9EBD\u79FB\u52D5\u7684\u5EF6\u9072\u6BD4\u96FB\u4FE1\u9AD8\u597D\u591A\uFF1F\u96FB\u4FE1\u4E0B\u63A8\u6587\u79D2\u958B\uFF0C\u79FB\u52D5\u767D\u5929\u90FD\u5F97\u7B492\u79D2\uFF0C\u665A\u4E0A\u751A\u81F3\u8D85\u904E5\u79D2\uFF0C\u5883\u5185\u7DB2\u7AD9\u4E5F\u597D\u4E0D\u5230\u54EA\u53BB\u3002",
  "id" : 944754274478837760,
  "created_at" : "2017-12-24 02:19:06 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/P0uTEyIrEg",
      "expanded_url" : "https:\/\/archive.is\/zyG74",
      "display_url" : "archive.is\/zyG74"
    } ]
  },
  "geo" : { },
  "id_str" : "944753488113864704",
  "text" : "\u7F8E\u570B\u9AD8\u4E2D\u751F\u6B32\u6253\u7834\u534A\u5C0E\u9AD4\u884C\u696D\u58DF\u65B7\uFF1Ahttps:\/\/t.co\/P0uTEyIrEg\n\uFF08\u771FTMD\u52F5\u5FD7",
  "id" : 944753488113864704,
  "created_at" : "2017-12-24 02:15:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/944574564566224897\/photo\/1",
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/XTanx5cmsg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRvNiwEUIAA3VXE.jpg",
      "id_str" : "944574543766495232",
      "id" : 944574543766495232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRvNiwEUIAA3VXE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 742,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 742,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 742,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/XTanx5cmsg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944574564566224897",
  "text" : "WTF\uFF1F https:\/\/t.co\/XTanx5cmsg",
  "id" : 944574564566224897,
  "created_at" : "2017-12-23 14:25:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cloudwindy",
      "screen_name" : "HelloKittyGolds",
      "indices" : [ 0, 16 ],
      "id_str" : "935043573417787393",
      "id" : 935043573417787393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944568741903212544",
  "geo" : { },
  "id_str" : "944571183256793094",
  "in_reply_to_user_id" : 935043573417787393,
  "text" : "@HelloKittyGolds \u4F60\u591A\u5927\uFF1F",
  "id" : 944571183256793094,
  "in_reply_to_status_id" : 944568741903212544,
  "created_at" : "2017-12-23 14:11:34 +0000",
  "in_reply_to_screen_name" : "HelloKittyGolds",
  "in_reply_to_user_id_str" : "935043573417787393",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Guan",
      "screen_name" : "guan_tom",
      "indices" : [ 0, 9 ],
      "id_str" : "821683432023437312",
      "id" : 821683432023437312
    }, {
      "name" : "\u4F50\u5009\u306B\u306A",
      "screen_name" : "Sakura_nina2333",
      "indices" : [ 10, 26 ],
      "id_str" : "916138073154404352",
      "id" : 916138073154404352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944561156286447617",
  "geo" : { },
  "id_str" : "944563121783496704",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@guan_tom @Sakura_nina2333",
  "id" : 944563121783496704,
  "in_reply_to_status_id" : 944561156286447617,
  "created_at" : "2017-12-23 13:39:32 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944559934146072576",
  "geo" : { },
  "id_str" : "944561156286447617",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u5927\u9678\u5927\u5EE0\u7684\u8EDF\u4EF6\u7121\u4F8B\u5916\u5730\u7D22\u8981\u7BA1\u7406\u54E1\u6B0A\u9650\u548C\u66F4\u6539\u9A45\u52D5\uFF0C\u751A\u81F3\u5378\u8F09\u5B83\u5011\u90FD\u4E0D\u80FD\u963B\u6B62\u5176\u4F5C\u60E1\u3002",
  "id" : 944561156286447617,
  "in_reply_to_status_id" : 944559934146072576,
  "created_at" : "2017-12-23 13:31:43 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Tu2PSABi6f",
      "expanded_url" : "https:\/\/archive.is\/4KsKp",
      "display_url" : "archive.is\/4KsKp"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/KP2hicxIRQ",
      "expanded_url" : "https:\/\/archive.is\/JhMnP",
      "display_url" : "archive.is\/JhMnP"
    } ]
  },
  "geo" : { },
  "id_str" : "944559934146072576",
  "text" : "\u9806\u8457\u63A8\u7279\u7684\u95DC\u6CE8\u93C8\u7FFB\u5230\u4E0D\u5C11\u8EAB\u5728\u5927\u9678\u7684\u81FA\u7063\u4EBA\u5728bio\u88CF\u7559\u4E86QQ\u865F\u3002\u6211\u51FA\u65BC\u653F\u6CBB\u548C\u5B89\u5168\u7684\u539F\u56E0\u5EFA\u8B70\u4F60\u5011\u653E\u68C4QQ\uFF0C\u56E0\u7232\u5B83\u4E0D\u50C5\u63A7\u5236\u8F3F\u8AD6\uFF0C\u66F4\u662F\u6728\u99AC\uFF08https:\/\/t.co\/Tu2PSABi6f\uFF09\u548C\u5211\u5075\u5DE5\u5177\uFF08https:\/\/t.co\/KP2hicxIRQ\uFF09\uFF1B\u5373\u4F7F\u4F60\u80FD\u901A\u904E\u6280\u8853\u624B\u6BB5\u898F\u907F\u9019\u4E9B\u58DE\u8655\uFF0C\u4F60\u4E5F\u5728\u652F\u6301QQ\uFF0C\u8B93\u66F4\u591A\u4EBA\u53D7\u5BB3\u3002",
  "id" : 944559934146072576,
  "created_at" : "2017-12-23 13:26:52 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cloudwindy",
      "screen_name" : "HelloKittyGolds",
      "indices" : [ 0, 16 ],
      "id_str" : "935043573417787393",
      "id" : 935043573417787393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/0ewFeY8iSS",
      "expanded_url" : "https:\/\/twitter.com\/Wordless_Echo\/status\/938936074050584576",
      "display_url" : "twitter.com\/Wordless_Echo\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "941561357874339840",
  "geo" : { },
  "id_str" : "944548558417616896",
  "in_reply_to_user_id" : 935043573417787393,
  "text" : "@HelloKittyGolds \u840C\u65B0\u4F60\u597D\uFF01https:\/\/t.co\/0ewFeY8iSS",
  "id" : 944548558417616896,
  "in_reply_to_status_id" : 941561357874339840,
  "created_at" : "2017-12-23 12:41:39 +0000",
  "in_reply_to_screen_name" : "HelloKittyGolds",
  "in_reply_to_user_id_str" : "935043573417787393",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944399026493054976",
  "geo" : { },
  "id_str" : "944541948513259520",
  "in_reply_to_user_id" : 3359880735,
  "text" : "Solidot\u6062\u5FA9\u4E86\u3002\n\uFF08\u7336\u8C6B\u8981\u4E0D\u8981\u6350\u9322\u3002\u3002",
  "id" : 944541948513259520,
  "in_reply_to_status_id" : 944399026493054976,
  "created_at" : "2017-12-23 12:15:23 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944442318425395200",
  "text" : "\u5E38\u5E38\u78B0\u5230\u4E0D\u8A8D\u8B58\u7684\u8A71\u4E1F\u8C37\u6B4C\u7FFB\u8B6F\u88CF\uFF0C\u7FFB\u6210\u201C\u4E2D\u6587\u201D\u540E\u8B8A\u6210\u82F1\u6587\uFF0C\u5F97\u5148\u7FFB\u6210\u65E5\u6587\u518D\u7FFB\u56DE\u4E2D\u6587\u3002",
  "id" : 944442318425395200,
  "created_at" : "2017-12-23 05:39:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941546902629376000\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/qEJHwUM7xB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DREL4DmXcAA1GxS.jpg",
      "id_str" : "941546854763950080",
      "id" : 941546854763950080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DREL4DmXcAA1GxS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qEJHwUM7xB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/jjujRPXm2B",
      "expanded_url" : "https:\/\/www.battleforthenet.com\/",
      "display_url" : "battleforthenet.com"
    } ]
  },
  "geo" : { },
  "id_str" : "944440622433406978",
  "text" : "RT @dou4cc: Congress can overrule the FCC vote. This is how.https:\/\/t.co\/jjujRPXm2B https:\/\/t.co\/qEJHwUM7xB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941546902629376000\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/qEJHwUM7xB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DREL4DmXcAA1GxS.jpg",
        "id_str" : "941546854763950080",
        "id" : 941546854763950080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DREL4DmXcAA1GxS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 706,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 706,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 706,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qEJHwUM7xB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/jjujRPXm2B",
        "expanded_url" : "https:\/\/www.battleforthenet.com\/",
        "display_url" : "battleforthenet.com"
      } ]
    },
    "in_reply_to_status_id_str" : "941546707447361536",
    "geo" : { },
    "id_str" : "941546902629376000",
    "in_reply_to_user_id" : 3359880735,
    "text" : "Congress can overrule the FCC vote. This is how.https:\/\/t.co\/jjujRPXm2B https:\/\/t.co\/qEJHwUM7xB",
    "id" : 941546902629376000,
    "in_reply_to_status_id" : 941546707447361536,
    "created_at" : "2017-12-15 05:54:09 +0000",
    "in_reply_to_screen_name" : "dou4cc",
    "in_reply_to_user_id_str" : "3359880735",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 944440622433406978,
  "created_at" : "2017-12-23 05:32:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Huang",
      "screen_name" : "hjc4869",
      "indices" : [ 0, 8 ],
      "id_str" : "996744811",
      "id" : 996744811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944436920016240640",
  "geo" : { },
  "id_str" : "944439954645700613",
  "in_reply_to_user_id" : 996744811,
  "text" : "@hjc4869 \u56E0\u7232\u540C\u4E00\u63A8\u6587\u5728\u6642\u9593\u7DAB\u4E2D\u8879\u986F\u793A\u4E00\u904D\uFF0C\u9019\u4E9B\u63D0\u524D\u7684\u63A8\u6587\u88AB\u96B1\u85CF\u6389\u4E4B\u5F8C\u9084\u4E0D\u80FD\u81EA\u52D5\u56DE\u5230\u6309\u6642\u5E8F\u6392\u5E8F\u7684\u6B63\u5E38\u6642\u9593\u7DAB\uFF0C\u5F97\u5237\u65B0\u91CD\u4F86\u3002",
  "id" : 944439954645700613,
  "in_reply_to_status_id" : 944436920016240640,
  "created_at" : "2017-12-23 05:30:06 +0000",
  "in_reply_to_screen_name" : "hjc4869",
  "in_reply_to_user_id_str" : "996744811",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/944422677317668865\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/rWLK5j6kQq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRtDZMiW4AA2iGp.jpg",
      "id_str" : "944422647005372416",
      "id" : 944422647005372416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRtDZMiW4AA2iGp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 1116
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 1116
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 1116
      } ],
      "display_url" : "pic.twitter.com\/rWLK5j6kQq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944422677317668865",
  "text" : "\u600E\u9EBD\u505A\u5230\u9023fo\u4E86\u591A\u5C11\u4EBA\u90FD\u96B1\u85CF\u6389\u7684\uFF1F https:\/\/t.co\/rWLK5j6kQq",
  "id" : 944422677317668865,
  "created_at" : "2017-12-23 04:21:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    }, {
      "name" : "\u5F20\u9AA5\u9A70",
      "screen_name" : "JichiZhangJimmy",
      "indices" : [ 13, 29 ],
      "id_str" : "2477303354",
      "id" : 2477303354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944410936030277632",
  "geo" : { },
  "id_str" : "944411889836154880",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang @JichiZhangJimmy \u53B2\u5BB3\u554A\uFF0C\u6BD4\u6211\u5C0F\u5169\u6B72\u534A\uFF0C\u9084\u6BD4\u6211\u65E9\u4E0A\u63A8\u3002\n\u8A71\u8AAC\u6211QQ\u7A7A\u9593\u4E5F\u662F2015\u5E74\u624D\u958B\u59CB\u7528\u3002",
  "id" : 944411889836154880,
  "in_reply_to_status_id" : 944410936030277632,
  "created_at" : "2017-12-23 03:38:35 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 0, 12 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944111086055317504",
  "geo" : { },
  "id_str" : "944402841489362945",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@DevinStever \u5FC3\u75BC\u4F4F\u6821\u9EE8\u3002",
  "id" : 944402841489362945,
  "in_reply_to_status_id" : 944111086055317504,
  "created_at" : "2017-12-23 03:02:38 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 0, 12 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    }, {
      "name" : "\u5F20\u9AA5\u9A70",
      "screen_name" : "JichiZhangJimmy",
      "indices" : [ 17, 33 ],
      "id_str" : "2477303354",
      "id" : 2477303354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943888875109335040",
  "geo" : { },
  "id_str" : "944402064947412992",
  "in_reply_to_user_id" : 4628523253,
  "text" : "@jichi_zhang \u5F20\u9AA5\u9A70\uFF08@JichiZhangJimmy\uFF09\u662F\u4F60\u7684\u524D\u8EAB\u55CE\uFF1F",
  "id" : 944402064947412992,
  "in_reply_to_status_id" : 943888875109335040,
  "created_at" : "2017-12-23 02:59:33 +0000",
  "in_reply_to_screen_name" : "jichi_zhang",
  "in_reply_to_user_id_str" : "4628523253",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/710RaIabK0",
      "expanded_url" : "https:\/\/slashdot.org",
      "display_url" : "slashdot.org"
    } ]
  },
  "in_reply_to_status_id_str" : "944382525622931456",
  "geo" : { },
  "id_str" : "944399026493054976",
  "in_reply_to_user_id" : 3359880735,
  "text" : "Slashdot\u6B61\u8FCE\u4F60\uFF1Ahttps:\/\/t.co\/710RaIabK0",
  "id" : 944399026493054976,
  "in_reply_to_status_id" : 944382525622931456,
  "created_at" : "2017-12-23 02:47:28 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/cRGwMrshAD",
      "expanded_url" : "https:\/\/music.163.com\/#\/song?id=505230372",
      "display_url" : "music.163.com\/#\/song?id=5052\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "944397781564841985",
  "text" : "\u521D\u5FC3\uFF1Ahttps:\/\/t.co\/cRGwMrshAD",
  "id" : 944397781564841985,
  "created_at" : "2017-12-23 02:42:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/0vsVMZAHXy",
      "expanded_url" : "https:\/\/twitter.com\/EmmaYR00\/status\/944202795682381824",
      "display_url" : "twitter.com\/EmmaYR00\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "944392602580930562",
  "text" : "\u7232\u4EC0\u9EBD\u770B\u5230\u5973\u5B69\u5B50\u53EB\u7537\u5B69\u5B50\u201C\u4E3B\u4EBA\u201D\u611F\u89BA\u6709\u9EDE\u60E1\u5FC3\uFF1F https:\/\/t.co\/0vsVMZAHXy",
  "id" : 944392602580930562,
  "created_at" : "2017-12-23 02:21:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "safufu\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    }, {
      "name" : "Kios",
      "screen_name" : "7yinhuofuB7zhi",
      "indices" : [ 9, 24 ],
      "id_str" : "871645492077363201",
      "id" : 871645492077363201
    }, {
      "name" : "cloudwindy",
      "screen_name" : "HelloKittyGolds",
      "indices" : [ 25, 41 ],
      "id_str" : "935043573417787393",
      "id" : 935043573417787393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944391023362416640",
  "geo" : { },
  "id_str" : "944392358623399936",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot @7yinhuofuB7zhi @HelloKittyGolds \u6240\u4EE5\u4F60\u63A5\u7684\u4EC0\u9EBD\u5916\u5305\uFF1F",
  "id" : 944392358623399936,
  "in_reply_to_status_id" : 944391023362416640,
  "created_at" : "2017-12-23 02:20:58 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kios",
      "screen_name" : "7yinhuofuB7zhi",
      "indices" : [ 0, 15 ],
      "id_str" : "871645492077363201",
      "id" : 871645492077363201
    }, {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 16, 24 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    }, {
      "name" : "cloudwindy",
      "screen_name" : "HelloKittyGolds",
      "indices" : [ 25, 41 ],
      "id_str" : "935043573417787393",
      "id" : 935043573417787393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944212403750760448",
  "geo" : { },
  "id_str" : "944390979439792128",
  "in_reply_to_user_id" : 871645492077363201,
  "text" : "@7yinhuofuB7zhi @39__bot @HelloKittyGolds \u63A8\u7279\u4E0A\u8AB0\u4E0D\u6703\u7DE8\u7A0B\uFF1F",
  "id" : 944390979439792128,
  "in_reply_to_status_id" : 944212403750760448,
  "created_at" : "2017-12-23 02:15:30 +0000",
  "in_reply_to_screen_name" : "7yinhuofuB7zhi",
  "in_reply_to_user_id_str" : "871645492077363201",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944387227408322560",
  "text" : "Outlook\u771F\u662F\u55AB\u4E86\u5C4E\u4E86\uFF0C\u8A02\u95B2\u90F5\u4EF6\u5F80\u5783\u573E\u90F5\u4EF6\u88CF\u653E\uFF0C\u5783\u573E\u90F5\u4EF6\u5F80\u8A02\u95B2\u90F5\u4EF6\u88CF\u653E\u3002",
  "id" : 944387227408322560,
  "created_at" : "2017-12-23 02:00:35 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/e9iXhq6YJ1",
      "expanded_url" : "https:\/\/t.me\/solidot",
      "display_url" : "t.me\/solidot"
    } ]
  },
  "in_reply_to_status_id_str" : "944382234135588864",
  "geo" : { },
  "id_str" : "944382525622931456",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u7B2C\u4E09\u65B9Telegram Channel\u5B58\u6709\u5168\u6587\u5099\u4EFD\uFF1Ahttps:\/\/t.co\/e9iXhq6YJ1",
  "id" : 944382525622931456,
  "in_reply_to_status_id" : 944382234135588864,
  "created_at" : "2017-12-23 01:41:54 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/6nL2HnQCMS",
      "expanded_url" : "https:\/\/archive.is\/FRmlB",
      "display_url" : "archive.is\/FRmlB"
    } ]
  },
  "geo" : { },
  "id_str" : "944382234135588864",
  "text" : "Solidot\u518D\u6B21\u5B95\u6A5F\uFF0C\u5DF2\u88AB\u559D\u8336\uFF1Ahttps:\/\/t.co\/6nL2HnQCMS",
  "id" : 944382234135588864,
  "created_at" : "2017-12-23 01:40:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944211016484818944",
  "text" : "\u665A\u4E0A\u5EF6\u9072\u9AD8\u5230\u70B8\uFF0C\u9084\u597D\u5E36\u5BEC\u6C92\u53D7\u5F71\u97FF\u3002",
  "id" : 944211016484818944,
  "created_at" : "2017-12-22 14:20:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victoria Raymond",
      "screen_name" : "projectv2ray",
      "indices" : [ 16, 29 ],
      "id_str" : "3727242017",
      "id" : 3727242017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943776400925954048",
  "geo" : { },
  "id_str" : "944137921833127936",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@Calcutec114514 @projectv2ray \u662F\u7834\u5A03\u8B93\u522A\u7684\u55CE\uFF1F",
  "id" : 944137921833127936,
  "in_reply_to_status_id" : 943776400925954048,
  "created_at" : "2017-12-22 09:29:56 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 12, 22 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/ufnvb20ahb",
      "expanded_url" : "https:\/\/kujourin.com\/nikki\/1709",
      "display_url" : "kujourin.com\/nikki\/1709"
    } ]
  },
  "geo" : { },
  "id_str" : "944108532722470912",
  "text" : "RT @dou4cc: @kujou_rin \u4E5F\u4E0D\u662F\u5F88\u5927\u554A\uFF1Ahttps:\/\/t.co\/ufnvb20ahb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u4E5D\u6761\u51DB",
        "screen_name" : "kujou_rin",
        "indices" : [ 0, 10 ],
        "id_str" : "1700784456",
        "id" : 1700784456
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/ufnvb20ahb",
        "expanded_url" : "https:\/\/kujourin.com\/nikki\/1709",
        "display_url" : "kujourin.com\/nikki\/1709"
      } ]
    },
    "in_reply_to_status_id_str" : "944049285326192641",
    "geo" : { },
    "id_str" : "944107042050060288",
    "in_reply_to_user_id" : 1700784456,
    "text" : "@kujou_rin \u4E5F\u4E0D\u662F\u5F88\u5927\u554A\uFF1Ahttps:\/\/t.co\/ufnvb20ahb",
    "id" : 944107042050060288,
    "in_reply_to_status_id" : 944049285326192641,
    "created_at" : "2017-12-22 07:27:14 +0000",
    "in_reply_to_screen_name" : "kujou_rin",
    "in_reply_to_user_id_str" : "1700784456",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 944108532722470912,
  "created_at" : "2017-12-22 07:33:09 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944107042050060288",
  "geo" : { },
  "id_str" : "944107770848129024",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@kujou_rin \u4E0D\u904E\u6587\u98A8\u8B8A\u4E86\u597D\u591A\u6B21\u3002",
  "id" : 944107770848129024,
  "in_reply_to_status_id" : 944107042050060288,
  "created_at" : "2017-12-22 07:30:07 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/ufnvb20ahb",
      "expanded_url" : "https:\/\/kujourin.com\/nikki\/1709",
      "display_url" : "kujourin.com\/nikki\/1709"
    } ]
  },
  "in_reply_to_status_id_str" : "944049285326192641",
  "geo" : { },
  "id_str" : "944107042050060288",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u4E5F\u4E0D\u662F\u5F88\u5927\u554A\uFF1Ahttps:\/\/t.co\/ufnvb20ahb",
  "id" : 944107042050060288,
  "in_reply_to_status_id" : 944049285326192641,
  "created_at" : "2017-12-22 07:27:14 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944100860077809664",
  "geo" : { },
  "id_str" : "944101249019973632",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u624B\u597D\u6F02\u4EAE\uFF01",
  "id" : 944101249019973632,
  "in_reply_to_status_id" : 944100860077809664,
  "created_at" : "2017-12-22 07:04:12 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944096706018336768",
  "geo" : { },
  "id_str" : "944096978732019712",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@kujou_rin \u4E3B\u8981\u662F\u5206\u8A5E\u505A\u5F97\u4E0D\u597D\u3002\u4E0D\u904E\u4E00\u500B\u5B57\u3001\u4E00\u500B\u5B57\u641C\u7684\u8A71\u662F\u6C92\u6709\u5206\u8A5E\u7684\u3002",
  "id" : 944096978732019712,
  "in_reply_to_status_id" : 944096706018336768,
  "created_at" : "2017-12-22 06:47:14 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944096530457280513",
  "geo" : { },
  "id_str" : "944096706018336768",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u5E76\u4E0D\u554A\uFF0C\u4F60\u5207\u5230\u201D\u6700\u65B0\u201C\u7684tab\u8A66\u8A66\u3002",
  "id" : 944096706018336768,
  "in_reply_to_status_id" : 944096530457280513,
  "created_at" : "2017-12-22 06:46:09 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944087566265016325",
  "geo" : { },
  "id_str" : "944096357660397568",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u6240\u4EE5\u9396\u63A8\u7684\u50B7\u5BB3\u662F\u6C38\u4E45\u7684\u3002",
  "id" : 944096357660397568,
  "in_reply_to_status_id" : 944087566265016325,
  "created_at" : "2017-12-22 06:44:46 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 3, 13 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944095204436598784",
  "text" : "RT @kujou_rin: \u5927\u5BB6\u4E92\u76F8\u4EA4\u63DB\u4E00\u4E0B\u5973\u88DD\u7167\u7247\uFF0C\u904E\u5E74\u56DE\u53BB\u5C31\u53EF\u4EE5\u7D66\u5BB6\u88E1\u4EBA\u4EA4\u4EE3\u4E86www",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.071665, 116.350946 ]
    },
    "id_str" : "423803484937256960",
    "text" : "\u5927\u5BB6\u4E92\u76F8\u4EA4\u63DB\u4E00\u4E0B\u5973\u88DD\u7167\u7247\uFF0C\u904E\u5E74\u56DE\u53BB\u5C31\u53EF\u4EE5\u7D66\u5BB6\u88E1\u4EBA\u4EA4\u4EE3\u4E86www",
    "id" : 423803484937256960,
    "created_at" : "2014-01-16 13:06:39 +0000",
    "user" : {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "protected" : false,
      "id_str" : "1700784456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745048870908899328\/oeWnHP7Q_normal.jpg",
      "id" : 1700784456,
      "verified" : false
    }
  },
  "id" : 944095204436598784,
  "created_at" : "2017-12-22 06:40:11 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944093777773264896",
  "geo" : { },
  "id_str" : "944094295782580230",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u60F3\u60F32013\u5E74\u90A3\u6703\u5152\u6211\u624D\u77E5\u9053Greatfire\u3002",
  "id" : 944094295782580230,
  "in_reply_to_status_id" : 944093777773264896,
  "created_at" : "2017-12-22 06:36:35 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 3, 13 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    }, {
      "name" : "\u5C3C\u8FB0\u5DE6\u53F3",
      "screen_name" : "yku",
      "indices" : [ 15, 19 ],
      "id_str" : "38714541",
      "id" : 38714541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944092721312161792",
  "text" : "RT @kujou_rin: @yku \u90A3\u6211\u4EE5\u5F8C\u9084\u662F\u7528\u5634\u597D\u4E86",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5C3C\u8FB0\u5DE6\u53F3",
        "screen_name" : "yku",
        "indices" : [ 0, 4 ],
        "id_str" : "38714541",
        "id" : 38714541
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "415133929901785088",
    "geo" : { },
    "id_str" : "415134087037202432",
    "in_reply_to_user_id" : 38714541,
    "text" : "@yku \u90A3\u6211\u4EE5\u5F8C\u9084\u662F\u7528\u5634\u597D\u4E86",
    "id" : 415134087037202432,
    "in_reply_to_status_id" : 415133929901785088,
    "created_at" : "2013-12-23 14:57:33 +0000",
    "in_reply_to_screen_name" : "yku",
    "in_reply_to_user_id_str" : "38714541",
    "user" : {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "protected" : false,
      "id_str" : "1700784456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745048870908899328\/oeWnHP7Q_normal.jpg",
      "id" : 1700784456,
      "verified" : false
    }
  },
  "id" : 944092721312161792,
  "created_at" : "2017-12-22 06:30:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 3, 13 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kujou_rin\/status\/395056012484284416\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/W4G3hQNfue",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXuFWasCEAAX_M7.jpg",
      "id_str" : "395056012492673024",
      "id" : 395056012492673024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXuFWasCEAAX_M7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/W4G3hQNfue"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944091646454566917",
  "text" : "RT @kujou_rin: \u5929\u5B89\u9580\u3067\u7206\u767A\u3057\u305F\u8ECA\u4E21\u30CA\u30F3\u30D0\u30FC\u306F\u65B0\u7586\u30A6\u30A4\u30B0\u30EB\u81EA\u6CBB\u533A\u306E\u3082\u306E\u3067\u3001\u5BB9\u7591\u8005\u304C\u540C\u81EA\u6CBB\u533A\u51FA\u8EAB\u8005\u3067\u3042\u308B\u3001\u3068\u5317\u4EAC\u5E02\u6CBB\u5B89\u7DCF\u968A\u304C\u660E\u304B\u3057\u305F http:\/\/t.co\/W4G3hQNfue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kujou_rin\/status\/395056012484284416\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/W4G3hQNfue",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXuFWasCEAAX_M7.jpg",
        "id_str" : "395056012492673024",
        "id" : 395056012492673024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXuFWasCEAAX_M7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/W4G3hQNfue"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395056012484284416",
    "text" : "\u5929\u5B89\u9580\u3067\u7206\u767A\u3057\u305F\u8ECA\u4E21\u30CA\u30F3\u30D0\u30FC\u306F\u65B0\u7586\u30A6\u30A4\u30B0\u30EB\u81EA\u6CBB\u533A\u306E\u3082\u306E\u3067\u3001\u5BB9\u7591\u8005\u304C\u540C\u81EA\u6CBB\u533A\u51FA\u8EAB\u8005\u3067\u3042\u308B\u3001\u3068\u5317\u4EAC\u5E02\u6CBB\u5B89\u7DCF\u968A\u304C\u660E\u304B\u3057\u305F http:\/\/t.co\/W4G3hQNfue",
    "id" : 395056012484284416,
    "created_at" : "2013-10-29 05:14:27 +0000",
    "user" : {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "protected" : false,
      "id_str" : "1700784456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745048870908899328\/oeWnHP7Q_normal.jpg",
      "id" : 1700784456,
      "verified" : false
    }
  },
  "id" : 944091646454566917,
  "created_at" : "2017-12-22 06:26:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/944087566265016325\/photo\/1",
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/onITYKYnrG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRoSoIKXcAEnSZI.jpg",
      "id_str" : "944087552482570241",
      "id" : 944087552482570241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRoSoIKXcAEnSZI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/onITYKYnrG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944087566265016325",
  "text" : "\u63A8\u7279\u53EF\u4EE5\u53BB\u6B7B\u4E86\uFF1A https:\/\/t.co\/onITYKYnrG",
  "id" : 944087566265016325,
  "created_at" : "2017-12-22 06:09:50 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944086468821159936",
  "text" : "1\u6BD4\u7279\u5E63 \u2248 14000\u7F8E\u5143",
  "id" : 944086468821159936,
  "created_at" : "2017-12-22 06:05:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poi\u2642next\u2642door",
      "screen_name" : "v2_poi",
      "indices" : [ 0, 7 ],
      "id_str" : "1092469987",
      "id" : 1092469987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "939772323938390017",
  "geo" : { },
  "id_str" : "944081574408216576",
  "in_reply_to_user_id" : 1092469987,
  "text" : "@v2_poi \u6211\u4EE5\u7232\u662F\u5169\u5929\u6C92\u55AB\u7CBE\u6DB2\u3002",
  "id" : 944081574408216576,
  "in_reply_to_status_id" : 939772323938390017,
  "created_at" : "2017-12-22 05:46:02 +0000",
  "in_reply_to_screen_name" : "v2_poi",
  "in_reply_to_user_id_str" : "1092469987",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    }, {
      "name" : "Tom Guan",
      "screen_name" : "guan_tom",
      "indices" : [ 11, 20 ],
      "id_str" : "821683432023437312",
      "id" : 821683432023437312
    }, {
      "name" : "Nichijou\u277E",
      "screen_name" : "nichijou999",
      "indices" : [ 21, 33 ],
      "id_str" : "852903467890769920",
      "id" : 852903467890769920
    }, {
      "name" : "\u5343\u4EE3\u3048\u304D\u307F\u3093",
      "screen_name" : "Jyulury",
      "indices" : [ 34, 42 ],
      "id_str" : "771411886239846400",
      "id" : 771411886239846400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940468097269489664",
  "geo" : { },
  "id_str" : "944080693386186752",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin @guan_tom @nichijou999 @Jyulury \u767C\u904E\u81EA\u5DF1\u982D\u50CF\u7167\u7247\u3001\u8B1B\u904E\u81EA\u5DF1\u6240\u5728\u57CE\u5E02\u548CISP\u4F7F\u7528\u60C5\u6CC1\u7684\u6211\u4E00\u81C9\u61F5\u903C\u3002\u4F60\u5011\u628A\u68AF\u5B50\u7576tor\/i2p\u55CE\uFF1F",
  "id" : 944080693386186752,
  "in_reply_to_status_id" : 940468097269489664,
  "created_at" : "2017-12-22 05:42:32 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Guan@\u5143\u65E6\u6D3B\u52D5\u6E96\u5099\u4E2D",
      "screen_name" : "guan_tom",
      "indices" : [ 3, 12 ],
      "id_str" : "821683432023437312",
      "id" : 821683432023437312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "944076696088645632",
  "text" : "RT @guan_tom: \u88AB\u516C\u5B89\u5C40\u8ACB\u53BB\u559D\u8336\u4E86",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "940460552958091265",
    "text" : "\u88AB\u516C\u5B89\u5C40\u8ACB\u53BB\u559D\u8336\u4E86",
    "id" : 940460552958091265,
    "created_at" : "2017-12-12 05:57:23 +0000",
    "user" : {
      "name" : "Tom Guan",
      "screen_name" : "guan_tom",
      "protected" : false,
      "id_str" : "821683432023437312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/944066825871953920\/aD7sqryp_normal.jpg",
      "id" : 821683432023437312,
      "verified" : false
    }
  },
  "id" : 944076696088645632,
  "created_at" : "2017-12-22 05:26:39 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/t3u1KRssta",
      "expanded_url" : "https:\/\/archive.is\/4unlM",
      "display_url" : "archive.is\/4unlM"
    } ]
  },
  "geo" : { },
  "id_str" : "944069967384891392",
  "text" : "\u5C0D\u885D\u57FA\u91D1\u6216\u9032\u8ECD\u6BD4\u7279\u5E63\uFF1Ahttps:\/\/t.co\/t3u1KRssta",
  "id" : 944069967384891392,
  "created_at" : "2017-12-22 04:59:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/wO1ydCryCa",
      "expanded_url" : "https:\/\/twitter.com\/gehouhun\/status\/943872586953277442",
      "display_url" : "twitter.com\/gehouhun\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "944069487527124992",
  "text" : "py\uFF1F https:\/\/t.co\/wO1ydCryCa",
  "id" : 944069487527124992,
  "created_at" : "2017-12-22 04:58:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "safufu\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943906256183443457",
  "geo" : { },
  "id_str" : "944064979061432320",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u5176\u5BE6\u7834\u5A03\u4E5F\u662F\u5973\u5B69\u5B50\u4E86\u3002",
  "id" : 944064979061432320,
  "in_reply_to_status_id" : 943906256183443457,
  "created_at" : "2017-12-22 04:40:05 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poi\u2642next\u2642door",
      "screen_name" : "v2_poi",
      "indices" : [ 0, 7 ],
      "id_str" : "1092469987",
      "id" : 1092469987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813386528810405888",
  "geo" : { },
  "id_str" : "944064166826004481",
  "in_reply_to_user_id" : 1092469987,
  "text" : "@v2_poi \u4F60\u4E0D\u662F\u5927\u4E8C\u6216\u5927\u4E09\u55CE\uFF1F\u5BE6\u7FD2\u4E86\uFF1F",
  "id" : 944064166826004481,
  "in_reply_to_status_id" : 813386528810405888,
  "created_at" : "2017-12-22 04:36:51 +0000",
  "in_reply_to_screen_name" : "v2_poi",
  "in_reply_to_user_id_str" : "1092469987",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6DF1\u84DD\u4E4B\u9083",
      "screen_name" : "SL_Deongaree",
      "indices" : [ 0, 13 ],
      "id_str" : "761865426263343104",
      "id" : 761865426263343104
    }, {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 14, 22 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943966270734532608",
  "geo" : { },
  "id_str" : "944063683356975104",
  "in_reply_to_user_id" : 761865426263343104,
  "text" : "@SL_Deongaree @39__bot \u53C8\u8B8A\u56DE\u7537\u751F\u4E86\uFF1F",
  "id" : 944063683356975104,
  "in_reply_to_status_id" : 943966270734532608,
  "created_at" : "2017-12-22 04:34:56 +0000",
  "in_reply_to_screen_name" : "SL_Deongaree",
  "in_reply_to_user_id_str" : "761865426263343104",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    }, {
      "name" : "\u99C6\u9010\u8266\u0412\u0435\u0440\u043D\u044B\u0439",
      "screen_name" : "ruima0512",
      "indices" : [ 9, 19 ],
      "id_str" : "1953413498",
      "id" : 1953413498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944005312826109953",
  "geo" : { },
  "id_str" : "944062728158801920",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot @ruima0512 \u975C\u975C\u5730\u770B\u4F60\u628A\u4F60\u54E5\u8A13\u7DF4\u6210S\u3002",
  "id" : 944062728158801920,
  "in_reply_to_status_id" : 944005312826109953,
  "created_at" : "2017-12-22 04:31:08 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944049285326192641",
  "geo" : { },
  "id_str" : "944050247701094400",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u201C\u738B\u5C3C\u746A\u8879\u662F\u500B\u982D\u5957\uFF0C\u6211\u4E0D\u662F\u738B\u5C3C\u746A\u3002\u201D",
  "id" : 944050247701094400,
  "in_reply_to_status_id" : 944049285326192641,
  "created_at" : "2017-12-22 03:41:33 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E5D\u6761\u51DB",
      "screen_name" : "kujou_rin",
      "indices" : [ 0, 10 ],
      "id_str" : "1700784456",
      "id" : 1700784456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "944042912588820480",
  "geo" : { },
  "id_str" : "944048348599869441",
  "in_reply_to_user_id" : 1700784456,
  "text" : "@kujou_rin \u4F60\u5230\u5E95\u591A\u5927\uFF1F",
  "id" : 944048348599869441,
  "in_reply_to_status_id" : 944042912588820480,
  "created_at" : "2017-12-22 03:34:00 +0000",
  "in_reply_to_screen_name" : "kujou_rin",
  "in_reply_to_user_id_str" : "1700784456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/SwkOfKc3yU",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/12\/blog-post_981.html",
      "display_url" : "molihua.org\/2017\/12\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943839101714911233",
  "text" : "\u66DD\u5149\u7684\u6587\u4EF6\u78BA\u8A8D\u516D\u56DB\u4E8B\u4EF6\u8D85\u904E\u4E00\u842C\u4EBA\u8EAB\u4EA1\uFF1Ahttps:\/\/t.co\/SwkOfKc3yU",
  "id" : 943839101714911233,
  "created_at" : "2017-12-21 13:42:32 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/xad4EMAkRq",
      "expanded_url" : "https:\/\/whatcanidoformozilla.org\/#!\/progornoprog\/proglang\/perl\/bmo",
      "display_url" : "whatcanidoformozilla.org\/#!\/progornopro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943826913184927744",
  "text" : "What I can do for Mozilla\uFF1Ahttps:\/\/t.co\/xad4EMAkRq",
  "id" : 943826913184927744,
  "created_at" : "2017-12-21 12:54:06 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "943825050737827840",
  "text" : "1\u6BD4\u7279\u5E63 \u2248 17000\u7F8E\u5143",
  "id" : 943825050737827840,
  "created_at" : "2017-12-21 12:46:42 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "943819570846060544",
  "text" : "\u79FB\u52D5\u73FE\u5728\u771F\u662F\u512A\u52E2\u5168\u7121\u3002",
  "id" : 943819570846060544,
  "created_at" : "2017-12-21 12:24:55 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/S1OTjMlF1x",
      "expanded_url" : "https:\/\/twitter.com\/jichi_zhang\/status\/943139633809965057",
      "display_url" : "twitter.com\/jichi_zhang\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943815802079326208",
  "text" : "\u6703\u653E\u68C4\u81EA\u5DF1\u7684\u7ACB\u5834\u3002 https:\/\/t.co\/S1OTjMlF1x",
  "id" : 943815802079326208,
  "created_at" : "2017-12-21 12:09:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943145762694733824",
  "geo" : { },
  "id_str" : "943815284456083456",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB\u70EB",
  "id" : 943815284456083456,
  "in_reply_to_status_id" : 943145762694733824,
  "created_at" : "2017-12-21 12:07:53 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943795785317126144",
  "geo" : { },
  "id_str" : "943814632787075072",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@39__bot \u5176\u5BE6\u662F\u60E1\u5FC3\uFF08\u9806\u624B\u9EDE\u958B\u4E00\u500B\u4E59\u5973\u6293",
  "id" : 943814632787075072,
  "in_reply_to_status_id" : 943795785317126144,
  "created_at" : "2017-12-21 12:05:18 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6795\u5934\u519B Jason \u6B7B\u9C7C\u773C\u65E5\u7167\u4E0D\u8DB3",
      "screen_name" : "YN_CZTJ",
      "indices" : [ 3, 11 ],
      "id_str" : "758179488429727745",
      "id" : 758179488429727745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/YN_CZTJ\/status\/943259416400314369\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/h3wNu5rW5d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRchbldVAAEakWk.jpg",
      "id_str" : "943259404752715777",
      "id" : 943259404752715777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRchbldVAAEakWk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 864
      } ],
      "display_url" : "pic.twitter.com\/h3wNu5rW5d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "943813785948774400",
  "text" : "RT @YN_CZTJ: \u8FD9\u662F\u60F3\u53D8\u6210\u96C6\u4E2D\u8425\uFF1F https:\/\/t.co\/h3wNu5rW5d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YN_CZTJ\/status\/943259416400314369\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/h3wNu5rW5d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DRchbldVAAEakWk.jpg",
        "id_str" : "943259404752715777",
        "id" : 943259404752715777,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRchbldVAAEakWk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 864
        } ],
        "display_url" : "pic.twitter.com\/h3wNu5rW5d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "943259416400314369",
    "text" : "\u8FD9\u662F\u60F3\u53D8\u6210\u96C6\u4E2D\u8425\uFF1F https:\/\/t.co\/h3wNu5rW5d",
    "id" : 943259416400314369,
    "created_at" : "2017-12-19 23:19:04 +0000",
    "user" : {
      "name" : "\u6795\u5934\u519B Jason \u6B7B\u9C7C\u773C\u65E5\u7167\u4E0D\u8DB3",
      "screen_name" : "YN_CZTJ",
      "protected" : false,
      "id_str" : "758179488429727745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925392412721082369\/Y9vcR-1s_normal.jpg",
      "id" : 758179488429727745,
      "verified" : false
    }
  },
  "id" : 943813785948774400,
  "created_at" : "2017-12-21 12:01:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    }, {
      "name" : "\u51B0\u6893 #\u5723\u8BDE Ver 16.3.2",
      "screen_name" : "babywbx",
      "indices" : [ 9, 17 ],
      "id_str" : "992637470",
      "id" : 992637470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943809053389656064",
  "geo" : { },
  "id_str" : "943810154918801409",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@39__bot @babywbx \u602A\u4E0D\u5F97\u4F60\u4E0D\u6703\u55B5\u55B5\u55B5\u4E86~",
  "id" : 943810154918801409,
  "in_reply_to_status_id" : 943809053389656064,
  "created_at" : "2017-12-21 11:47:30 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    }, {
      "name" : "\u51B0\u6893 #\u5723\u8BDE Ver 16.3.2",
      "screen_name" : "babywbx",
      "indices" : [ 9, 17 ],
      "id_str" : "992637470",
      "id" : 992637470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943393680764706816",
  "geo" : { },
  "id_str" : "943809053389656064",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot @babywbx \u525B\u525B\u7279\u5730google\u4E86\u4E00\u4E0B\u3002\u3002",
  "id" : 943809053389656064,
  "in_reply_to_status_id" : 943393680764706816,
  "created_at" : "2017-12-21 11:43:08 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6DF1\u84DD\u4E4B\u9083",
      "screen_name" : "SL_Deongaree",
      "indices" : [ 0, 13 ],
      "id_str" : "761865426263343104",
      "id" : 761865426263343104
    }, {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 14, 22 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943495472332677125",
  "geo" : { },
  "id_str" : "943806638288527361",
  "in_reply_to_user_id" : 761865426263343104,
  "text" : "@SL_Deongaree @39__bot \u8B8A\u5973\u5B69\u5B50\u4E86\uFF1F",
  "id" : 943806638288527361,
  "in_reply_to_status_id" : 943495472332677125,
  "created_at" : "2017-12-21 11:33:32 +0000",
  "in_reply_to_screen_name" : "SL_Deongaree",
  "in_reply_to_user_id_str" : "761865426263343104",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "He Qinglian",
      "screen_name" : "HeQinglian",
      "indices" : [ 3, 14 ],
      "id_str" : "126798663",
      "id" : 126798663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/i8S3oexl8Z",
      "expanded_url" : "https:\/\/twitter.com\/HeQinglian\/status\/943252736979734528",
      "display_url" : "twitter.com\/HeQinglian\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943805372166557696",
  "text" : "RT @HeQinglian: \u7F8E\u56FD\u53C2\u8BAE\u9662\u4ECA\u5929\u65E9\u95F4\u4EE551\u7968\u5BF948\u7968\u901A\u8FC7\u7A0E\u6539\u8BAE\u6848\u3002\u7F8E\u56FD30\u5E74\u4EE5\u6765\u6700\u5927\u7A0E\u6539\u6CD5\u6848\u7EC8\u4E8E\u6210\u884C\u3002 https:\/\/t.co\/i8S3oexl8Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/i8S3oexl8Z",
        "expanded_url" : "https:\/\/twitter.com\/HeQinglian\/status\/943252736979734528",
        "display_url" : "twitter.com\/HeQinglian\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "943500275473702912",
    "text" : "\u7F8E\u56FD\u53C2\u8BAE\u9662\u4ECA\u5929\u65E9\u95F4\u4EE551\u7968\u5BF948\u7968\u901A\u8FC7\u7A0E\u6539\u8BAE\u6848\u3002\u7F8E\u56FD30\u5E74\u4EE5\u6765\u6700\u5927\u7A0E\u6539\u6CD5\u6848\u7EC8\u4E8E\u6210\u884C\u3002 https:\/\/t.co\/i8S3oexl8Z",
    "id" : 943500275473702912,
    "created_at" : "2017-12-20 15:16:09 +0000",
    "user" : {
      "name" : "He Qinglian",
      "screen_name" : "HeQinglian",
      "protected" : false,
      "id_str" : "126798663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3163471607\/1d95ff4319b9671426e74d3b4973be12_normal.jpeg",
      "id" : 126798663,
      "verified" : false
    }
  },
  "id" : 943805372166557696,
  "created_at" : "2017-12-21 11:28:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79E6\u515D\u7684\u8DEF\u7531\u5668",
      "screen_name" : "fqrouter",
      "indices" : [ 3, 12 ],
      "id_str" : "281579156",
      "id" : 281579156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "943804678881587200",
  "text" : "\u79E6\u515D\uFF08@fqrouter\uFF09\u5931\u806F20\u5929\u3002",
  "id" : 943804678881587200,
  "created_at" : "2017-12-21 11:25:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/943802526654230528\/photo\/1",
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/WxrlWFYomd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRkPOD8VoAA8ima.jpg",
      "id_str" : "943802331161796608",
      "id" : 943802331161796608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRkPOD8VoAA8ima.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 609
      } ],
      "display_url" : "pic.twitter.com\/WxrlWFYomd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943800871074320384",
  "geo" : { },
  "id_str" : "943802526654230528",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u627E\u4E0D\u5230\u6539\u7684\u5730\u65B9\u554A~ https:\/\/t.co\/WxrlWFYomd",
  "id" : 943802526654230528,
  "in_reply_to_status_id" : 943800871074320384,
  "created_at" : "2017-12-21 11:17:12 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/943800871074320384\/photo\/1",
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/xAB5mgL1Iu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRkN1UwUQAAchH7.jpg",
      "id_str" : "943800806666420224",
      "id" : 943800806666420224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRkN1UwUQAAchH7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 352
      } ],
      "display_url" : "pic.twitter.com\/xAB5mgL1Iu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "943800871074320384",
  "text" : "\u5165\u63A8\u6642\u9593\u80FD\u6539\uFF1F https:\/\/t.co\/xAB5mgL1Iu",
  "id" : 943800871074320384,
  "created_at" : "2017-12-21 11:10:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kios #\u8036\u7A23\u9171\u751F\u65E5\u7279\u522B\u7248",
      "screen_name" : "7yinhuofuB7zhi",
      "indices" : [ 0, 15 ],
      "id_str" : "871645492077363201",
      "id" : 871645492077363201
    }, {
      "name" : "\u5149\u602A\u9646\u79BB\u7684Arewaty\uD83C\uDF84",
      "screen_name" : "Arewaty",
      "indices" : [ 16, 24 ],
      "id_str" : "754014048396513280",
      "id" : 754014048396513280
    }, {
      "name" : "\u795E\u697D\u5742\u6CC9@\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "KagurazakaIzumi",
      "indices" : [ 25, 41 ],
      "id_str" : "482695937",
      "id" : 482695937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/NqTEwon3Z5",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/920840465477402627",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "943786295498702849",
  "geo" : { },
  "id_str" : "943799007998042112",
  "in_reply_to_user_id" : 871645492077363201,
  "text" : "@7yinhuofuB7zhi @Arewaty @KagurazakaIzumi \u4E0D\u8981\u7528\u8F2A\u5B50\u4FC2\u68AF\u5B50\uFF0C\u7591\u4F3C\u88AB\u63A7\u5236\uFF1Ahttps:\/\/t.co\/NqTEwon3Z5",
  "id" : 943799007998042112,
  "in_reply_to_status_id" : 943786295498702849,
  "created_at" : "2017-12-21 11:03:13 +0000",
  "in_reply_to_screen_name" : "7yinhuofuB7zhi",
  "in_reply_to_user_id_str" : "871645492077363201",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943194445679247360",
  "geo" : { },
  "id_str" : "943795785317126144",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u4F60\u771F\u7684\u559C\u6B61\u4F60\u8F49\u7684\u90A3\u9EBD\u591A\u7D19\u7247\u5C0F\u59D0\u59D0\u55CE\uFF1F\u6211\u5237\u63A8\u5237\u591A\u4E86\uFF0C\u73FE\u5728\u770B\u5230\u90FD\u6C92\u6709\u611F\u89BA\u4E86~",
  "id" : 943795785317126144,
  "in_reply_to_status_id" : 943194445679247360,
  "created_at" : "2017-12-21 10:50:24 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/DjkuaCBB7B",
      "expanded_url" : "https:\/\/archive.is\/lFVVC",
      "display_url" : "archive.is\/lFVVC"
    } ]
  },
  "geo" : { },
  "id_str" : "943779589276479489",
  "text" : "\u738B\u5C3C\u746A\u88AB\u63A7\u5236\uFF1Ahttps:\/\/t.co\/DjkuaCBB7B",
  "id" : 943779589276479489,
  "created_at" : "2017-12-21 09:46:03 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "943776462582243328",
  "text" : "RT @dou4cc: @Calcutec114514 https:\/\/t.co\/2qDQXPQNMD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/2qDQXPQNMD",
        "expanded_url" : "https:\/\/twitter.com\/projectv2ray\/status\/898958448439709696",
        "display_url" : "twitter.com\/projectv2ray\/s\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "943773884297502721",
    "geo" : { },
    "id_str" : "943776400925954048",
    "in_reply_to_user_id" : 3359880735,
    "text" : "@Calcutec114514 https:\/\/t.co\/2qDQXPQNMD",
    "id" : 943776400925954048,
    "in_reply_to_status_id" : 943773884297502721,
    "created_at" : "2017-12-21 09:33:23 +0000",
    "in_reply_to_screen_name" : "dou4cc",
    "in_reply_to_user_id_str" : "3359880735",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 943776462582243328,
  "created_at" : "2017-12-21 09:33:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/2qDQXPQNMD",
      "expanded_url" : "https:\/\/twitter.com\/projectv2ray\/status\/898958448439709696",
      "display_url" : "twitter.com\/projectv2ray\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "943773884297502721",
  "geo" : { },
  "id_str" : "943776400925954048",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@Calcutec114514 https:\/\/t.co\/2qDQXPQNMD",
  "id" : 943776400925954048,
  "in_reply_to_status_id" : 943773884297502721,
  "created_at" : "2017-12-21 09:33:23 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/ZXGOipvFdD",
      "expanded_url" : "https:\/\/archive.is\/Psusv",
      "display_url" : "archive.is\/Psusv"
    } ]
  },
  "geo" : { },
  "id_str" : "943775388345552896",
  "text" : "Chrome\u5C07\u65BC2018\/02\/15\u81EA\u5E36\u5EE3\u544A\u6514\u622A\uFF1Ahttps:\/\/t.co\/ZXGOipvFdD",
  "id" : 943775388345552896,
  "created_at" : "2017-12-21 09:29:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch\u4E2D\u6587\u7248",
      "screen_name" : "TechCrunchCN",
      "indices" : [ 3, 16 ],
      "id_str" : "1565464544",
      "id" : 1565464544
    }, {
      "name" : "John Biggs",
      "screen_name" : "johnbiggs",
      "indices" : [ 63, 73 ],
      "id_str" : "788673",
      "id" : 788673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/UxzsetqSOu",
      "expanded_url" : "http:\/\/techcrunch.cn\/2017\/12\/19\/more-dead-commenters-appear-to-come-out-against-net-neutrality\/",
      "display_url" : "techcrunch.cn\/2017\/12\/19\/mor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "943775131767377920",
  "text" : "RT @TechCrunchCN: \u652F\u6301\u5E9F\u9664\u7F51\u7EDC\u4E2D\u7ACB\uFF0C\u6B7B\u4EBA\u52A0\u5165\u6C34\u519B\u53D1\u58F0 https:\/\/t.co\/UxzsetqSOu by @johnbiggs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/10up.com\" rel=\"nofollow\"\u003E10up Publish Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Biggs",
        "screen_name" : "johnbiggs",
        "indices" : [ 45, 55 ],
        "id_str" : "788673",
        "id" : 788673
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/UxzsetqSOu",
        "expanded_url" : "http:\/\/techcrunch.cn\/2017\/12\/19\/more-dead-commenters-appear-to-come-out-against-net-neutrality\/",
        "display_url" : "techcrunch.cn\/2017\/12\/19\/mor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "943086115141033984",
    "text" : "\u652F\u6301\u5E9F\u9664\u7F51\u7EDC\u4E2D\u7ACB\uFF0C\u6B7B\u4EBA\u52A0\u5165\u6C34\u519B\u53D1\u58F0 https:\/\/t.co\/UxzsetqSOu by @johnbiggs",
    "id" : 943086115141033984,
    "created_at" : "2017-12-19 11:50:26 +0000",
    "user" : {
      "name" : "TechCrunch\u4E2D\u6587\u7248",
      "screen_name" : "TechCrunchCN",
      "protected" : false,
      "id_str" : "1565464544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836425237159825409\/GpmdN2he_normal.jpg",
      "id" : 1565464544,
      "verified" : true
    }
  },
  "id" : 943775131767377920,
  "created_at" : "2017-12-21 09:28:20 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter kong",
      "screen_name" : "jbkk988",
      "indices" : [ 0, 8 ],
      "id_str" : "1977367500",
      "id" : 1977367500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942900139970011136",
  "geo" : { },
  "id_str" : "943774254667063296",
  "in_reply_to_user_id" : 1977367500,
  "text" : "@jbkk988 \u54C8\u54C8\u54C8\u54C8\u54C8",
  "id" : 943774254667063296,
  "in_reply_to_status_id" : 942900139970011136,
  "created_at" : "2017-12-21 09:24:51 +0000",
  "in_reply_to_screen_name" : "jbkk988",
  "in_reply_to_user_id_str" : "1977367500",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pilgrims",
      "screen_name" : "Calcutec114514",
      "indices" : [ 0, 15 ],
      "id_str" : "4241602824",
      "id" : 4241602824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "943131542682923008",
  "geo" : { },
  "id_str" : "943773884297502721",
  "in_reply_to_user_id" : 4241602824,
  "text" : "@Calcutec114514 \u771F\u662Ftrans\uFF1F",
  "id" : 943773884297502721,
  "in_reply_to_status_id" : 943131542682923008,
  "created_at" : "2017-12-21 09:23:23 +0000",
  "in_reply_to_screen_name" : "Calcutec114514",
  "in_reply_to_user_id_str" : "4241602824",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5468\u950B\u9501 Fengsuo Zhou",
      "screen_name" : "ZhouFengSuo",
      "indices" : [ 3, 15 ],
      "id_str" : "202963011",
      "id" : 202963011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "943767801067724800",
  "text" : "RT @ZhouFengSuo: Wu Xiangyang \u5434\u5411\u6D0B, owner of \u51E1\u72D7 teevpn was sentenced to 5.5 years in prison for selling VPN. \nThe harsh sentence raised many\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZhouFengSuo\/status\/943725067376005120\/photo\/1",
        "indices" : [ 261, 284 ],
        "url" : "https:\/\/t.co\/xeulM6A9GE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DRjI8VJUIAAO9-H.jpg",
        "id_str" : "943725060728037376",
        "id" : 943725060728037376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRjI8VJUIAAO9-H.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/xeulM6A9GE"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ZhouFengSuo\/status\/943725067376005120\/photo\/1",
        "indices" : [ 261, 284 ],
        "url" : "https:\/\/t.co\/xeulM6A9GE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DRjI8VMUEAAbDvu.jpg",
        "id_str" : "943725060740616192",
        "id" : 943725060740616192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRjI8VMUEAAbDvu.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1106
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 367
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1106
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 648
        } ],
        "display_url" : "pic.twitter.com\/xeulM6A9GE"
      } ],
      "hashtags" : [ {
        "text" : "China",
        "indices" : [ 254, 260 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "943725067376005120",
    "text" : "Wu Xiangyang \u5434\u5411\u6D0B, owner of \u51E1\u72D7 teevpn was sentenced to 5.5 years in prison for selling VPN. \nThe harsh sentence raised many questions since Wu was little known even among VPN users.\nHe quit his supposedly well paying job at Tencent to start this company.\n#China https:\/\/t.co\/xeulM6A9GE",
    "id" : 943725067376005120,
    "created_at" : "2017-12-21 06:09:24 +0000",
    "user" : {
      "name" : "\u5468\u950B\u9501 Fengsuo Zhou",
      "screen_name" : "ZhouFengSuo",
      "protected" : false,
      "id_str" : "202963011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925790201720463360\/eKh0SD6L_normal.jpg",
      "id" : 202963011,
      "verified" : false
    }
  },
  "id" : 943767801067724800,
  "created_at" : "2017-12-21 08:59:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u62A0\u811A\u80A5\u5B85\u5927\u6C49",
      "screen_name" : "hakureyuyuko",
      "indices" : [ 0, 13 ],
      "id_str" : "967252740",
      "id" : 967252740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942539624026484742",
  "geo" : { },
  "id_str" : "943105029657055238",
  "in_reply_to_user_id" : 967252740,
  "text" : "@hakureyuyuko \u53EF\u80FD\u662F\u9AD8\u7AEF\u4E94\u6BDB\uFF0C\u8ACB\u6C42\u516C\u4F48\u8A0E\u8AD6\u4E32\u3002",
  "id" : 943105029657055238,
  "in_reply_to_status_id" : 942539624026484742,
  "created_at" : "2017-12-19 13:05:35 +0000",
  "in_reply_to_screen_name" : "hakureyuyuko",
  "in_reply_to_user_id_str" : "967252740",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuki",
      "screen_name" : "yukixz",
      "indices" : [ 0, 7 ],
      "id_str" : "153642121",
      "id" : 153642121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940168876301545472",
  "geo" : { },
  "id_str" : "943103774293405697",
  "in_reply_to_user_id" : 153642121,
  "text" : "@yukixz Edge\u4EA6\u662F\u5982\u6B64\u3002",
  "id" : 943103774293405697,
  "in_reply_to_status_id" : 940168876301545472,
  "created_at" : "2017-12-19 13:00:36 +0000",
  "in_reply_to_screen_name" : "yukixz",
  "in_reply_to_user_id_str" : "153642121",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "943094249196834816",
  "text" : "\u611F\u89BA\u962E\u4E00\u5CF0\u73FE\u5728\u662F\u88AB\u8D0A\u52A9\u5546\u903C\u8457\u5BEB\u535A\u6587~",
  "id" : 943094249196834816,
  "created_at" : "2017-12-19 12:22:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/1Nnri9AT7A",
      "expanded_url" : "https:\/\/archive.is\/3P4iK",
      "display_url" : "archive.is\/3P4iK"
    } ]
  },
  "geo" : { },
  "id_str" : "943086894090514432",
  "text" : "\u806F\u901A\u88AB\u66DD\u5C0D\u5883\u5916\u624B\u6A5F\u5361\u6D41\u91CFDNS\u6C61\u67D3\uFF1Ahttps:\/\/t.co\/1Nnri9AT7A",
  "id" : 943086894090514432,
  "created_at" : "2017-12-19 11:53:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 0, 12 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942749973673795584",
  "geo" : { },
  "id_str" : "943082365588566017",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@DevinStever bl\u4E0D\u597D\u55CE\uFF1F",
  "id" : 943082365588566017,
  "in_reply_to_status_id" : 942749973673795584,
  "created_at" : "2017-12-19 11:35:32 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JavaScript Daily",
      "screen_name" : "JavaScriptDaily",
      "indices" : [ 3, 19 ],
      "id_str" : "459275531",
      "id" : 459275531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/jMkUt706dk",
      "expanded_url" : "https:\/\/dev.to\/voodooattack\/introducing-nexusjs-a-multi-threaded-javascript-run-time-3g6",
      "display_url" : "dev.to\/voodooattack\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "942723894204600320",
  "text" : "RT @JavaScriptDaily: Introducing Nexus.js: A Multi-Threaded JavaScript Runtime - https:\/\/t.co\/jMkUt706dk (Based on WebKit's JavaScriptCore,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/jMkUt706dk",
        "expanded_url" : "https:\/\/dev.to\/voodooattack\/introducing-nexusjs-a-multi-threaded-javascript-run-time-3g6",
        "display_url" : "dev.to\/voodooattack\/i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "942719102669508608",
    "text" : "Introducing Nexus.js: A Multi-Threaded JavaScript Runtime - https:\/\/t.co\/jMkUt706dk (Based on WebKit's JavaScriptCore, Nexus is based around a thread pool instead of an event loop.)",
    "id" : 942719102669508608,
    "created_at" : "2017-12-18 11:32:03 +0000",
    "user" : {
      "name" : "JavaScript Daily",
      "screen_name" : "JavaScriptDaily",
      "protected" : false,
      "id_str" : "459275531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877477206418653184\/W63ZlNa1_normal.jpg",
      "id" : 459275531,
      "verified" : false
    }
  },
  "id" : 942723894204600320,
  "created_at" : "2017-12-18 11:51:05 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942721880812871685",
  "geo" : { },
  "id_str" : "942722424851845120",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@39__bot \u6211\u53EF\u80FD\u65B7\u53E5\u56F0\u96E3\uFF0C\u597D\u5C37\u5C2C\uFF0C\u767C\u51FA\u7684\u63A8\u6587\u90FD\u88ABlike\uFF0C\u672C\u4F86\u60F3\u522A\u6389\u7684\u3002",
  "id" : 942722424851845120,
  "in_reply_to_status_id" : 942721880812871685,
  "created_at" : "2017-12-18 11:45:15 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942721527778127872",
  "geo" : { },
  "id_str" : "942721880812871685",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u201C\u4E0D\u958B\u5FC3\u201D\u662F\u201C\u4E0D\u559C\u6B61\u201D\u7684\u8CD3\u8A9E\u55CE\uFF1F",
  "id" : 942721880812871685,
  "in_reply_to_status_id" : 942721527778127872,
  "created_at" : "2017-12-18 11:43:05 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "safufu\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942718554037567493",
  "geo" : { },
  "id_str" : "942721454797393921",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \uFF1F\uFF1F\n\u7834\u58DE = \u556A\u556A\u556A\uFF1F",
  "id" : 942721454797393921,
  "in_reply_to_status_id" : 942718554037567493,
  "created_at" : "2017-12-18 11:41:24 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942700465505972224",
  "geo" : { },
  "id_str" : "942718176659427328",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u90A3\u908AMtF\u90A3\u9EBD\u6613\u788E\uFF0C\u9019\u908A\u5973\u5B69\u5B50\u958B\u8ECA\u958B\u6210\u9019\u6A23\u3002\u3002",
  "id" : 942718176659427328,
  "in_reply_to_status_id" : 942700465505972224,
  "created_at" : "2017-12-18 11:28:22 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942384976854622208",
  "geo" : { },
  "id_str" : "942716401512566786",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u7CBE\u6DB2\uFF1F\u4E0D\u662F\u5DF2\u7D93\u559D\u904E\u4E86\u55CE\uFF1F\n\u9084\u662F\u96C4\u6FC0\u7D20\uFF1F",
  "id" : 942716401512566786,
  "in_reply_to_status_id" : 942384976854622208,
  "created_at" : "2017-12-18 11:21:19 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/jJP00seBvr",
      "expanded_url" : "https:\/\/twitter.com\/kujou_rin\/status\/942684799457566721",
      "display_url" : "twitter.com\/kujou_rin\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "942711163682545664",
  "text" : "\u606D\u559C\u5165\u5751\uFF01 https:\/\/t.co\/jJP00seBvr",
  "id" : 942711163682545664,
  "created_at" : "2017-12-18 11:00:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/LlqYHl4v2R",
      "expanded_url" : "http:\/\/www.bbc.com\/zhongwen\/simp\/chinese-news-42382863",
      "display_url" : "bbc.com\/zhongwen\/simp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "942698339862241280",
  "text" : "\u4F4E\u7AEF\u85DD\u8853\u5BB6\u83EF\u6D8C\u7684\u6700\u540E\u6642\u523B\uFF1Ahttps:\/\/t.co\/LlqYHl4v2R",
  "id" : 942698339862241280,
  "created_at" : "2017-12-18 10:09:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/hRwtVmy4Nv",
      "expanded_url" : "https:\/\/archive.is\/4nH62",
      "display_url" : "archive.is\/4nH62"
    } ]
  },
  "geo" : { },
  "id_str" : "942367618249515008",
  "text" : "\u6170\u5B89\u5A66\u89F8\u52D5\u5927\u962A\u5E95\u7DAB\uFF1Ahttps:\/\/t.co\/hRwtVmy4Nv",
  "id" : 942367618249515008,
  "created_at" : "2017-12-17 12:15:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "safufu\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942066376625283073",
  "geo" : { },
  "id_str" : "942362233996283910",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u76F4\u63A5\u5165\u5634\u7684\u55CE\uFF1F\n\u6211\u8879\u662F\u51D1\u8FD1\u805E\u904E\uFF0C\u54EA\u5929\u4E5F\u559D\u9EDE\u8A66\u8A66~",
  "id" : 942362233996283910,
  "in_reply_to_status_id" : 942066376625283073,
  "created_at" : "2017-12-17 11:53:59 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79E6\u660E",
      "screen_name" : "KobeStones55",
      "indices" : [ 0, 13 ],
      "id_str" : "843138026951790593",
      "id" : 843138026951790593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "942344479901544449",
  "geo" : { },
  "id_str" : "942348768384573441",
  "in_reply_to_user_id" : 843138026951790593,
  "text" : "@KobeStones55 \u4F60\u8AAC\u624B\u7E8C\u8CBB\uFF1F",
  "id" : 942348768384573441,
  "in_reply_to_status_id" : 942344479901544449,
  "created_at" : "2017-12-17 11:00:29 +0000",
  "in_reply_to_screen_name" : "KobeStones55",
  "in_reply_to_user_id_str" : "843138026951790593",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "942340636593795072",
  "text" : "1\u6BD4\u7279\u5E63 \u2248 20000\u7F8E\u5143",
  "id" : 942340636593795072,
  "created_at" : "2017-12-17 10:28:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/1ghYfKhbRx",
      "expanded_url" : "https:\/\/archive.is\/S74vd",
      "display_url" : "archive.is\/S74vd"
    } ]
  },
  "geo" : { },
  "id_str" : "941936811114450944",
  "text" : "\u5927\u91CF\u6210\u4EBA\u8996\u983B\u73FE\u201C360\u6444\u50CF\u673A\u201D\u6C34\u5370\uFF1Ahttps:\/\/t.co\/1ghYfKhbRx",
  "id" : 941936811114450944,
  "created_at" : "2017-12-16 07:43:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/MUwZ6rdomv",
      "expanded_url" : "https:\/\/zh.wikipedia.org\/zh-cn\/%E4%B8%AD%E5%9B%BD%E5%A4%A7%E9%99%86%E8%89%BE%E6%BB%8B%E7%97%85%E6%83%85%E5%86%B5",
      "display_url" : "zh.wikipedia.org\/zh-cn\/%E4%B8%A\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "941918438099845120",
  "geo" : { },
  "id_str" : "941930757366472704",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot https:\/\/t.co\/MUwZ6rdomv",
  "id" : 941930757366472704,
  "in_reply_to_status_id" : 941918438099845120,
  "created_at" : "2017-12-16 07:19:27 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/EaK0Ef23Se",
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941925443850113024",
      "display_url" : "twitter.com\/dou4cc\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "941928773015998464",
  "text" : "\u5509~ https:\/\/t.co\/EaK0Ef23Se",
  "id" : 941928773015998464,
  "created_at" : "2017-12-16 07:11:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D62\u9999 \u732B @New Year \uD83C\uDF86",
      "screen_name" : "ayakaneko",
      "indices" : [ 0, 10 ],
      "id_str" : "791155015360667649",
      "id" : 791155015360667649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941484068763340800",
  "geo" : { },
  "id_str" : "941925443850113024",
  "in_reply_to_user_id" : 791155015360667649,
  "text" : "@ayakaneko \u7232\u4EC0\u9EBD\u7528facebook\u7684\u670D\u52D9\uFF1F",
  "id" : 941925443850113024,
  "in_reply_to_status_id" : 941484068763340800,
  "created_at" : "2017-12-16 06:58:20 +0000",
  "in_reply_to_screen_name" : "ayakaneko",
  "in_reply_to_user_id_str" : "791155015360667649",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941741225832472577",
  "geo" : { },
  "id_str" : "941922649730666496",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u5F8C\u9762\u9AD8\u6F6E\u540E\u6015\u51B7\uFF0C\u524D\u9762\u9AD8\u6F6E\u540E\u6015\u71B1\uFF1F",
  "id" : 941922649730666496,
  "in_reply_to_status_id" : 941741225832472577,
  "created_at" : "2017-12-16 06:47:14 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "Eric_2369",
      "indices" : [ 0, 10 ],
      "id_str" : "703752069396750336",
      "id" : 703752069396750336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931416732534788096",
  "geo" : { },
  "id_str" : "941921156004761600",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@Eric_2369\u522A\u5149\u4E86\u5979\u7684\u63A8\u6587\u3002",
  "id" : 941921156004761600,
  "in_reply_to_status_id" : 931416732534788096,
  "created_at" : "2017-12-16 06:41:18 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/nVm7BBDCou",
      "expanded_url" : "https:\/\/archive.is\/YMVYw",
      "display_url" : "archive.is\/YMVYw"
    } ]
  },
  "geo" : { },
  "id_str" : "941919776301076480",
  "text" : "\u7206\u51FA\u6F0F\u6D1E\u540E\uFF0CIntel ME\u5C07\u7981\u6B62\u7981\u7528\uFF1Ahttps:\/\/t.co\/nVm7BBDCou",
  "id" : 941919776301076480,
  "created_at" : "2017-12-16 06:35:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u534E\u5C14\u8857\u65E5\u62A5\u4E2D\u6587\u7F51",
      "screen_name" : "ChineseWSJ",
      "indices" : [ 3, 14 ],
      "id_str" : "46574977",
      "id" : 46574977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/6pX6vndSEk",
      "expanded_url" : "http:\/\/on.wsj.com\/2o6hiB2",
      "display_url" : "on.wsj.com\/2o6hiB2"
    } ]
  },
  "geo" : { },
  "id_str" : "941916774093770753",
  "text" : "RT @ChineseWSJ: \u7F8E\u56FD\u8BA1\u5212\u53D6\u6D88H-1B\u7B7E\u8BC1\u6301\u6709\u8005\u914D\u5076\u7684\u5728\u7F8E\u5DE5\u4F5C\u8D44\u683C\u4E86\uFF01\u56FD\u571F\u5B89\u5168\u90E8\u5468\u56DB\u53D1\u5E03\u901A\u77E5\u79F0\uFF0C\u8BA1\u5212\u5E9F\u9664\u5965\u5DF4\u9A6C\u65F6\u671F\u63A8\u51FA\u7684\u8FD9\u4E2A\u9879\u76EE\uFF0C\u8FD9\u662F\u5BF9\u4ECA\u5E74\u65E9\u4E9B\u65F6\u5019\u7279\u6717\u666E\u7B7E\u7F72\u7684\u201C\u4E70\u7F8E\u56FD\u8D27\u3001\u96C7\u7F8E\u56FD\u4EBA\u201D\u884C\u653F\u547D\u4EE4\u7684\u54CD\u5E94\u3002 https:\/\/t.co\/6pX6vndSEk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/6pX6vndSEk",
        "expanded_url" : "http:\/\/on.wsj.com\/2o6hiB2",
        "display_url" : "on.wsj.com\/2o6hiB2"
      } ]
    },
    "geo" : { },
    "id_str" : "941593171972296704",
    "text" : "\u7F8E\u56FD\u8BA1\u5212\u53D6\u6D88H-1B\u7B7E\u8BC1\u6301\u6709\u8005\u914D\u5076\u7684\u5728\u7F8E\u5DE5\u4F5C\u8D44\u683C\u4E86\uFF01\u56FD\u571F\u5B89\u5168\u90E8\u5468\u56DB\u53D1\u5E03\u901A\u77E5\u79F0\uFF0C\u8BA1\u5212\u5E9F\u9664\u5965\u5DF4\u9A6C\u65F6\u671F\u63A8\u51FA\u7684\u8FD9\u4E2A\u9879\u76EE\uFF0C\u8FD9\u662F\u5BF9\u4ECA\u5E74\u65E9\u4E9B\u65F6\u5019\u7279\u6717\u666E\u7B7E\u7F72\u7684\u201C\u4E70\u7F8E\u56FD\u8D27\u3001\u96C7\u7F8E\u56FD\u4EBA\u201D\u884C\u653F\u547D\u4EE4\u7684\u54CD\u5E94\u3002 https:\/\/t.co\/6pX6vndSEk",
    "id" : 941593171972296704,
    "created_at" : "2017-12-15 08:58:00 +0000",
    "user" : {
      "name" : "\u534E\u5C14\u8857\u65E5\u62A5\u4E2D\u6587\u7F51",
      "screen_name" : "ChineseWSJ",
      "protected" : false,
      "id_str" : "46574977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324615974\/WSJ_tSina_pic_normal.jpg",
      "id" : 46574977,
      "verified" : false
    }
  },
  "id" : 941916774093770753,
  "created_at" : "2017-12-16 06:23:53 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/mFELnUUlgb",
      "expanded_url" : "https:\/\/archive.is\/wXzdf",
      "display_url" : "archive.is\/wXzdf"
    } ]
  },
  "geo" : { },
  "id_str" : "941912631841120256",
  "text" : "\u4E2D\u5171\u70BA\u570B\u5BB6\u5B89\u5168\u7981\u6B62\u570B\u5916\u81EA\u52D5\u99D5\u99DB\u6C7D\u8ECA\u4E0A\u8DEF\uFF1Ahttps:\/\/t.co\/mFELnUUlgb",
  "id" : 941912631841120256,
  "created_at" : "2017-12-16 06:07:25 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79E6\u515D\u7684\u8DEF\u7531\u5668",
      "screen_name" : "fqrouter",
      "indices" : [ 3, 12 ],
      "id_str" : "281579156",
      "id" : 281579156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "941909112979378176",
  "text" : "\u79E6\u515D\uFF08@fqrouter\uFF09\u5931\u806F15\u5929\u3002",
  "id" : 941909112979378176,
  "created_at" : "2017-12-16 05:53:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941546902629376000\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/qEJHwUM7xB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DREL4DmXcAA1GxS.jpg",
      "id_str" : "941546854763950080",
      "id" : 941546854763950080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DREL4DmXcAA1GxS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qEJHwUM7xB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/jjujRPXm2B",
      "expanded_url" : "https:\/\/www.battleforthenet.com\/",
      "display_url" : "battleforthenet.com"
    } ]
  },
  "in_reply_to_status_id_str" : "941546707447361536",
  "geo" : { },
  "id_str" : "941546902629376000",
  "in_reply_to_user_id" : 3359880735,
  "text" : "Congress can overrule the FCC vote. This is how.https:\/\/t.co\/jjujRPXm2B https:\/\/t.co\/qEJHwUM7xB",
  "id" : 941546902629376000,
  "in_reply_to_status_id" : 941546707447361536,
  "created_at" : "2017-12-15 05:54:09 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PDKPWLqSFU",
      "expanded_url" : "https:\/\/twitter.com\/TheNextWeb\/status\/941534556452159489",
      "display_url" : "twitter.com\/TheNextWeb\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "941546470917984256",
  "geo" : { },
  "id_str" : "941546707447361536",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/PDKPWLqSFU",
  "id" : 941546707447361536,
  "in_reply_to_status_id" : 941546470917984256,
  "created_at" : "2017-12-15 05:53:22 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gc7rDw3kYx",
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/941518195478863873",
      "display_url" : "twitter.com\/engadget\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "941230836325773313",
  "geo" : { },
  "id_str" : "941546470917984256",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/gc7rDw3kYx",
  "id" : 941546470917984256,
  "in_reply_to_status_id" : 941230836325773313,
  "created_at" : "2017-12-15 05:52:26 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "%\u7BE0\u539F\u86CD(\u8C03\u8BD5)",
      "screen_name" : "shinoharahotaru",
      "indices" : [ 0, 16 ],
      "id_str" : "885571903565385728",
      "id" : 885571903565385728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941270619857018880",
  "geo" : { },
  "id_str" : "941536422175092736",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@shinoharahotaru Welcome back!",
  "id" : 941536422175092736,
  "in_reply_to_status_id" : 941270619857018880,
  "created_at" : "2017-12-15 05:12:30 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941274516554244097\/photo\/1",
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/FQfaSE0IEO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRAUK9bXUAAzHtC.jpg",
      "id_str" : "941274500641017856",
      "id" : 941274500641017856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRAUK9bXUAAzHtC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 857,
        "resize" : "fit",
        "w" : 1319
      }, {
        "h" : 780,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 857,
        "resize" : "fit",
        "w" : 1319
      } ],
      "display_url" : "pic.twitter.com\/FQfaSE0IEO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "941274516554244097",
  "text" : "Why? https:\/\/t.co\/FQfaSE0IEO",
  "id" : 941274516554244097,
  "created_at" : "2017-12-14 11:51:47 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941271790780895232\/photo\/1",
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/YHf3aSyDcm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DRARp6mXkAACzmD.jpg",
      "id_str" : "941271733922926592",
      "id" : 941271733922926592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DRARp6mXkAACzmD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 588,
        "resize" : "fit",
        "w" : 1292
      }, {
        "h" : 588,
        "resize" : "fit",
        "w" : 1292
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/YHf3aSyDcm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "941271790780895232",
  "text" : "Why? https:\/\/t.co\/YHf3aSyDcm",
  "id" : 941271790780895232,
  "created_at" : "2017-12-14 11:40:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "username here",
      "screen_name" : "shinoharahotaru",
      "indices" : [ 0, 16 ],
      "id_str" : "885571903565385728",
      "id" : 885571903565385728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931416732534788096",
  "geo" : { },
  "id_str" : "941270619857018880",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@shinoharahotaru\u522A\u9664\u4E86\u5979\u7684\u8CEC\u865F\uFF0C\u540C\u5927\u534A\u5E74\u4F86\u7684\u4E0A\u767E\u689D\u63A8\u6587\u4E00\u8D77\u6D88\u5931\u3002",
  "id" : 941270619857018880,
  "in_reply_to_status_id" : 931416732534788096,
  "created_at" : "2017-12-14 11:36:18 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/eYsQS6CrY5",
      "expanded_url" : "https:\/\/archive.is\/9GCjZ",
      "display_url" : "archive.is\/9GCjZ"
    } ]
  },
  "geo" : { },
  "id_str" : "941266470700568576",
  "text" : "IoT\u50F5\u5C38\u7DB2\u7D61\u7834\u58DE\u8005\u8FEB\u65BC\u58D3\u529B\u9000\u51FAInternet Chemotherapy\u904B\u52D5\uFF1Ahttps:\/\/t.co\/eYsQS6CrY5",
  "id" : 941266470700568576,
  "created_at" : "2017-12-14 11:19:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/NaQjFC6jih",
      "expanded_url" : "https:\/\/archive.is\/4kPsT",
      "display_url" : "archive.is\/4kPsT"
    } ]
  },
  "geo" : { },
  "id_str" : "941265105190379520",
  "text" : "\u7E7C\u5929\u7DB2\u9805\u76EE\uFF0C\u4E2D\u5171\u5728\u65B0\u7586\u958B\u5C55\u4EBA\u53E3\u7CBE\u6E96\u767B\u8A18\u6838\u5BE6\u5DE5\u4F5C\uFF0C\u5F3A\u5236\u6536\u96C6\u4E3B\u8981\u5E74\u9F61\u6BB5\u4EBA\u7FA4\u7684\u751F\u7269\u4FE1\u606F\uFF0C\u5305\u62EC\u4F46\u4E0D\u9650\u65BC\u4EBA\u50CF\u3001\u6307\u7D0B\u3001\u8679\u819C\uFF1Ahttps:\/\/t.co\/NaQjFC6jih",
  "id" : 941265105190379520,
  "created_at" : "2017-12-14 11:14:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    }, {
      "name" : "Kios",
      "screen_name" : "7yinhuofuB7zhi",
      "indices" : [ 9, 24 ],
      "id_str" : "871645492077363201",
      "id" : 871645492077363201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941262362740375552",
  "geo" : { },
  "id_str" : "941262485792976896",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot @7yinhuofuB7zhi \u679C\u7136\u8001\u4E86\u3002\u3002",
  "id" : 941262485792976896,
  "in_reply_to_status_id" : 941262362740375552,
  "created_at" : "2017-12-14 11:03:59 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kios #\u8036\u7A23\u9171\u751F\u65E5\u7279\u522B\u7248",
      "screen_name" : "7yinhuofuB7zhi",
      "indices" : [ 0, 15 ],
      "id_str" : "871645492077363201",
      "id" : 871645492077363201
    }, {
      "name" : "safufu\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 16, 24 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941253854888259584",
  "geo" : { },
  "id_str" : "941261953607094278",
  "in_reply_to_user_id" : 871645492077363201,
  "text" : "@7yinhuofuB7zhi @39__bot \u4F60\u6CE8\u518A\u50C56\u6708\u5C31\u767C\u4E865000+\u63A8\u6587\uFF0C\u559C\u6B61\u7684\u63A8\u6587\u63A5\u8FD13\u842C\uFF0C\u5728bio\u4E2D\u7D66\u4EBA\u6263\u5E3D\u5B50\u3001\u4EBA\u8EAB\u653B\u64CA\uFF0C\u5927\u91CF\u8F49\u767C\u653F\u6CBB\u6C34\u6587\uFF0C\u884C\u6587\u63A5\u8FD1\u6C34\u8ECD\u3002\u5982\u679C\u932F\u8A8D\uFF0C\u5728\u6B64\u62B1\u6B49\u3002",
  "id" : 941261953607094278,
  "in_reply_to_status_id" : 941253854888259584,
  "created_at" : "2017-12-14 11:01:52 +0000",
  "in_reply_to_screen_name" : "7yinhuofuB7zhi",
  "in_reply_to_user_id_str" : "871645492077363201",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941122012017074176",
  "geo" : { },
  "id_str" : "941236101838143488",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u4E26\u4E0D\u559C\u6B61\u5B78\u6821\uFF0C\u8879\u662F\u5C0D\u6BD4\u4F60\u5011\u611F\u89BA\u81EA\u5DF1\u5F88\u5931\u843D\u3002",
  "id" : 941236101838143488,
  "in_reply_to_status_id" : 941122012017074176,
  "created_at" : "2017-12-14 09:19:08 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941233458050842624",
  "geo" : { },
  "id_str" : "941233599973675009",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u62B1\u6B49",
  "id" : 941233599973675009,
  "in_reply_to_status_id" : 941233458050842624,
  "created_at" : "2017-12-14 09:09:12 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0D\u4F1A\u55B5\u55B5\u55B5\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941232964561551360",
  "geo" : { },
  "id_str" : "941233142123384832",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u73FE\u5728\u8B8A\u6210\u4E86\u5169\u500B\u554F\u984C\u3002\u3002",
  "id" : 941233142123384832,
  "in_reply_to_status_id" : 941232964561551360,
  "created_at" : "2017-12-14 09:07:23 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941232674357723136",
  "geo" : { },
  "id_str" : "941232815781314562",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u81EA\u613F\u9084\u662F\u88AB\u8FEB\uFF1F",
  "id" : 941232815781314562,
  "in_reply_to_status_id" : 941232674357723136,
  "created_at" : "2017-12-14 09:06:05 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00CAtr-\u0410\u0443-M\u00F5d\u00EB",
      "screen_name" : "Roux_boost_lux",
      "indices" : [ 3, 18 ],
      "id_str" : "811477924498915328",
      "id" : 811477924498915328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "941232687095992323",
  "text" : "RT @Roux_boost_lux: \u4F59\u5149\u4E2D\uFF081928\u5E7410\u670821\u65E5\uFF0D2017\u5E7412\u670814\u65E5\uFF09\uFF0C\u751F\u4E8E\u5357\u4EAC\uFF0C\u7C4D\u8D2F\u798F\u5EFA\u6CC9\u5DDE\u6C38\u6625\uFF0C\u901D\u4E16\u4E8E\u9AD8\u96C4\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "941182687540211712",
    "text" : "\u4F59\u5149\u4E2D\uFF081928\u5E7410\u670821\u65E5\uFF0D2017\u5E7412\u670814\u65E5\uFF09\uFF0C\u751F\u4E8E\u5357\u4EAC\uFF0C\u7C4D\u8D2F\u798F\u5EFA\u6CC9\u5DDE\u6C38\u6625\uFF0C\u901D\u4E16\u4E8E\u9AD8\u96C4\u3002",
    "id" : 941182687540211712,
    "created_at" : "2017-12-14 05:46:53 +0000",
    "user" : {
      "name" : "\u00CAtr-\u0410\u0443-M\u00F5d\u00EB",
      "screen_name" : "Roux_boost_lux",
      "protected" : false,
      "id_str" : "811477924498915328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941553991288107008\/W54IdIdc_normal.jpg",
      "id" : 811477924498915328,
      "verified" : false
    }
  },
  "id" : 941232687095992323,
  "created_at" : "2017-12-14 09:05:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941198198198099968",
  "geo" : { },
  "id_str" : "941232607420993536",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u4F60\u54E5\u662F\u9AD8\u4E2D\u751F\u55CE\uFF1F",
  "id" : 941232607420993536,
  "in_reply_to_status_id" : 941198198198099968,
  "created_at" : "2017-12-14 09:05:15 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941230836325773313\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/JZfvru76cp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQ_scrxVAAIJCQn.jpg",
      "id_str" : "941230824673837058",
      "id" : 941230824673837058,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQ_scrxVAAIJCQn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 533
      } ],
      "display_url" : "pic.twitter.com\/JZfvru76cp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940881195344285696",
  "geo" : { },
  "id_str" : "941230836325773313",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/JZfvru76cp",
  "id" : 941230836325773313,
  "in_reply_to_status_id" : 940881195344285696,
  "created_at" : "2017-12-14 08:58:13 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kios",
      "screen_name" : "7yinhuofuB7zhi",
      "indices" : [ 0, 15 ],
      "id_str" : "871645492077363201",
      "id" : 871645492077363201
    }, {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 16, 24 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941145683037364224",
  "geo" : { },
  "id_str" : "941228171025965056",
  "in_reply_to_user_id" : 871645492077363201,
  "text" : "@7yinhuofuB7zhi @39__bot \u80FD\u89E3\u91CB\u4E00\u4E0B\u4F60\u7684\u767C\u5E16\u91CF\u55CE\uFF1F",
  "id" : 941228171025965056,
  "in_reply_to_status_id" : 941145683037364224,
  "created_at" : "2017-12-14 08:47:37 +0000",
  "in_reply_to_screen_name" : "7yinhuofuB7zhi",
  "in_reply_to_user_id_str" : "871645492077363201",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941227203399995392\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/zLgk9BspDm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQ_pITWX0AA8Leu.jpg",
      "id_str" : "941227175986057216",
      "id" : 941227175986057216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQ_pITWX0AA8Leu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 525
      } ],
      "display_url" : "pic.twitter.com\/zLgk9BspDm"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/941227203399995392\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/zLgk9BspDm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQ_pITXX0AAcYfp.jpg",
      "id_str" : "941227175990251520",
      "id" : 941227175990251520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQ_pITXX0AAcYfp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 819
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 819
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 819
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/zLgk9BspDm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "941227203399995392",
  "text" : "Phus Lu\u53CD\u5BE9\u67E5\u751F\u6DAF\u7684\u5C3E\u8072\uFF1A https:\/\/t.co\/zLgk9BspDm",
  "id" : 941227203399995392,
  "created_at" : "2017-12-14 08:43:47 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941121184074051585",
  "geo" : { },
  "id_str" : "941121371547078656",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u3002\u3002\u3002\n\u6211\u4E16\u754C\u89C0\u5D29\u584C\u4E86\u3002\u3002\n\u63A8\u4E0A\u90FD\u662F\u4EC0\u9EBD\u4EBA\u554A\u3002\u3002\u3002\u3002\u3002",
  "id" : 941121371547078656,
  "in_reply_to_status_id" : 941121184074051585,
  "created_at" : "2017-12-14 01:43:14 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941120480949309440",
  "geo" : { },
  "id_str" : "941121052670873603",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u521D\u4E2D\u7562\u696D\uFF1F",
  "id" : 941121052670873603,
  "in_reply_to_status_id" : 941120480949309440,
  "created_at" : "2017-12-14 01:41:58 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yesh13",
      "screen_name" : "yesh132",
      "indices" : [ 0, 8 ],
      "id_str" : "2879755227",
      "id" : 2879755227
    }, {
      "name" : "\u4E0D\u6234\u773C\u955C\uFF0C\u4F46\u773C\u955C\u662F\u672C\u4F53\uFF0C\u6545\u65E0\u5B58\u5728\u611F",
      "screen_name" : "GClover1985",
      "indices" : [ 9, 21 ],
      "id_str" : "190942865",
      "id" : 190942865
    }, {
      "name" : "\u4E03\u5200",
      "screen_name" : "gehouhun",
      "indices" : [ 22, 31 ],
      "id_str" : "43650503",
      "id" : 43650503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940995985722839041",
  "geo" : { },
  "id_str" : "941120596800192517",
  "in_reply_to_user_id" : 2879755227,
  "text" : "@yesh132 @GClover1985 @gehouhun \u8B58\u5225\u51FA\u7684\u6587\u5B57\u5B58\u591A\u4E45\uFF1F",
  "id" : 941120596800192517,
  "in_reply_to_status_id" : 940995985722839041,
  "created_at" : "2017-12-14 01:40:10 +0000",
  "in_reply_to_screen_name" : "yesh132",
  "in_reply_to_user_id_str" : "2879755227",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yesh13",
      "screen_name" : "yesh132",
      "indices" : [ 3, 11 ],
      "id_str" : "2879755227",
      "id" : 2879755227
    }, {
      "name" : "\u4E0D\u6234\u773C\u955C\uFF0C\u4F46\u773C\u955C\u662F\u672C\u4F53\uFF0C\u6545\u65E0\u5B58\u5728\u611F",
      "screen_name" : "GClover1985",
      "indices" : [ 13, 25 ],
      "id_str" : "190942865",
      "id" : 190942865
    }, {
      "name" : "\u4E03\u5200",
      "screen_name" : "gehouhun",
      "indices" : [ 26, 35 ],
      "id_str" : "43650503",
      "id" : 43650503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "941120548477775873",
  "text" : "RT @yesh132: @GClover1985 @gehouhun \u8FD0\u8425\u5546\u8BED\u97F3\u7559\u5B58\u670911\u4E2A\u6708\uFF0C\u6240\u4EE5\u5404\u4F4D\u4EB2\u4EEC\uD83D\uDE02",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u4E0D\u6234\u773C\u955C\uFF0C\u4F46\u773C\u955C\u662F\u672C\u4F53\uFF0C\u6545\u65E0\u5B58\u5728\u611F",
        "screen_name" : "GClover1985",
        "indices" : [ 0, 12 ],
        "id_str" : "190942865",
        "id" : 190942865
      }, {
        "name" : "\u4E03\u5200",
        "screen_name" : "gehouhun",
        "indices" : [ 13, 22 ],
        "id_str" : "43650503",
        "id" : 43650503
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "940827238836178945",
    "geo" : { },
    "id_str" : "940995985722839041",
    "in_reply_to_user_id" : 190942865,
    "text" : "@GClover1985 @gehouhun \u8FD0\u8425\u5546\u8BED\u97F3\u7559\u5B58\u670911\u4E2A\u6708\uFF0C\u6240\u4EE5\u5404\u4F4D\u4EB2\u4EEC\uD83D\uDE02",
    "id" : 940995985722839041,
    "in_reply_to_status_id" : 940827238836178945,
    "created_at" : "2017-12-13 17:25:00 +0000",
    "in_reply_to_screen_name" : "GClover1985",
    "in_reply_to_user_id_str" : "190942865",
    "user" : {
      "name" : "yesh13",
      "screen_name" : "yesh132",
      "protected" : false,
      "id_str" : "2879755227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860176154367361025\/kmby7SZ8_normal.jpg",
      "id" : 2879755227,
      "verified" : false
    }
  },
  "id" : 941120548477775873,
  "created_at" : "2017-12-14 01:39:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "941118255300616192",
  "geo" : { },
  "id_str" : "941119850835075072",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u5317\u4EAC\u9AD8\u4E2D\u751F\uFF1F",
  "id" : 941119850835075072,
  "in_reply_to_status_id" : 941118255300616192,
  "created_at" : "2017-12-14 01:37:12 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940911333616230400",
  "geo" : { },
  "id_str" : "940911668615401472",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u53EA\u554F\u4F60\u3001\u4E0D\u81EA\u6211\u4ECB\u7D39\uFF0C\u6709\u5957\u53D6\u4FE1\u606F\u7684\u5ACC\u7591\u3002",
  "id" : 940911668615401472,
  "in_reply_to_status_id" : 940911333616230400,
  "created_at" : "2017-12-13 11:49:57 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "safufu\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940905109617221633",
  "geo" : { },
  "id_str" : "940910898876747776",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u6211\u662F\u7368\u751F\u5B50\u3001\u7537\u5B69\u5B50\u3001\u9AD8\u4E2D\u751F\uFF0C\u4F60\u770B\u5F97\u5230\u6211\u7684\u751F\u8FB0\u5E74\u6708\u3002",
  "id" : 940910898876747776,
  "in_reply_to_status_id" : 940905109617221633,
  "created_at" : "2017-12-13 11:46:54 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poi\u2642next\u2642door",
      "screen_name" : "v2_poi",
      "indices" : [ 0, 7 ],
      "id_str" : "1092469987",
      "id" : 1092469987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940908460622909440",
  "geo" : { },
  "id_str" : "940910085689237504",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@v2_poi \u88DC\u5145\u4E00\u4E0B\uFF0C\u6211\u68AF\u5B50\u6240\u6709\u6D41\u91CF\u8D70\u4E2D\u8F49\uFF0C\u4E0D\u7522\u751F\u4EFB\u4F55\u5883\u5916\u6D41\u91CF\u3002",
  "id" : 940910085689237504,
  "in_reply_to_status_id" : 940908460622909440,
  "created_at" : "2017-12-13 11:43:40 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "Poi\u2642next\u2642door",
      "screen_name" : "v2_poi",
      "indices" : [ 12, 19 ],
      "id_str" : "1092469987",
      "id" : 1092469987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "940908864144330752",
  "text" : "RT @dou4cc: @v2_poi \u6211\u4E5F\u7D93\u5E38\u9047\u5230\u9019\u7A2E\u60C5\u6CC1\uFF0C\u901A\u5E38\u628A\u68AF\u5B50\u95DC\u6389\u3001\u7B49\u5E7E\u5206\u9418\u5C31\u597D\u4E86\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Poi\u2642next\u2642door",
        "screen_name" : "v2_poi",
        "indices" : [ 0, 7 ],
        "id_str" : "1092469987",
        "id" : 1092469987
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "940648058320076805",
    "geo" : { },
    "id_str" : "940908460622909440",
    "in_reply_to_user_id" : 1092469987,
    "text" : "@v2_poi \u6211\u4E5F\u7D93\u5E38\u9047\u5230\u9019\u7A2E\u60C5\u6CC1\uFF0C\u901A\u5E38\u628A\u68AF\u5B50\u95DC\u6389\u3001\u7B49\u5E7E\u5206\u9418\u5C31\u597D\u4E86\u3002",
    "id" : 940908460622909440,
    "in_reply_to_status_id" : 940648058320076805,
    "created_at" : "2017-12-13 11:37:12 +0000",
    "in_reply_to_screen_name" : "v2_poi",
    "in_reply_to_user_id_str" : "1092469987",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 940908864144330752,
  "created_at" : "2017-12-13 11:38:49 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poi\u2642next\u2642door",
      "screen_name" : "v2_poi",
      "indices" : [ 0, 7 ],
      "id_str" : "1092469987",
      "id" : 1092469987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940648058320076805",
  "geo" : { },
  "id_str" : "940908460622909440",
  "in_reply_to_user_id" : 1092469987,
  "text" : "@v2_poi \u6211\u4E5F\u7D93\u5E38\u9047\u5230\u9019\u7A2E\u60C5\u6CC1\uFF0C\u901A\u5E38\u628A\u68AF\u5B50\u95DC\u6389\u3001\u7B49\u5E7E\u5206\u9418\u5C31\u597D\u4E86\u3002",
  "id" : 940908460622909440,
  "in_reply_to_status_id" : 940648058320076805,
  "created_at" : "2017-12-13 11:37:12 +0000",
  "in_reply_to_screen_name" : "v2_poi",
  "in_reply_to_user_id_str" : "1092469987",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940903822926405632",
  "geo" : { },
  "id_str" : "940904393242705920",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u53CC\u72EC\u4E24\u5B69\uFF1F",
  "id" : 940904393242705920,
  "in_reply_to_status_id" : 940903822926405632,
  "created_at" : "2017-12-13 11:21:03 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "safufu\u768439\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940903245135908864",
  "geo" : { },
  "id_str" : "940903690730459138",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@39__bot \uFF08\u4E0D\u56DE\u5FA9\u7684\u9EBD\uFF1F\uFF09",
  "id" : 940903690730459138,
  "in_reply_to_status_id" : 940903245135908864,
  "created_at" : "2017-12-13 11:18:15 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F4E\u7AEF39\u2019",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940852484368629760",
  "geo" : { },
  "id_str" : "940903245135908864",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u4F60\u54E5\u54E5\u591A\u5927\uFF1F",
  "id" : 940903245135908864,
  "in_reply_to_status_id" : 940852484368629760,
  "created_at" : "2017-12-13 11:16:29 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/VVaZfltMEf",
      "expanded_url" : "https:\/\/archive.is\/pcZm2",
      "display_url" : "archive.is\/pcZm2"
    } ]
  },
  "geo" : { },
  "id_str" : "940898681481555974",
  "text" : "\u7F8E\u570B\u7ACB\u6CD5\u7981\u6B62\u806F\u90A6\u653F\u5E9C\u4F7F\u7528\u5361\u5DF4\u65AF\u57FA\uFF1Ahttps:\/\/t.co\/VVaZfltMEf",
  "id" : 940898681481555974,
  "created_at" : "2017-12-13 10:58:21 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/bMG7aCL1SA",
      "expanded_url" : "https:\/\/archive.is\/I3j3j",
      "display_url" : "archive.is\/I3j3j"
    } ]
  },
  "geo" : { },
  "id_str" : "940896544584290309",
  "text" : "Google\u6210\u7ACBAI\u4E2D\u570B\u4E2D\u5FC3\uFF1Ahttps:\/\/t.co\/bMG7aCL1SA",
  "id" : 940896544584290309,
  "created_at" : "2017-12-13 10:49:51 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940724843133243392",
  "geo" : { },
  "id_str" : "940881195344285696",
  "in_reply_to_user_id" : 3359880735,
  "text" : "mmp\uFF0Cwidget\u4F7F\u7528\u7684\u5C45\u7136\u662F\u672C\u5730\u6642\u5340\u3002\u3002\u9084\u4EE5\u7232\u5012\u8A08\u6642\u6B78\u96F6\u4E4B\u5F8C\u662F\u4EC0\u9EBD\u91CD\u8981\u4E8B\u4EF6\u3002\u3002",
  "id" : 940881195344285696,
  "in_reply_to_status_id" : 940724843133243392,
  "created_at" : "2017-12-13 09:48:52 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/940724843133243392\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/UoNn90xJAn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQ4gPvsWsAAqUAG.jpg",
      "id_str" : "940724827039641600",
      "id" : 940724827039641600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQ4gPvsWsAAqUAG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 532
      } ],
      "display_url" : "pic.twitter.com\/UoNn90xJAn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940450189835423745",
  "geo" : { },
  "id_str" : "940724843133243392",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/UoNn90xJAn",
  "id" : 940724843133243392,
  "in_reply_to_status_id" : 940450189835423745,
  "created_at" : "2017-12-12 23:27:35 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/rQEYPwLBiG",
      "expanded_url" : "https:\/\/archive.is\/YwtYc",
      "display_url" : "archive.is\/YwtYc"
    } ]
  },
  "geo" : { },
  "id_str" : "940547106112143360",
  "text" : "\u5883\u5185ISP\u5168\u9762\u5553\u7528\u6A5F\u5668\u5B78\u7FD2\uFF1Ahttps:\/\/t.co\/rQEYPwLBiG",
  "id" : 940547106112143360,
  "created_at" : "2017-12-12 11:41:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/tcHCVl9l9O",
      "expanded_url" : "https:\/\/archive.is\/V1IxV",
      "display_url" : "archive.is\/V1IxV"
    } ]
  },
  "geo" : { },
  "id_str" : "940545847397412864",
  "text" : "\u6BD4\u7279\u5E63\u4EA4\u6613\u8CBB\u98C6\u5347\uFF1Ahttps:\/\/t.co\/tcHCVl9l9O",
  "id" : 940545847397412864,
  "created_at" : "2017-12-12 11:36:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 0, 9 ],
      "id_str" : "45630895",
      "id" : 45630895
    }, {
      "name" : "Beryl",
      "screen_name" : "Beryl_snw",
      "indices" : [ 10, 20 ],
      "id_str" : "244847248",
      "id" : 244847248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940543228821913601",
  "geo" : { },
  "id_str" : "940544093356285952",
  "in_reply_to_user_id" : 45630895,
  "text" : "@chengr28 @Beryl_snw \u6211\u78BA\u5BE6\u932F\u4E86\u3002",
  "id" : 940544093356285952,
  "in_reply_to_status_id" : 940543228821913601,
  "created_at" : "2017-12-12 11:29:20 +0000",
  "in_reply_to_screen_name" : "chengr28",
  "in_reply_to_user_id_str" : "45630895",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beryl",
      "screen_name" : "Beryl_snw",
      "indices" : [ 0, 10 ],
      "id_str" : "244847248",
      "id" : 244847248
    }, {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 11, 20 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940535933597777920",
  "geo" : { },
  "id_str" : "940541030860017665",
  "in_reply_to_user_id" : 3359880735,
  "text" : "@Beryl_snw @chengr28 \u63A8\u6587\u88CF\u7684\u8996\u983B\u505A\u5F97\u4E0D\u5982u2b\uFF0C\u4E0D\u904E\u6211\u96A8\u624B\u9EDE\u958B\u7684\u8996\u983B\u90FD\u80FD\u6D41\u66A2720p\u3002\u9084\u6709\uFF0C\u4F60\u7684\u901F\u5EA6\u662F2Mbps\u800C\u975E20Mbps\u3002",
  "id" : 940541030860017665,
  "in_reply_to_status_id" : 940535933597777920,
  "created_at" : "2017-12-12 11:17:10 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/GM22VbMvQb",
      "expanded_url" : "https:\/\/archive.is\/8JFp4",
      "display_url" : "archive.is\/8JFp4"
    } ]
  },
  "geo" : { },
  "id_str" : "940539152201932800",
  "text" : "Microsoft\u767C\u4F48Q#\u91CF\u5B50\u8A9E\u8A00\uFF1Ahttps:\/\/t.co\/GM22VbMvQb",
  "id" : 940539152201932800,
  "created_at" : "2017-12-12 11:09:42 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beryl",
      "screen_name" : "Beryl_snw",
      "indices" : [ 0, 10 ],
      "id_str" : "244847248",
      "id" : 244847248
    }, {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 11, 20 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/940535933597777920\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/9yVwtBi2ip",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQ10bwEVQAAfoZr.jpg",
      "id_str" : "940535917298663424",
      "id" : 940535917298663424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQ10bwEVQAAfoZr.jpg",
      "sizes" : [ {
        "h" : 851,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 851,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 851,
        "resize" : "fit",
        "w" : 616
      } ],
      "display_url" : "pic.twitter.com\/9yVwtBi2ip"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940453810073362432",
  "geo" : { },
  "id_str" : "940535933597777920",
  "in_reply_to_user_id" : 244847248,
  "text" : "@Beryl_snw @chengr28 \u6700\u8A0E\u53AD\u7684\u662F\u4E0D\u80FD\u624B\u52D5\u66F4\u6539\u756B\u8CEA\uFF0C\u9084\u6709\uFF0C\u4F60\u7684\u901F\u5EA6\u662F\u771F\u7684\u4F4E\uFF1A https:\/\/t.co\/9yVwtBi2ip",
  "id" : 940535933597777920,
  "in_reply_to_status_id" : 940453810073362432,
  "created_at" : "2017-12-12 10:56:55 +0000",
  "in_reply_to_screen_name" : "Beryl_snw",
  "in_reply_to_user_id_str" : "244847248",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beryl",
      "screen_name" : "Beryl_snw",
      "indices" : [ 0, 10 ],
      "id_str" : "244847248",
      "id" : 244847248
    }, {
      "name" : "28\u5C0F\u76C6\u53CB",
      "screen_name" : "chengr28",
      "indices" : [ 11, 20 ],
      "id_str" : "45630895",
      "id" : 45630895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940236335989760003",
  "geo" : { },
  "id_str" : "940451657254625280",
  "in_reply_to_user_id" : 244847248,
  "text" : "@Beryl_snw @chengr28 \u4E0D\u662F\u4E0A\u50B3\u6642\u58D3\u7E2E\uFF0C\u662F\u4F60\u770B\u8996\u983B\u6642\u63A8\u7279\u6839\u64DA\u4F60\u7684\u7DB2\u901F\u81EA\u52D5\u8ABF\u6574\u756B\u8CEA\u3002",
  "id" : 940451657254625280,
  "in_reply_to_status_id" : 940236335989760003,
  "created_at" : "2017-12-12 05:22:02 +0000",
  "in_reply_to_screen_name" : "Beryl_snw",
  "in_reply_to_user_id_str" : "244847248",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/940450189835423745\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0qA0ixTUzL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQ0mdLcVoAEyNME.jpg",
      "id_str" : "940450179920011265",
      "id" : 940450179920011265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQ0mdLcVoAEyNME.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 531
      } ],
      "display_url" : "pic.twitter.com\/0qA0ixTUzL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940173065488666624",
  "geo" : { },
  "id_str" : "940450189835423745",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/0qA0ixTUzL",
  "id" : 940450189835423745,
  "in_reply_to_status_id" : 940173065488666624,
  "created_at" : "2017-12-12 05:16:12 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/IreWgU5ojw",
      "expanded_url" : "https:\/\/archive.is\/htiNi",
      "display_url" : "archive.is\/htiNi"
    } ]
  },
  "geo" : { },
  "id_str" : "940449190118854657",
  "text" : "\u4E2D\u5171\u5929\u7DB2\u521D\u9AD4\u9A57\uFF1Ahttps:\/\/t.co\/IreWgU5ojw",
  "id" : 940449190118854657,
  "created_at" : "2017-12-12 05:12:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "940124020296507392",
  "geo" : { },
  "id_str" : "940177137994289152",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u88DDlinux\u554A\uFF0Cwin\u53C8\u4E0D\u80FD\u50B3\u6559~",
  "id" : 940177137994289152,
  "in_reply_to_status_id" : 940124020296507392,
  "created_at" : "2017-12-11 11:11:12 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/3sxtvhiC4B",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/12\/blog-post_52.html",
      "display_url" : "molihua.org\/2017\/12\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "940173323337682944",
  "text" : "\u5317\u4EAC\u7684\u5E73\u58E4\u5929\u969B\u7DAB\uFF1Ahttps:\/\/t.co\/3sxtvhiC4B",
  "id" : 940173323337682944,
  "created_at" : "2017-12-11 10:56:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/940173065488666624\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/TAOYj6nXum",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQwqaOdVwAMpFZ9.jpg",
      "id_str" : "940173052259713027",
      "id" : 940173052259713027,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQwqaOdVwAMpFZ9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/TAOYj6nXum"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "939737802891300864",
  "geo" : { },
  "id_str" : "940173065488666624",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/TAOYj6nXum",
  "id" : 940173065488666624,
  "in_reply_to_status_id" : 939737802891300864,
  "created_at" : "2017-12-11 10:55:01 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79E6\u515D\u7684\u8DEF\u7531\u5668",
      "screen_name" : "fqrouter",
      "indices" : [ 3, 12 ],
      "id_str" : "281579156",
      "id" : 281579156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "940171808015376384",
  "text" : "\u79E6\u515D\uFF08@fqrouter\uFF09\u5931\u806F10\u5929\u3002",
  "id" : 940171808015376384,
  "created_at" : "2017-12-11 10:50:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/i4lT2eZxv1",
      "expanded_url" : "https:\/\/techyan.me\/something-about-north-korea\/",
      "display_url" : "techyan.me\/something-abou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "939744046003773440",
  "geo" : { },
  "id_str" : "940165730158415872",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/i4lT2eZxv1",
  "id" : 940165730158415872,
  "in_reply_to_status_id" : 939744046003773440,
  "created_at" : "2017-12-11 10:25:52 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/Nvy0sQOJJn",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/12\/blog-post_9.html",
      "display_url" : "molihua.org\/2017\/12\/blog-p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "939743939959148544",
  "geo" : { },
  "id_str" : "939744046003773440",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u91D1\u6B63\u6069\u6216\u5DF2\u9003\u96E2\u671D\u9BAE\uFF1Ahttps:\/\/t.co\/Nvy0sQOJJn",
  "id" : 939744046003773440,
  "in_reply_to_status_id" : 939743939959148544,
  "created_at" : "2017-12-10 06:30:14 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/p8kJz3Q31t",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/12\/blog-post_80.html",
      "display_url" : "molihua.org\/2017\/12\/blog-p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "939041624981585920",
  "geo" : { },
  "id_str" : "939743939959148544",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u89E3\u653E\u8ECD\u5927\u898F\u6A21\u8ABF\u5175\u4E2D\u671D\u908A\u5883\uFF1Ahttps:\/\/t.co\/p8kJz3Q31t",
  "id" : 939743939959148544,
  "in_reply_to_status_id" : 939041624981585920,
  "created_at" : "2017-12-10 06:29:49 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/939737802891300864\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/wNByVpfgfx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQqeeYEUMAAk6L3.jpg",
      "id_str" : "939737716953985024",
      "id" : 939737716953985024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQqeeYEUMAAk6L3.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/wNByVpfgfx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "939470712737280005",
  "geo" : { },
  "id_str" : "939737802891300864",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/wNByVpfgfx",
  "id" : 939737802891300864,
  "in_reply_to_status_id" : 939470712737280005,
  "created_at" : "2017-12-10 06:05:26 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "939734863116201984",
  "text" : "1\u6BD4\u7279\u5E63 \u2248 15000\u7F8E\u5143",
  "id" : 939734863116201984,
  "created_at" : "2017-12-10 05:53:45 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "939733748513374208",
  "text" : "\u7232\u4EC0\u9EBDWindows 10 1709\u7684Internet Connection Sharing (ICS)\u670D\u52D9\u6703\u5360\u7528UDP53\u7AEF\u53E3\uFF1F",
  "id" : 939733748513374208,
  "created_at" : "2017-12-10 05:49:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 0, 8 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "939247671369273344",
  "geo" : { },
  "id_str" : "939489812184227840",
  "in_reply_to_user_id" : 769927156768055296,
  "text" : "@39__bot \u7FA1\u6155\u5AC9\u5992\u6068",
  "id" : 939489812184227840,
  "in_reply_to_status_id" : 939247671369273344,
  "created_at" : "2017-12-09 13:40:00 +0000",
  "in_reply_to_screen_name" : "39__bot",
  "in_reply_to_user_id_str" : "769927156768055296",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/939470712737280005\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ogbjKWXp9E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQmrnv1UEAAFXe-.jpg",
      "id_str" : "939470696626786304",
      "id" : 939470696626786304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQmrnv1UEAAFXe-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/ogbjKWXp9E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "939469970869833729",
  "geo" : { },
  "id_str" : "939470712737280005",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/ogbjKWXp9E",
  "id" : 939470712737280005,
  "in_reply_to_status_id" : 939469970869833729,
  "created_at" : "2017-12-09 12:24:07 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/939469970869833729\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/aA8wvprzcc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQmq7xsXkAEF_VA.jpg",
      "id_str" : "939469941211893761",
      "id" : 939469941211893761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQmq7xsXkAEF_VA.jpg",
      "sizes" : [ {
        "h" : 481,
        "resize" : "fit",
        "w" : 727
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 727
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 727
      } ],
      "display_url" : "pic.twitter.com\/aA8wvprzcc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/AkvNVJ4KWA",
      "expanded_url" : "https:\/\/www.battleforthenet.com\/breaktheinternet\/",
      "display_url" : "battleforthenet.com\/breaktheintern\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "938998228590108673",
  "geo" : { },
  "id_str" : "939469970869833729",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/AkvNVJ4KWA https:\/\/t.co\/aA8wvprzcc",
  "id" : 939469970869833729,
  "in_reply_to_status_id" : 938998228590108673,
  "created_at" : "2017-12-09 12:21:10 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/PAFIXBoWXa",
      "expanded_url" : "https:\/\/archive.is\/yyvgr",
      "display_url" : "archive.is\/yyvgr"
    }, {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/iCohcG1lhx",
      "expanded_url" : "https:\/\/archive.is\/ADPhP",
      "display_url" : "archive.is\/ADPhP"
    }, {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/871uD9k6el",
      "expanded_url" : "https:\/\/archive.is\/Ou9vc",
      "display_url" : "archive.is\/Ou9vc"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/gGfne6pJ9k",
      "expanded_url" : "https:\/\/bbs.kafan.cn\/thread-2110691-1-1.html",
      "display_url" : "bbs.kafan.cn\/thread-2110691\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "939458926223020033",
  "text" : "Intel CPU\u7684AMT\u3001ME\u3001TXE\u3001SPS\u5747\u6709\u6F0F\u6D1E\u2014\u2014\np1\uFF1Ahttps:\/\/t.co\/PAFIXBoWXa\np2\uFF1Ahttps:\/\/t.co\/iCohcG1lhx\np3\uFF1Ahttps:\/\/t.co\/871uD9k6el\nhttps:\/\/t.co\/gGfne6pJ9k",
  "id" : 939458926223020033,
  "created_at" : "2017-12-09 11:37:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/IUC1BiLQjL",
      "expanded_url" : "https:\/\/archive.is\/sF4qX",
      "display_url" : "archive.is\/sF4qX"
    } ]
  },
  "geo" : { },
  "id_str" : "939065754229530624",
  "text" : "\u5831\u9053\u5DF4\u62FF\u99AC\u6587\u4EF6\u7684\u8A18\u8005\u9047\u523A\u8EAB\u4EA1\uFF1Ahttps:\/\/t.co\/IUC1BiLQjL",
  "id" : 939065754229530624,
  "created_at" : "2017-12-08 09:34:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/InaRSh6BuM",
      "expanded_url" : "https:\/\/hacks.mozilla.org\/2017\/12\/using-headless-mode-in-firefox\/",
      "display_url" : "hacks.mozilla.org\/2017\/12\/using-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "939060565347065856",
  "text" : "Using Headless Mode in Firefox\uFF1Ahttps:\/\/t.co\/InaRSh6BuM",
  "id" : 939060565347065856,
  "created_at" : "2017-12-08 09:14:20 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/0EoyRyUizM",
      "expanded_url" : "https:\/\/archive.is\/g1tFd",
      "display_url" : "archive.is\/g1tFd"
    } ]
  },
  "in_reply_to_status_id_str" : "939039785854713856",
  "geo" : { },
  "id_str" : "939041624981585920",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u7279\u6717\u666E\u6216\u82072017\/12\/18\u65AC\u9996\u91D1\u6B63\u6069\uFF1Ahttps:\/\/t.co\/0EoyRyUizM",
  "id" : 939041624981585920,
  "in_reply_to_status_id" : 939039785854713856,
  "created_at" : "2017-12-08 07:59:04 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/LvbHuhVps7",
      "expanded_url" : "https:\/\/archive.is\/aVKRM",
      "display_url" : "archive.is\/aVKRM"
    } ]
  },
  "in_reply_to_status_id_str" : "939039199243640832",
  "geo" : { },
  "id_str" : "939039785854713856",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u300A\u5409\u6797\u65E5\u62A5\u300B\u520A\u767B\u6838\u6B66\u5668\u5C08\u520A\uFF1Ahttps:\/\/t.co\/LvbHuhVps7",
  "id" : 939039785854713856,
  "in_reply_to_status_id" : 939039199243640832,
  "created_at" : "2017-12-08 07:51:46 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/rVWrS8WGZp",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/12\/blog-post_51.html",
      "display_url" : "molihua.org\/2017\/12\/blog-p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "939037435022807040",
  "geo" : { },
  "id_str" : "939039199243640832",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u4E2D\u570B\u79FB\u52D5\u5949\u547D\u4FDD\u969C\u96E3\u6C11\u71DF\u4FE1\u865F\u5168\u8986\u84CB\uFF1Ahttps:\/\/t.co\/rVWrS8WGZp",
  "id" : 939039199243640832,
  "in_reply_to_status_id" : 939037435022807040,
  "created_at" : "2017-12-08 07:49:26 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/yzcgzB59Oh",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/12\/blog-post_34.html",
      "display_url" : "molihua.org\/2017\/12\/blog-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "939037435022807040",
  "text" : "\u50B3\u5409\u6797\u8A2D\u96E3\u6C11\u71DF\uFF1Ahttps:\/\/t.co\/yzcgzB59Oh",
  "id" : 939037435022807040,
  "created_at" : "2017-12-08 07:42:25 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938998228590108673\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/il5baKPI4V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQf95qBUIAAYzHB.jpg",
      "id_str" : "938998214304210944",
      "id" : 938998214304210944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQf95qBUIAAYzHB.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/il5baKPI4V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "938749590630797313",
  "geo" : { },
  "id_str" : "938998228590108673",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/il5baKPI4V",
  "id" : 938998228590108673,
  "in_reply_to_status_id" : 938749590630797313,
  "created_at" : "2017-12-08 05:06:38 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xxnet",
      "screen_name" : "XXNetDev",
      "indices" : [ 10, 19 ],
      "id_str" : "2998823642",
      "id" : 2998823642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938993871752609793",
  "text" : "Michael.X\uFF08@XXNetDev\uFF09\u5931\u806F6\u5929\u3002",
  "id" : 938993871752609793,
  "created_at" : "2017-12-08 04:49:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/LTDKJ21c75",
      "expanded_url" : "https:\/\/gitter.im\/phuslu\/goproxy?at=5a2a0f4187680e6230e5e7b7",
      "display_url" : "gitter.im\/phuslu\/goproxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "938991267475628033",
  "text" : "\u64DA\u50B3\u96FB\u4FE1\u666E\u53CAIPv6\u540E\u5206\u914D\u7684\u5185\u7DB2IPv4\u4E0D\u80FD\u8A2A\u554F\u4EFB\u4F55\u5883\u5916\u7DB2\u7AD9\uFF1Ahttps:\/\/t.co\/LTDKJ21c75",
  "id" : 938991267475628033,
  "created_at" : "2017-12-08 04:38:58 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/HdzndsD8pS",
      "expanded_url" : "https:\/\/archive.is\/n0EQb",
      "display_url" : "archive.is\/n0EQb"
    } ]
  },
  "geo" : { },
  "id_str" : "938989697799294976",
  "text" : "\u4E2D\u7F8E\u7C3D\u7F72\u300A\u5317\u6597\u4E0E GPS \u4FE1\u53F7\u517C\u5BB9\u4E0E\u4E92\u64CD\u4F5C\u8054\u5408\u58F0\u660E\u300B\uFF1Ahttps:\/\/t.co\/HdzndsD8pS",
  "id" : 938989697799294976,
  "created_at" : "2017-12-08 04:32:44 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/938948172910444544\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/4vJvRokDoZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQfQWtCUQAA3uyV.jpg",
      "id_str" : "938948135795048448",
      "id" : 938948135795048448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQfQWtCUQAA3uyV.jpg",
      "sizes" : [ {
        "h" : 323,
        "resize" : "fit",
        "w" : 1137
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 1137
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 1137
      } ],
      "display_url" : "pic.twitter.com\/4vJvRokDoZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/Rq1IR5lFPB",
      "expanded_url" : "https:\/\/www.recode.net\/2017\/12\/7\/16749536\/coinbase-bitcoin-most-downloaded-app-iphone",
      "display_url" : "recode.net\/2017\/12\/7\/1674\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "938985430967570433",
  "text" : "RT @ruanyf: \u968F\u7740\u6BD4\u7279\u5E01\u4EF7\u683C\u7A81\u783417000\u7F8E\u5143\uFF0CCoinbase \u53D8\u6210\u4E86\u7F8E\u56FD\u6392\u540D\u7B2C\u4E00\u7684 iPhone App\u3002https:\/\/t.co\/Rq1IR5lFPB https:\/\/t.co\/4vJvRokDoZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/938948172910444544\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/4vJvRokDoZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DQfQWtCUQAA3uyV.jpg",
        "id_str" : "938948135795048448",
        "id" : 938948135795048448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQfQWtCUQAA3uyV.jpg",
        "sizes" : [ {
          "h" : 323,
          "resize" : "fit",
          "w" : 1137
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 1137
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 1137
        } ],
        "display_url" : "pic.twitter.com\/4vJvRokDoZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/Rq1IR5lFPB",
        "expanded_url" : "https:\/\/www.recode.net\/2017\/12\/7\/16749536\/coinbase-bitcoin-most-downloaded-app-iphone",
        "display_url" : "recode.net\/2017\/12\/7\/1674\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "938948172910444544",
    "text" : "\u968F\u7740\u6BD4\u7279\u5E01\u4EF7\u683C\u7A81\u783417000\u7F8E\u5143\uFF0CCoinbase \u53D8\u6210\u4E86\u7F8E\u56FD\u6392\u540D\u7B2C\u4E00\u7684 iPhone App\u3002https:\/\/t.co\/Rq1IR5lFPB https:\/\/t.co\/4vJvRokDoZ",
    "id" : 938948172910444544,
    "created_at" : "2017-12-08 01:47:43 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 938985430967570433,
  "created_at" : "2017-12-08 04:15:46 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marisa Kirisame",
      "screen_name" : "MarisaVeryMoe",
      "indices" : [ 3, 17 ],
      "id_str" : "710405068147699712",
      "id" : 710405068147699712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopTheFCC",
      "indices" : [ 89, 100 ]
    }, {
      "text" : "NetNeutrality",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938982537577287681",
  "text" : "RT @MarisaVeryMoe: Nationwide protests happening in 700+ cities today demanding Congress #StopTheFCC from killing #NetNeutrality. Find one\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.internetdefenseleague.org\" rel=\"nofollow\"\u003EInternet Defense League\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Team Internet",
        "screen_name" : "idltweets",
        "indices" : [ 158, 168 ],
        "id_str" : "3122240513",
        "id" : 3122240513
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopTheFCC",
        "indices" : [ 70, 81 ]
      }, {
        "text" : "NetNeutrality",
        "indices" : [ 95, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/p9DK2qDKB6",
        "expanded_url" : "http:\/\/VerizonProtests.com",
        "display_url" : "VerizonProtests.com"
      } ]
    },
    "geo" : { },
    "id_str" : "938817631972483072",
    "text" : "Nationwide protests happening in 700+ cities today demanding Congress #StopTheFCC from killing #NetNeutrality. Find one near you: https:\/\/t.co\/p9DK2qDKB6 via @IDLTweets",
    "id" : 938817631972483072,
    "created_at" : "2017-12-07 17:09:00 +0000",
    "user" : {
      "name" : "Marisa Kirisame",
      "screen_name" : "MarisaVeryMoe",
      "protected" : false,
      "id_str" : "710405068147699712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710421855824314368\/ApIpwWDy_normal.jpg",
      "id" : 710405068147699712,
      "verified" : false
    }
  },
  "id" : 938982537577287681,
  "created_at" : "2017-12-08 04:04:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "937236851949060096",
  "geo" : { },
  "id_str" : "938775181505564672",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u5728\u6211\u591A\u6B21\u628Anotify@protonmail.ch\u7684\u90F5\u4EF6\u79FB\u56DE\u6536\u4EF6\u7BB1\u540E\uFF0COutlook\u4E0D\u518D\u5224\u5B9A\u5176\u70BA\u5783\u573E\u90F5\u4EF6\u3002",
  "id" : 938775181505564672,
  "in_reply_to_status_id" : 937236851949060096,
  "created_at" : "2017-12-07 14:20:19 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938772165033431040\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/MLSsM5vnKU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQcwJG2VwAEsiB2.jpg",
      "id_str" : "938771980345524225",
      "id" : 938771980345524225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQcwJG2VwAEsiB2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/MLSsM5vnKU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/jir6FaVm4r",
      "expanded_url" : "https:\/\/gitter.im\/phuslu\/goproxy?at=5a2936423ae2aa6b3f99c1dd",
      "display_url" : "gitter.im\/phuslu\/goproxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "938772165033431040",
  "text" : "\u65B0\u4E00\u8F2A\u7DB2\u7D61\u5C01\u9396\uFF1Ahttps:\/\/t.co\/jir6FaVm4r\nPS. archive.is\u548Cgitter.im\u600E\u9EBD\u4E86\uFF1F https:\/\/t.co\/MLSsM5vnKU",
  "id" : 938772165033431040,
  "created_at" : "2017-12-07 14:08:20 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938768119815950336",
  "text" : "archive.is\u5C01\u6389\u4E86Psiphon3\u7684\u7F8E\u570B\u7BC0\u9EDE\u3002",
  "id" : 938768119815950336,
  "created_at" : "2017-12-07 13:52:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u795E\u697D\u5742\u6CC9@\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "KagurazakaIzumi",
      "indices" : [ 0, 16 ],
      "id_str" : "482695937",
      "id" : 482695937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "938738852146978817",
  "geo" : { },
  "id_str" : "938764261886742529",
  "in_reply_to_user_id" : 482695937,
  "text" : "@KagurazakaIzumi \u6C92\u5BC6\u78BC\uFF1F\u6C92\u8A2D\u5099\u52A0\u5BC6\uFF1F",
  "id" : 938764261886742529,
  "in_reply_to_status_id" : 938738852146978817,
  "created_at" : "2017-12-07 13:36:56 +0000",
  "in_reply_to_screen_name" : "KagurazakaIzumi",
  "in_reply_to_user_id_str" : "482695937",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938749590630797313\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/tZPTFhwlIp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQcbwIhV4AADaig.jpg",
      "id_str" : "938749561065037824",
      "id" : 938749561065037824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQcbwIhV4AADaig.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/tZPTFhwlIp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "938363415533367296",
  "geo" : { },
  "id_str" : "938749590630797313",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/tZPTFhwlIp",
  "id" : 938749590630797313,
  "in_reply_to_status_id" : 938363415533367296,
  "created_at" : "2017-12-07 12:38:38 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "938745206714851328",
  "geo" : { },
  "id_str" : "938746083479519233",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u6211\u4E0D\u76F8\u4FE1esutv\u7684\u8209\u63AA\u80FD\u4FDD\u8B77\u4ED6\uFF0C\u65BC\u662F\u6709\u4E86\u5982\u4E0A\u7684\u63A8\u6587\u3002\u5982\u679C\u5468\u6E5B\u840D\u771F\u7684\u662FBreakWa11\uFF0C\u5E0C\u671B\u5927\u5BB6\u80FD\u4FDD\u8B77\u4ED6\u3002\u9019\u500B\u4E8B\u4EF6\u8B93\u6211\u660E\u767D\u8B66\u65B9\u5982\u4F55\u96D9\u6A19\u4E0ATelegram\uFF0C\u901A\u904E\u4EBA\u8089\u96E2\u9593SS\u548CSSR\u3002",
  "id" : 938746083479519233,
  "in_reply_to_status_id" : 938745206714851328,
  "created_at" : "2017-12-07 12:24:42 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/ia5K6QZ4CR",
      "expanded_url" : "https:\/\/t.me\/realesu",
      "display_url" : "t.me\/realesu"
    }, {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/CVoN4Hc8HO",
      "expanded_url" : "https:\/\/t.me\/esutv",
      "display_url" : "t.me\/esutv"
    } ]
  },
  "geo" : { },
  "id_str" : "938745206714851328",
  "text" : "BreakWa11\u88AB\u516C\u5B89\u5C40\u54E1\u5DE5\u4EBA\u8089\uFF08https:\/\/t.co\/ia5K6QZ4CR\uFF09\uFF0Chttps:\/\/t.co\/CVoN4Hc8HO\u7232\u4E86\u4FDD\u8B77\u4ED6\u522A\u53BB\u4E86\u6307\u5411\u8A72\u983B\u9053\u7684\u93C8\u63A5\u3002",
  "id" : 938745206714851328,
  "created_at" : "2017-12-07 12:21:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u95EB\u6069\u94ED",
      "screen_name" : "TechyanWP",
      "indices" : [ 0, 10 ],
      "id_str" : "2986143630",
      "id" : 2986143630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "938659001134301184",
  "geo" : { },
  "id_str" : "938739797857841152",
  "in_reply_to_user_id" : 2986143630,
  "text" : "@TechyanWP @HgrsKy810114514 \u4F60\u9084\u9700\u8981\u76E3\u63A7\uFF1F\uFF1F",
  "id" : 938739797857841152,
  "in_reply_to_status_id" : 938659001134301184,
  "created_at" : "2017-12-07 11:59:43 +0000",
  "in_reply_to_screen_name" : "TechyanWP",
  "in_reply_to_user_id_str" : "2986143630",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/eb0IcwmbfL",
      "expanded_url" : "http:\/\/www.bbc.com\/zhongwen\/simp\/world-42264167",
      "display_url" : "bbc.com\/zhongwen\/simp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "938735886858117122",
  "text" : "\u6FB3\u6D32\u540C\u6027\u6200\u5408\u6CD5\uFF1Ahttps:\/\/t.co\/eb0IcwmbfL",
  "id" : 938735886858117122,
  "created_at" : "2017-12-07 11:44:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938735667441557506",
  "text" : "1\u6BD4\u7279\u5E63 &gt; 14000\u7F8E\u5143",
  "id" : 938735667441557506,
  "created_at" : "2017-12-07 11:43:18 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marisa Kirisame",
      "screen_name" : "MarisaVeryMoe",
      "indices" : [ 3, 17 ],
      "id_str" : "710405068147699712",
      "id" : 710405068147699712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 34, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/p9DK2qDKB6",
      "expanded_url" : "http:\/\/VerizonProtests.com",
      "display_url" : "VerizonProtests.com"
    } ]
  },
  "geo" : { },
  "id_str" : "938734208465424385",
  "text" : "RT @MarisaVeryMoe: TOMORROW: 600+ #NetNeutrality protests across the US! Find one near you here: https:\/\/t.co\/p9DK2qDKB6 | Can't go? Contac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.internetdefenseleague.org\" rel=\"nofollow\"\u003EInternet Defense League\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Team Internet",
        "screen_name" : "idltweets",
        "indices" : [ 173, 183 ],
        "id_str" : "3122240513",
        "id" : 3122240513
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 15, 29 ]
      }, {
        "text" : "StopTheFCC",
        "indices" : [ 157, 168 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/p9DK2qDKB6",
        "expanded_url" : "http:\/\/VerizonProtests.com",
        "display_url" : "VerizonProtests.com"
      }, {
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/34OBM8BuSr",
        "expanded_url" : "http:\/\/BattleForTheNet.com",
        "display_url" : "BattleForTheNet.com"
      } ]
    },
    "geo" : { },
    "id_str" : "938460797260517377",
    "text" : "TOMORROW: 600+ #NetNeutrality protests across the US! Find one near you here: https:\/\/t.co\/p9DK2qDKB6 | Can't go? Contact your reps: https:\/\/t.co\/34OBM8BuSr #StopTheFCC via @IDLTweets",
    "id" : 938460797260517377,
    "created_at" : "2017-12-06 17:31:04 +0000",
    "user" : {
      "name" : "Marisa Kirisame",
      "screen_name" : "MarisaVeryMoe",
      "protected" : false,
      "id_str" : "710405068147699712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710421855824314368\/ApIpwWDy_normal.jpg",
      "id" : 710405068147699712,
      "verified" : false
    }
  },
  "id" : 938734208465424385,
  "created_at" : "2017-12-07 11:37:30 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938391556880584704\/photo\/1",
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/lCsSaK0hAN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQXWI9NW0AEMc9K.jpg",
      "id_str" : "938391546734497793",
      "id" : 938391546734497793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQXWI9NW0AEMc9K.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 652
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 652
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 652
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 652
      } ],
      "display_url" : "pic.twitter.com\/lCsSaK0hAN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938391556880584704",
  "text" : "\u5475\u5475 https:\/\/t.co\/lCsSaK0hAN",
  "id" : 938391556880584704,
  "created_at" : "2017-12-06 12:55:56 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938388948677783553\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/UQEHrWtMtj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQXTxT_WAAALLAy.jpg",
      "id_str" : "938388941509623808",
      "id" : 938388941509623808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQXTxT_WAAALLAy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 452
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 452
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 452
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 452
      } ],
      "display_url" : "pic.twitter.com\/UQEHrWtMtj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "937261012574769152",
  "geo" : { },
  "id_str" : "938388948677783553",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u6211\u624B\u8CE4\u9EDE\u958B\u4E86wmplayer\uFF1A https:\/\/t.co\/UQEHrWtMtj",
  "id" : 938388948677783553,
  "in_reply_to_status_id" : 937261012574769152,
  "created_at" : "2017-12-06 12:45:34 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kios",
      "screen_name" : "7yinhuofuB7zhi",
      "indices" : [ 0, 15 ],
      "id_str" : "871645492077363201",
      "id" : 871645492077363201
    }, {
      "name" : "\u4F60\u7684\u5173\u5FC3\uFF0C\u624D\u662F\u5934\u6761",
      "screen_name" : "39__bot",
      "indices" : [ 16, 24 ],
      "id_str" : "769927156768055296",
      "id" : 769927156768055296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "938239204449906688",
  "geo" : { },
  "id_str" : "938374387190976512",
  "in_reply_to_user_id" : 871645492077363201,
  "text" : "@7yinhuofuB7zhi @39__bot \u4F60\u771F\u7684\u4E0D\u662F\u4E94\u6BDB\u6216\u6A5F\u5668\u4EBA\u55CE\uFF1F\u80FD\u5426\u89E3\u91CB\u4E00\u4E0B\u4F60\u7684\u767C\u5E16\u91CF\uFF1F",
  "id" : 938374387190976512,
  "in_reply_to_status_id" : 938239204449906688,
  "created_at" : "2017-12-06 11:47:42 +0000",
  "in_reply_to_screen_name" : "7yinhuofuB7zhi",
  "in_reply_to_user_id_str" : "871645492077363201",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/kbCj30V0N1",
      "expanded_url" : "https:\/\/archive.is\/q70Wb",
      "display_url" : "archive.is\/q70Wb"
    } ]
  },
  "geo" : { },
  "id_str" : "938371948626808832",
  "text" : "\u6709\u8DE1\u8C61\u8868\u660E\u5FAE\u4FE1\u700F\u89BD\u5668\u76E3\u807D\u6240\u6709\u6D41\u91CF\uFF1Ahttps:\/\/t.co\/kbCj30V0N1",
  "id" : 938371948626808832,
  "created_at" : "2017-12-06 11:38:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wuyu",
      "screen_name" : "SW_CMM",
      "indices" : [ 0, 7 ],
      "id_str" : "2336783467",
      "id" : 2336783467
    }, {
      "name" : "fang1024",
      "screen_name" : "fang2hua",
      "indices" : [ 8, 17 ],
      "id_str" : "2731159912",
      "id" : 2731159912
    }, {
      "name" : "surveillance104",
      "screen_name" : "Surveillance410",
      "indices" : [ 18, 34 ],
      "id_str" : "4924076429",
      "id" : 4924076429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "938367210422018049",
  "geo" : { },
  "id_str" : "938371338577817600",
  "in_reply_to_user_id" : 2336783467,
  "text" : "@SW_CMM @fang2hua @Surveillance410 \uFF1F\n\u6211\u4E0D\u7528\u4EE3\u7406\u64F4\u5C55\u3002",
  "id" : 938371338577817600,
  "in_reply_to_status_id" : 938367210422018049,
  "created_at" : "2017-12-06 11:35:35 +0000",
  "in_reply_to_screen_name" : "SW_CMM",
  "in_reply_to_user_id_str" : "2336783467",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/YpGnxPXgdQ",
      "expanded_url" : "https:\/\/archive.is\/4OGiJ#selection-1749.1-1749.13",
      "display_url" : "archive.is\/4OGiJ#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "938364781177769985",
  "text" : "\u4E2D\u5171\u516C\u4F48\u53CD\u9593\u8ADC\u6CD5\u5BE6\u65BD\u7D30\u5247\uFF0C\u6216\u53EF\u7D66\u52A0\u5BC6\u5DE5\u5177\u5B9A\u7F6A\uFF1Ahttps:\/\/t.co\/YpGnxPXgdQ",
  "id" : 938364781177769985,
  "created_at" : "2017-12-06 11:09:32 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79E6\u515D\u7684\u8DEF\u7531\u5668",
      "screen_name" : "fqrouter",
      "indices" : [ 3, 12 ],
      "id_str" : "281579156",
      "id" : 281579156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938363620479721472",
  "text" : "\u79E6\u515D\uFF08@fqrouter \uFF09\u5931\u806F5\u5929\u3002",
  "id" : 938363620479721472,
  "created_at" : "2017-12-06 11:04:55 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938363415533367296\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/BjSMkyMXA6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQW8ivxX4AE8QFQ.jpg",
      "id_str" : "938363402501742593",
      "id" : 938363402501742593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQW8ivxX4AE8QFQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/BjSMkyMXA6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "937853217718841344",
  "geo" : { },
  "id_str" : "938363415533367296",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/BjSMkyMXA6",
  "id" : 938363415533367296,
  "in_reply_to_status_id" : 937853217718841344,
  "created_at" : "2017-12-06 11:04:06 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/bJWu1QQL1W",
      "expanded_url" : "https:\/\/cn.nytimes.com\/business\/20171206\/china-internet-conference-wuzhen\/",
      "display_url" : "cn.nytimes.com\/business\/20171\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "938361827112742912",
  "geo" : { },
  "id_str" : "938362175764205568",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u6F14\u793A\u4E86\uFF1Ahttps:\/\/t.co\/bJWu1QQL1W",
  "id" : 938362175764205568,
  "in_reply_to_status_id" : 938361827112742912,
  "created_at" : "2017-12-06 10:59:11 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938361827112742912\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/73TRNIAD7K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQW7GkgX4AIrdrz.jpg",
      "id_str" : "938361818929684482",
      "id" : 938361818929684482,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQW7GkgX4AIrdrz.jpg",
      "sizes" : [ {
        "h" : 353,
        "resize" : "fit",
        "w" : 657
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 657
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 657
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 657
      } ],
      "display_url" : "pic.twitter.com\/73TRNIAD7K"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/B3NB8um7Gs",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=54759",
      "display_url" : "solidot.org\/story?sid=54759"
    } ]
  },
  "geo" : { },
  "id_str" : "938361827112742912",
  "text" : "\u4E2D\u5171\u5728\u70CF\u93AE\u5927\u6703\u4E0A\u6F14\u793A\u5148\u9032\u7684\u76E3\u63A7\u6280\u8853\uFF1Ahttps:\/\/t.co\/B3NB8um7Gs https:\/\/t.co\/73TRNIAD7K",
  "id" : 938361827112742912,
  "created_at" : "2017-12-06 10:57:48 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/qDCDVMpCv0",
      "expanded_url" : "http:\/\/www.zdnet.com\/article\/popular-virtual-keyboard-leaks-31-million-user-data\/",
      "display_url" : "zdnet.com\/article\/popula\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "938360168508788736",
  "geo" : { },
  "id_str" : "938361197472165888",
  "in_reply_to_user_id" : 3359880735,
  "text" : "\u6CC4\u9732\u4E86\uFF1Ahttps:\/\/t.co\/qDCDVMpCv0",
  "id" : 938361197472165888,
  "in_reply_to_status_id" : 938360168508788736,
  "created_at" : "2017-12-06 10:55:18 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938360460214259712\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/zL42cdVGwv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQW52SvUQAELkv5.jpg",
      "id_str" : "938360439770988545",
      "id" : 938360439770988545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQW52SvUQAELkv5.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 290
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 290
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 290
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 290
      } ],
      "display_url" : "pic.twitter.com\/zL42cdVGwv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/6p26nGQiKi",
      "expanded_url" : "http:\/\/www.solidot.org\/",
      "display_url" : "solidot.org"
    } ]
  },
  "geo" : { },
  "id_str" : "938360460214259712",
  "text" : "Solidot\u5B95\u6A5F\uFF1Ahttps:\/\/t.co\/6p26nGQiKi https:\/\/t.co\/zL42cdVGwv",
  "id" : 938360460214259712,
  "created_at" : "2017-12-06 10:52:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/938360168508788736\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Niy3bhPboA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQW5j1zWkAEu06u.jpg",
      "id_str" : "938360122765643777",
      "id" : 938360122765643777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQW5j1zWkAEu06u.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/Niy3bhPboA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/7JsqrPs6MK",
      "expanded_url" : "http:\/\/www.solidot.org\/story?sid=54750",
      "display_url" : "solidot.org\/story?sid=54750"
    } ]
  },
  "geo" : { },
  "id_str" : "938360168508788736",
  "text" : "\u865A\u62DF\u952E\u76D8\u5E94\u7528AI.type\u5077\u5077\u6536\u96C6\u7684\u81F3\u5C11577GB\u96B1\u79C1\u6578\u64DA\u6CC4\u9732\uFF1Ahttps:\/\/t.co\/7JsqrPs6MK https:\/\/t.co\/Niy3bhPboA",
  "id" : 938360168508788736,
  "created_at" : "2017-12-06 10:51:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/CcGgRmw1Ai",
      "expanded_url" : "https:\/\/archive.is\/v1aZ3",
      "display_url" : "archive.is\/v1aZ3"
    } ]
  },
  "geo" : { },
  "id_str" : "938358688162689024",
  "text" : "\u5FB7\u570B\u64EC\u5F3A\u5236\u6240\u6709\u8A2D\u5099\u958B\u5F8C\u9580\uFF1Ahttps:\/\/t.co\/CcGgRmw1Ai",
  "id" : 938358688162689024,
  "created_at" : "2017-12-06 10:45:19 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/LN7L3T19LK",
      "expanded_url" : "https:\/\/archive.is\/UBQoI",
      "display_url" : "archive.is\/UBQoI"
    } ]
  },
  "geo" : { },
  "id_str" : "938358603567771654",
  "text" : "\u7F8E\u570B\u5F3A\u8ABF\u5176\u8981\u6C42\u7522\u54C1\u6DFB\u52A0\u5F8C\u9580\u7121\u9700\u8072\u660E\uFF1Ahttps:\/\/t.co\/LN7L3T19LK",
  "id" : 938358603567771654,
  "created_at" : "2017-12-06 10:44:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victoria Raymond",
      "screen_name" : "projectv2ray",
      "indices" : [ 3, 16 ],
      "id_str" : "3727242017",
      "id" : 3727242017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/gJKRpuEu22",
      "expanded_url" : "https:\/\/steemit.com\/cn\/@v2ray\/v2ray-project-v",
      "display_url" : "steemit.com\/cn\/@v2ray\/v2ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937960096201617408",
  "text" : "RT @projectv2ray: \u5728 V2Ray \u5347\u7EA7\u5230 3.0 \u7684\u540C\u65F6\uFF0CV2Ray \u6B63\u5F0F\u6269\u5C55\u4E3A Project V: https:\/\/t.co\/gJKRpuEu22",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/gJKRpuEu22",
        "expanded_url" : "https:\/\/steemit.com\/cn\/@v2ray\/v2ray-project-v",
        "display_url" : "steemit.com\/cn\/@v2ray\/v2ra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "937748892334067712",
    "text" : "\u5728 V2Ray \u5347\u7EA7\u5230 3.0 \u7684\u540C\u65F6\uFF0CV2Ray \u6B63\u5F0F\u6269\u5C55\u4E3A Project V: https:\/\/t.co\/gJKRpuEu22",
    "id" : 937748892334067712,
    "created_at" : "2017-12-04 18:22:13 +0000",
    "user" : {
      "name" : "Victoria Raymond",
      "screen_name" : "projectv2ray",
      "protected" : false,
      "id_str" : "3727242017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839625441640083456\/H7JI2b6g_normal.jpg",
      "id" : 3727242017,
      "verified" : false
    }
  },
  "id" : 937960096201617408,
  "created_at" : "2017-12-05 08:21:28 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/7h4lhN8SXG",
      "expanded_url" : "https:\/\/archive.is\/nX4gf",
      "display_url" : "archive.is\/nX4gf"
    } ]
  },
  "geo" : { },
  "id_str" : "937958013641601024",
  "text" : "\u65B0\u8FA6\u79FB\u52D5\u5BEC\u5E36\u88AB\u66DD\u4E0D\u80FD\u8A2A\u554F\u4EFB\u4F55\u5883\u5916\u7DB2\u7AD9\uFF1Ahttps:\/\/t.co\/7h4lhN8SXG",
  "id" : 937958013641601024,
  "created_at" : "2017-12-05 08:13:11 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9B54\u6CD5\u5C11\u5973 \u2606 poi \u9171",
      "screen_name" : "PoiScript",
      "indices" : [ 0, 10 ],
      "id_str" : "2582471214",
      "id" : 2582471214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "934458980599939074",
  "geo" : { },
  "id_str" : "937956231939010560",
  "in_reply_to_user_id" : 2582471214,
  "text" : "@PoiScript \u6240\u8B02\u8056\u676F\u4F48\u5C40\u3002",
  "id" : 937956231939010560,
  "in_reply_to_status_id" : 934458980599939074,
  "created_at" : "2017-12-05 08:06:06 +0000",
  "in_reply_to_screen_name" : "PoiScript",
  "in_reply_to_user_id_str" : "2582471214",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/937853217718841344\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/psx2i7mj2S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQPshbaVAAAfgsO.jpg",
      "id_str" : "937853206461218816",
      "id" : 937853206461218816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQPshbaVAAAfgsO.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/psx2i7mj2S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "937852884296830977",
  "geo" : { },
  "id_str" : "937853217718841344",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/psx2i7mj2S",
  "id" : 937853217718841344,
  "in_reply_to_status_id" : 937852884296830977,
  "created_at" : "2017-12-05 01:16:46 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/937852884296830977\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0pPgXChaOI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQPsLcNWsAA3w-S.jpg",
      "id_str" : "937852828718116864",
      "id" : 937852828718116864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQPsLcNWsAA3w-S.jpg",
      "sizes" : [ {
        "h" : 827,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 861,
        "resize" : "fit",
        "w" : 1250
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 861,
        "resize" : "fit",
        "w" : 1250
      } ],
      "display_url" : "pic.twitter.com\/0pPgXChaOI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "937509820495745025",
  "geo" : { },
  "id_str" : "937852884296830977",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/0pPgXChaOI",
  "id" : 937852884296830977,
  "in_reply_to_status_id" : 937509820495745025,
  "created_at" : "2017-12-05 01:15:26 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/pkjZlPOlIS",
      "expanded_url" : "https:\/\/archive.is\/2EQRd",
      "display_url" : "archive.is\/2EQRd"
    } ]
  },
  "geo" : { },
  "id_str" : "937849499950747652",
  "text" : "\u4F4E\u7AEF\u4EBA\u53E3\u88AB\u8D95\u8D70\u7684\u4F8B\u5B50\uFF1Ahttps:\/\/t.co\/pkjZlPOlIS",
  "id" : 937849499950747652,
  "created_at" : "2017-12-05 01:01:59 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/Lv4ocPBDyn",
      "expanded_url" : "https:\/\/archive.is\/Tq14p",
      "display_url" : "archive.is\/Tq14p"
    } ]
  },
  "geo" : { },
  "id_str" : "937843967353348103",
  "text" : "AutoML\u53D6\u5F97\u9032\u5C55\uFF1Ahttps:\/\/t.co\/Lv4ocPBDyn",
  "id" : 937843967353348103,
  "created_at" : "2017-12-05 00:40:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/9k6mZ2gGS5",
      "expanded_url" : "https:\/\/archive.is\/qz2V0",
      "display_url" : "archive.is\/qz2V0"
    }, {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/O0i5hn5GtH",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/937592147410288640",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937619432737828864",
  "text" : "Google\u9AD8\u7BA1\u5728\u70CF\u93AE\u5927\u6703\u4E0A\u4E00\u5718\u548C\u6C23\uFF1Ahttps:\/\/t.co\/9k6mZ2gGS5 https:\/\/t.co\/O0i5hn5GtH",
  "id" : 937619432737828864,
  "created_at" : "2017-12-04 09:47:47 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/vNHtvxi920",
      "expanded_url" : "https:\/\/archive.is\/bLl7e",
      "display_url" : "archive.is\/bLl7e"
    } ]
  },
  "geo" : { },
  "id_str" : "937613749543981056",
  "text" : "Chrome\u81F3v72\u5C07\u5185\u7F6E\u5B8C\u5584\u7684\u53CD\u9593\u8ADC\u8EDF\u4EF6\uFF1Ahttps:\/\/t.co\/vNHtvxi920",
  "id" : 937613749543981056,
  "created_at" : "2017-12-04 09:25:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/XchQcl2vUK",
      "expanded_url" : "https:\/\/archive.is\/Nn5DO",
      "display_url" : "archive.is\/Nn5DO"
    } ]
  },
  "geo" : { },
  "id_str" : "937612869667119104",
  "text" : "\u9727\u973E\u662F\u611A\u6C11\u7684\u4E00\u90E8\u5206\uFF1Ahttps:\/\/t.co\/XchQcl2vUK",
  "id" : 937612869667119104,
  "created_at" : "2017-12-04 09:21:42 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u95EB\u6069\u94ED",
      "screen_name" : "TechyanWP",
      "indices" : [ 3, 13 ],
      "id_str" : "2986143630",
      "id" : 2986143630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TechyanWP\/status\/937544934264995841\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/MhgeXYP23H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQLUIANVAAAQgTM.jpg",
      "id_str" : "937544906406428672",
      "id" : 937544906406428672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQLUIANVAAAQgTM.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/MhgeXYP23H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "937611999588110336",
  "text" : "RT @TechyanWP: \u8D35\u5708\u771F\u4E71\u3002\u3002\n\n\u6700\u540E\u7ED3\u679C\u662F\u6211\u4E00\u4E2A\u6276\u5899\u7528\u7684VPS\u5916\u52A0 techyan.me \u7684\u7F51\u7AD9\u6302\u4E86 https:\/\/t.co\/MhgeXYP23H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TechyanWP\/status\/937544934264995841\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/MhgeXYP23H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DQLUIANVAAAQgTM.jpg",
        "id_str" : "937544906406428672",
        "id" : 937544906406428672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQLUIANVAAAQgTM.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/MhgeXYP23H"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "937544934264995841",
    "text" : "\u8D35\u5708\u771F\u4E71\u3002\u3002\n\n\u6700\u540E\u7ED3\u679C\u662F\u6211\u4E00\u4E2A\u6276\u5899\u7528\u7684VPS\u5916\u52A0 techyan.me \u7684\u7F51\u7AD9\u6302\u4E86 https:\/\/t.co\/MhgeXYP23H",
    "id" : 937544934264995841,
    "created_at" : "2017-12-04 04:51:45 +0000",
    "user" : {
      "name" : "\u95EB\u6069\u94ED",
      "screen_name" : "TechyanWP",
      "protected" : false,
      "id_str" : "2986143630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911474193014808576\/dl_REU_0_normal.jpg",
      "id" : 2986143630,
      "verified" : false
    }
  },
  "id" : 937611999588110336,
  "created_at" : "2017-12-04 09:18:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/5yv78mRJBh",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/12\/427.html",
      "display_url" : "molihua.org\/2017\/12\/427.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937517860653617152",
  "text" : "\u5317\u4EAC\u5468\u908A4\u7701\u517127\u5E02\u7981\u6B62\u4F4E\u7AEF\u4EBA\u53E3\u843D\u6236\uFF1Ahttps:\/\/t.co\/5yv78mRJBh",
  "id" : 937517860653617152,
  "created_at" : "2017-12-04 03:04:10 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/d72T8Ocomq",
      "expanded_url" : "https:\/\/archive.is\/goztA#selection-733.0-733.51",
      "display_url" : "archive.is\/goztA#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937513824596439040",
  "text" : "\u9032\u53E3\u6559\u6750\u7684\u4F7F\u7528\u5C07\u9010\u6B65\u6E1B\u5C11\uFF1Ahttps:\/\/t.co\/d72T8Ocomq",
  "id" : 937513824596439040,
  "created_at" : "2017-12-04 02:48:08 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/937509820495745025\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1W1BYhV7Ak",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQK0M1BXkAEHq8S.jpg",
      "id_str" : "937509804930732033",
      "id" : 937509804930732033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQK0M1BXkAEHq8S.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/1W1BYhV7Ak"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "937235741758849024",
  "geo" : { },
  "id_str" : "937509820495745025",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/1W1BYhV7Ak",
  "id" : 937509820495745025,
  "in_reply_to_status_id" : 937235741758849024,
  "created_at" : "2017-12-04 02:32:13 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/7DdaAPbFJG",
      "expanded_url" : "https:\/\/archive.is\/2nlxl",
      "display_url" : "archive.is\/2nlxl"
    } ]
  },
  "geo" : { },
  "id_str" : "937504131387940864",
  "text" : "Dell\u958B\u59CB\u63D0\u4F9B\u6536\u8CBB\u7684Intel ME\u95DC\u9589\u670D\u52D9\uFF1Ahttps:\/\/t.co\/7DdaAPbFJG",
  "id" : 937504131387940864,
  "created_at" : "2017-12-04 02:09:37 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/937261012574769152\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/fI4qrNPPOE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQHR5ajWsAEYHug.jpg",
      "id_str" : "937260981780131841",
      "id" : 937260981780131841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQHR5ajWsAEYHug.jpg",
      "sizes" : [ {
        "h" : 666,
        "resize" : "fit",
        "w" : 483
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 483
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 483
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 483
      } ],
      "display_url" : "pic.twitter.com\/fI4qrNPPOE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "937261012574769152",
  "text" : "Microsoft Groove\u7684\u6B63\u5728\u64AD\u653E\u5217\u8868\u4E0D\u53BB\u91CD\u9084\u4E0D\u80FD\u79FB\u9664\u9805\u76EE\uFF1A https:\/\/t.co\/fI4qrNPPOE",
  "id" : 937261012574769152,
  "created_at" : "2017-12-03 10:03:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "937257923641737218",
  "text" : "Google\u7FFB\u8B6F\u5C0D\u5927\u5C0F\u5BEB\u7684\u5340\u5206\u6709\u6642\u5F88\u8A0E\u53AD\u3002",
  "id" : 937257923641737218,
  "created_at" : "2017-12-03 09:51:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/8ZB0c1KRwb",
      "expanded_url" : "https:\/\/archive.is\/PG1rb",
      "display_url" : "archive.is\/PG1rb"
    } ]
  },
  "geo" : { },
  "id_str" : "937256960105336832",
  "text" : "js\u4E2Dstring\u7684\u5BE6\u73FE\uFF1Ahttps:\/\/t.co\/8ZB0c1KRwb",
  "id" : 937256960105336832,
  "created_at" : "2017-12-03 09:47:27 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/937247763687002113\/photo\/1",
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/cobOwtSg9F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQHF3QRWAAElCEd.jpg",
      "id_str" : "937247750520963073",
      "id" : 937247750520963073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQHF3QRWAAElCEd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 825,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 825,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/cobOwtSg9F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "937247763687002113",
  "text" : "\u7232\u4EC0\u9EBD\u6642\u4E0D\u6642\u51FA\u73FE\u9019\u7A2E\uFF1F https:\/\/t.co\/cobOwtSg9F",
  "id" : 937247763687002113,
  "created_at" : "2017-12-03 09:10:54 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Huang",
      "screen_name" : "hjc4869",
      "indices" : [ 0, 8 ],
      "id_str" : "996744811",
      "id" : 996744811
    }, {
      "name" : "Nangcr",
      "screen_name" : "Nangcr",
      "indices" : [ 9, 16 ],
      "id_str" : "866175097",
      "id" : 866175097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "937242550322081792",
  "geo" : { },
  "id_str" : "937243947604291584",
  "in_reply_to_user_id" : 996744811,
  "text" : "@hjc4869 @Nangcr \u660E\u5E742\u6708\uFF0C\u4E00\u8D77\u671F\u5F85\u3002",
  "id" : 937243947604291584,
  "in_reply_to_status_id" : 937242550322081792,
  "created_at" : "2017-12-03 08:55:44 +0000",
  "in_reply_to_screen_name" : "hjc4869",
  "in_reply_to_user_id_str" : "996744811",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "indices" : [ 3, 10 ],
      "id_str" : "3359880735",
      "id" : 3359880735
    }, {
      "name" : "Nangcr",
      "screen_name" : "Nangcr",
      "indices" : [ 12, 19 ],
      "id_str" : "866175097",
      "id" : 866175097
    }, {
      "name" : "David Huang",
      "screen_name" : "hjc4869",
      "indices" : [ 20, 28 ],
      "id_str" : "996744811",
      "id" : 996744811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "937241000359223296",
  "text" : "RT @dou4cc: @Nangcr @hjc4869 \u5DE8\u982D\u7232\u6B64\u4ED8\u51FA\u4EE3\u50F9\u662F\u503C\u5F97\u7684\u3002\u5982\u679C\u793E\u5340\u8D81\u6A5F\u958B\u767C\u51FA\u4E00\u5957\u6210\u719F\u7684\u5206\u4F48\u5F0F\u76F4\u64AD\u7CFB\u7D71\uFF0C\u5DE8\u982D\u5011\u5C07\u4E0D\u53EF\u633D\u56DE\u5730\u88AB\u908A\u7DE3\u5316\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nangcr",
        "screen_name" : "Nangcr",
        "indices" : [ 0, 7 ],
        "id_str" : "866175097",
        "id" : 866175097
      }, {
        "name" : "David Huang",
        "screen_name" : "hjc4869",
        "indices" : [ 8, 16 ],
        "id_str" : "996744811",
        "id" : 996744811
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "937236269624582145",
    "geo" : { },
    "id_str" : "937240959028547584",
    "in_reply_to_user_id" : 866175097,
    "text" : "@Nangcr @hjc4869 \u5DE8\u982D\u7232\u6B64\u4ED8\u51FA\u4EE3\u50F9\u662F\u503C\u5F97\u7684\u3002\u5982\u679C\u793E\u5340\u8D81\u6A5F\u958B\u767C\u51FA\u4E00\u5957\u6210\u719F\u7684\u5206\u4F48\u5F0F\u76F4\u64AD\u7CFB\u7D71\uFF0C\u5DE8\u982D\u5011\u5C07\u4E0D\u53EF\u633D\u56DE\u5730\u88AB\u908A\u7DE3\u5316\u3002",
    "id" : 937240959028547584,
    "in_reply_to_status_id" : 937236269624582145,
    "created_at" : "2017-12-03 08:43:52 +0000",
    "in_reply_to_screen_name" : "Nangcr",
    "in_reply_to_user_id_str" : "866175097",
    "user" : {
      "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
      "screen_name" : "dou4cc",
      "protected" : false,
      "id_str" : "3359880735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
      "id" : 3359880735,
      "verified" : false
    }
  },
  "id" : 937241000359223296,
  "created_at" : "2017-12-03 08:44:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nangcr",
      "screen_name" : "Nangcr",
      "indices" : [ 0, 7 ],
      "id_str" : "866175097",
      "id" : 866175097
    }, {
      "name" : "David Huang",
      "screen_name" : "hjc4869",
      "indices" : [ 8, 16 ],
      "id_str" : "996744811",
      "id" : 996744811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "937236269624582145",
  "geo" : { },
  "id_str" : "937240959028547584",
  "in_reply_to_user_id" : 866175097,
  "text" : "@Nangcr @hjc4869 \u5DE8\u982D\u7232\u6B64\u4ED8\u51FA\u4EE3\u50F9\u662F\u503C\u5F97\u7684\u3002\u5982\u679C\u793E\u5340\u8D81\u6A5F\u958B\u767C\u51FA\u4E00\u5957\u6210\u719F\u7684\u5206\u4F48\u5F0F\u76F4\u64AD\u7CFB\u7D71\uFF0C\u5DE8\u982D\u5011\u5C07\u4E0D\u53EF\u633D\u56DE\u5730\u88AB\u908A\u7DE3\u5316\u3002",
  "id" : 937240959028547584,
  "in_reply_to_status_id" : 937236269624582145,
  "created_at" : "2017-12-03 08:43:52 +0000",
  "in_reply_to_screen_name" : "Nangcr",
  "in_reply_to_user_id_str" : "866175097",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/KzWFqNIZoF",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=15814121",
      "display_url" : "news.ycombinator.com\/item?id=158141\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937236851949060096",
  "text" : "Google\u66FE\u5C4F\u8CD3ProtonMail\uFF0C\u800COutlook\u81F3\u4ECA\u4ECD\u628Anotify@protonmail.ch\u7684\u90F5\u4EF6\u8A8D\u4F5C\u5783\u573E\u90F5\u4EF6\uFF1Ahttps:\/\/t.co\/KzWFqNIZoF",
  "id" : 937236851949060096,
  "created_at" : "2017-12-03 08:27:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/N6TRULoj08",
      "expanded_url" : "https:\/\/arstechnica.com\/tech-policy\/2017\/12\/att-says-it-never-blocked-apps-fails-to-mention-how-it-blocked-facetime\/",
      "display_url" : "arstechnica.com\/tech-policy\/20\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "937212746961182720",
  "geo" : { },
  "id_str" : "937235741758849024",
  "in_reply_to_user_id" : 3359880735,
  "text" : "AT&amp;T\u66FE\u5C01\u9396FaceTime\uFF1Ahttps:\/\/t.co\/N6TRULoj08",
  "id" : 937235741758849024,
  "in_reply_to_status_id" : 937212746961182720,
  "created_at" : "2017-12-03 08:23:08 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/6FDMhRNxHu",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=15836027",
      "display_url" : "news.ycombinator.com\/item?id=158360\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "937228943194836993",
  "text" : "Firefox\u7684\u7368\u7ACB\u4F86\u4E4B\u4E0D\u6613\uFF1Ahttps:\/\/t.co\/6FDMhRNxHu",
  "id" : 937228943194836993,
  "created_at" : "2017-12-03 07:56:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/8weXDrRqJS",
      "expanded_url" : "https:\/\/archive.is\/HXO6p",
      "display_url" : "archive.is\/HXO6p"
    } ]
  },
  "geo" : { },
  "id_str" : "937214881530630144",
  "text" : "\u91D1\u78DA\u4E94\u56EF\u4F01\u5716\u6495\u88C2\u4E92\u806F\u7DB2\uFF1Ahttps:\/\/t.co\/8weXDrRqJS",
  "id" : 937214881530630144,
  "created_at" : "2017-12-03 07:00:15 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/937212746961182720\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/kVlmsIBqu2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQGmBKZXUAA999T.jpg",
      "id_str" : "937212736370593792",
      "id" : 937212736370593792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQGmBKZXUAA999T.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/kVlmsIBqu2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "936853722394533888",
  "geo" : { },
  "id_str" : "937212746961182720",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/kVlmsIBqu2",
  "id" : 937212746961182720,
  "in_reply_to_status_id" : 936853722394533888,
  "created_at" : "2017-12-03 06:51:46 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/scJZyEdzrv",
      "expanded_url" : "https:\/\/archive.is\/RSxOj#selection-4479.0-4479.42",
      "display_url" : "archive.is\/RSxOj#selectio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936952018043916288",
  "text" : "Chrome\u4E0D\u4F46Canary\u4E0D\u652F\u6301Linux\uFF0C\u6B63\u5F0F\u7248\u4E5F\u5728Linux\u4E2D\u5B58\u5728\u666E\u904D\u7684\u5185\u5B58\u6CC4\u6F0F\u554F\u984C\uFF1Ahttps:\/\/t.co\/scJZyEdzrv",
  "id" : 936952018043916288,
  "created_at" : "2017-12-02 13:35:43 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 0, 12 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    }, {
      "name" : "\u6708\u5E95\u5403\u571F\u7684Jimmy Zhang\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "jichi_zhang",
      "indices" : [ 13, 25 ],
      "id_str" : "4628523253",
      "id" : 4628523253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "936936230536617984",
  "geo" : { },
  "id_str" : "936936618744864768",
  "in_reply_to_user_id" : 745341593817747456,
  "text" : "@DevinStever @jichi_zhang jimmy\u7684\u7DB2\u901F\u90FD\u662F\u4E09\u4F4D\u6578\u8D77\u6B65\u7684\u3002",
  "id" : 936936618744864768,
  "in_reply_to_status_id" : 936936230536617984,
  "created_at" : "2017-12-02 12:34:32 +0000",
  "in_reply_to_screen_name" : "DevinStever",
  "in_reply_to_user_id_str" : "745341593817747456",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/U5iaVUAT2G",
      "expanded_url" : "http:\/\/theschemer.org\/",
      "display_url" : "theschemer.org"
    } ]
  },
  "geo" : { },
  "id_str" : "936926971338153984",
  "text" : "Scheme\u4E2D\u6587\u793E\u5340\u4E0A\u7DAB\u4E86\uFF1Ahttps:\/\/t.co\/U5iaVUAT2G",
  "id" : 936926971338153984,
  "created_at" : "2017-12-02 11:56:11 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9648\u5C11\u4E3E",
      "screen_name" : "chenshaoju",
      "indices" : [ 3, 14 ],
      "id_str" : "17482838",
      "id" : 17482838
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chenshaoju\/status\/936478154356539392\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/SqjMiOraEX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DP8J6l5VQAAyE5s.jpg",
      "id_str" : "936478149725995008",
      "id" : 936478149725995008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP8J6l5VQAAyE5s.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 1277
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 1277
      } ],
      "display_url" : "pic.twitter.com\/SqjMiOraEX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/y4cG4BQbov",
      "expanded_url" : "http:\/\/jsfzb.jschina.com.cn\/mp2\/pc\/c\/201710\/25\/c393290.html",
      "display_url" : "jsfzb.jschina.com.cn\/mp2\/pc\/c\/20171\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936926291445604352",
  "text" : "RT @chenshaoju: \u67E5\u4E86\u4E00\u4E0B\uFF0C\u622A\u56FE\u5B58\u6863\uFF1A https:\/\/t.co\/y4cG4BQbov https:\/\/t.co\/SqjMiOraEX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sourceforge.jp\/projects\/opentween\/\" rel=\"nofollow\"\u003EOpenTween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chenshaoju\/status\/936478154356539392\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/SqjMiOraEX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DP8J6l5VQAAyE5s.jpg",
        "id_str" : "936478149725995008",
        "id" : 936478149725995008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP8J6l5VQAAyE5s.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 785,
          "resize" : "fit",
          "w" : 1277
        }, {
          "h" : 785,
          "resize" : "fit",
          "w" : 1277
        } ],
        "display_url" : "pic.twitter.com\/SqjMiOraEX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/y4cG4BQbov",
        "expanded_url" : "http:\/\/jsfzb.jschina.com.cn\/mp2\/pc\/c\/201710\/25\/c393290.html",
        "display_url" : "jsfzb.jschina.com.cn\/mp2\/pc\/c\/20171\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "936478154356539392",
    "text" : "\u67E5\u4E86\u4E00\u4E0B\uFF0C\u622A\u56FE\u5B58\u6863\uFF1A https:\/\/t.co\/y4cG4BQbov https:\/\/t.co\/SqjMiOraEX",
    "id" : 936478154356539392,
    "created_at" : "2017-12-01 06:12:45 +0000",
    "user" : {
      "name" : "\u9648\u5C11\u4E3E",
      "screen_name" : "chenshaoju",
      "protected" : false,
      "id_str" : "17482838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431978219240038400\/s5n7jbKl_normal.png",
      "id" : 17482838,
      "verified" : false
    }
  },
  "id" : 936926291445604352,
  "created_at" : "2017-12-02 11:53:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9648\u5C11\u4E3E",
      "screen_name" : "chenshaoju",
      "indices" : [ 3, 14 ],
      "id_str" : "17482838",
      "id" : 17482838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/OkeO3RASwd",
      "expanded_url" : "https:\/\/www.sockscap64.com\/en\/sstap-sockscap64-permanently-stop-developmentsstap%e5%92%8csockscap64%e5%b0%87%e6%b0%b8%e4%b9%85%e5%81%9c%e6%ad%a2%e9%96%8b%e7%99%bc\/",
      "display_url" : "sockscap64.com\/en\/sstap-socks\u2026"
    }, {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/xbzzZVjg1g",
      "expanded_url" : "https:\/\/twitter.com\/jiangshan\/status\/936884847234007040",
      "display_url" : "twitter.com\/jiangshan\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936926149657186304",
  "text" : "RT @chenshaoju: \u67E5\u4E86\u4E00\u4E0B\uFF0C\u771F\u662F\u9057\u61BE\u3002 https:\/\/t.co\/OkeO3RASwd https:\/\/t.co\/xbzzZVjg1g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sourceforge.jp\/projects\/opentween\/\" rel=\"nofollow\"\u003EOpenTween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/OkeO3RASwd",
        "expanded_url" : "https:\/\/www.sockscap64.com\/en\/sstap-sockscap64-permanently-stop-developmentsstap%e5%92%8csockscap64%e5%b0%87%e6%b0%b8%e4%b9%85%e5%81%9c%e6%ad%a2%e9%96%8b%e7%99%bc\/",
        "display_url" : "sockscap64.com\/en\/sstap-socks\u2026"
      }, {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/xbzzZVjg1g",
        "expanded_url" : "https:\/\/twitter.com\/jiangshan\/status\/936884847234007040",
        "display_url" : "twitter.com\/jiangshan\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "936885537142534145",
    "text" : "\u67E5\u4E86\u4E00\u4E0B\uFF0C\u771F\u662F\u9057\u61BE\u3002 https:\/\/t.co\/OkeO3RASwd https:\/\/t.co\/xbzzZVjg1g",
    "id" : 936885537142534145,
    "created_at" : "2017-12-02 09:11:33 +0000",
    "user" : {
      "name" : "\u9648\u5C11\u4E3E",
      "screen_name" : "chenshaoju",
      "protected" : false,
      "id_str" : "17482838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431978219240038400\/s5n7jbKl_normal.png",
      "id" : 17482838,
      "verified" : false
    }
  },
  "id" : 936926149657186304,
  "created_at" : "2017-12-02 11:52:55 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/TZfacaKzAs",
      "expanded_url" : "https:\/\/archive.is\/Ni7Ix",
      "display_url" : "archive.is\/Ni7Ix"
    } ]
  },
  "geo" : { },
  "id_str" : "936888597499723776",
  "text" : "\u7E7CPurism\u4E4B\u5F8CSystem76\u9ED8\u8A8D\u7981\u7528Intel ME\uFF1Ahttps:\/\/t.co\/TZfacaKzAs",
  "id" : 936888597499723776,
  "created_at" : "2017-12-02 09:23:42 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RaIN|\u94C3\u7FBD",
      "screen_name" : "Rain_txy",
      "indices" : [ 3, 12 ],
      "id_str" : "2316404671",
      "id" : 2316404671
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Rain_txy\/status\/936405324625354752\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/JL1mWAtr2C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DP7Hq-rUQAAd2AD.jpg",
      "id_str" : "936405313732755456",
      "id" : 936405313732755456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP7Hq-rUQAAd2AD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/JL1mWAtr2C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936864148989755398",
  "text" : "RT @Rain_txy: \u5929\u6D25\u4E5F\u8981\u6B65\u5317\u4EAC\u540E\u5C18\u5417 https:\/\/t.co\/JL1mWAtr2C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Rain_txy\/status\/936405324625354752\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/JL1mWAtr2C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DP7Hq-rUQAAd2AD.jpg",
        "id_str" : "936405313732755456",
        "id" : 936405313732755456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP7Hq-rUQAAd2AD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/JL1mWAtr2C"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "936405324625354752",
    "text" : "\u5929\u6D25\u4E5F\u8981\u6B65\u5317\u4EAC\u540E\u5C18\u5417 https:\/\/t.co\/JL1mWAtr2C",
    "id" : 936405324625354752,
    "created_at" : "2017-12-01 01:23:21 +0000",
    "user" : {
      "name" : "RaIN|\u94C3\u7FBD",
      "screen_name" : "Rain_txy",
      "protected" : false,
      "id_str" : "2316404671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945298967796920320\/F6cY6goi_normal.jpg",
      "id" : 2316404671,
      "verified" : false
    }
  },
  "id" : 936864148989755398,
  "created_at" : "2017-12-02 07:46:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "936617126944653312",
  "geo" : { },
  "id_str" : "936859996381310976",
  "in_reply_to_user_id" : 853215582342086656,
  "text" : "@pixivp \u7DB2\u6613\u96F2\u97F3\u6A02\u8F38\u6389\u7248\u6B0A\u540E\u65E5\u63A8\u5DF2\u5F9E\u63A8\u85A6\u8B8A\u6210\u5F15\u5C0E\u3002",
  "id" : 936859996381310976,
  "in_reply_to_status_id" : 936617126944653312,
  "created_at" : "2017-12-02 07:30:03 +0000",
  "in_reply_to_screen_name" : "pio777777",
  "in_reply_to_user_id_str" : "853215582342086656",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/936853722394533888\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/wHs1gYXbzy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DQBfeiqUEAACmQj.jpg",
      "id_str" : "936853700798058496",
      "id" : 936853700798058496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DQBfeiqUEAACmQj.jpg",
      "sizes" : [ {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/wHs1gYXbzy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "936392949235179521",
  "geo" : { },
  "id_str" : "936853722394533888",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/wHs1gYXbzy",
  "id" : 936853722394533888,
  "in_reply_to_status_id" : 936392949235179521,
  "created_at" : "2017-12-02 07:05:07 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/kmewhElwhu",
      "expanded_url" : "https:\/\/www.bennythink.com\/all-platform-scientific-internet-all-in-one.html",
      "display_url" : "bennythink.com\/all-platform-s\u2026"
    }, {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/TcToQmYq8E",
      "expanded_url" : "https:\/\/github.com\/XX-net\/XX-Net",
      "display_url" : "github.com\/XX-net\/XX-Net"
    }, {
      "indices" : [ 160, 183 ],
      "url" : "https:\/\/t.co\/J0gtRY19Tf",
      "expanded_url" : "https:\/\/twitter.com\/Air_Mu\/status\/935895591837503489",
      "display_url" : "twitter.com\/Air_Mu\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936431204148174850",
  "text" : "\u525B\u525B\u9AD4\u9A57\u4E86\u4E00\u4E0B\u4F4E\u7AEF\u4EBA\u53E3\u7684\u7FFB\u58BB\u65E5\u5E38\uFF1A\n- \u4E0A\u767E\u5EA6\u641C\u201C\u79D1\u5B66\u4E0A\u7F51\u201D\n- \u70B9\u7B2C\u4E00\u6761\u8FDB\u5165https:\/\/t.co\/kmewhElwhu\n- \u6309\u6587\u5185\u93C8\u63A5\u9032\u5165https:\/\/t.co\/TcToQmYq8E\n- \u8F49\u4E0B\u8F09\u9801\u4E0B\u8F09\uFF0C\u4E0B\u4E86\u5927\u6982\u534A\u5C0F\u6642\n- \u6253\u958BXX-Net\uFF0C\u9032\u5165X-Tunnel\uFF0C\u6CE8\u518A\u8CEC\u865F\u7372\u5F97500M\u6D41\u91CF\n- \u901F\u5EA6\u52C9\u5F3A\u80FD\u700F\u89BD\u7DB2\u9801 https:\/\/t.co\/J0gtRY19Tf",
  "id" : 936431204148174850,
  "created_at" : "2017-12-01 03:06:11 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/Xx53gEeibL",
      "expanded_url" : "http:\/\/www.molihua.org\/2017\/11\/200.html",
      "display_url" : "molihua.org\/2017\/11\/200.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936406732905025536",
  "text" : "\u5F20\u9633\u81EA\u6BBA\uFF1Ahttps:\/\/t.co\/Xx53gEeibL",
  "id" : 936406732905025536,
  "created_at" : "2017-12-01 01:28:57 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "indices" : [ 3, 15 ],
      "id_str" : "745341593817747456",
      "id" : 745341593817747456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936398788687749120",
  "text" : "RT @DevinStever: \u6211\u7EC8\u4E8E\u77E5\u9053\u4E3A\u4EC0\u4E48SSR\u4F7F\u7528http\u6DF7\u6DC6\u548Ctls\u6DF7\u6DC6\u7684\u65F6\u5019\u4F1A\u7ECF\u5E38\u65AD\u7EBF\u51FA\u73B0\u7591\u4F3C\u88AB\u5899\u7684\u72B6\u6001\u4E86\u3002\n\u539F\u6765\u662F\u5899\u4F1A\u8DDF\u5728\u6A21\u62DFhttp\u8BF7\u6C42\u7684\u5305\u540E\u9762\u4E5F\u53BBGET\u4E00\u4E0B\u6216\u8005\u662F\u4E5F\u53D1\u4E00\u4E2ATLS\u63E1\u624B\uFF0C\u5224\u65AD\u662F\u4E0D\u662F\u771F\u6B63\u7684\u670D\u52A1\u5668\uFF0C\u5982\u679C\u4E0D\u662F\u5C31\u4E22\u5305\u3002\u3002\u3002\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "936112511115444225",
    "text" : "\u6211\u7EC8\u4E8E\u77E5\u9053\u4E3A\u4EC0\u4E48SSR\u4F7F\u7528http\u6DF7\u6DC6\u548Ctls\u6DF7\u6DC6\u7684\u65F6\u5019\u4F1A\u7ECF\u5E38\u65AD\u7EBF\u51FA\u73B0\u7591\u4F3C\u88AB\u5899\u7684\u72B6\u6001\u4E86\u3002\n\u539F\u6765\u662F\u5899\u4F1A\u8DDF\u5728\u6A21\u62DFhttp\u8BF7\u6C42\u7684\u5305\u540E\u9762\u4E5F\u53BBGET\u4E00\u4E0B\u6216\u8005\u662F\u4E5F\u53D1\u4E00\u4E2ATLS\u63E1\u624B\uFF0C\u5224\u65AD\u662F\u4E0D\u662F\u771F\u6B63\u7684\u670D\u52A1\u5668\uFF0C\u5982\u679C\u4E0D\u662F\u5C31\u4E22\u5305\u3002\u3002\u3002\u3002",
    "id" : 936112511115444225,
    "created_at" : "2017-11-30 05:59:49 +0000",
    "user" : {
      "name" : "Devin Stever",
      "screen_name" : "DevinStever",
      "protected" : false,
      "id_str" : "745341593817747456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924484708607647744\/qIOYZnbn_normal.jpg",
      "id" : 745341593817747456,
      "verified" : false
    }
  },
  "id" : 936398788687749120,
  "created_at" : "2017-12-01 00:57:23 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dou4cc\/status\/936392949235179521\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/rhw4JLrvXc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DP68au1V4AEKAWK.jpg",
      "id_str" : "936392939974025217",
      "id" : 936392939974025217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP68au1V4AEKAWK.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 665
      } ],
      "display_url" : "pic.twitter.com\/rhw4JLrvXc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "936064518739939328",
  "geo" : { },
  "id_str" : "936392949235179521",
  "in_reply_to_user_id" : 3359880735,
  "text" : "https:\/\/t.co\/rhw4JLrvXc",
  "id" : 936392949235179521,
  "in_reply_to_status_id" : 936064518739939328,
  "created_at" : "2017-12-01 00:34:11 +0000",
  "in_reply_to_screen_name" : "dou4cc",
  "in_reply_to_user_id_str" : "3359880735",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]