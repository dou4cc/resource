Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/777859930728517632\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/OH5aAQgiyl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsuDeFyVUAAsOH3.jpg",
      "id_str" : "777859913624145920",
      "id" : 777859913624145920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsuDeFyVUAAsOH3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 687,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 1446
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 1446
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/OH5aAQgiyl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/kE2LfgBAwo",
      "expanded_url" : "https:\/\/developers.google.com\/web\/updates\/2016\/03\/access-usb-devices-on-the-web",
      "display_url" : "developers.google.com\/web\/updates\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778594260723470336",
  "text" : "RT @ruanyf: Chrome v54 \u90E8\u7F72\u4E86WebUSB \u63A5\u53E3\uFF0C\u53EF\u4EE5\u76F4\u63A5\u4ECE\u6D4F\u89C8\u5668\u63A7\u5236 USB \u8BBE\u5907\uFF01\u64CD\u4F5C\u7CFB\u7EDF\u7684API\uFF0C\u6B63\u5728\u4E00\u9879\u9879\u79FB\u690D\u5230\u6D4F\u89C8\u5668\uFF0CWeb \u5E94\u7528\u7684\u524D\u666F\u4E00\u7247\u5149\u660E\u3002https:\/\/t.co\/kE2LfgBAwo https:\/\/t.co\/OH5aAQgiyl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/777859930728517632\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/OH5aAQgiyl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsuDeFyVUAAsOH3.jpg",
        "id_str" : "777859913624145920",
        "id" : 777859913624145920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsuDeFyVUAAsOH3.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 828,
          "resize" : "fit",
          "w" : 1446
        }, {
          "h" : 828,
          "resize" : "fit",
          "w" : 1446
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/OH5aAQgiyl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/kE2LfgBAwo",
        "expanded_url" : "https:\/\/developers.google.com\/web\/updates\/2016\/03\/access-usb-devices-on-the-web",
        "display_url" : "developers.google.com\/web\/updates\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777859930728517632",
    "text" : "Chrome v54 \u90E8\u7F72\u4E86WebUSB \u63A5\u53E3\uFF0C\u53EF\u4EE5\u76F4\u63A5\u4ECE\u6D4F\u89C8\u5668\u63A7\u5236 USB \u8BBE\u5907\uFF01\u64CD\u4F5C\u7CFB\u7EDF\u7684API\uFF0C\u6B63\u5728\u4E00\u9879\u9879\u79FB\u690D\u5230\u6D4F\u89C8\u5668\uFF0CWeb \u5E94\u7528\u7684\u524D\u666F\u4E00\u7247\u5149\u660E\u3002https:\/\/t.co\/kE2LfgBAwo https:\/\/t.co\/OH5aAQgiyl",
    "id" : 777859930728517632,
    "created_at" : "2016-09-19 13:20:34 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 778594260723470336,
  "created_at" : "2016-09-21 13:58:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778593439327723521",
  "text" : "RT @williamlong: \u300A\u7F51\u6613\u8BBA\u575B\u5BA3\u5E03\u5173\u95ED\u300B \u8BBA\u575B\u8FD9\u79CD\u670D\u52A1\u7684\u4E00\u5927\u7279\u70B9\u662F\uFF0C\u5176\u5185\u5BB9100%\u7531\u7528\u6237\u4EA7\u751F\uFF0C\u5B58\u5728\u7740\u5F88\u5927\u7684\u653F\u7B56\u98CE\u9669\uFF0C\u9700\u8981\u4E0D\u65AD\u589E\u52A0\u4EBA\u529B\u8D44\u6E90\u6765\u7EF4\u62A4\uFF0C\u4EE5\u9632\u201C\u6709\u5BB3\u4FE1\u606F\u201D\u7684\u51FA\u73B0\u5F15\u6765\u653F\u7B56\u98CE\u9669\uFF0C\u8FDE\u7D2F\u5176\u4ED6\u670D\u52A1\uFF0C\u8FD9\u4E5F\u5BFC\u81F4\u8FD9\u79CDUGC\u670D\u52A1\u4E00\u65E6\u88AB\u653E\u5F03\uFF0C\u5C31\u53EA\u80FD\u5F7B\u5E95\u5173\u95ED https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/W5WKYBfO2B",
        "expanded_url" : "http:\/\/t.cn\/RcWOnSn",
        "display_url" : "t.cn\/RcWOnSn"
      } ]
    },
    "geo" : { },
    "id_str" : "778533378538737665",
    "text" : "\u300A\u7F51\u6613\u8BBA\u575B\u5BA3\u5E03\u5173\u95ED\u300B \u8BBA\u575B\u8FD9\u79CD\u670D\u52A1\u7684\u4E00\u5927\u7279\u70B9\u662F\uFF0C\u5176\u5185\u5BB9100%\u7531\u7528\u6237\u4EA7\u751F\uFF0C\u5B58\u5728\u7740\u5F88\u5927\u7684\u653F\u7B56\u98CE\u9669\uFF0C\u9700\u8981\u4E0D\u65AD\u589E\u52A0\u4EBA\u529B\u8D44\u6E90\u6765\u7EF4\u62A4\uFF0C\u4EE5\u9632\u201C\u6709\u5BB3\u4FE1\u606F\u201D\u7684\u51FA\u73B0\u5F15\u6765\u653F\u7B56\u98CE\u9669\uFF0C\u8FDE\u7D2F\u5176\u4ED6\u670D\u52A1\uFF0C\u8FD9\u4E5F\u5BFC\u81F4\u8FD9\u79CDUGC\u670D\u52A1\u4E00\u65E6\u88AB\u653E\u5F03\uFF0C\u5C31\u53EA\u80FD\u5F7B\u5E95\u5173\u95ED https:\/\/t.co\/W5WKYBfO2B",
    "id" : 778533378538737665,
    "created_at" : "2016-09-21 09:56:36 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 778593439327723521,
  "created_at" : "2016-09-21 13:55:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]