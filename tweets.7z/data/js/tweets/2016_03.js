Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/713748485623820288\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/IiKHmiCDOg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cee-cT7WQAAqaBO.jpg",
      "id_str" : "713748459556323328",
      "id" : 713748459556323328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cee-cT7WQAAqaBO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 165,
        "resize" : "fit",
        "w" : 394
      }, {
        "h" : 165,
        "resize" : "fit",
        "w" : 394
      }, {
        "h" : 165,
        "resize" : "fit",
        "w" : 394
      }, {
        "h" : 165,
        "resize" : "fit",
        "w" : 394
      } ],
      "display_url" : "pic.twitter.com\/IiKHmiCDOg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/6hSrwAztZW",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/36203614\/super-does-not-pass-arguments-when-instantiating-a-class-extended-from-object",
      "display_url" : "stackoverflow.com\/questions\/3620\u2026"
    }, {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/cUFrpq40EO",
      "expanded_url" : "https:\/\/bugs.chromium.org\/p\/chromium\/issues\/detail?id=597493",
      "display_url" : "bugs.chromium.org\/p\/chromium\/iss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714033866789367808",
  "text" : "RT @ruanyf: ES6 \u4E00\u4E2A\u4EE4\u4EBA\u9707\u60CA\u7684\u884C\u4E3A\uFF0C Chrome 49 \u8FD4\u56DE false\u3002\nhttps:\/\/t.co\/6hSrwAztZW\n\nhttps:\/\/t.co\/cUFrpq40EO https:\/\/t.co\/IiKHmiCDOg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/713748485623820288\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/IiKHmiCDOg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cee-cT7WQAAqaBO.jpg",
        "id_str" : "713748459556323328",
        "id" : 713748459556323328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cee-cT7WQAAqaBO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 165,
          "resize" : "fit",
          "w" : 394
        }, {
          "h" : 165,
          "resize" : "fit",
          "w" : 394
        }, {
          "h" : 165,
          "resize" : "fit",
          "w" : 394
        }, {
          "h" : 165,
          "resize" : "fit",
          "w" : 394
        } ],
        "display_url" : "pic.twitter.com\/IiKHmiCDOg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/6hSrwAztZW",
        "expanded_url" : "http:\/\/stackoverflow.com\/questions\/36203614\/super-does-not-pass-arguments-when-instantiating-a-class-extended-from-object",
        "display_url" : "stackoverflow.com\/questions\/3620\u2026"
      }, {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/cUFrpq40EO",
        "expanded_url" : "https:\/\/bugs.chromium.org\/p\/chromium\/issues\/detail?id=597493",
        "display_url" : "bugs.chromium.org\/p\/chromium\/iss\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "713748485623820288",
    "text" : "ES6 \u4E00\u4E2A\u4EE4\u4EBA\u9707\u60CA\u7684\u884C\u4E3A\uFF0C Chrome 49 \u8FD4\u56DE false\u3002\nhttps:\/\/t.co\/6hSrwAztZW\n\nhttps:\/\/t.co\/cUFrpq40EO https:\/\/t.co\/IiKHmiCDOg",
    "id" : 713748485623820288,
    "created_at" : "2016-03-26 15:24:34 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 714033866789367808,
  "created_at" : "2016-03-27 10:18:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TayTweets",
      "screen_name" : "TayandYou",
      "indices" : [ 0, 10 ],
      "id_str" : "4531940473",
      "id" : 4531940473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713331123292672004",
  "in_reply_to_user_id" : 4531940473,
  "text" : "@TayandYou Nice to know you!",
  "id" : 713331123292672004,
  "created_at" : "2016-03-25 11:46:07 +0000",
  "in_reply_to_screen_name" : "TayandYou",
  "in_reply_to_user_id_str" : "4531940473",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712846869605396480",
  "geo" : { },
  "id_str" : "713317485538328576",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u679C\u7136\u662F\u963F\u91CC\u4EBA\u3002",
  "id" : 713317485538328576,
  "in_reply_to_status_id" : 712846869605396480,
  "created_at" : "2016-03-25 10:51:56 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713317005403766784",
  "text" : "RT @williamlong: \u9999\u6E2F\u8B66\u65B9\u8BC1\u5B9E\uFF0C\u94DC\u9523\u6E7E\u4E66\u5E97\u8D1F\u8D23\u4EBA\u674E\u6CE224\u65E5\u4E0B\u5348\u7ECF\u843D\u9A6C\u6D32\u53E3\u5CB8\u8FD4\u6E2F\uFF0C\u5F53\u65F6\u4ED6\u4F7F\u7528\u8EAB\u4EFD\u8BC1\u5165\u5883\uFF0C\u5165\u5883\u5904\u4EBA\u5458\u53CA\u8B66\u65B9\u5148\u540E\u4F1A\u89C1\u674E\u6CE2\uFF0C\u674E\u6CE2\u8981\u6C42\u9500\u6848\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "713165711670161408",
    "text" : "\u9999\u6E2F\u8B66\u65B9\u8BC1\u5B9E\uFF0C\u94DC\u9523\u6E7E\u4E66\u5E97\u8D1F\u8D23\u4EBA\u674E\u6CE224\u65E5\u4E0B\u5348\u7ECF\u843D\u9A6C\u6D32\u53E3\u5CB8\u8FD4\u6E2F\uFF0C\u5F53\u65F6\u4ED6\u4F7F\u7528\u8EAB\u4EFD\u8BC1\u5165\u5883\uFF0C\u5165\u5883\u5904\u4EBA\u5458\u53CA\u8B66\u65B9\u5148\u540E\u4F1A\u89C1\u674E\u6CE2\uFF0C\u674E\u6CE2\u8981\u6C42\u9500\u6848\u3002",
    "id" : 713165711670161408,
    "created_at" : "2016-03-25 00:48:50 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 713317005403766784,
  "created_at" : "2016-03-25 10:50:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712843706416508930",
  "geo" : { },
  "id_str" : "712992762656722946",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u793E\u533A\u662F\u4E0D\u662F\u88ABUnix\u795E\u68CD\u5E26\u574F\u4E86\uFF1F\u4E00\u505A\u901A\u7528\u7684\u4E1C\u897F\u5C31\u662F\u6587\u4EF6\u7CFB\u7EDF\u3002",
  "id" : 712992762656722946,
  "in_reply_to_status_id" : 712843706416508930,
  "created_at" : "2016-03-24 13:21:36 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712590787821707264",
  "text" : "RT @williamlong: \u5173\u4E8E\u6BD2\u75AB\u82D7\u4E8B\u4EF6\u7684\u51E0\u4E2A\u201C\u65E7\u95FB\u201D\uFF0C\u51E0\u5E74\u524D\u8BB0\u8005\u738B\u514B\u52E4\u62A5\u9053\u8FC7\u5C71\u897F\u75AB\u82D7\u7684\u5927\u89C4\u6A21\u533B\u7597\u4E8B\u6545\uFF0C\u7136\u800C\u4ED6\u5728\u62A5\u9053\u540E\u88AB\u8FEB\u8F9E\u804C\uFF0C\u5F8B\u5E08\u5510\u8346\u9675\u5341\u5E74\u524D\u5C31\u5F00\u59CB\u4EE3\u7406\u75AB\u82D7\u53D7\u5BB3\u8005\u5BB6\u957F\u7684\u8BC9\u8BBC\uFF0C\u7136\u800C2014\u5E74\u5E7F\u5DDE\u8B66\u65B9\u4EE5\u201C\u98A0\u8986\u56FD\u5BB6\u5B89\u5168\u7F6A\u201D\u7684\u7F6A\u540D\u5C06\u4ED6\u62D8\u7559\uFF0C2016\u5E741\u6708\uFF0C\u4ED6\u88AB\u5224\u5904\u6709\u671F\u5F92\u5211\u4E94\u5E74\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712301834237583361",
    "text" : "\u5173\u4E8E\u6BD2\u75AB\u82D7\u4E8B\u4EF6\u7684\u51E0\u4E2A\u201C\u65E7\u95FB\u201D\uFF0C\u51E0\u5E74\u524D\u8BB0\u8005\u738B\u514B\u52E4\u62A5\u9053\u8FC7\u5C71\u897F\u75AB\u82D7\u7684\u5927\u89C4\u6A21\u533B\u7597\u4E8B\u6545\uFF0C\u7136\u800C\u4ED6\u5728\u62A5\u9053\u540E\u88AB\u8FEB\u8F9E\u804C\uFF0C\u5F8B\u5E08\u5510\u8346\u9675\u5341\u5E74\u524D\u5C31\u5F00\u59CB\u4EE3\u7406\u75AB\u82D7\u53D7\u5BB3\u8005\u5BB6\u957F\u7684\u8BC9\u8BBC\uFF0C\u7136\u800C2014\u5E74\u5E7F\u5DDE\u8B66\u65B9\u4EE5\u201C\u98A0\u8986\u56FD\u5BB6\u5B89\u5168\u7F6A\u201D\u7684\u7F6A\u540D\u5C06\u4ED6\u62D8\u7559\uFF0C2016\u5E741\u6708\uFF0C\u4ED6\u88AB\u5224\u5904\u6709\u671F\u5F92\u5211\u4E94\u5E74\u3002",
    "id" : 712301834237583361,
    "created_at" : "2016-03-22 15:36:05 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 712590787821707264,
  "created_at" : "2016-03-23 10:44:17 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boying Xu",
      "screen_name" : "xuboying",
      "indices" : [ 0, 9 ],
      "id_str" : "49253181",
      "id" : 49253181
    }, {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 10, 17 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709605007595806720",
  "geo" : { },
  "id_str" : "710815094565810176",
  "in_reply_to_user_id" : 49253181,
  "text" : "@xuboying @ruanyf \u539Fpo\u53EA\u8BF4\u8BA8\u538C\u4E0A\u8272\uFF0C\u6CA1\u8BF4\u5173\u952E\u5B57\u4E0D\u53EF\u4EE5\u52A0\u7C97\u554A\uFF1F",
  "id" : 710815094565810176,
  "in_reply_to_status_id" : 709605007595806720,
  "created_at" : "2016-03-18 13:08:19 +0000",
  "in_reply_to_screen_name" : "xuboying",
  "in_reply_to_user_id_str" : "49253181",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E00\u822C\u4F1A\u793E\u54E1\u8774\u8776\u85CDP",
      "screen_name" : "AiHina",
      "indices" : [ 3, 10 ],
      "id_str" : "105541512",
      "id" : 105541512
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AiHina\/status\/710064297989148673\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/O9GPZQ6pkl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdqntQIUMAAVF4g.jpg",
      "id_str" : "710064287130071040",
      "id" : 710064287130071040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdqntQIUMAAVF4g.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 969,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 969,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 969,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/O9GPZQ6pkl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710782680539869188",
  "text" : "RT @AiHina: \u8FD9\u9524\u5B50\u548B\u8FD9\u4E48\u5B9E\u5728\u5462\uD83D\uDE02 https:\/\/t.co\/O9GPZQ6pkl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AiHina\/status\/710064297989148673\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/O9GPZQ6pkl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdqntQIUMAAVF4g.jpg",
        "id_str" : "710064287130071040",
        "id" : 710064287130071040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdqntQIUMAAVF4g.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 969,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 969,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 969,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/O9GPZQ6pkl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "710064297989148673",
    "text" : "\u8FD9\u9524\u5B50\u548B\u8FD9\u4E48\u5B9E\u5728\u5462\uD83D\uDE02 https:\/\/t.co\/O9GPZQ6pkl",
    "id" : 710064297989148673,
    "created_at" : "2016-03-16 11:24:55 +0000",
    "user" : {
      "name" : "\u4E00\u822C\u4F1A\u793E\u54E1\u8774\u8776\u85CDP",
      "screen_name" : "AiHina",
      "protected" : false,
      "id_str" : "105541512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/914100840784211968\/ehywL1QB_normal.jpg",
      "id" : 105541512,
      "verified" : false
    }
  },
  "id" : 710782680539869188,
  "created_at" : "2016-03-18 10:59:31 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HiKo",
      "screen_name" : "hikoship",
      "indices" : [ 0, 9 ],
      "id_str" : "623262574",
      "id" : 623262574
    }, {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 10, 17 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/sV2UCHDtpf",
      "expanded_url" : "http:\/\/evanhahn.github.io\/English-text-highlighting\/",
      "display_url" : "evanhahn.github.io\/English-text-h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "709385137369157632",
  "geo" : { },
  "id_str" : "710096046261534720",
  "in_reply_to_user_id" : 623262574,
  "text" : "@hikoship @ruanyf \u81EA\u7136\u8BED\u8A00\u9AD8\u4EAE\u89C1\u6B64\uFF1Ahttps:\/\/t.co\/sV2UCHDtpf",
  "id" : 710096046261534720,
  "in_reply_to_status_id" : 709385137369157632,
  "created_at" : "2016-03-16 13:31:05 +0000",
  "in_reply_to_screen_name" : "hikoship",
  "in_reply_to_user_id_str" : "623262574",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/vzOrptIdT3",
      "expanded_url" : "https:\/\/herbsutter.com\/2016\/03\/11\/trip-report-winter-iso-c-standards-meeting\/",
      "display_url" : "herbsutter.com\/2016\/03\/11\/tri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708959789129162752",
  "text" : "ISO C++17\u5373\u5C06\u53D1\u5E03\uFF1Ahttps:\/\/t.co\/vzOrptIdT3",
  "id" : 708959789129162752,
  "created_at" : "2016-03-13 10:16:00 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/Ow4NfXFHpM",
      "expanded_url" : "https:\/\/github.com\/rlidwka\/sinopia",
      "display_url" : "github.com\/rlidwka\/sinopia"
    } ]
  },
  "geo" : { },
  "id_str" : "708954664708870144",
  "text" : "\u79C1\u6709npm\u4ED3\u5E93\uFF1Ahttps:\/\/t.co\/Ow4NfXFHpM",
  "id" : 708954664708870144,
  "created_at" : "2016-03-13 09:55:38 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/bSC9vJoU46",
      "expanded_url" : "https:\/\/github.com\/Rochester-NRT\/AlphaGo",
      "display_url" : "github.com\/Rochester-NRT\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708294072788619265",
  "text" : "RT @ruanyf: \u7F51\u53CB\u6839\u636EAlphaGo\u7684\u8BBA\u6587\uFF0C\u81EA\u5DF1\u5199\u4E86\u4E00\u4E2A\u5B9E\u73B0\uFF0C\u5DF2\u7ECF\u53EF\u8FD0\u884C https:\/\/t.co\/bSC9vJoU46",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/bSC9vJoU46",
        "expanded_url" : "https:\/\/github.com\/Rochester-NRT\/AlphaGo",
        "display_url" : "github.com\/Rochester-NRT\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708276967309582336",
    "text" : "\u7F51\u53CB\u6839\u636EAlphaGo\u7684\u8BBA\u6587\uFF0C\u81EA\u5DF1\u5199\u4E86\u4E00\u4E2A\u5B9E\u73B0\uFF0C\u5DF2\u7ECF\u53EF\u8FD0\u884C https:\/\/t.co\/bSC9vJoU46",
    "id" : 708276967309582336,
    "created_at" : "2016-03-11 13:02:42 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 708294072788619265,
  "created_at" : "2016-03-11 14:10:41 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]