Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693427246330064896",
  "geo" : { },
  "id_str" : "693437862201589762",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u4E0D\u662F\u4E3A\u4E86\u5FEB\u901F\u8FED\u4EE3\u4E48\uFF1F",
  "id" : 693437862201589762,
  "in_reply_to_status_id" : 693427246330064896,
  "created_at" : "2016-01-30 14:17:24 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693394985484292096",
  "text" : "RT @williamlong: \u4ECA\u5E74\u4E09\u6708\u4EFD\u8C37\u6B4CAlphaGo\u6311\u6218\u674E\u4E16\u77F3\u7684\u56F4\u68CB\u5927\u8D5B\uFF0C\u6211\u8D4C\u674E\u4E16\u77F3\u4F1A\u8D62\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693103251101782016",
    "text" : "\u4ECA\u5E74\u4E09\u6708\u4EFD\u8C37\u6B4CAlphaGo\u6311\u6218\u674E\u4E16\u77F3\u7684\u56F4\u68CB\u5927\u8D5B\uFF0C\u6211\u8D4C\u674E\u4E16\u77F3\u4F1A\u8D62\u3002",
    "id" : 693103251101782016,
    "created_at" : "2016-01-29 16:07:46 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 693394985484292096,
  "created_at" : "2016-01-30 11:27:01 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/692921562572406785\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/i7CMO6AB76",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ3AcuRWcAA_RoN.jpg",
      "id_str" : "692921517374599168",
      "id" : 692921517374599168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ3AcuRWcAA_RoN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1079
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1079
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1079
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/i7CMO6AB76"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692933885731147776",
  "text" : "RT @ruanyf: \u771F\u75AF\u72C2\uFF0C\u65E5\u672C\u5B9E\u884C\u8D1F\u5229\u7387\uFF0C\u5B58\u94B1\u8FDB\u94F6\u884C\uFF0C\u94F6\u884C\u4E0D\u4EC5\u4E0D\u7ED9\u5229\u606F\uFF0C\u8FD8\u8981\u6536\u8D39\u3002\u65E5\u672C\u7684\u94F6\u884C\u4E1A\u5C82\u4E0D\u662F\u5B8C\u86CB\u4E86\u2026\u2026 https:\/\/t.co\/i7CMO6AB76",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/692921562572406785\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/i7CMO6AB76",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ3AcuRWcAA_RoN.jpg",
        "id_str" : "692921517374599168",
        "id" : 692921517374599168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ3AcuRWcAA_RoN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 1079
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 1079
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 1079
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/i7CMO6AB76"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692921562572406785",
    "text" : "\u771F\u75AF\u72C2\uFF0C\u65E5\u672C\u5B9E\u884C\u8D1F\u5229\u7387\uFF0C\u5B58\u94B1\u8FDB\u94F6\u884C\uFF0C\u94F6\u884C\u4E0D\u4EC5\u4E0D\u7ED9\u5229\u606F\uFF0C\u8FD8\u8981\u6536\u8D39\u3002\u65E5\u672C\u7684\u94F6\u884C\u4E1A\u5C82\u4E0D\u662F\u5B8C\u86CB\u4E86\u2026\u2026 https:\/\/t.co\/i7CMO6AB76",
    "id" : 692921562572406785,
    "created_at" : "2016-01-29 04:05:49 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 692933885731147776,
  "created_at" : "2016-01-29 04:54:47 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692003206109396994",
  "geo" : { },
  "id_str" : "692681400030375936",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u5E0C\u671B\u5982\u6B64\uFF0C\u800C\u975E\u53C8\u4E00\u6B21\u8F6F\u4EF6\u5371\u673A\u3002",
  "id" : 692681400030375936,
  "in_reply_to_status_id" : 692003206109396994,
  "created_at" : "2016-01-28 12:11:29 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692680616366637057",
  "text" : "RT @williamlong: \u56F4\u68CB\u56E0\u4E3A\u5176\u975E\u5E38\u590D\u6742\uFF0C\u4E4B\u524D\u6700\u5F3A\u7684\u56F4\u68CB\u8F6F\u4EF6\u57FA\u672C\u4E0A\u8FDE\u4E1A\u4F59\u68CB\u624B\u90FD\u65E0\u6CD5\u6218\u80DC\uFF0C\u800C\u8C37\u6B4C\u6539\u53D8\u4E86\u601D\u8DEF\uFF0C\u901A\u8FC7\u673A\u5668\u5B66\u4E60\u7684\u65B9\u5F0F\u63D0\u9AD8AI\uFF0C\u5E76\u4E14\u76F4\u63A5\u6218\u80DC\u4E86\u56F4\u68CB\u804C\u4E1A\u68CB\u624B\uFF0C\u5982\u679C\u4ECA\u5E743\u6708\u4EFD\u7684\u6BD4\u8D5B\u674E\u4E16\u77F3\u6218\u8D25\u7684\u8BDD\uFF0C\u4EBA\u7C7B\u6700\u540E\u4E00\u4E2A\u80FD\u6218\u80DC\u4EBA\u5DE5\u667A\u80FD\u7684\u68CB\u7C7B\u6E38\u620F\u5C31\u5C06\u7EC8\u7ED3\u4E86\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692551031255875584",
    "text" : "\u56F4\u68CB\u56E0\u4E3A\u5176\u975E\u5E38\u590D\u6742\uFF0C\u4E4B\u524D\u6700\u5F3A\u7684\u56F4\u68CB\u8F6F\u4EF6\u57FA\u672C\u4E0A\u8FDE\u4E1A\u4F59\u68CB\u624B\u90FD\u65E0\u6CD5\u6218\u80DC\uFF0C\u800C\u8C37\u6B4C\u6539\u53D8\u4E86\u601D\u8DEF\uFF0C\u901A\u8FC7\u673A\u5668\u5B66\u4E60\u7684\u65B9\u5F0F\u63D0\u9AD8AI\uFF0C\u5E76\u4E14\u76F4\u63A5\u6218\u80DC\u4E86\u56F4\u68CB\u804C\u4E1A\u68CB\u624B\uFF0C\u5982\u679C\u4ECA\u5E743\u6708\u4EFD\u7684\u6BD4\u8D5B\u674E\u4E16\u77F3\u6218\u8D25\u7684\u8BDD\uFF0C\u4EBA\u7C7B\u6700\u540E\u4E00\u4E2A\u80FD\u6218\u80DC\u4EBA\u5DE5\u667A\u80FD\u7684\u68CB\u7C7B\u6E38\u620F\u5C31\u5C06\u7EC8\u7ED3\u4E86\u3002",
    "id" : 692551031255875584,
    "created_at" : "2016-01-28 03:33:27 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 692680616366637057,
  "created_at" : "2016-01-28 12:08:22 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692311212747390976",
  "geo" : { },
  "id_str" : "692336803752312834",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u962E\u5144\u8001\u4E86\uFF1F",
  "id" : 692336803752312834,
  "in_reply_to_status_id" : 692311212747390976,
  "created_at" : "2016-01-27 13:22:11 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 0, 12 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689681929621409792",
  "geo" : { },
  "id_str" : "690807450677542912",
  "in_reply_to_user_id" : 2786701,
  "text" : "@williamlong \u5C31\u7B49Twitter\u4E86\u3002",
  "id" : 690807450677542912,
  "in_reply_to_status_id" : 689681929621409792,
  "created_at" : "2016-01-23 08:05:05 +0000",
  "in_reply_to_screen_name" : "williamlong",
  "in_reply_to_user_id_str" : "2786701",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 0, 12 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690505396390354944",
  "geo" : { },
  "id_str" : "690513049266982913",
  "in_reply_to_user_id" : 2786701,
  "text" : "@williamlong Facebook\u4F5C\u6076\u3002",
  "id" : 690513049266982913,
  "in_reply_to_status_id" : 690505396390354944,
  "created_at" : "2016-01-22 12:35:14 +0000",
  "in_reply_to_screen_name" : "williamlong",
  "in_reply_to_user_id_str" : "2786701",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689802114986414080",
  "text" : "\u521A\u521A\u6CE8\u518C\u4E03\u725B\uFF0C\u6211\u7684live\u90AE\u7BB1\u4E00\u76F4\u6536\u4E0D\u5230\u9A8C\u8BC1\u90AE\u4EF6\uFF0C\u6362\u6210163\u90AE\u7BB1\u5C31\u6210\u529F\u4E86\uFF0C\u4F3C\u4E4E\u6709\u6DF1\u6DF1\u7684\u6076\u610F\u3002",
  "id" : 689802114986414080,
  "created_at" : "2016-01-20 13:30:14 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689598172834869249",
  "geo" : { },
  "id_str" : "689787562894823424",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u662F\u4E0D\u662F\u8BE5\u5E26\u4E0AServo\uFF1F",
  "id" : 689787562894823424,
  "in_reply_to_status_id" : 689598172834869249,
  "created_at" : "2016-01-20 12:32:25 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 0, 12 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689775545274490880",
  "geo" : { },
  "id_str" : "689787235302912000",
  "in_reply_to_user_id" : 2786701,
  "text" : "@williamlong \n\u8C37\u6B4C\u4F5C\u6076\u3002",
  "id" : 689787235302912000,
  "in_reply_to_status_id" : 689775545274490880,
  "created_at" : "2016-01-20 12:31:07 +0000",
  "in_reply_to_screen_name" : "williamlong",
  "in_reply_to_user_id_str" : "2786701",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/oWo3zlurbp",
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/688231033905364993",
      "display_url" : "twitter.com\/ruanyf\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689046139115421697",
  "text" : "Wow! https:\/\/t.co\/oWo3zlurbp",
  "id" : 689046139115421697,
  "created_at" : "2016-01-18 11:26:16 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/688566493508845568\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Whan2EKF7V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY5Hk4cUEAATAe-.jpg",
      "id_str" : "688566491986268160",
      "id" : 688566491986268160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY5Hk4cUEAATAe-.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/Whan2EKF7V"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/uz4DeHcIb8",
      "expanded_url" : "http:\/\/www.ruanyifeng.com\/blog\/2016\/01\/ian-murdock.html",
      "display_url" : "ruanyifeng.com\/blog\/2016\/01\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689045459243937792",
  "text" : "RT @ruanyf: \u65B0\u7684\u535A\u5BA2\u6587\u7AE0\u300A\u66F4\u591A\u7684\u4EBA\u6B7B\u4E8E\u5FC3\u788E\u300B\uFF1A2015\u5E7412\u670828\u65E5\u4E2D\u5348\uFF0CIan Murdock\u5728\u63A8\u7279\u4E0A\u53D1\u5E03\u4E86\u4E00\u6761\u7B80\u77ED\u7684\u6D88\u606F\u3002https:\/\/t.co\/uz4DeHcIb8 https:\/\/t.co\/Whan2EKF7V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/688566493508845568\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/Whan2EKF7V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY5Hk4cUEAATAe-.jpg",
        "id_str" : "688566491986268160",
        "id" : 688566491986268160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY5Hk4cUEAATAe-.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/Whan2EKF7V"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/uz4DeHcIb8",
        "expanded_url" : "http:\/\/www.ruanyifeng.com\/blog\/2016\/01\/ian-murdock.html",
        "display_url" : "ruanyifeng.com\/blog\/2016\/01\/i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688566493508845568",
    "text" : "\u65B0\u7684\u535A\u5BA2\u6587\u7AE0\u300A\u66F4\u591A\u7684\u4EBA\u6B7B\u4E8E\u5FC3\u788E\u300B\uFF1A2015\u5E7412\u670828\u65E5\u4E2D\u5348\uFF0CIan Murdock\u5728\u63A8\u7279\u4E0A\u53D1\u5E03\u4E86\u4E00\u6761\u7B80\u77ED\u7684\u6D88\u606F\u3002https:\/\/t.co\/uz4DeHcIb8 https:\/\/t.co\/Whan2EKF7V",
    "id" : 688566493508845568,
    "created_at" : "2016-01-17 03:40:19 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 689045459243937792,
  "created_at" : "2016-01-18 11:23:33 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/HuLIWoE9Cg",
      "expanded_url" : "http:\/\/t.cn\/R4psnUA",
      "display_url" : "t.cn\/R4psnUA"
    }, {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/JKrZs2UMIw",
      "expanded_url" : "http:\/\/t.cn\/R49kOCE",
      "display_url" : "t.cn\/R49kOCE"
    } ]
  },
  "geo" : { },
  "id_str" : "687222450623397888",
  "text" : "RT @williamlong: \u5FEB\u64AD\u5EAD\u5BA1\u73B0\u573A\u89C6\u9891 (\u4E0A) (\u4E0B) https:\/\/t.co\/HuLIWoE9Cg https:\/\/t.co\/JKrZs2UMIw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/HuLIWoE9Cg",
        "expanded_url" : "http:\/\/t.cn\/R4psnUA",
        "display_url" : "t.cn\/R4psnUA"
      }, {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/JKrZs2UMIw",
        "expanded_url" : "http:\/\/t.cn\/R49kOCE",
        "display_url" : "t.cn\/R49kOCE"
      } ]
    },
    "geo" : { },
    "id_str" : "687099946240241664",
    "text" : "\u5FEB\u64AD\u5EAD\u5BA1\u73B0\u573A\u89C6\u9891 (\u4E0A) (\u4E0B) https:\/\/t.co\/HuLIWoE9Cg https:\/\/t.co\/JKrZs2UMIw",
    "id" : 687099946240241664,
    "created_at" : "2016-01-13 02:32:47 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 687222450623397888,
  "created_at" : "2016-01-13 10:39:34 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/MzyWWP17jy",
      "expanded_url" : "http:\/\/t.cn\/R49cUJ6",
      "display_url" : "t.cn\/R49cUJ6"
    } ]
  },
  "geo" : { },
  "id_str" : "686513043874779136",
  "text" : "RT @williamlong: \u201C\u5FEB\u64AD\u201D\u6D89\u5ACC\u4F20\u64AD\u6DEB\u79FD\u7269\u54C1\u725F\u5229\u6848\u5EAD\u5BA1\u89C6\u9891 https:\/\/t.co\/MzyWWP17jy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/MzyWWP17jy",
        "expanded_url" : "http:\/\/t.cn\/R49cUJ6",
        "display_url" : "t.cn\/R49cUJ6"
      } ]
    },
    "geo" : { },
    "id_str" : "686490923971252224",
    "text" : "\u201C\u5FEB\u64AD\u201D\u6D89\u5ACC\u4F20\u64AD\u6DEB\u79FD\u7269\u54C1\u725F\u5229\u6848\u5EAD\u5BA1\u89C6\u9891 https:\/\/t.co\/MzyWWP17jy",
    "id" : 686490923971252224,
    "created_at" : "2016-01-11 10:12:45 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 686513043874779136,
  "created_at" : "2016-01-11 11:40:39 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/BhFOwIe1Sq",
      "expanded_url" : "http:\/\/disposable.dhc-app.com",
      "display_url" : "disposable.dhc-app.com"
    } ]
  },
  "geo" : { },
  "id_str" : "686165167290187776",
  "text" : "\u5373\u6536\u5373\u6BC1\u533F\u540D\u90AE\u7BB1\uFF1Ahttps:\/\/t.co\/BhFOwIe1Sq",
  "id" : 686165167290187776,
  "created_at" : "2016-01-10 12:38:18 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685330966299082752",
  "text" : "RT @williamlong: \u3010\u9999\u6E2F\u4E66\u5546\u81EA\u5371\u201C\u7981\u4E66\u201D\u7EB7\u4E0B\u67B6\u3011\u9999\u6E2F\u94DC\u9523\u6E7E\u4E66\u5E97\u8D1F\u8D23\u4EBA\u4E0E\u5DE5\u4F5C\u4EBA\u5458\u9646\u7EED\u5931\u8E2A\u540E\uFF0C\u5F53\u5730\u90E8\u5206\u51FA\u552E\u201C\u7981\u4E66\u201D\u7684\u4E66\u5E97\u5DF2\u5C06\u201C\u7981\u4E66\u201D\u4E0B\u67B6\u3002\u5728\u9999\u6E2F\u6709\u516B\u5BB6\u5206\u5E97\u7684\u53F6\u58F9\u5802\u81EA\u53BB\u5E7411\u6708\u672B\u5F00\u59CB\u5C06\u201C\u7981\u4E66\u201D\u4E0B\u67B6\uFF0C\u4E66\u5E97\u7ECF\u8425\u8005\u4EBA\u4EBA\u81EA\u5371\uFF0C\u5F00\u59CB\u5C06\u201C\u7981\u4E66\u201D\u4E0B\u67B6\uFF0C\u5F71\u54CD\u201C\u7981\u4E66\u201D\u7684\u9500\u552E\u7BA1\u9053\uFF0C\u9999\u6E2F\u201C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685289378927656960",
    "text" : "\u3010\u9999\u6E2F\u4E66\u5546\u81EA\u5371\u201C\u7981\u4E66\u201D\u7EB7\u4E0B\u67B6\u3011\u9999\u6E2F\u94DC\u9523\u6E7E\u4E66\u5E97\u8D1F\u8D23\u4EBA\u4E0E\u5DE5\u4F5C\u4EBA\u5458\u9646\u7EED\u5931\u8E2A\u540E\uFF0C\u5F53\u5730\u90E8\u5206\u51FA\u552E\u201C\u7981\u4E66\u201D\u7684\u4E66\u5E97\u5DF2\u5C06\u201C\u7981\u4E66\u201D\u4E0B\u67B6\u3002\u5728\u9999\u6E2F\u6709\u516B\u5BB6\u5206\u5E97\u7684\u53F6\u58F9\u5802\u81EA\u53BB\u5E7411\u6708\u672B\u5F00\u59CB\u5C06\u201C\u7981\u4E66\u201D\u4E0B\u67B6\uFF0C\u4E66\u5E97\u7ECF\u8425\u8005\u4EBA\u4EBA\u81EA\u5371\uFF0C\u5F00\u59CB\u5C06\u201C\u7981\u4E66\u201D\u4E0B\u67B6\uFF0C\u5F71\u54CD\u201C\u7981\u4E66\u201D\u7684\u9500\u552E\u7BA1\u9053\uFF0C\u9999\u6E2F\u201C\u7981\u4E66\u201D\u5E02\u573A\u9884\u8BA1\u5C06\u8FDB\u4E00\u6B65\u840E\u7F29\u3002",
    "id" : 685289378927656960,
    "created_at" : "2016-01-08 02:38:14 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 685330966299082752,
  "created_at" : "2016-01-08 05:23:29 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 3, 10 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/683370181570134016\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/zGNtrS2mPn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXvRjzdUQAA6gsI.jpg",
      "id_str" : "683370181515558912",
      "id" : 683370181515558912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXvRjzdUQAA6gsI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zGNtrS2mPn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/NcRgfUsFud",
      "expanded_url" : "https:\/\/github.com\/VerbalExpressions\/JSVerbalExpressions\/",
      "display_url" : "github.com\/VerbalExpressi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684688086660284420",
  "text" : "RT @ruanyf: VerbalExpression\uFF1A\u4E00\u4E2A\u4F7F\u7528\u81EA\u7136\u8BED\u8A00\u751F\u6210\u6B63\u5219\u8868\u8FBE\u5F0F\u7684\u5E93\u3002https:\/\/t.co\/NcRgfUsFud https:\/\/t.co\/zGNtrS2mPn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruanyf\/status\/683370181570134016\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/zGNtrS2mPn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXvRjzdUQAA6gsI.jpg",
        "id_str" : "683370181515558912",
        "id" : 683370181515558912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXvRjzdUQAA6gsI.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zGNtrS2mPn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/NcRgfUsFud",
        "expanded_url" : "https:\/\/github.com\/VerbalExpressions\/JSVerbalExpressions\/",
        "display_url" : "github.com\/VerbalExpressi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683370181570134016",
    "text" : "VerbalExpression\uFF1A\u4E00\u4E2A\u4F7F\u7528\u81EA\u7136\u8BED\u8A00\u751F\u6210\u6B63\u5219\u8868\u8FBE\u5F0F\u7684\u5E93\u3002https:\/\/t.co\/NcRgfUsFud https:\/\/t.co\/zGNtrS2mPn",
    "id" : 683370181570134016,
    "created_at" : "2016-01-02 19:32:02 +0000",
    "user" : {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "protected" : false,
      "id_str" : "1580781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363795309\/wbi37mdkxhr2trsr4ofa_normal.jpeg",
      "id" : 1580781,
      "verified" : false
    }
  },
  "id" : 684688086660284420,
  "created_at" : "2016-01-06 10:48:55 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682898828182163458",
  "text" : "RT @williamlong: \u5FAE\u8F6F\u516C\u53F8\u79F0\u4E2D\u56FD\u653B\u51FB\u4E86\u4E0A\u5343\u4E2A\u6D77\u5916Hotmail\u7535\u5B50\u90AE\u4EF6\u8D26\u6237\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682518754715107330",
    "text" : "\u5FAE\u8F6F\u516C\u53F8\u79F0\u4E2D\u56FD\u653B\u51FB\u4E86\u4E0A\u5343\u4E2A\u6D77\u5916Hotmail\u7535\u5B50\u90AE\u4EF6\u8D26\u6237\u3002",
    "id" : 682518754715107330,
    "created_at" : "2015-12-31 11:08:46 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 682898828182163458,
  "created_at" : "2016-01-01 12:19:02 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]