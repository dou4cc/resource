Grailbird.data.tweets_2017_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822333943009529856",
  "geo" : { },
  "id_str" : "822394818177298432",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u4E0D\u662Fbug",
  "id" : 822394818177298432,
  "in_reply_to_status_id" : 822333943009529856,
  "created_at" : "2017-01-20 10:46:18 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 0, 7 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "822385497523646464",
  "geo" : { },
  "id_str" : "822392346578915328",
  "in_reply_to_user_id" : 1580781,
  "text" : "@ruanyf \u662F\u8FD0\u884C\u65F6\u4F20\u503C\uFF1A((a = 1) =&gt; (b = a) =&gt; (a = 2, b))()() \/\/1",
  "id" : 822392346578915328,
  "in_reply_to_status_id" : 822385497523646464,
  "created_at" : "2017-01-20 10:36:29 +0000",
  "in_reply_to_screen_name" : "ruanyf",
  "in_reply_to_user_id_str" : "1580781",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/6UwxciacNG",
      "expanded_url" : "https:\/\/twitter.com\/williamlong\/status\/822257876831965184",
      "display_url" : "twitter.com\/williamlong\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "822384955107876866",
  "text" : "\u65E0\u89C6fb https:\/\/t.co\/6UwxciacNG",
  "id" : 822384955107876866,
  "created_at" : "2017-01-20 10:07:07 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819848481246511104",
  "text" : "RT @wikileaks: Please stop asking us for \"proof of life\". We do not control Assange's physical environment or internet connection. @MashiRa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rafael Correa",
        "screen_name" : "MashiRafael",
        "indices" : [ 116, 128 ],
        "id_str" : "209780362",
        "id" : 209780362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "801902914885324804",
    "text" : "Please stop asking us for \"proof of life\". We do not control Assange's physical environment or internet connection. @MashiRafael does.",
    "id" : 801902914885324804,
    "created_at" : "2016-11-24 21:38:48 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 819848481246511104,
  "created_at" : "2017-01-13 10:08:04 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ldehai",
      "screen_name" : "ldehai",
      "indices" : [ 0, 7 ],
      "id_str" : "19331968",
      "id" : 19331968
    }, {
      "name" : "ruanyf",
      "screen_name" : "ruanyf",
      "indices" : [ 8, 15 ],
      "id_str" : "1580781",
      "id" : 1580781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815219480565452801",
  "geo" : { },
  "id_str" : "815487113852583936",
  "in_reply_to_user_id" : 19331968,
  "text" : "@ldehai @ruanyf twitter\u7F51\u9875\u7248\u591F\u7528",
  "id" : 815487113852583936,
  "in_reply_to_status_id" : 815219480565452801,
  "created_at" : "2017-01-01 09:17:33 +0000",
  "in_reply_to_screen_name" : "ldehai",
  "in_reply_to_user_id_str" : "19331968",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "indices" : [ 3, 15 ],
      "id_str" : "2786701",
      "id" : 2786701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815486522766094337",
  "text" : "RT @williamlong: \u57282016\u5E74\u5373\u5C06\u7ED3\u675F\u65F6\uFF0C\u53C8\u6709\u4E00\u4EF6\u602A\u4E8B\u9707\u60CA\u56F4\u68CB\u754C\u2014\u2014\u4E00\u4E2A\u7F51\u540D\u4E3AMaster\u7684\u201C\u7F51\u7EDC\u68CB\u624B\u201D\u5728\u8457\u540D\u56F4\u68CB\u5BF9\u5F08\u7F51\u7AD9\u5F08\u57CE\u7F51\u4E0A\u5BF9\u5305\u62EC\u4E2D\u97E9\u9876\u5C16\u804C\u4E1A\u9AD8\u624B\u5728\u5185\u7684\u68CB\u624B(\u67EF\u6D01\u3001\u6734\u5EF7\u6853\u7B49)\u521B\u4E0B26\u80DC0\u8D1F\u7684\u6218\u7EE9\u3002\u4E2D\u56FD\u56F4\u68CB\u961F\u603B\u6559\u7EC3\u4FDE\u658C\u79F0\uFF0C\u4E0D\u6392\u9664\u8FD9\u662F\u5728\u4EBA\u673A\u5927\u6218\u4E2D\u4E00\u4E3E\u6210\u540D\u7684\u201CA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "815466902101364736",
    "text" : "\u57282016\u5E74\u5373\u5C06\u7ED3\u675F\u65F6\uFF0C\u53C8\u6709\u4E00\u4EF6\u602A\u4E8B\u9707\u60CA\u56F4\u68CB\u754C\u2014\u2014\u4E00\u4E2A\u7F51\u540D\u4E3AMaster\u7684\u201C\u7F51\u7EDC\u68CB\u624B\u201D\u5728\u8457\u540D\u56F4\u68CB\u5BF9\u5F08\u7F51\u7AD9\u5F08\u57CE\u7F51\u4E0A\u5BF9\u5305\u62EC\u4E2D\u97E9\u9876\u5C16\u804C\u4E1A\u9AD8\u624B\u5728\u5185\u7684\u68CB\u624B(\u67EF\u6D01\u3001\u6734\u5EF7\u6853\u7B49)\u521B\u4E0B26\u80DC0\u8D1F\u7684\u6218\u7EE9\u3002\u4E2D\u56FD\u56F4\u68CB\u961F\u603B\u6559\u7EC3\u4FDE\u658C\u79F0\uFF0C\u4E0D\u6392\u9664\u8FD9\u662F\u5728\u4EBA\u673A\u5927\u6218\u4E2D\u4E00\u4E3E\u6210\u540D\u7684\u201CAlphaGo\u201D\u3002",
    "id" : 815466902101364736,
    "created_at" : "2017-01-01 07:57:14 +0000",
    "user" : {
      "name" : "\u6708\u5149\u535A\u5BA2",
      "screen_name" : "williamlong",
      "protected" : false,
      "id_str" : "2786701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933841000484864\/c3HBUtHo_normal.jpg",
      "id" : 2786701,
      "verified" : false
    }
  },
  "id" : 815486522766094337,
  "created_at" : "2017-01-01 09:15:12 +0000",
  "user" : {
    "name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
    "screen_name" : "dou4cc",
    "protected" : false,
    "id_str" : "3359880735",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892654388711309313\/qBQo9YR5_normal.jpg",
    "id" : 3359880735,
    "verified" : false
  }
} ]