var user_details =  {
  "screen_name" : "dou4cc",
  "full_name" : "dou4cc\u2192\u4F4E\u7AEF\u4EBA\u53E3",
  "bio" : "\u5DF2\u5F03\u7528Twitter\u3002",
  "id" : "3359880735",
  "created_at" : "2015-07-05 04:40:34 +0000"
}